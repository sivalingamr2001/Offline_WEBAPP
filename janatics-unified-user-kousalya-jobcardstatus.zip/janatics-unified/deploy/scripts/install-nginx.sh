#!/usr/bin/env bash
# Install Nginx site for JUSPlatform (requires root).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
DOMAIN="${JUSPLATFORM_DOMAIN:-api.example.com}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo JUSPLATFORM_DOMAIN=your.domain $0" >&2
  exit 1
fi

if ! command -v nginx &>/dev/null; then
  echo "nginx not found. Install: apt install nginx" >&2
  exit 1
fi

mkdir -p /etc/nginx/snippets
install -m 644 "${ROOT}/deploy/nginx/jusplatform-proxy.conf" /etc/nginx/snippets/jusplatform-proxy.conf

sed "s/api.example.com/${DOMAIN}/g" "${ROOT}/deploy/nginx/jusplatform.conf" \
  > /etc/nginx/sites-available/jusplatform.conf

ln -sf /etc/nginx/sites-available/jusplatform.conf /etc/nginx/sites-enabled/jusplatform.conf

nginx -t
systemctl reload nginx

echo "Nginx site enabled for ${DOMAIN} → 127.0.0.1:8080"
echo "TLS: certbot --nginx -d ${DOMAIN}"
