#!/usr/bin/env bash
# Login (if needed) and enqueue a job via POST /api/v1/jobs.
# Configure in /etc/jusplatform/jusplatform.env — used by jusplatform-scheduled-jobs.timer.
set -euo pipefail

BASE_URL="${JUSPLATFORM_BASE_URL:-http://127.0.0.1:8080}"
EMAIL="${JUSPLATFORM_JOB_SERVICE_EMAIL:?Set JUSPLATFORM_JOB_SERVICE_EMAIL in jusplatform.env}"
PASSWORD="${JUSPLATFORM_JOB_SERVICE_PASSWORD:?Set JUSPLATFORM_JOB_SERVICE_PASSWORD in jusplatform.env}"
JOB_BODY="${JUSPLATFORM_SCHEDULED_JOB_BODY:-{\"jobType\":\"invoice-sync-demo\",\"payload\":{\"customerCode\":\"CUST-001\",\"invoiceNumber\":\"SCHED-001\",\"notifyEmail\":\"ops@example.com\"}}}"

login_response="$(curl -sf -X POST "${BASE_URL%/}/api/v1/auth/login" \
  -H 'Content-Type: application/json' \
  -d "{\"email\":\"${EMAIL}\",\"password\":\"${PASSWORD}\"}")"

token="$(echo "${login_response}" | python3 -c "import sys,json; print(json.load(sys.stdin)['accessToken'])")"

response="$(curl -sf -w '\n%{http_code}' -X POST "${BASE_URL%/}/api/v1/jobs" \
  -H "Authorization: Bearer ${token}" \
  -H 'Content-Type: application/json' \
  -d "${JOB_BODY}")"

http_code="$(echo "${response}" | tail -n1)"
body="$(echo "${response}" | sed '$d')"

if [[ "${http_code}" == "202" ]]; then
  echo "Job enqueued: ${body}"
  exit 0
fi

echo "Enqueue failed (HTTP ${http_code}): ${body}" >&2
exit 1
