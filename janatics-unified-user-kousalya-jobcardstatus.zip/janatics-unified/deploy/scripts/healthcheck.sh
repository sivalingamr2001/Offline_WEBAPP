#!/usr/bin/env bash
# Probe JUSPlatform readiness (used by systemd timer).
set -euo pipefail

BASE_URL="${JUSPLATFORM_BASE_URL:-http://127.0.0.1:8080}"
HEALTH_URL="${BASE_URL%/}/api/heath"

code="$(curl -sf -o /dev/null -w '%{http_code}' "${HEALTH_URL}" || echo "000")"

if [[ "${code}" == "200" ]]; then
  echo "OK ${HEALTH_URL} (${code})"
  exit 0
fi

echo "UNHEALTHY ${HEALTH_URL} (HTTP ${code})" >&2
exit 1
