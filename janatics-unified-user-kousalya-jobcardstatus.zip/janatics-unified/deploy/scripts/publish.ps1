# Publish JUSPlatform Release build to .\artifacts\publish (Windows default)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$Out = Join-Path $Root 'artifacts\publish'

Write-Host "Publishing to $Out ..."
New-Item -ItemType Directory -Force -Path $Out | Out-Null
dotnet publish (Join-Path $Root 'JUSPlatform\JUSPlatform.csproj') `
    -c Release `
    -o $Out `
    /p:UseAppHost=false

Write-Host "Done. Copy $Out to the IIS site folder (see deploy\iis\README.md)."
Write-Host "Linux servers: use deploy\scripts\publish.sh and systemd instead."
