#!/usr/bin/env bash
# Install JUSPlatform systemd units (requires root).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
APP_USER="${JUSPLATFORM_USER:-jusplatform}"
APP_DIR="${JUSPLATFORM_DIR:-/opt/jusplatform}"
DATA_DIR="${JUSPLATFORM_DATA_DIR:-/var/lib/jusplatform}"
ENV_DIR="/etc/jusplatform"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo $0" >&2
  exit 1
fi

if ! id "${APP_USER}" &>/dev/null; then
  useradd --system --home "${APP_DIR}" --shell /usr/sbin/nologin "${APP_USER}"
  echo "Created system user ${APP_USER}"
fi

mkdir -p "${APP_DIR}" "${DATA_DIR}/logs" "${ENV_DIR}"
chown -R "${APP_USER}:${APP_USER}" "${DATA_DIR}"

if [[ ! -f "${ENV_DIR}/jusplatform.env" ]]; then
  cp "${ROOT}/deploy/systemd/jusplatform.env.example" "${ENV_DIR}/jusplatform.env"
  chmod 600 "${ENV_DIR}/jusplatform.env"
  echo "Created ${ENV_DIR}/jusplatform.env — edit secrets before starting."
fi

install -m 644 "${ROOT}/deploy/systemd/jusplatform.service" /etc/systemd/system/
install -m 644 "${ROOT}/deploy/systemd/jusplatform-scheduled-jobs.service" /etc/systemd/system/
install -m 644 "${ROOT}/deploy/systemd/jusplatform-scheduled-jobs.timer" /etc/systemd/system/

systemctl daemon-reload
systemctl enable jusplatform.service

echo ""
echo "Systemd units installed."
echo "  jusplatform.service — restarts on failure; starts after network + PostgreSQL (+ Redis if present)"
echo ""
echo "  1) Publish app:  ./deploy/scripts/publish.sh"
echo "  2) Copy publish output to ${APP_DIR} and chown ${APP_USER}:${APP_USER}"
echo "  3) Edit ${ENV_DIR}/jusplatform.env"
echo "  4) systemctl start jusplatform"
echo ""
echo "Optional:"
echo "  systemctl enable --now jusplatform-scheduled-jobs.timer   # cron-style job enqueue"
echo "  deploy/systemd/optional/jusplatform-healthcheck.timer     # external probe (not required)"
