#!/usr/bin/env bash
# Publish JUSPlatform Release build to ./artifacts/publish
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT="${ROOT}/artifacts/publish"

echo "Publishing to ${OUT}..."
mkdir -p "${OUT}"
dotnet publish "${ROOT}/JUSPlatform/JUSPlatform.csproj" \
  -c Release \
  -o "${OUT}" \
  /p:UseAppHost=false

mkdir -p "${OUT}/scripts"
cp "${ROOT}/deploy/scripts/healthcheck.sh" "${ROOT}/deploy/scripts/enqueue-scheduled-job.sh" "${OUT}/scripts/"
chmod +x "${OUT}/scripts/"*.sh

echo "Done. Upload ${OUT} to /opt/jusplatform on the server."
