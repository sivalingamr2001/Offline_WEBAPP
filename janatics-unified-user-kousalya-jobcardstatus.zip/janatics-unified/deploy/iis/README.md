# JUSPlatform on IIS (Windows, default production host)

Publisher: **Janatics India**. Runtime: **.NET 10** (licensed).

IIS terminates TLS and hosts the API + SPA through **ASP.NET Core Module V2** (in-process). Hangfire and background jobs run inside the same worker process — same model as Linux `jusplatform.service`.

```text
Internet → IIS (:443) → ANCM in-process → Kestrel in w3wp
                              ├── API + SPA (wwwroot)
                              └── Hangfire dashboard (when enabled)
```

## Prerequisites

- Windows Server with **IIS**
- **ASP.NET Core 10 Hosting Bundle** (includes ANCM v2 + .NET 10 runtime)
- PostgreSQL reachable from the server
- Site physical path = published output (`dotnet publish`)

Do not install a .NET 8 hosting bundle for this app.

## Publish (build machine, Windows)

```powershell
dotnet publish .\JUSPlatform\JUSPlatform.csproj -c Release -o .\artifacts\publish /p:UseAppHost=false
```

Or `.\deploy\scripts\publish.ps1`. The published folder includes `web.config` from this directory.

## IIS site

1. Install the Hosting Bundle, then `iisreset`.
2. Create an **Application Pool**:
   - .NET CLR version: **No Managed Code**
   - Pipeline: Integrated
   - Identity: `ApplicationPoolIdentity` or a dedicated service account that can read the site folder and reach PostgreSQL
3. Create a **Site** (or application):
   - Physical path: `C:\inetpub\jusplatform` (copy of `artifacts\publish`)
   - Binding: `https://<INTERNAL_FQDN>:443` with a proper certificate
   - Application pool: the pool from step 2
4. Grant the pool identity **Modify** on `.\logs` (stdout) and upload storage if local files are used.

## Configuration (no secrets in git)

Set these on the **server** (IIS Configuration Editor → `system.webServer/aspNetCore/environmentVariables`, or edit the live `web.config`):

| Name | Notes |
|------|--------|
| `ASPNETCORE_ENVIRONMENT` | `Production` |
| `ConnectionStrings__Default` | PostgreSQL; Hangfire uses the same DB. Use `CHANGE_ME` placeholders only in git. |
| `Jwt__SigningKey` | Long random secret; never commit the real value |
| `Hangfire__Enabled` | `true` in production if jobs are required |
| `Jobs__WorkerEnabled` | `false` when Hangfire is on |
| `AppDebug` | `false` |
| `Cors__Origins__0` | Exact UI origin if the UI is on another host |

`web.config` in this folder only sets environment and in-process hosting. Connection strings stay out of the repo.

After first deploy (empty database):

```powershell
Set-Location C:\inetpub\jusplatform
$env:ConnectionStrings__Default = "<same as IIS>"
dotnet .\JUSPlatform.dll --seed
```

Then start the site. EF `MigrateAsync` also runs on API startup.

## web.config notes

| Setting | Why |
|---------|-----|
| `hostingModel="inprocess"` | Same w3wp process; required for this layout |
| `processPath="dotnet"` | Framework-dependent publish (`UseAppHost=false`) |
| `arguments=".\JUSPlatform.dll"` | Entry assembly |
| `stdoutLogEnabled="false"` | Turn `true` only while diagnosing startup failures |
| `maxAllowedContentLength` | 50 MB — avatar / file uploads |

The app already serves the SPA (`wwwroot`) and returns JSON 404 for unknown `/api/*`. Do not add an IIS URL Rewrite fallback that swallows `/api`.

Anonymous authentication **on**. Windows authentication **off** (JWT is the app auth).

## Health

```powershell
Invoke-RestMethod http://127.0.0.1:8080/api
Invoke-RestMethod https://<INTERNAL_FQDN>/api/health
```

Replace `<INTERNAL_FQDN>` with the real host; do not commit internal names.

## Linux

If the host is Linux, use [../README.md](../README.md) (systemd + Nginx), not this folder.
