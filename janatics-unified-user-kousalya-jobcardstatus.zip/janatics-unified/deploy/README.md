# Production deployment

**Windows (default):** IIS — [iis/README.md](iis/README.md) and `iis/web.config`.

**Linux:** systemd + Nginx (this page). Docker ship stack remains optional via `.\docker\ship-up.ps1` / `./docker/ship-up.sh`.

## Architecture

```text
Internet → Nginx (:80/:443) → Kestrel (:8080, localhost only)
                                    ├── API + SPA (wwwroot)
                                    ├── Hangfire server + dashboard (when enabled)
                                    └── JobRun worker (Hangfire or polling)
```

**One systemd service** runs the API and all in-process background jobs. You do **not** need a separate worker unit — Hangfire and `JobWorkerService` live inside `jusplatform.service`.

| Component | Purpose |
|-----------|---------|
| `jusplatform.service` | Long-running API + job execution; `Restart=on-failure`, binds to PostgreSQL |
| `jusplatform-scheduled-jobs.timer` | Optional cron: enqueue a job daily (via API) |
| Nginx | TLS termination, reverse proxy, optional IP lock on `/hangfire` |

## Prerequisites

- Licensed **.NET 10** ASP.NET runtime (`aspnetcore-runtime-10.0`) or the **ASP.NET Core 10 Hosting Bundle** on IIS.
- PostgreSQL 16+ (same DB for app + Hangfire schema)
- Redis (optional, recommended for query cache)
- Nginx
- Linux user `jusplatform` (created by install script)

## Quick install

On your **build machine**:

```bash
./deploy/scripts/publish.sh
# Upload artifacts/publish/ to the server → /opt/jusplatform
```

On the **server** (as root):

```bash
cd /path/to/hello-net-webapi

# 1) App files
rsync -a artifacts/publish/ /opt/jusplatform/
chown -R jusplatform:jusplatform /opt/jusplatform

# 2) systemd
./deploy/scripts/install-systemd.sh
nano /etc/jusplatform/jusplatform.env   # secrets, connection strings, Hangfire password

# 3) Nginx
JUSPLATFORM_DOMAIN=api.yourcompany.com ./deploy/scripts/install-nginx.sh

# 4) Start
systemctl start jusplatform
# Optional: scheduled job enqueue timer
systemctl enable --now jusplatform-scheduled-jobs.timer
```

Restart and dependencies are handled by `jusplatform.service` (`Restart=on-failure`, `After`/`Requires`/`BindsTo` for network + PostgreSQL). No healthcheck timer is required.

## Environment file

Copy `deploy/systemd/jusplatform.env.example` → `/etc/jusplatform/jusplatform.env` (mode `0600`).

Key production settings:

| Variable | Notes |
|----------|--------|
| `ASPNETCORE_URLS` | Bind localhost only; Nginx faces the public |
| `ConnectionStrings__Default` | PostgreSQL; Hangfire uses the same DB |
| `Jwt__SigningKey` | Long random secret |
| `Hangfire__Enabled` | `true` for production job dispatch + dashboard |
| `Jobs__WorkerEnabled` | `false` when Hangfire is enabled |
| `AppDebug` | `false` |

EF migrations run automatically on API startup (`MigrateAsync`, no-op if current). **Seed is not on boot.** After first deploy (empty database):

```bash
sudo -u jusplatform -E dotnet /opt/jusplatform/JUSPlatform.dll --seed
# or from a build machine with the same connection string:
# dotnet JUSPlatform.dll --seed
systemctl start jusplatform
```

### systemd dependencies

`jusplatform.service` is wired to:

- **`After=`** `network-online.target`, `postgresql.service`, `redis-server.service` / `redis.service`
- **`Requires=`** + **`BindsTo=`** `postgresql.service` — app won't start without DB; stops when PostgreSQL stops
- **`Wants=`** Redis — starts after Redis if installed; app still runs with `Redis__Enabled=false`
- **`Restart=on-failure`** + **`RestartSec=5`** — systemd restarts the app on crash

If your distro uses different unit names, add a drop-in:

```bash
sudo systemctl edit jusplatform
# [Unit]
# After=your-db.service
# Requires=your-db.service
```

Optional external probe (load balancer / monitoring): `deploy/systemd/optional/jusplatform-healthcheck.timer` — **not installed by default**.

## Nginx

- Site config: `deploy/nginx/jusplatform.conf`
- Proxy snippet: `deploy/nginx/jusplatform-proxy.conf` → `/etc/nginx/snippets/`
- Restrict `/hangfire` by IP in the site config (in addition to HTTP Basic Auth in the app)

## systemd timers (optional)

### Scheduled jobs (cron-style)

The timer runs `enqueue-scheduled-job.sh`, which:

1. Logs in with `JUSPLATFORM_JOB_SERVICE_EMAIL` / `JUSPLATFORM_JOB_SERVICE_PASSWORD`
2. `POST /api/v1/jobs` with `JUSPLATFORM_SCHEDULED_JOB_BODY`

Create a dedicated user with `job.write` (e.g. Manager role or custom).

Edit schedule in `jusplatform-scheduled-jobs.timer` (`OnCalendar`).

```bash
# Run once manually
systemctl start jusplatform-scheduled-jobs.service
journalctl -u jusplatform-scheduled-jobs.service -n 20
```

For many schedules, prefer **Hangfire RecurringJob** in code or multiple timer units with different env drop-ins.

## Operations

```bash
systemctl status jusplatform
journalctl -u jusplatform -f
systemctl restart jusplatform

curl -s http://127.0.0.1:8080/api
curl -s http://127.0.0.1/api/heath   # via nginx
```

## Deploy update

```bash
./deploy/scripts/publish.sh
rsync -a artifacts/publish/ server:/opt/jusplatform/
ssh server 'systemctl restart jusplatform'
```

## Deploy scripts (no Makefile)

Windows publish:

```powershell
.\deploy\scripts\publish.ps1
```

Linux:

```bash
./deploy/scripts/publish.sh
sudo ./deploy/scripts/install-systemd.sh
sudo JUSPLATFORM_DOMAIN=api.example.com ./deploy/scripts/install-nginx.sh
```

## Security checklist

- [ ] `Jwt__SigningKey` and `Hangfire__DashboardPassword` set
- [ ] `jusplatform.env` mode `0600`
- [ ] Kestrel bound to `127.0.0.1` only
- [ ] TLS on Nginx
- [ ] `/hangfire` IP-restricted or VPN-only
- [ ] `AppDebug=false`, `Bugsink`/`MockIntegrations` off unless needed
- [ ] PostgreSQL user `jusplatform` with least privilege (not superuser)
