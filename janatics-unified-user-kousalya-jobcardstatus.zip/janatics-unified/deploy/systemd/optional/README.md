# Optional: external HTTP health probe for load balancers / monitoring.
# Not required — jusplatform.service already uses Restart=on-failure and
# Depends on network-online + postgresql.service.
#
# Install manually:
#   sudo cp jusplatform-healthcheck.* /etc/systemd/system/
#   sudo systemctl daemon-reload
#   sudo systemctl enable --now jusplatform-healthcheck.timer
