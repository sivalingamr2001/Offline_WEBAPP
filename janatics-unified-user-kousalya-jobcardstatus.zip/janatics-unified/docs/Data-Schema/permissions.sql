CREATE TABLE IF NOT EXISTS public.permissions
(
    id uuid NOT NULL,
    code character varying(100) COLLATE pg_catalog."default" NOT NULL,
    name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    module character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    CONSTRAINT pk_permissions PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE public.permissions
    OWNER to jan_jutest_usr;

-- Index: public.ix_permissions_code
CREATE UNIQUE INDEX IF NOT EXISTS ix_permissions_code
    ON public.permissions USING btree
    (code COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;