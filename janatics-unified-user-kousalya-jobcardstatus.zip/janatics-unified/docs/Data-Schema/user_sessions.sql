CREATE TABLE IF NOT EXISTS public.user_sessions
(
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    session_token character varying(250) COLLATE pg_catalog."default" NOT NULL,
    ip_address character varying(50) COLLATE pg_catalog."default",
    machine_name character varying(200) COLLATE pg_catalog."default",
    status character varying(10) COLLATE pg_catalog."default" NOT NULL,
    last_activity timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    CONSTRAINT pk_user_sessions PRIMARY KEY (id),
    CONSTRAINT fk_user_sessions_users_user_id FOREIGN KEY (user_id)
        REFERENCES public.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.user_sessions
    OWNER to jan_jutest_usr;

-- Index: public.ix_user_sessions_session_token
CREATE UNIQUE INDEX IF NOT EXISTS ix_user_sessions_session_token
    ON public.user_sessions USING btree
    (session_token COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_user_sessions_user_id
CREATE INDEX IF NOT EXISTS ix_user_sessions_user_id
    ON public.user_sessions USING btree
    (user_id ASC NULLS LAST)
    TABLESPACE pg_default;