CREATE TABLE IF NOT EXISTS public.role_permissions
(
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    CONSTRAINT pk_role_permissions PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_role_permissions_permissions_permission_id FOREIGN KEY (permission_id)
        REFERENCES public.permissions (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_roles_role_id FOREIGN KEY (role_id)
        REFERENCES public.roles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.role_permissions
    OWNER to jan_jutest_usr;

-- Index: public.ix_role_permissions_permission_id
CREATE INDEX IF NOT EXISTS ix_role_permissions_permission_id
    ON public.role_permissions USING btree
    (permission_id ASC NULLS LAST)
    TABLESPACE pg_default;