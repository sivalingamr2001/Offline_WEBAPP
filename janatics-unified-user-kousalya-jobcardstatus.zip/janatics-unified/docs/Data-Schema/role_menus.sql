CREATE TABLE IF NOT EXISTS public.role_menus
(
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    module_id uuid NOT NULL,
    menu_id uuid NOT NULL,
    perm_view boolean NOT NULL,
    perm_add boolean NOT NULL,
    perm_edit boolean NOT NULL,
    perm_delete boolean NOT NULL,
    perm_export boolean NOT NULL,
    perm_approve boolean NOT NULL,
    restricted_columns character varying(1000) COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    CONSTRAINT pk_role_menus PRIMARY KEY (id),
    CONSTRAINT fk_role_menus_app_menus_menu_id FOREIGN KEY (menu_id)
        REFERENCES public.app_menus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT fk_role_menus_app_modules_module_id FOREIGN KEY (module_id)
        REFERENCES public.app_modules (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT fk_role_menus_roles_role_id FOREIGN KEY (role_id)
        REFERENCES public.roles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.role_menus
    OWNER to jan_jutest_usr;

-- Index: public.ix_role_menus_menu_id
CREATE INDEX IF NOT EXISTS ix_role_menus_menu_id
    ON public.role_menus USING btree
    (menu_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_role_menus_module_id
CREATE INDEX IF NOT EXISTS ix_role_menus_module_id
    ON public.role_menus USING btree
    (module_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_role_menus_role_id_menu_id
CREATE UNIQUE INDEX IF NOT EXISTS ix_role_menus_role_id_menu_id
    ON public.role_menus USING btree
    (role_id ASC NULLS LAST, menu_id ASC NULLS LAST)
    TABLESPACE pg_default;