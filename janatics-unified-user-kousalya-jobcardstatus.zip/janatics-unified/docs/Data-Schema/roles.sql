CREATE TABLE IF NOT EXISTS public.roles
(
    id uuid NOT NULL,
    organization_id uuid,
    name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    description character varying(500) COLLATE pg_catalog."default",
    is_system boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    code character varying(40) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    source_type character varying(20) COLLATE pg_catalog."default" NOT NULL DEFAULT 'INTERNAL'::character varying,
    CONSTRAINT pk_roles PRIMARY KEY (id),
    CONSTRAINT fk_roles_organizations_organization_id FOREIGN KEY (organization_id)
        REFERENCES public.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.roles
    OWNER to jan_jutest_usr;

-- Index: public.ix_roles_organization_id_code
CREATE UNIQUE INDEX IF NOT EXISTS ix_roles_organization_id_code
    ON public.roles USING btree
    (organization_id ASC NULLS LAST, code COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_roles_organization_id_name
CREATE UNIQUE INDEX IF NOT EXISTS ix_roles_organization_id_name
    ON public.roles USING btree
    (organization_id ASC NULLS LAST, name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;