CREATE TABLE IF NOT EXISTS public.users
(
    id uuid NOT NULL,
    organization_id uuid,
    email character varying(256) COLLATE pg_catalog."default" NOT NULL,
    display_name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    designation character varying(200) COLLATE pg_catalog."default",
    password_hash character varying(500) COLLATE pg_catalog."default" NOT NULL,
    avatar_path character varying(500) COLLATE pg_catalog."default",
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    role_id uuid,
    user_code character varying(10) COLLATE pg_catalog."default",
    emp_id character varying(10) COLLATE pg_catalog."default",
    CONSTRAINT pk_users PRIMARY KEY (id),
    CONSTRAINT fk_users_organizations_organization_id FOREIGN KEY (organization_id)
        REFERENCES public.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT fk_users_roles_role_id FOREIGN KEY (role_id)
        REFERENCES public.roles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE RESTRICT
)

TABLESPACE pg_default;

ALTER TABLE public.users
    OWNER to jan_jutest_usr;

-- Index: public.ix_users_email
CREATE UNIQUE INDEX IF NOT EXISTS ix_users_email
    ON public.users USING btree
    (email COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_users_organization_id
CREATE INDEX IF NOT EXISTS ix_users_organization_id
    ON public.users USING btree
    (organization_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_users_role_id
CREATE INDEX IF NOT EXISTS ix_users_role_id
    ON public.users USING btree
    (role_id ASC NULLS LAST)
    TABLESPACE pg_default;