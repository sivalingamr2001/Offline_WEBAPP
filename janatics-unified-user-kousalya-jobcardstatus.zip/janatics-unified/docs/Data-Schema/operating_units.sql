CREATE TABLE IF NOT EXISTS public.operating_units
(
    id uuid NOT NULL,
    org_id integer NOT NULL,
    name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamp without time zone NOT NULL DEFAULT now(),
    updated_at timestamp without time zone NOT NULL DEFAULT now(),
    CONSTRAINT operating_units_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE public.operating_units
    OWNER to jan_jutest_usr;
