CREATE TABLE IF NOT EXISTS public.app_menus
(
    id uuid NOT NULL,
    code character varying(40) COLLATE pg_catalog."default" NOT NULL,
    name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    display_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    module_id uuid NOT NULL,
    parent_menu_id uuid,
    menu_type character varying(20) COLLATE pg_catalog."default" NOT NULL,
    nature character varying(20) COLLATE pg_catalog."default" NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    menu_path character varying(100) COLLATE pg_catalog."default",
    menu_icon character varying(100) COLLATE pg_catalog."default",
    resource_code character varying(40) COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    parent_id uuid,
    path character varying(200) COLLATE pg_catalog."default",
    icon character varying(100) COLLATE pg_catalog."default",
    permission_code character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT pk_app_menus PRIMARY KEY (id),
    CONSTRAINT fk_app_menus_app_menus_parent_id FOREIGN KEY (parent_id)
        REFERENCES public.app_menus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE RESTRICT,
    CONSTRAINT fk_app_menus_app_menus_parent_menu_id FOREIGN KEY (parent_menu_id)
        REFERENCES public.app_menus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE RESTRICT,
    CONSTRAINT fk_app_menus_app_modules_module_id FOREIGN KEY (module_id)
        REFERENCES public.app_modules (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.app_menus
    OWNER to jan_jutest_usr;

-- Index: public.ix_app_menus_code
CREATE UNIQUE INDEX IF NOT EXISTS ix_app_menus_code
    ON public.app_menus USING btree
    (code COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_app_menus_module_id
CREATE INDEX IF NOT EXISTS ix_app_menus_module_id
    ON public.app_menus USING btree
    (module_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_app_menus_parent_id
CREATE INDEX IF NOT EXISTS ix_app_menus_parent_id
    ON public.app_menus USING btree
    (parent_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_app_menus_parent_menu_id
CREATE INDEX IF NOT EXISTS ix_app_menus_parent_menu_id
    ON public.app_menus USING btree
    (parent_menu_id ASC NULLS LAST)
    TABLESPACE pg_default;