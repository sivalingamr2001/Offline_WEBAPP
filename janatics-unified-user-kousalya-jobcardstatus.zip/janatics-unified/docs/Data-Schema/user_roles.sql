CREATE TABLE IF NOT EXISTS public.user_roles
(
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    CONSTRAINT pk_user_roles PRIMARY KEY (user_id, role_id),
    CONSTRAINT fk_user_roles_roles_role_id FOREIGN KEY (role_id)
        REFERENCES public.roles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT fk_user_roles_users_user_id FOREIGN KEY (user_id)
        REFERENCES public.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.user_roles
    OWNER to jan_jutest_usr;

-- Index: public.ix_user_roles_role_id
CREATE INDEX IF NOT EXISTS ix_user_roles_role_id
    ON public.user_roles USING btree
    (role_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_user_roles_user_id
CREATE UNIQUE INDEX IF NOT EXISTS ix_user_roles_user_id
    ON public.user_roles USING btree
    (user_id ASC NULLS LAST)
    TABLESPACE pg_default;