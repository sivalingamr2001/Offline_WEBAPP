CREATE TABLE IF NOT EXISTS public.organizations
(
    id uuid NOT NULL,
    name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    code character varying(50) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    oracle_org_id numeric(18,0),
    unit_name character varying(100) COLLATE pg_catalog."default",
    operating_unit_id integer,
    CONSTRAINT pk_organizations PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE public.organizations
    OWNER to jan_jutest_usr;

-- Index: public.ix_organizations_code
CREATE UNIQUE INDEX IF NOT EXISTS ix_organizations_code
    ON public.organizations USING btree
    (code COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;