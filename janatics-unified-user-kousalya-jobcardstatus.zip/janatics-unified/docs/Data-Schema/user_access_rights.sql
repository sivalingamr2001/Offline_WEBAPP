CREATE TABLE IF NOT EXISTS public.user_access_rights
(
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    operating_unit integer,
    limit_value numeric(15,2),
    access_channel character varying(10) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean NOT NULL,
    remarks character varying(400) COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    CONSTRAINT pk_user_access_rights PRIMARY KEY (id),
    CONSTRAINT fk_user_access_rights_organizations_organization_id FOREIGN KEY (organization_id)
        REFERENCES public.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT fk_user_access_rights_users_user_id FOREIGN KEY (user_id)
        REFERENCES public.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE public.user_access_rights
    OWNER to jan_jutest_usr;

-- Index: public.ix_user_access_rights_organization_id
CREATE INDEX IF NOT EXISTS ix_user_access_rights_organization_id
    ON public.user_access_rights USING btree
    (organization_id ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: public.ix_user_access_rights_user_id_organization_id
CREATE UNIQUE INDEX IF NOT EXISTS ix_user_access_rights_user_id_organization_id
    ON public.user_access_rights USING btree
    (user_id ASC NULLS LAST, organization_id ASC NULLS LAST)
    TABLESPACE pg_default;