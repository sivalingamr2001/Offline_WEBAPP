CREATE TABLE IF NOT EXISTS public.app_modules
(
    id uuid NOT NULL,
    code character varying(40) COLLATE pg_catalog."default" NOT NULL,
    name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    default_menu character varying(100) COLLATE pg_catalog."default",
    sort_order integer NOT NULL,
    remarks character varying(400) COLLATE pg_catalog."default",
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by_user_id uuid,
    description character varying(1000) COLLATE pg_catalog."default",
    icon character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT pk_app_modules PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE public.app_modules
    OWNER to jan_jutest_usr;

-- Index: public.ix_app_modules_code
CREATE UNIQUE INDEX IF NOT EXISTS ix_app_modules_code
    ON public.app_modules USING btree
    (code COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;