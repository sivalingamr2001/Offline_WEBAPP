# DevSecOps — JUSPlatform UI (Docker)

Frontend Secure SDLC mirrors the backend: **scanners run in Docker**, outputs are **SARIF**, and `security-evidence.html` is generated from all `*.sarif` files in `docker/security/reports/`.

## Architecture

```text
JUSPlatformUI/                    React + Vite + pnpm
docker/ci/docker-compose.yml   ui-ci (lint, typecheck, build)
docker/security/               semgrep-ui, trivy-ui → SARIF
docker/ci/run-security-pr.sh   backend + UI scanners → run-html.sh
```

Shared Docker volumes (`jusplatform_pnpm_store`, `jusplatform_semgrep_cache`, `jusplatform_trivy_cache`) keep repeat runs fast.

## Commands

| Command | What it runs |
|--------|----------------|
| `./docker/ci/run-ui-ci.sh` | Oxlint + `tsc -b` + Vite build in Node 22 container |
| `./docker/ci/run-ui-security-pr.sh` then `./docker/ci/run-html.sh` | Semgrep UI + Trivy UI → SARIF + HTML |
| `./docker/ci/run-security-pr.sh` | Backend Semgrep/Trivy/Gitleaks **+ UI scanners** + HTML |
| `./docker/security/run-all.sh` (or `.\docker\security\run-all.ps1`) | Full analyze stack including UI |

## SARIF outputs (UI)

| File | Tool |
|------|------|
| `semgrep-ui.sarif` | Semgrep (`p/react`, `p/typescript`, `semgrep-ui.rules.yml`) |
| `trivy-ui.sarif` | Trivy filesystem on `JUSPlatformUI/` (skips `node_modules`, `dist`) |

Gitleaks still scans the **whole repo** (including `JUSPlatformUI/`) in the backend gate.

## Jenkins

The root `Jenkinsfile` runs:

1. `run-ui-ci.sh` — frontend SDLC gate  
2. `run-security-pr.sh` — includes UI SARIF scanners  

HTML Publisher surfaces `docker/security/reports/security-evidence.html` alongside coverage.

## Recommended PR policy (report-only → enforce)

| Check | Start | Tighten later |
|-------|-------|----------------|
| `./docker/ci/run-ui-ci.sh` | Fail on lint/type/build errors | Keep |
| Semgrep UI | Report in SARIF | Fail on `ERROR` rules |
| Trivy UI | Report CVEs | Fail on Critical |
| Gitleaks | `--exit-code=0` today | Fail on any secret |

## Secure SDLC checklist (developers)

- [ ] No `VITE_*` secrets in `.env` (see `.env.example`)
- [ ] Run `./docker/ci/run-ui-ci.sh` before pushing UI changes
- [ ] Review `semgrep-ui.sarif` / `trivy-ui.sarif` after `./docker/ci/run-ui-security-pr.sh`
- [ ] Regenerate Orval clients after API changes (`pnpm api:generate`)

Product notes: [JUSPlatformUI/SECURITY.md](../JUSPlatformUI/SECURITY.md)
