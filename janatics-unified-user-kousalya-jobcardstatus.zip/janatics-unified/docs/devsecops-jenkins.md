# DevSecOps — Jenkins (Docker-only CI)

JUSPlatform backend CI runs **entirely in Docker** — no .NET SDK, Semgrep, or Trivy on developer machines or Jenkins host (beyond Docker itself).

Works with **Subversion** (today) or **Forgejo/Git** (migration path).

## Architecture

```text
Jenkins (container) ──docker.sock──► docker compose
                                        ├── dotnet-build   (NuGet cache volume)
                                        ├── semgrep/trivy/gitleaks (scanner cache volumes)
                                        └── ship stack     (full scan / DAST only)

Persistent volumes:
  jusplatform_jenkins_home      Jenkins config & job history
  jusplatform_jenkins_reports   SARIF + HTML (shared via nginx :8091)
  jusplatform_nuget_cache       NuGet packages
  jusplatform_semgrep_cache     Semgrep rules cache
  jusplatform_trivy_cache       Trivy DB cache
  jusplatform_gitleaks_cache    Gitleaks cache
  jusplatform_zap_cache         ZAP workspace
```

## Quick start (local demo)

```bash
./docker/jenkins/jenkins-up.sh

# Open Jenkins → http://localhost:8085
# Get initial password:
docker compose -f docker/jenkins/docker-compose.yml exec jenkins \
  cat /var/jenkins_home/secrets/initialAdminPassword
```

Create a **Pipeline** job:

| Setting | Value |
|---------|--------|
| SCM | Subversion *or* Git (Forgejo) |
| Script Path | `Jenkinsfile` |
| Repository URL | your SVN/Forgejo URL |

### Pipeline modes

| Trigger | `FULL_SCAN` | What runs |
|---------|-------------|-----------|
| PR / commit | `false` (default) | `run-build.sh` + `run-security-pr.sh` |
| Nightly / release | `true` | + ship image, API stack, DAST, container scan |

## Reports sharing

After each build, `archive-reports.sh` copies artifacts to the **`jusplatform_jenkins_reports`** volume:

```text
/var/jenkins_reports/{JOB_NAME}/{BUILD}_{timestamp}/
/var/jenkins_reports/{JOB_NAME}/latest/          ← symlink copy for quick access
```

**Nginx reports server** (port **8091**):

```text
http://localhost:8091/jusplatform-backend/latest/security-evidence.html
http://localhost:8091/                          ← directory listing of all jobs
```

Jenkins also archives workspace artifacts and publishes **Security Evidence** HTML in the build UI (HTML Publisher plugin).

## Run CI without Jenkins (developer / SVN hook)

```bash
./docker/ci/run-build.sh           # build in Docker
./docker/ci/run-security-pr.sh     # fast security gate
./docker/ci/run-security-full.sh   # full scan (starts ship stack)
./docker/ci/archive-reports.sh     # copy to REPORTS_ARCHIVE if mounted
```

The `Jenkinsfile` and `docker/ci/*` scripts are the source of truth:

```bash
./docker/ci/run-build.sh
./docker/ci/run-security-pr.sh
./docker/ci/run-security-full.sh
```

## SVN integration

1. **Post-commit hook** on SVN server → trigger Jenkins `build?token=...` (recommended), *or*
2. Jenkins **Poll SCM** on trunk/branches, *or*
3. Jenkins **Subversion plugin** checkout (standard)

The `Jenkinsfile` lives in the repo root — same for SVN and Forgejo after migration.

## Forgejo migration

- Switch job SCM from Subversion to Git
- Keep the same `Jenkinsfile` and `docker/ci/*` scripts
- Optional later: Forgejo Actions mirroring `run-security-pr.sh` for lighter PR checks

## Cache behaviour

- **First run:** pulls scanner images + NuGet restore (slow)
- **Later runs:** named volumes reuse Semgrep/Trivy/Gitleaks/NuGet caches
- **Docker layer cache:** `docker build` for ship image reuses layers when Dockerfile unchanged

## Security gates (recommended policy)

| Stage | Fail build on |
|-------|----------------|
| Gitleaks | Any secret detected (set `--exit-code=1` when ready) |
| Trivy fs | Critical CVEs (add policy in Jenkins post-step) |
| Semgrep | Error severity rules |
| Full scan | DAST high alerts (manual review initially) |

Start with **report-only** (`--exit-code=0` on gitleaks today), tighten gates once baseline is clean.

## Files

| Path | Role |
|------|------|
| `Jenkinsfile` | Declarative pipeline |
| `docker/jenkins/` | Jenkins + reports nginx compose |
| `docker/ci/` | Docker-only build & security scripts |
| `docker/security/` | Scanner compose (shared caches) |

## Stop Jenkins

```bash
./docker/jenkins/jenkins-down.sh
```

Volumes are retained for fast restart and report history.
