# JUSPlatform — Agent & Developer Policy

This document is the **working contract** for humans and coding agents touching `JUSPlatform/`.
Prefer this over inventing new auth, tenancy, or API patterns.

---

## 1. Mental model (non-negotiable)

```text
Authentication  →  who are you?           JWT Bearer
Authorization   →  what may you do?       permission claims + policies
Tenancy         →  whose data?            JWT claim org_id
```

Never confuse these three.

### Rules

| Do | Don't |
|----|--------|
| Enforce capabilities with `[Authorize(Policy = …)]` on controllers | Check `if (user.Role == "Admin")` |
| Resolve tenant via `ICurrentUser.RequireOrganizationId()` in Application | Accept `organizationId` from body/query for tenant scope |
| Treat roles as **collections of permissions** | Put role names in JWT as the authz source of truth |
| Keep controllers thin (HTTP adapter only) | Put EF queries / business rules in controllers |
| Keep PostgreSQL (Npgsql) as the app database | Point `ConnectionStrings:Default` at MariaDB/MySQL, SQL Server, or SQLite |
| Map PostgreSQL columns in snake_case (`having_this_col`) | Persist PascalCase column names (`HavingThisCol`) |
| Add OpenAPI metadata (`EndpointName`, summary, `ProducesResponseType`) | Ship endpoints without stable `operationId` |

---

## 2. Permission / policy wiring

**Catalog:** `Authorization/Permissions.cs`  
**Policies:** mapped 1:1 in `Infrastructure/Authorization/PermissionAuthorization.cs`  
**Enforcement:** controller attributes  
**Claim type:** `permission`  
**Org claim:** `org_id`

Flow:

```text
User → one Role → Permission codes
        ↓
Login flattens distinct permission codes into JWT
        ↓
[Authorize(Policy = Policies.SalesRead)]
        ↓
PermissionAuthorizationHandler requires claim permission=sale.read
```

### When adding a new capability

1. Add permission code to `Permissions.Catalog`
2. Add matching `Policies.*` constant
3. Register policy in `AddPermissionPolicies`
4. Put `[Authorize(Policy = …)]` on the endpoint
5. Scope data by JWT org in the Application service
6. Update Bruno under `apidocs/`
7. Ensure OpenAPI has `operationId` + status codes

Seed / role admin assignment is how users receive permissions — not hardcoded role checks.

**Access layers**

| Layer | Role | Scope |
|-------|------|--------|
| 0 | `SuperAdmin` | Platform owner. No `org_id`. Seeded only. Manages organizations and users. |
| 1 | `Admin` | Organization owner. JWT `org_id`. Manages that org's users and settings. |
| 2 | `Manager` / `DataEntryOperator` / custom | Permission-driven work inside one org. |

Login returns a single `roleName`; JWT carries one `role_name` claim. SuperAdmin JWT has no `org_id`.

---

## 3. Tenancy policy

- **Org users:** JWT `org_id` is the tenant. Do not accept `organizationId` from body/query.
- **SuperAdmin:** no tenant. May pass `organizationId` only on user/role list/create to target an org.
- **Own company (Admin):** `GET/PUT /api/v1/organizations/me` — no id in URL.
- **All companies (SuperAdmin):** `GET/POST /api/v1/organizations`.
- **Forbidden for org users:** client-supplied org id for Users, Roles, Inventory, Sales, PO, Invoices.
- **Resource ids** (`userId`, `productId`, …) are fine; org users always filter `OrganizationId == jwtOrg`.
- Missing/mismatched tenant data → **404** (do not leak cross-tenant existence when avoidable).

`POST /api/v1/organizations` is SuperAdmin-only (does not switch the caller's JWT).

---

## 4. Layering policy

```text
Controllers     → authZ attributes, bind input, call Application, return HTTP
Application     → use cases, org scoping, domain rules, validation orchestration
Domain          → entities, enums, domain exceptions (no EF / ASP.NET)
Infrastructure  → EF, JWT, sinks, seed, external adapters
```

Dependency direction: Api/Controllers → Application → Domain; Infrastructure implements Application needs.

### Feature DX (keep high)

When adding/changing a feature, touch the vertical slice together:

```text
Domain/Entities/<Thing>.cs
Infrastructure/Persistence/Configurations/<Thing>Configuration.cs
Application/<Feature>/...
Controllers/<Feature>Controller.cs
apidocs/<feature>/...
```

- Domain entity = shape + navigations + C# defaults
- Fluent configuration = Unique / FK / lengths / precision / filters
- Then: `dotnet ef migrations add <Name>` and update Bruno/OpenAPI

Keep mappings split per feature (not one giant config file).

---

## 5. Security baselines already expected

- Login is **enum-safe**: same 401 message; password work always runs (dummy hash if user missing).
- Login body does **not** expose `organizationId`.
- Soft-delete filters on entities; join tables (`UserRole`, `RolePermission`) have matching filters.
- Errors use minimal JSON envelope (`ApiErrorResponse`: `success`, `detail`, `errors`). All `/api/*` **401**, **403**, and **404** use the same shape. Optional `type`/`title`/`status`, `traceId`, and `exception` are config-gated (`ErrorResponse` section).
- Correlation: server always sets `X-Response-Id`. Optional client `X-Request-Id` is validated (max 64, alphanumeric/`_-` only); invalid values are discarded. When observability is on, server also sets `X-Trace-Id` (OTel trace id for Tempo lookup).
- Secrets stay in config / env — never commit real signing keys or DB passwords for shared envs.
- **Enterprise data guardrail:** credentials, NDA material, and customer/tenant data must not enter model prompts, chat, or training. See `.cursor/rules/enterprise-data-guardrail.mdc`.

---

## 6. API / Orval policy

Every public endpoint needs:

- Tag
- Stable `operationId` (`[EndpointName]`)
- Summary (+ description when non-obvious)
- Typed success + error `ProducesResponseType`
- Auth requirement reflected (anonymous only for login/health)

Enums are JSON **strings**. Prefer camelCase DTOs.

---

## 7. Logging policy

Operational logs ≠ audit logs.

| Kind | Purpose | Sink |
|------|---------|------|
| Operational | diagnose failures | `LogSink` File (default) / Database / Seq |
| Audit | who changed what | `audit_entries` via `EntityChangeInterceptor` on SaveChanges |

List-cache invalidation is also owned by that interceptor — services must not call `InvalidateAsync` by hand.

Do not log passwords, tokens, or full JWTs.  
`Fatal` only for process-ending failures.

---

## 8. Agent operating rules

When changing JUSPlatform:

1. Read this file and `JUSPlatform/README.md` before inventing patterns.
2. Prefer extending existing feature folders over new global `Helpers/` dumps.
3. Do not weaken tenancy or permission checks “for convenience.”
4. Do not add `organizationId` request fields for tenant APIs.
5. Update Bruno + OpenAPI metadata with behavioral changes.
6. Keep `Program.cs` as composition root only (no feature logic / validators).
7. Do not send credentials, NDA content, or real customer/tenant data to the model. Redact; never ask anyone to paste secrets into chat.

---

## 9. Known gaps (track here; do not ignore)

See the living checklist below. Agents should update this section when closing a gap.

### Auth / security

- [ ] Refresh tokens / token revocation / logout denylist
- [ ] Login rate limiting / lockout
- [ ] Stronger JWT signing key management (no long-lived dev key in shared deploys)
- [ ] HTTPS redirection enabled outside local dev
- [ ] CORS policy for real frontends
- [ ] Platform vs tenant admin split for `POST /organizations` (provision)
- [ ] Permission reload without re-login (or short-lived access tokens + refresh)

### Product / ERP correctness

- [ ] Concurrency control on stock (row version / transactional locking)
- [ ] Idempotency keys for confirm/complete/pay commands
- [ ] Stronger document number generation (race-safe sequences)
- [x] Pagination / filtering on list endpoints (`PagedListQuery` + `ApiPagedResponse<T>`)
- [ ] Soft-delete APIs and restore policy
- [x] Audit trail for entity changes (`audit_entries` + SaveChanges interceptor)
- [x] Central query-cache invalidation (`EntityChangeInterceptor` + Redis index sets)

### Quality / delivery

- [x] Background jobs API (enqueue + poll + logs + retries)
- [ ] FluentValidation coverage for Sales / PO / Invoice / Role requests
- [x] Paginated query cache (`Redis:QueryCacheEnabled`; filter + interceptor, off by default)
- [x] OpenTelemetry observability (`Observability:Enabled=false`; OTLP → Grafana stack demo via `.\scripts\obs-up.ps1`)
- [x] Bugsink error tracking (`Bugsink:Enabled=false`; Sentry SDK → self-hosted via `.\scripts\bugsink-up.ps1`)
- [ ] CI: build, test, OpenAPI lint
- [ ] Dapper usage policy: keep EF-first; Dapper only for approved exceptions (e.g. log sink)

### Ops

- [ ] Seq (or other OSS) stood up and documented for the team
- [ ] Health path alias `/api/health` (current route is `/api/heath` by product choice)
- [ ] Migration discipline for every schema change (no silent `EnsureCreated`)
