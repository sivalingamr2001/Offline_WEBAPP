# Security scanning (Docker — optional)

Docker is not required for local API/UI development. Use this document when Docker is available for CI or security evidence.

Two Docker tracks:

| Track | Path | Purpose |
|-------|------|---------|
| **Ship** | `JUSPlatform/Dockerfile` + root `docker-compose.yml` | Runnable API (+ PostgreSQL) |
| **Analyze** | `docker/security/Dockerfile` + `docker/security/docker-compose.yml` | SAST / SCA / secrets / DAST → **SARIF** |

Scanner engines use **pinned official images**. Named volumes (`jusplatform_semgrep_cache`, `jusplatform_trivy_cache`, etc.) persist DBs/rules so re-runs stay fast — shared between `.\docker\security\run-all.ps1`, Jenkins CI, and developer machines. The analysis Dockerfile is the thin workspace companion; Semgrep/Trivy/Gitleaks/ZAP run as sibling services for cache reuse.

`apidocs/` and `.cursor/` are **tracked by git** (they sync with the repo). They are only listed in `.dockerignore` so they are not copied into the ship image.

**Jenkins CI:** see [devsecops-jenkins.md](devsecops-jenkins.md) — `./docker/jenkins/jenkins-up.sh` starts Docker-only pipeline controller + report sharing on `:8091`.

**Frontend (JUSPlatform UI):** see [devsecops-frontend.md](devsecops-frontend.md) — `./docker/ci/run-ui-ci.sh` and UI SARIF scanners (`semgrep-ui.sarif`, `trivy-ui.sarif`) merge into the same HTML evidence report.

## Quick reference

| Action | Windows PowerShell (default) | Linux |
|--------|------------------------------|--------|
| Dev settings | `.\scripts\setup-dev.ps1` | `./scripts/setup-dev.sh` |
| Start API + DB (auto) | `.\docker\ship-up.ps1` | `./docker/ship-up.sh` |
| Force compose PostgreSQL (:5433) | `$env:FORCE_COMPOSE_DB='1'; .\docker\ship-up.ps1` | `FORCE_COMPOSE_DB=1 ./docker/ship-up.sh` |
| Force host DB (:5432) | `$env:FORCE_HOST_DB='1'; .\docker\ship-up.ps1` | `FORCE_HOST_DB=1 ./docker/ship-up.sh` |
| Stop stack | `docker compose --profile with-db down` | `docker compose --profile with-db down` |
| API logs | `docker compose logs -f api` | `docker compose logs -f api` |
| SAST/SCA/secrets + HTML | `.\docker\security\run-all.ps1` | `./docker/security/run-all.sh` |
| **All scans + HTML evidence** | **`$env:SECURITY_ALL='1'; .\docker\security\run-all.ps1`** | **`SECURITY_ALL=1 ./docker/security/run-all.sh`** |
| Rebuild HTML from SARIF | `python .\docker\security\sarif-to-html.py --reports-dir .\docker\security\reports` | `python3 docker/security/sarif-to-html.py --reports-dir docker/security/reports` |
| + DAST only | `$env:RUN_DAST="1"; $env:TARGET_URL="http://127.0.0.1:8080"; .\docker\security\run-all.ps1` | `RUN_DAST=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh` |
| Image SCA | `$env:RUN_IMAGE_SCA="1"; .\docker\security\run-all.ps1` | `RUN_IMAGE_SCA=1 ./docker/security/run-all.sh` |
| Reports | `Get-ChildItem docker\security\reports` | `ls -la docker/security/reports` |
| **UI SDLC (Docker)** | **`.\docker\ci\run-ui-ci.sh`** (Git Bash) | **`./docker/ci/run-ui-ci.sh`** |
| **UI security SARIF** | **`.\docker\ci\run-ui-security-pr.sh`** (Git Bash) | **`./docker/ci/run-ui-security-pr.sh`** |

### Full evidence run (recommended)

1. Start the API (needed for DAST + image scan target). Auto-detects host PostgreSQL on `:5432`; otherwise starts container DB on host `:5433`:

```powershell
.\docker\ship-up.ps1
# $env:FORCE_COMPOSE_DB='1'; .\docker\ship-up.ps1
# $env:FORCE_HOST_DB='1'; .\docker\ship-up.ps1
```

```bash
./docker/ship-up.sh
# FORCE_COMPOSE_DB=1 ./docker/ship-up.sh
# FORCE_HOST_DB=1 ./docker/ship-up.sh
```

2. Run **all** scanners and generate SARIF + HTML:

```bash
SECURITY_ALL=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh
```

```powershell
$env:SECURITY_ALL = "1"
$env:TARGET_URL = "http://127.0.0.1:8080"
.\docker\security\run-all.ps1
```

Artifacts under `docker/security/reports/`:

| File | Role |
|------|------|
| `*.sarif` | Machine-readable evidence |
| `security-evidence.html` | Human HTML report (**built dynamically from SARIF**) |
| `security-evidence-*.html` | Timestamped HTML copy for retention |

Open `docker/security/reports/security-evidence.html` in a browser. Re-render HTML anytime with `python .\docker\security\sarif-to-html.py --reports-dir .\docker\security\reports` without re-scanning.

## Copy-paste (no Makefile)

```powershell
# Windows (default)
.\scripts\setup-dev.ps1
.\docker\ship-up.ps1
docker compose --profile with-db down
.\docker\security\run-all.ps1
$env:RUN_DAST='1'; $env:TARGET_URL='http://127.0.0.1:8080'; .\docker\security\run-all.ps1
$env:RUN_IMAGE_SCA='1'; .\docker\security\run-all.ps1
Get-ChildItem .\docker\security\reports
```

```bash
# Linux
./scripts/setup-dev.sh
./docker/ship-up.sh
docker compose --profile with-db down
./docker/security/run-all.sh
RUN_DAST=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh
RUN_IMAGE_SCA=1 ./docker/security/run-all.sh
ls -la docker/security/reports
```

## Coverage

| Layer | Tool | Output |
|-------|------|--------|
| SAST | Semgrep | `docker/security/reports/semgrep.sarif` |
| SCA | Trivy (filesystem) | `trivy.sarif` |
| Secrets | Gitleaks | `gitleaks.sarif` |
| DAST | OWASP ZAP baseline | `zap.sarif` (+ `zap-report.json`) |
| Image SCA (optional) | Trivy image | `trivy-image.sarif` |

## Run analysis (shell)

```bash
./docker/security/run-all.sh
docker compose up -d --build
RUN_DAST=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh
```

```powershell
.\docker\security\run-all.ps1
docker compose up -d --build
$env:RUN_DAST = "1"
$env:TARGET_URL = "http://127.0.0.1:8080"
.\docker\security\run-all.ps1
```

## Windows

Docker Desktop is required. Prefer one of:

### 1. WSL2 (recommended)

Same commands as Linux inside your distro:

```bash
./docker/ship-up.sh
./docker/security/run-all.sh
RUN_DAST=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh
```

### 2. Git Bash

Install [Git for Windows](https://git-scm.com/download/win), open **Git Bash** in the repo root, then use `./docker/ship-up.sh` or `./docker/security/run-all.sh`.

### 3. PowerShell (no Make)

```powershell
# Ship
docker compose up --build -d
docker compose logs -f api
docker compose down

# Analyze
.\docker\security\run-all.ps1

# + DAST when API is up
$env:RUN_DAST = "1"
$env:TARGET_URL = "http://127.0.0.1:8080"
.\docker\security\run-all.ps1

# Optional image SCA
$env:RUN_IMAGE_SCA = "1"
.\docker\security\run-all.ps1

# Single scanners
docker compose -f docker/security/docker-compose.yml run --rm --no-deps semgrep
docker compose -f docker/security/docker-compose.yml run --rm --no-deps trivy
docker compose -f docker/security/docker-compose.yml run --rm --no-deps gitleaks

# Dev settings template
Copy-Item JUSPlatform\appsettings.Development.json.example JUSPlatform\appsettings.Development.json
```

If you want GNU Make on Windows, install it via Chocolatey (`choco install make`) or Scoop (`scoop install make`), but bash scripts still need Git Bash or WSL — `.\scripts\*.ps1` and `.\docker\security\run-all.ps1` are enough without Make.

**DAST note:** ZAP uses `network_mode: host`. On Docker Desktop for Windows that may not reach `localhost` the same way as Linux; if ZAP cannot hit the API, set `$env:TARGET_URL = "http://host.docker.internal:8080"` and temporarily drop `network_mode: host` for the `zap` service, or run DAST from WSL2.

## Ship

```powershell
# Windows (default)
docker compose up --build -d
# API: http://localhost:8080
```

```bash
# Linux
./docker/ship-up.sh
# API: http://localhost:8080
```

## Local secrets / gitignore

- `appsettings.Development.json` is **ignored** (stop tracking with `git rm --cached` if it was committed)
- Copy `JUSPlatform/appsettings.Development.json.example` → `appsettings.Development.json`
- Prefer env vars / user-secrets for JWT signing keys in shared environments
- Scan reports under `docker/security/reports/` are ignored except `.gitkeep`
