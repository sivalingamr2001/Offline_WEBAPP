# JUSPlatform on .NET 10

The product TFM is **`net10.0`**. Janatics India licenses **.NET 10**. .NET 10 LTS runs through **November 2028**.

Do not mix TFMs across API, tests, mocks, IIS hosting bundle, and Docker images.

## What shipped in the 8 → 10 bump

- Every `TargetFramework` is `net10.0` (`JUSPlatform`, unit tests, integration tests, `Mock/MockServices`).
- `global.json` pins SDK `10.0.0` with `rollForward: latestFeature`.
- ASP.NET packages on the 10.0 line: `Microsoft.AspNetCore.Authentication.JwtBearer`, `Microsoft.AspNetCore.Mvc.Testing`.
- OpenAPI: built-in `Microsoft.AspNetCore.OpenApi` + document transformers. Contract URL stays **`/openapi/v1.json`** (Orval unchanged).
- Forwarded headers use `KnownIPNetworks` (not `KnownNetworks`).
- Docker images: `mcr.microsoft.com/dotnet/sdk:10.0` and `aspnet:10.0`.
- EF Core stays on **9.x** (`UseNpgsql`). Do not treat EF 9 → 10 as part of this runtime bump.

## OpenAPI on 10

```csharp
services.AddOpenApi(options =>
{
    options.AddDocumentTransformer((document, context, _) =>
    {
        // set document.Info, Components.SecuritySchemes["Bearer"], document.Security
        return Task.CompletedTask;
    });
});

app.MapOpenApi(); // Development: /openapi/v1.json
```

`[EndpointName]` / `[EndpointSummary]` stay. Do not change controller routes as part of a TFM bump.

## IIS / Linux hosts

Install the **ASP.NET Core 10 Hosting Bundle** (Windows) or `aspnetcore-runtime-10.0` (Linux). Keep `deploy/iis/web.config` (`processPath="dotnet"`). Do not point IIS at a .NET 8 hosting bundle while the app is `net10.0`.

## Verify

```powershell
$env:PATH = "$env:USERPROFILE\.dotnet;$env:PATH"
dotnet --version
dotnet test .\tests\JUSPlatform.UnitTests\JUSPlatform.UnitTests.csproj
dotnet test .\tests\JUSPlatform.IntegrationTests\JUSPlatform.IntegrationTests.csproj
dotnet run --project .\JUSPlatform\JUSPlatform.csproj
# Open http://localhost:5201/openapi/v1.json and /docs
```
