# OSP Jobs Feature Guide

## Purpose

OSP Jobs is the Control Tower view for monitoring outside-process jobs sent to external vendors. It presents the full multi-OSP train journey for filtered jobs, summarizes performance with KPIs and charts, and provides a drill-down page for one job and all of its operations.

OSP means outside processing. A job can contain multiple OSP operations, and each operation is represented by three phases: Pre, Processing, and Post.

## Entry Points


| Route                                   | Screen                             | Responsibility                                |
| --------------------------------------- | ---------------------------------- | --------------------------------------------- |
| `/dashboard/control-tower/osp-jobs`     | `[index.tsx](index.tsx)`           | Filtered OSP dashboard and train table        |
| `/dashboard/control-tower/osp-jobs/:id` | `[OspJobById.tsx](OspJobById.tsx)` | One-job header, journey, and operation detail |


The routes are registered in `[src/routers/AppRouter.tsx](../../../../routers/AppRouter.tsx)` and are protected by the authenticated dashboard route. Both screens render inside `[ControlTowerLayout.tsx](../../layouts/ControlTowerLayout.tsx)`.

## File Map



### Screen files

- `[index.tsx](index.tsx)`: owns dashboard filter state, React Query loading, error handling, and composition of the KPI, train-table, and analytics sections.
- `[OspJobById.tsx](OspJobById.tsx)`: reads the route `id`, loads one job, renders header fields and the train journey, and renders the operations table.



### Supporting components

- `[OspTrainTable.tsx](../../components/OspTrainTable.tsx)`: renders the all-jobs table, status legend, expandable quantity rows, train journey visualization, status mappings, and OSP value formatters.
- `[OspKpiStrip.tsx](../../components/OspKpiStrip.tsx)`: renders the eight KPI cards and their calculation guidance.
- `[OspAnalytics.tsx](../../components/OspAnalytics.tsx)`: renders variance-by-stage bars, delayed-vendor bars, and the status donut.
- `[ControlTowerFiltersContext.tsx](../../components/ControlTowerFiltersContext.tsx)`: supplies the shared Control Tower `refreshKey`; OSP does not use the shared year/month and period filters.



### API and models

- `[src/api/controlTower.ts](../../../../api/controlTower.ts)`: exports the generated Control Tower API client and the shared `toNum` conversion helper.
- `[src/api/generated/control-tower/control-tower.ts](../../../../api/generated/control-tower/control-tower.ts)`: defines `getOspJobs` and `getOspJob`.
- `[src/api/generated/models/ospJobsScreenDto.ts](../../../../api/generated/models/ospJobsScreenDto.ts)`: list-screen response contract.
- `[src/api/generated/models/ospJobRowDto.ts](../../../../api/generated/models/ospJobRowDto.ts)`: row contract used by the train table.
- `[src/api/generated/models/ospJobDetailDto.ts](../../../../api/generated/models/ospJobDetailDto.ts)`: detail-page response contract.
- `[src/api/generated/models/ospOperationDto.ts](../../../../api/generated/models/ospOperationDto.ts)` and `[ospPhaseDto.ts](../../../../api/generated/models/ospPhaseDto.ts)`: operation and phase contracts.

Generated API files are produced by Orval. Change the API specification and run `pnpm api:generate` instead of editing generated files manually.

## Dashboard Logic

`ControlTowerOspJobsScreen` performs the following steps:

1. Sets the page title to `OSP Jobs`.
2. Reads `refreshKey` from `useControlTowerFilters()`.
3. Creates local state for:
  - `dateRange`, defaulting to `last30`.
  - `jobType`, `product`, and `plant`, defaulting to all values.
  - `expanded`, controlling whether every row shows quantity details.
4. Runs a React Query request with key:
  ```text
   ['control-tower', 'osp-jobs', dateRange, jobType, product, plant, refreshKey]
  ```
5. Calls `controlTowerApi.getOspJobs()` with empty optional filters converted to `undefined`.
6. Shows `LoadingState` while loading and a danger `Callout` if the request fails or has no data.
7. Builds filter options from the response (`jobTypes`, `products`, and `plants`) rather than maintaining a second client-side option list.
8. Renders the response sections in this order:
  - `OspKpiStrip` using `data.kpis`.
  - `OspTrainTable` using `data.jobs` and the `expanded` flag.
  - `OspAnalytics` using `varianceByStage`, `topDelayedOsps`, and `jobsByStatus`.



### Dashboard implementation

The screen keeps OSP-specific filters local and includes every request-affecting value in the React Query key:

```tsx
const [dateRange, setDateRange] = useState('last30')
const [jobType, setJobType] = useState('')
const [product, setProduct] = useState('')
const [plant, setPlant] = useState('')
const [expanded, setExpanded] = useState(false)

const query = useQuery({
   queryKey: ['control-tower', 'osp-jobs', dateRange, jobType, product, plant, filters.refreshKey],
   queryFn: () =>
      controlTowerApi.getOspJobs({
         dateRange,
         jobType: jobType || undefined,
         product: product || undefined,
         plant: plant || undefined,
      }),
})
```

The response is composed directly into the feature sections. The page does not duplicate KPI or chart calculations:

```tsx
if (query.isLoading) {
   return <LoadingState label="Loading OSP jobs…" />
}

if (query.isError || !query.data) {
   return <Callout tone="danger">{getApiErrorMessage(query.error) || 'Failed to load OSP jobs.'}</Callout>
}

const data = query.data

return (
   <div className="space-y-5">
      <FilterSelect label="Date Range" value={dateRange} onChange={setDateRange} options={dateRangeOptions} />
      <OspKpiStrip kpis={data.kpis} />
      <OspTrainTable jobs={data.jobs} expanded={expanded} />
      <OspAnalytics
         varianceByStage={data.varianceByStage}
         topDelayedOsps={data.topDelayedOsps}
         jobsByStatus={data.jobsByStatus}
      />
   </div>
)
```

`FilterSelect` maps the UI sentinel `__all__` to an empty string. The query function then maps that empty string to `undefined`, which omits the optional query parameter.

### List request

`GET /api/v1/control-tower/osp-jobs`

Query parameters:


| Parameter   | Values / meaning                                |
| ----------- | ----------------------------------------------- |
| `dateRange` | `last30`, `last90`, `ytd`, or `all` from the UI |
| `jobType`   | Optional selected job type                      |
| `product`   | Optional selected product                       |
| `plant`     | Optional selected customer location             |


The generated model documents `last30`, `last90`, and `ytd`; the UI also offers `all`.

### List response

`OspJobsScreenDto` contains:

- `kpis`: aggregate counters, percentages, and TAT/variance values.
- `jobs`: one row per job, including its operation list.
- `varianceByStage`: average variance used by the stage chart.
- `topDelayedOsps`: delayed vendor/process rows.
- `jobsByStatus`: status counts and percentages for the donut.
- `plants`, `jobTypes`, `products`: values used to populate local filter selects.
- `lastUpdated`: server timestamp currently available in the payload but not displayed by these screens.



## Train Table and Status Logic

Each job row displays job number, description, plant, OSP count, planned TAT, actual TAT, variance, overall status, and the visual train journey.

The job number links to `routes.controlTowerOspJobById(job.id)`.

The `expanded` view adds one compact quantity summary for every operation:

```text
OSP <index> <name>: Q <queue> · M <move> · S <scrap> · C <complete> · <vendor>
```

Each operation journey contains:

1. A start truck node.
2. One operation card per OSP.
3. Pre, Processing, and Post phase nodes inside each card.
4. Connectors colored from the operation or phase status.
5. An end flag node.

Status labels and visual tones are centralized in `OspTrainTable.tsx`:


| API status   | Label       | Meaning / visual tone               |
| ------------ | ----------- | ----------------------------------- |
| `onTrack`    | On Track    | Green / success                     |
| `atRisk`     | At Risk     | Orange                              |
| `delayed`    | Delayed     | Red / danger                        |
| `completed`  | Completed   | Blue/info badge; green journey line |
| `notStarted` | Not Started | Neutral dashed presentation         |


Status and KPI thresholds are calculated by the backend. The frontend maps statuses to labels and styles; it does not recalculate job status.

## KPI Logic

The KPI explanations in `[OspKpiStrip.tsx](../../components/OspKpiStrip.tsx)` describe the backend measures:

- **Total OSP Jobs**: jobs matching the current filters.
- **On Track**: current phases are at or under plan; on-time completed jobs are included.
- **At Risk**: current-stage actual TAT is up to one day over plan.
- **Delayed**: any Pre, Processing, or Post phase is more than one day over plan; one delayed OSP makes the whole job delayed.
- **Avg Plan TAT**: average planned train duration. The documented plan is 2 pre-process days plus vendor lead time plus 1 post-process day for each OSP.
- **Avg Actual TAT**: average elapsed duration across phases, using today for an open phase.
- **Avg Variance**: `Actual TAT - Plan TAT`; positive is late.
- **On-time Completion**: completed jobs with actual TAT less than or equal to plan, compared with the prior period.

The UI converts numeric API values with `toNum`, then formats days, percentages, and signed variance values for display.

## Detail Page Logic

`ControlTowerOspJobByIdScreen`:

1. Reads `id` from `useParams`.
2. Runs `getOspJob(id)` only when an `id` exists.
3. Uses query key `['control-tower', 'osp-job', id]`.
4. Sets the document title to the loaded job number, or `OSP Job` before loading.
5. Shows a loading state, or a back link plus error callout when the job is missing or the request fails.
6. Displays the job number, overall status, description, plant, and optional item number.
7. Displays header fields including identifiers, quantities, OSP count, plan/actual TAT, and signed variance.
8. Reuses `OspTrainJourney` for the detailed operation sequence.
9. Renders an operations table with sequence, vendor, queue/move/scrap/complete quantities, lead time, dates, status, and phase plan-vs-actual values.



### Detail implementation

The detail screen is driven by the route parameter and is disabled until the parameter exists:

```tsx
const { id } = useParams<{ id: string }>()

const query = useQuery({
   queryKey: ['control-tower', 'osp-job', id],
   queryFn: () => controlTowerApi.getOspJob(id!),
   enabled: Boolean(id),
})

const job = query.data
usePageTitle(job ? job.jobNo : 'OSP Job')

if (query.isLoading) {
   return <LoadingState label="Loading OSP job…" />
}

if (query.isError || !job) {
   return <Callout tone="danger">{getApiErrorMessage(query.error) || 'OSP job not found.'}</Callout>
}
```

The operation table reuses the same status and formatting functions as the list journey. This keeps status labels, quantity formatting, and day formatting consistent between summary and detail views:

```tsx
const variance = toNum(job.varianceDays)

<StatusBadge tone={ospStatusTone[job.overallStatus]} className="normal-case">
   {ospStatusLabel[job.overallStatus]}
</StatusBadge>

<Field label="Plan TAT" value={formatOspDays(job.planTatDays)} />
<Field label="Actual TAT" value={formatOspDays(job.actualTatDays)} />
<Field
   label="Variance"
   value={formatOspSignedDays(variance)}
   valueClass={variance > 0 ? 'text-red-600' : variance < 0 ? 'text-emerald-600' : undefined}
/>

<OspTrainJourney operations={job.operations} />
```

The back link targets `routes.controlTowerOspJobs`, so detail navigation returns to the dashboard route rather than preserving the previous filter values in the URL.

## Formatting Rules

- `toNum` treats `null` and `undefined` as `0` and accepts numeric strings from the API.
- `formatOspDays` displays whole or one-decimal day values with a `d` suffix.
- `formatOspSignedDays` displays positive variance with `+`, negative variance with a Unicode minus, and zero as `0`.
- `formatOspQty` uses `en-US` thousands separators.
- Detail dates use `en-GB` formatting (`02 Jun 2026`) and show `—` for missing or invalid values.
- Optional numeric identifiers show `—` when null or empty.

The shared conversion and formatting code is intentionally small:

```tsx
export function formatOspDays(value: number | string) {
   const n = toNum(value)
   return `${n % 1 === 0 ? n : n.toFixed(1)}d`
}

export function formatOspSignedDays(value: number) {
   if (value === 0) return '0'
   const abs = Math.abs(value)
   const body = abs % 1 === 0 ? String(abs) : abs.toFixed(1)
   return `${value > 0 ? '+' : '−'}${body}`
}

export function formatOspQty(value: number | string) {
   return toNum(value).toLocaleString('en-US')
}
```

The API client calls are generated but exposed through one feature-facing client:

```tsx
export const controlTowerApi = getControlTower()

// Generated methods:
controlTowerApi.getOspJobs(params)
controlTowerApi.getOspJob(id)
```



## Refresh, Loading, and Error Behavior

- The list is refetched when any local OSP filter changes because those values are part of the React Query key.
- A Control Tower refresh changes `refreshKey`, which is also part of that key and therefore refetches the list.
- The detail query is keyed by job ID and is independent of the list query.
- Loading states replace the page content while the initial request is pending.
- API errors are converted through `getApiErrorMessage`; list and detail screens provide OSP-specific fallback messages.
- An empty list is a successful response and is rendered by `OspTrainTable` as `No OSP jobs for the current filters.`



## Change Checklist

When changing this feature:

1. Update the OpenAPI source and regenerate Orval models/client code for API contract changes.
2. Keep status labels and tones synchronized in `OspTrainTable.tsx`.
3. Keep dashboard query-key inputs synchronized with request parameters.
4. Preserve numeric-string handling because generated API models allow both `number` and `string` for many measures.
5. Run `pnpm typecheck`, `pnpm lint`, and `pnpm build` after changes.

