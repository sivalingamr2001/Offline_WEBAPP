# RBAC Flow Diagram

This is the target authorization model using the supplied tables without changing columns, adding tables, or changing indexes. Authorization is **deny by default** and every protected data query is scoped by `user_access_rights`.

## 1. Domain and Permission Relationships

```mermaid
erDiagram
    USERS ||--o{ USER_ACCESS_RIGHTS : assigned_access
    ORGANIZATIONS ||--o{ ROLES : owns
    USERS }o--|| ROLES : uses_role_id
    ROLES ||--o{ USER_ROLES : legacy_link
    USERS ||--o{ USER_ROLES : legacy_link
    ORGANIZATIONS ||--o{ USER_ACCESS_RIGHTS : grants_access
    ORGANIZATIONS }o--o| OPERATING_UNITS : maps_by_integer_scope

    ROLES ||--o{ ROLE_PERMISSIONS : grants
    PERMISSIONS ||--o{ ROLE_PERMISSIONS : included
    ROLES ||--o{ ROLE_MENUS : exposes
    APP_MODULES ||--o{ APP_MENUS : contains
    APP_MENUS ||--o{ ROLE_MENUS : exposes

    USERS ||--o{ USER_SESSIONS : starts

    USERS {
        uuid id PK
        uuid organization_id "default organization"
        uuid role_id FK "effective role"
        boolean is_active
        boolean is_deleted
    }
    USER_ACCESS_RIGHTS {
        uuid id PK
        uuid user_id FK
        uuid organization_id FK
        integer operating_unit
        string access_channel
        boolean is_active
    }
    ORGANIZATIONS {
        uuid id PK
        string code UK
        boolean is_active
        boolean is_deleted
    }
    OPERATING_UNITS {
        integer id PK
        integer org_id "existing integer mapping"
        string name
        boolean is_active
    }
    ROLES {
        uuid id PK
        uuid organization_id FK
        string code
        boolean is_system
    }
    ROLE_PERMISSIONS {
        uuid role_id PK,FK
        uuid permission_id PK,FK
    }
    ROLE_MENUS {
        uuid role_id FK
        uuid module_id FK
        uuid menu_id FK
        boolean perm_view
        boolean perm_add
        boolean perm_edit
        boolean perm_delete
        boolean perm_export
        boolean perm_approve
    }
```

`USER_ACCESS_RIGHTS` is the authoritative user-to-organization relationship. Its unique `(user_id, organization_id)` index means one access row is available per organization; `operating_unit` is the optional integer scope. `USERS.role_id` is the effective role in the current schema. `USER_ROLES` is retained as an existing compatibility link, but its unique `user_id` index also permits only one role.

## 2. Administrative Setup Flow

```mermaid
flowchart TD
    SA[Super Admin] --> ORG[Create or update organization]
    ORG --> OU[Create operating units under organization]
    SA --> MOD[Create or activate module]
    MOD --> MENU[Create menu and parent-child menu tree]
    SA --> PERM[Create permission code]
    SA --> ROLE[Create organization role]
    ROLE --> RP[Assign permissions to role]
    ROLE --> RM[Assign visible menus and CRUD flags]
    SA --> USER[Create user]
    USER --> MEMBERSHIP[Assign one or more organizations]
    MEMBERSHIP --> SCOPE[Set existing operating_unit integer scope]
    USER --> UR[Set users.role_id]
    UR --> READY[User can sign in]
    RP --> READY
    RM --> READY
```

## 3. Runtime Request Authorization Flow

```mermaid
flowchart TD
    REQ[HTTP request] --> AUTH[Authenticate session/token]
    AUTH --> ACTIVE{User active and session valid?}
    ACTIVE -- No --> DENY401[401 Unauthorized]
    ACTIVE -- Yes --> CTX[Build authorization context]
    CTX --> ORGSEL{Requested organization selected?}
    ORGSEL -- No --> DEFAULT[Use one allowed default organization]
    ORGSEL -- Yes --> MEMBERSHIP{User belongs to organization?}
    DEFAULT --> MEMBERSHIP
    MEMBERSHIP -- No --> DENY403[403 Forbidden]
    MEMBERSHIP -- Yes --> ROLES[Load users.role_id and verify role organization]
    ROLES --> PERM[Resolve permission from role permissions]
    PERM --> ACTION{Permission allows requested action?}
    ACTION -- No --> DENY403
    ACTION -- Yes --> MENU{Module/menu is exposed to role?}
    MENU -- No --> DENY403
    MENU -- Yes --> SCOPE[Apply organization and operating-unit predicates to query]
    SCOPE --> DATA{Record belongs to allowed scope?}
    DATA -- No --> DENY404[404 or 403 by API policy]
    DATA -- Yes --> EXEC[Execute operation]
    EXEC --> AUDIT[Write audit event]
    AUDIT --> RESP[Return response]
```

## 4. CRUD Decision

```mermaid
flowchart LR
    REQUEST[Resource request] --> CONTEXT[organization_id + user_id + operating_unit_ids]
    CONTEXT --> ROLEPERM[Role permission check]
    ROLEPERM --> CRUD{Requested action}
    CRUD -->|read| READ[perm_view]
    CRUD -->|create| CREATE[perm_add]
    CRUD -->|update| UPDATE[perm_edit]
    CRUD -->|delete| DELETE[perm_delete]
    CRUD -->|export| EXPORT[perm_export]
    CRUD -->|approve| APPROVE[perm_approve]
    READ --> FILTER[Mandatory tenant/scope filter]
    CREATE --> FILTER
    UPDATE --> FILTER
    DELETE --> FILTER
    EXPORT --> FILTER
    APPROVE --> FILTER
    FILTER --> RESULT[Allow only rows in authorized organization and OU scope]
```

## 5. Super Admin Boundary

```mermaid
flowchart TD
    REQUEST[Super Admin request] --> GLOBAL{Global Super Admin?}
    GLOBAL -- Yes --> GLOBALROLE[Use a separately protected global role/claim]
    GLOBALROLE --> ALL[May administer organizations, users, roles, modules and menus]
    GLOBAL -- No --> ORGADMIN[Organization-scoped administrator]
    ORGADMIN --> OWNED[May administer only assigned organization and its data]
    ALL --> AUDIT[Audit every privileged change]
    OWNED --> AUDIT
```

A global Super Admin should be represented by a protected system role or claim, not by a normal organization role with a special name. A name such as `Super Admin` is not an authorization mechanism.
