# RBAC Implementation Guide

## 1. Authorization Contract

Implement authorization as a server-side policy, not as a frontend visibility feature.

For every protected request, the server must know:

```text
user_id
organization_id
operating_unit (nullable integer from user_access_rights)
resource/module/menu
action: view | add | edit | delete | export | approve
```

The request is allowed only when all of these are true:

1. The session is valid and the user is active and not deleted.
2. An active, non-deleted `user_access_rights` row exists for the selected organization.
3. `users.role_id` resolves to an active role allowed for that organization.
4. A role grants the requested action for the resource.
5. The target row belongs to the selected organization.
6. If `user_access_rights.operating_unit` is set, the target row matches that existing integer scope.

Never rely on menu visibility, a client-supplied role, or a hidden organization field as authorization.

## 2. Fit the Existing Schema

No table columns, tables, indexes, or constraints need to change for this implementation. Apply these rules in the service layer:

- `user_access_rights` grants a user access to many organizations. Require `is_active = true` and `is_deleted = false`.
- `user_access_rights.operating_unit` is the optional integer scope. A null value means organization-wide access; a value means the request's business row must match that integer.
- `users.organization_id` is the default organization at login, not the complete membership list.
- `users.role_id` is the effective role because the supplied `user_roles` index makes one role per user the only reliable current behavior. `user_roles` may be read for compatibility, but do not claim multi-role support without changing that index.
- `roles.organization_id` must equal the selected organization, unless the role is an explicitly seeded global system role.
- `organizations.operating_unit_id`, `user_access_rights.operating_unit`, and the business table's existing operating-unit field are compared as integers by application logic. Do not join them to `operating_units.id`, which is a UUID.
- `operating_units.org_id` is an existing integer mapping. Validate the mapping when an operating unit is created or selected; do not assume the database enforces it.

The tradeoff is intentional: a user can belong to many organizations, but with the current unique access index can have one operating-unit scope per organization, and with the current role indexes can have one effective role.

## 3. Permission Model

Use stable permission codes such as:

```text
CUSTOMER.VIEW
CUSTOMER.ADD
CUSTOMER.EDIT
CUSTOMER.DELETE
CUSTOMER.EXPORT
CUSTOMER.APPROVE
```

`permissions` is the catalog of actions. `role_permissions` grants those actions. `role_menus` controls navigation exposure and can also carry the CRUD flags used by the UI. The server must still check permission codes from `role_permissions`; `role_menus` must not be the only security check.

Recommended rule:

- `role_permissions`: authoritative API and service authorization.
- `role_menus`: navigation and screen-level capability hints.
- `app_modules` and `app_menus`: metadata and hierarchy, never user-controlled authorization input.

Keep module, menu, and permission ownership consistent. A role assignment query should reject a role-menu row if `module_id` does not match the menu's module.

## 4. Runtime Authorization Service

Create one reusable service used by controllers, handlers, background jobs, and exports:

```text
authorize(context, resource, action, target_id?) -> AuthorizationDecision
```

Example context:

```json
{
  "userId": "...",
  "organizationId": "...",
    "operatingUnit": 101,
  "sessionId": "..."
}
```

The service should:

1. Validate the session and active user.
2. Validate membership through `user_access_rights`.
3. Load `users.role_id` and verify the role's organization.
4. Resolve the permission code for `resource` and `action`.
5. Check `role_permissions`.
6. Check the resource row's organization and operating-unit scope.
7. Return an allow/deny decision with a correlation ID.

Fail closed on missing context, missing permission, deleted rows, or ambiguous organization selection.

## 5. Query Enforcement

Use the existing organization and operating-unit columns in each business table. Do not add or rename columns. The API must know which existing field represents organization and which existing integer field represents operating-unit scope for each resource.

A read query must include the scope predicate in the same query as the data access:

```sql
SELECT c.*
FROM public.customers AS c
WHERE c.organization_id = :organization_id
    AND (:user_operating_unit IS NULL OR c.operating_unit = :user_operating_unit)
  AND c.is_deleted = false;
```

For update and delete, repeat the scope predicate in the write statement. Do not select an ID first and then update by ID alone:

```sql
UPDATE public.customers
SET name = :name, updated_at = now()
WHERE id = :id
  AND organization_id = :organization_id
    AND (:user_operating_unit IS NULL OR operating_unit = :user_operating_unit)
  AND is_deleted = false;
```

Require exactly one affected row. Return a not-found or forbidden response according to the API policy, but do not reveal whether an ID exists in another organization.

RLS is not part of this schema-preserving implementation because it requires policies on every business table and assumes consistent column names. Enforce the predicates in the service/repository layer and add integration tests for every endpoint.

## 6. API and UI Flow

### Login

1. Verify the password against `password_hash` using a modern password hashing library.
2. Verify `users.is_active = true` and `users.is_deleted = false`.
3. Create a random, opaque session token; store it in the existing `user_sessions` table.
4. Load active organization memberships from `user_access_rights`.
5. Require an organization selection when more than one is available.
6. Put only the user and session identifiers in the token. Load permissions server-side or use a short-lived cache.

### Current-user endpoint

Return the selected organization, allowed organization list, operating-unit scope, menu tree, and UI capability hints from the authorization service. This endpoint improves UX; it does not replace API authorization.

### Protected endpoint

```text
authenticate -> select organization -> authorize action -> apply row scope -> execute -> audit
```

Do not accept `organization_id`, `user_id`, `role_id`, or permission flags from the client as trusted values. The selected organization can be supplied by the client, but the server must validate it against membership on every request or trusted context refresh.

## 7. Super Admin and Administration Rules

Create a seeded system role such as `GLOBAL_SUPER_ADMIN` with an immutable identifier. Protect assignments to it with a separate administrative workflow and application audit logging.

A global Super Admin may:

- create, update, deactivate, and delete organizations;
- create operating units under an organization;
- create modules, menus, and permission definitions;
- create users and assign memberships;
- create organization roles and assign permissions and menus;
- revoke sessions and inspect audit events.

An organization administrator may perform only the operations allowed by its organization-scoped role. It must not create or modify another organization's roles, memberships, or data.

Prevent privilege escalation:

- Do not allow an organization admin to grant `GLOBAL_SUPER_ADMIN`.
- Do not allow a role admin to assign permissions that the admin does not itself hold, unless this is an explicit global-admin operation.
- Do not allow role/menu assignments across organizations.
- Protect system roles and system permissions from deletion.
- Use a transaction for user creation plus `user_access_rights` and role assignment.

## 8. Audit and Operational Controls

Use the application's existing logging or external audit sink for security-sensitive actions because no audit table is being added. Audit successful and denied decisions for login, organization switching, user and role changes, permission changes, exports, approvals, and deletes. Never store passwords, raw session tokens, or sensitive secrets in logs.

Cache permission snapshots by `(user_id, organization_id, role_id)`. Use a short TTL and clear the cache after changes to `user_access_rights`, `users.role_id`, `role_permissions`, or `role_menus`. Revoke or invalidate sessions using the existing `user_sessions` rows when access is removed.

Add tests for:

- a user in two organizations seeing only the selected organization's rows;
- a user restricted to one operating unit;
- the current one-role behavior being enforced consistently;
- a deleted or inactive role granting nothing;
- update/delete attempts against another organization;
- organization-wide versus one operating-unit scope;
- global Super Admin versus organization administrator;
- menu hidden but API permission present, and API permission absent;
- role assignment and membership changes invalidating cached permissions.

## 9. Implementation Order Without Schema Changes

1. Back up the database and identify invalid organization/operating-unit mappings.
2. Seed modules, menus, permissions, and the global Super Admin role using the existing tables.
3. Create users and set the existing `users.organization_id` and `users.role_id` values.
4. Insert one active `user_access_rights` row for every organization the user may access.
5. Set `user_access_rights.operating_unit` to null for organization-wide access or to the permitted integer scope.
6. Load permissions from `role_permissions` and navigation from `role_menus`.
7. Implement one authorization middleware and one repository scope predicate per business resource.
8. Add application-level validation for the integer operating-unit mapping because the supplied foreign keys cannot enforce it.
9. Add integration tests for cross-organization and cross-operating-unit access.
10. Add application audit logging and short-lived permission caching.

## 10. Definition of Done

The implementation is complete when a test can prove that the same user, with the same session, receives different results after switching organizations, cannot read or mutate an unassigned operating unit, cannot call a hidden capability through a direct API request, and loses access immediately after a `user_access_rights` or role change.
