# Assign a role, PES module, menus, and permissions

Use this when **users already exist** in the Users table. You do not recreate the user. You attach a **role**, then attach **organizations**. Menus and API permissions belong to the **role**, not to the user row.

Sign in as **Super Admin**. After you change a user’s role, membership, or a role’s menus/permissions, that user must **sign out and sign in again** so the token picks up the new access.

## What each piece does

| You set this | Where | Effect |
|---|---|---|
| Role | Users → Edit → Role | One job template per person (`users.role_id` / `user_roles`) |
| Organizations | User organizations | Which plants/orgs they may work in (`user_access_rights`) |
| Module | Modules | Sidebar group (example: **PES**) (`app_modules`) |
| Menus | Menus, then Roles → Edit → Menus | Screens under that module (`app_menus` + `role_menus`) |
| Permissions | Permissions, then Roles → Edit → Permissions | API access (`permissions` + `role_permissions`) |

Do **not** try to tick menus on the user Edit dialog. Extra user menu checkboxes are not membership. Navigation comes from the role.

```text
User (already in table)
  → one Role
       → permission codes (API)
       → two PES menus (sidebar)
  → one or more Organizations (where they can work)
```

## Worked example

This guide uses:

- An existing user from the Users grid (for example Karthikeyan)
- A catalog role named **PES Operator**
- A module **PES**
- Two menus: **PES Overview** and **PES Transactions**
- Two permission codes: `pes.view` and `pes.edit`

Replace names, paths, and codes with your real PES screens.

---

## Step 1 — Confirm the user exists

1. Open **Admin → Users** (`/dashboard/users`).
2. Find the person in the table. Do not use Add user.
3. Note **Name**, **Email**, **Role** (often `—`), and **Default org** (often `—`).

You will assign the role in step 6 and organizations in step 7.

---

## Step 2 — Add the PES module

1. Open **Admin → Modules** (`/dashboard/modules` or `/dashboard/apps`).
2. Click **Add module**.
3. Fill:

   | Field | Example |
   |---|---|
   | Name | `PES` |
   | Code | `PES` |
   | Description | `Plant / PES workspace` |
   | Sort order | `30` |

4. Click **Create**. Confirm **PES** appears in the modules table.

---

## Step 3 — Add two PES menus

Menus must belong to the PES module. The **Path** should match a real UI route. If the screen is not built yet, the item still shows in the sidebar but navigation may bounce to Account home.

1. Open **Admin → Menus** (`/dashboard/menus`).
2. Click **Add menu**.
3. Create the first screen:

   | Field | Example |
   |---|---|
   | Module | `PES` (dropdown) |
   | Name | `PES Overview` |
   | Code | leave blank to auto-generate, or `PES001` |
   | Path | `/dashboard/pes` (your real path) |
   | Permission code | `pes.view` |

4. Click **Create**.
5. Click **Add menu** again for the second screen:

   | Field | Example |
   |---|---|
   | Module | `PES` |
   | Name | `PES Transactions` |
   | Code | `PES002` |
   | Path | `/dashboard/pes/transactions` |
   | Permission code | `pes.edit` |

6. On Menus, set **Module** filter to **PES** and confirm both rows.

Permission code on the menu is a hint for the catalog. The role still needs the same codes ticked under Permissions (step 4–5).

---

## Step 4 — Add permission codes (if they are not in the catalog)

1. Open **Admin → Permissions** (`/dashboard/permissions`).
2. If `pes.view` / `pes.edit` are missing, click **Add permission**.
3. Create:

   | Name | Code | Module |
   |---|---|---|
   | View PES | `pes.view` | `PES` (module dropdown) |
   | Edit PES | `pes.edit` | `PES` |

4. Repeat for the second code.
5. Confirm both codes in the permissions table.

Use lowercase dotted codes (`pes.view`). The API stores them in lowercase.

---

## Step 5 — Create or edit the role (permissions + two menus)

Menus and permission codes are granted on the **role**.

### New role

1. Open **Admin → Roles** (`/dashboard/roles`).
2. Click **Create role** (no organization filter).
3. **Role name:** `PES Operator`.
4. **Description:** optional.
5. **Permissions:** tick `pes.view` and `pes.edit` (and any other APIs this job needs).
6. **Menus:** under **PES**, tick:

   - **PES Overview** — leave **Read** on; add Create/Update/Delete only if that screen should allow those actions
   - **PES Transactions** — tick **Read**, and **Create** / **Update** if they may change data

7. Click **Create role**.

### Existing role

1. On Roles, click **Edit** on the role.
2. Tick the same two PES menus and permission codes.
3. Click save.

`role_permissions` is what the API checks. `role_menus` is what the sidebar shows. Tick **both**.

---

## Step 6 — Assign that role to the existing user

1. Open **Admin → Users**.
2. Click **Edit** on the user row (not Super Admin; that row is protected).
3. **Role:** choose **PES Operator**.
4. Save.

The Users grid **Role** column should show `PES Operator`.

One person has one role. If they need PES plus other modules, put those menus and permissions on the **same** role (or edit this role). Do not expect a second role on the same user.

---

## Step 7 — Assign organizations the user may work in

A role does not choose the plant. Membership does.

1. Open **Admin → User organizations** (`/dashboard/user-organizations`).
2. **User:** select the same person.
3. Tick every organization they are allowed to enter.
4. Click **Save organizations**.

If you save with **no** boxes ticked, they have no membership and cannot work in tenant data. The first ticked org becomes their default org on the Users grid.

---

## Step 8 — Verify as that user

1. Sign out of Super Admin (or use another browser).
2. Sign in as the user.
3. Confirm:

   - Sidebar shows a **PES** group with the two menus
   - Opening those paths works (if the screens exist)
   - APIs for PES succeed only with `pes.view` / `pes.edit` on the role
   - They can act only in organizations assigned in step 7

If menus are missing: they did not re-login, the role does not have `role_menus` for those two items, the menus are inactive, or they are still Super Admin (Super Admin sees the full catalog).

---

## Checklist (existing user → PES access)

1. [ ] User is in the Users table  
2. [ ] Module **PES** exists  
3. [ ] Two PES menus exist, with paths and permission codes  
4. [ ] `pes.view` and `pes.edit` exist in Permissions  
5. [ ] Role **PES Operator** has those permissions **and** those two menus  
6. [ ] User Edit → Role = **PES Operator**  
7. [ ] User organizations → orgs ticked and saved  
8. [ ] User signs in again and sees PES  

---

## Common mistakes

| Mistake | What happens |
|---|---|
| Create a new user instead of editing the row | Duplicate person |
| Tick menus on the user form | Nothing stored for navigation |
| Add PES menus but skip the role | User has no PES sidebar |
| Add role menus but skip permission codes | Screen may show; API returns 403 |
| Skip User organizations | User has a role but cannot work in an org |
| Expect two roles on one user | Schema allows one effective role |
| Forget re-login | Old token, old menus and permissions |
