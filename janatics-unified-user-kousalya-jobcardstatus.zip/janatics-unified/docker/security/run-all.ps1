# Run SAST + SCA + secrets (+ optional DAST/image) and build HTML evidence from SARIF.
# Outputs: docker/security/reports/*.sarif + security-evidence.html
#
# Examples (PowerShell):
#   .\docker\security\run-all.ps1
#   $env:SECURITY_ALL='1'; .\docker\security\run-all.ps1
#   $env:RUN_DAST='1'; $env:TARGET_URL='http://127.0.0.1:8080'; .\docker\security\run-all.ps1

$ErrorActionPreference = "Continue"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$ComposeFile = Join-Path $Root "docker\security\docker-compose.yml"
$Reports = Join-Path $Root "docker\security\reports"
$SarifToHtml = Join-Path $Root "docker\security\sarif-to-html.py"

New-Item -ItemType Directory -Force -Path $Reports | Out-Null
$gitkeep = Join-Path $Reports ".gitkeep"
if (-not (Test-Path $gitkeep)) { New-Item -ItemType File -Path $gitkeep | Out-Null }

if ($env:SECURITY_ALL -eq "1") {
    if (-not $env:RUN_DAST) { $env:RUN_DAST = "1" }
    if (-not $env:RUN_IMAGE_SCA) { $env:RUN_IMAGE_SCA = "1" }
    if (-not $env:WRITE_HTML) { $env:WRITE_HTML = "1" }
}
if (-not $env:WRITE_HTML) { $env:WRITE_HTML = "1" }

function Invoke-Step {
    param([string]$Name, [scriptblock]$Action)
    Write-Host "==> $Name"
    & $Action
    if ($LASTEXITCODE -eq 0) {
        Write-Host "    ok"
    } else {
        Write-Host "    finished with findings or non-zero exit (reports still written if supported)"
    }
}

function Invoke-Python {
    param([string[]]$PythonArgs)
    python @PythonArgs 2>$null
    if ($LASTEXITCODE -ne 0) {
        python3 @PythonArgs
    }
}

Write-Host "==> Pulling scanner images (Docker layer cache reused on later runs)"
& docker compose -f $ComposeFile pull semgrep trivy gitleaks zap

Invoke-Step "SAST Semgrep → semgrep.sarif" {
    & docker compose -f $ComposeFile run --rm --no-deps semgrep
}

Invoke-Step "SCA Trivy fs → trivy.sarif" {
    & docker compose -f $ComposeFile run --rm --no-deps trivy
}

Invoke-Step "Secrets Gitleaks → gitleaks.sarif" {
    & docker compose -f $ComposeFile run --rm --no-deps gitleaks
}

Invoke-Step "Frontend SAST/SCA → semgrep-ui.sarif + trivy-ui.sarif" {
    & docker compose -f $ComposeFile pull semgrep-ui trivy-ui
    & docker compose -f $ComposeFile run --rm --no-deps semgrep-ui
    & docker compose -f $ComposeFile run --rm --no-deps trivy-ui
}

if ($env:RUN_DAST -eq "1") {
    if (-not $env:TARGET_URL) { $env:TARGET_URL = "http://127.0.0.1:8080" }
    Invoke-Step "DAST OWASP ZAP → zap reports ($($env:TARGET_URL))" {
        & docker compose -f $ComposeFile run --rm --no-deps zap
    }
    $zapSarif = Join-Path $Reports "zap.sarif"
    $zapJson = Join-Path $Reports "zap-report.json"
    if (-not (Test-Path $zapSarif) -and (Test-Path $zapJson)) {
        $converter = Join-Path $Root "docker\security\zap-to-sarif.py"
        Invoke-Python @($converter, $zapJson, $zapSarif)
    }
} else {
    Write-Host "==> Skipping DAST (set `$env:RUN_DAST=1 or `$env:SECURITY_ALL=1; API should be up)"
}

if ($env:RUN_IMAGE_SCA -eq "1") {
    Invoke-Step "SCA Trivy image jusplatform:local → trivy-image.sarif" {
        & docker compose -f $ComposeFile --profile image run --rm --no-deps trivy-image
    }
}

if ($env:BUILD_WORKSPACE -eq "1") {
    Invoke-Step "Build analysis workspace image" {
        & docker compose -f $ComposeFile --profile workspace build workspace
    }
}

if ($env:WRITE_HTML -eq "1") {
    Invoke-Step "HTML evidence from SARIF → security-evidence.html" {
        Invoke-Python @($SarifToHtml, "--reports-dir", $Reports)
    }
}

Write-Host "==> Reports:"
Get-ChildItem $Reports | Format-Table Name, Length, LastWriteTime
Write-Host "Open evidence: $Reports\security-evidence.html"
