#!/usr/bin/env bash
# Run SAST + SCA + secrets (+ optional DAST/image) and build HTML evidence from SARIF.
# Outputs: docker/security/reports/*.sarif + security-evidence.html
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
COMPOSE=(docker compose -f "$ROOT/docker/security/docker-compose.yml")
REPORTS="$ROOT/docker/security/reports"
mkdir -p "$REPORTS"
touch "$REPORTS/.gitkeep"

# Full evidence mode: DAST + image SCA + HTML (override with RUN_DAST=0 etc.)
if [[ "${SECURITY_ALL:-0}" == "1" ]]; then
  RUN_DAST="${RUN_DAST:-1}"
  RUN_IMAGE_SCA="${RUN_IMAGE_SCA:-1}"
  WRITE_HTML="${WRITE_HTML:-1}"
fi
WRITE_HTML="${WRITE_HTML:-1}"

run_step() {
  local name="$1"
  shift
  echo "==> $name"
  if "$@"; then
    echo "    ok"
  else
    echo "    finished with findings or non-zero exit (reports still written if supported)"
  fi
}

echo "==> Pulling scanner images (Docker layer cache reused on later runs)"
"${COMPOSE[@]}" pull semgrep trivy gitleaks zap

run_step "SAST Semgrep → semgrep.sarif" \
  "${COMPOSE[@]}" run --rm --no-deps semgrep

run_step "SCA Trivy fs → trivy.sarif" \
  "${COMPOSE[@]}" run --rm --no-deps trivy

run_step "Secrets Gitleaks → gitleaks.sarif" \
  "${COMPOSE[@]}" run --rm --no-deps gitleaks

run_step "Frontend SAST/SCA (Semgrep UI + Trivy UI)" \
  "$ROOT/docker/security/run-ui-scanners.sh"

if [[ "${RUN_DAST:-0}" == "1" ]]; then
  export TARGET_URL="${TARGET_URL:-http://127.0.0.1:8080}"
  run_step "DAST OWASP ZAP → zap reports ($TARGET_URL)" \
    env TARGET_URL="$TARGET_URL" "${COMPOSE[@]}" run --rm --no-deps zap
  if [[ ! -f "$REPORTS/zap.sarif" && -f "$REPORTS/zap-report.json" ]]; then
    python3 "$ROOT/docker/security/zap-to-sarif.py" \
      "$REPORTS/zap-report.json" "$REPORTS/zap.sarif" || true
  fi
else
  echo "==> Skipping DAST (set RUN_DAST=1 or SECURITY_ALL=1; API should be up)"
fi

if [[ "${RUN_IMAGE_SCA:-0}" == "1" ]]; then
  run_step "SCA Trivy image jusplatform:local → trivy-image.sarif" \
    "${COMPOSE[@]}" --profile image run --rm --no-deps trivy-image
fi

if [[ "${BUILD_WORKSPACE:-0}" == "1" ]]; then
  run_step "Build analysis workspace image" \
    "${COMPOSE[@]}" --profile workspace build workspace
fi

if [[ "$WRITE_HTML" == "1" ]]; then
  run_step "HTML evidence from SARIF → security-evidence.html" \
    python3 "$ROOT/docker/security/sarif-to-html.py" --reports-dir "$REPORTS"
fi

echo "==> Reports:"
ls -la "$REPORTS"
echo ""
echo "Open evidence: $REPORTS/security-evidence.html"
