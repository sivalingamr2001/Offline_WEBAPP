#!/usr/bin/env bash
# Frontend SAST/SCA → semgrep-ui.sarif + trivy-ui.sarif (Docker, cached volumes).
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
COMPOSE=(docker compose -f "$ROOT/docker/security/docker-compose.yml")

run_step() {
  local name="$1"
  shift
  echo "==> $name"
  if "$@"; then
    echo "    ok"
  else
    echo "    finished with findings or non-zero exit (reports still written if supported)"
  fi
}

echo "==> Pulling UI scanner images"
"${COMPOSE[@]}" pull semgrep-ui trivy-ui

run_step "SAST Semgrep UI → semgrep-ui.sarif" \
  "${COMPOSE[@]}" run --rm --no-deps semgrep-ui

run_step "SCA Trivy UI → trivy-ui.sarif" \
  "${COMPOSE[@]}" run --rm --no-deps trivy-ui

echo "==> UI security scanners complete"
