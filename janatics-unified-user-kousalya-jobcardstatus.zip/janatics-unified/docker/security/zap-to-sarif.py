#!/usr/bin/env python3
"""Convert OWASP ZAP JSON report to a minimal SARIF 2.1 file."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <zap-report.json> <zap.sarif>", file=sys.stderr)
        return 2

    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    if not src.exists():
        print(f"Missing ZAP report: {src}", file=sys.stderr)
        return 1

    data = json.loads(src.read_text(encoding="utf-8"))
    results = []
    sites = data.get("site") or []
    for site in sites:
        for alert in site.get("alerts", []):
            risk = str(alert.get("riskdesc", "")).lower()
            level = "note"
            if "high" in risk:
                level = "error"
            elif "medium" in risk:
                level = "warning"
            elif "informational" in risk:
                level = "none"

            results.append(
                {
                    "ruleId": str(alert.get("pluginid", alert.get("alertRef", "zap"))),
                    "level": level,
                    "message": {"text": alert.get("alert", alert.get("name", "ZAP finding"))},
                    "properties": {
                        "confidence": alert.get("confidence"),
                        "risk": alert.get("riskdesc"),
                        "cweid": alert.get("cweid"),
                    },
                }
            )

    sarif = {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "OWASP ZAP",
                        "informationUri": "https://www.zaproxy.org/",
                    }
                },
                "results": results,
            }
        ],
    }
    dst.write_text(json.dumps(sarif, indent=2), encoding="utf-8")
    print(f"Wrote {dst} ({len(results)} results)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
