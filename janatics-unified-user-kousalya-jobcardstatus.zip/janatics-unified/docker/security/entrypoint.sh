#!/usr/bin/env bash
# Analysis workspace entrypoint (docker/security/Dockerfile).
# Scanners themselves run via docker compose services for image/volume cache reuse.
set -euo pipefail

cat <<'EOF'
JUSPlatform security analysis workspace

Ship image:    JUSPlatform/Dockerfile (+ root docker-compose.yml)
Analyze stack: docker/security/docker-compose.yml

From repo root on the host:
  ./docker/security/run-all.sh
  RUN_DAST=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh
  RUN_IMAGE_SCA=1 ./docker/security/run-all.sh

SARIF outputs: docker/security/reports/*.sarif
Caches:        Docker named volumes (semgrep_cache, trivy_cache, …)
EOF

if [[ "${1:-}" == "zap-to-sarif" ]]; then
  shift
  exec python3 /usr/local/bin/zap-to-sarif "$@"
fi

exit 0
