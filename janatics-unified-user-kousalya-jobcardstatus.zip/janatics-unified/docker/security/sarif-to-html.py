#!/usr/bin/env python3
"""Build HTML evidence reports dynamically from SARIF files (stdlib only)."""
from __future__ import annotations

import argparse
import html
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


LEVEL_ORDER = {"error": 0, "warning": 1, "note": 2, "none": 3, "unknown": 4}
LEVEL_LABEL = {
    "error": "High / Error",
    "warning": "Medium / Warning",
    "note": "Low / Note",
    "none": "Info / None",
    "unknown": "Unknown",
}


def load_sarif(path: Path) -> dict[str, Any] | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"Skip {path.name}: {exc}")
        return None


def normalize_level(raw: str | None) -> str:
    if not raw:
        return "unknown"
    level = str(raw).lower()
    if level in LEVEL_ORDER:
        return level
    return "unknown"


def extract_results(path: Path, data: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for run in data.get("runs") or []:
        tool = ((run.get("tool") or {}).get("driver") or {}).get("name") or path.stem
        for result in run.get("results") or []:
            level = normalize_level(result.get("level"))
            msg = ((result.get("message") or {}).get("text")) or ""
            loc = ""
            locations = result.get("locations") or []
            if locations:
                phys = (locations[0].get("physicalLocation") or {})
                art = (phys.get("artifactLocation") or {}).get("uri") or ""
                region = phys.get("region") or {}
                line = region.get("startLine")
                loc = f"{art}:{line}" if line else art
            rows.append(
                {
                    "tool": tool,
                    "ruleId": str(result.get("ruleId") or ""),
                    "level": level,
                    "message": msg,
                    "location": loc,
                    "source": path.name,
                }
            )
    return rows


def counts_by_level(rows: list[dict[str, Any]]) -> dict[str, int]:
    out = {k: 0 for k in LEVEL_ORDER}
    for row in rows:
        out[row["level"]] = out.get(row["level"], 0) + 1
    return out


def render_html(
    title: str,
    generated_at: str,
    sources: list[str],
    rows: list[dict[str, Any]],
) -> str:
    totals = counts_by_level(rows)
    by_tool: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_tool.setdefault(row["tool"], []).append(row)

    def esc(value: Any) -> str:
        return html.escape(str(value), quote=True)

    cards = "".join(
        f'<div class="card {lvl}"><div class="n">{totals.get(lvl, 0)}</div>'
        f"<div class=\"l\">{esc(LEVEL_LABEL[lvl])}</div></div>"
        for lvl in ("error", "warning", "note", "none", "unknown")
        if totals.get(lvl, 0) or lvl in ("error", "warning", "note")
    )

    source_list = "".join(f"<li><code>{esc(s)}</code></li>" for s in sources)

    sections = []
    for tool, tool_rows in sorted(by_tool.items(), key=lambda x: x[0].lower()):
        tool_rows = sorted(tool_rows, key=lambda r: (LEVEL_ORDER[r["level"]], r["ruleId"]))
        body = "".join(
            "<tr>"
            f'<td><span class="pill {esc(r["level"])}">{esc(r["level"])}</span></td>'
            f"<td><code>{esc(r['ruleId'])}</code></td>"
            f"<td>{esc(r['message'])}</td>"
            f"<td><code>{esc(r['location'])}</code></td>"
            f"<td><code>{esc(r['source'])}</code></td>"
            "</tr>"
            for r in tool_rows
        )
        sections.append(
            f"""
<section class="tool">
  <h2>{esc(tool)} <small>({len(tool_rows)})</small></h2>
  <table>
    <thead>
      <tr><th>Level</th><th>Rule</th><th>Message</th><th>Location</th><th>SARIF</th></tr>
    </thead>
    <tbody>{body or '<tr><td colspan="5">No findings</td></tr>'}</tbody>
  </table>
</section>
"""
        )

    all_body = "".join(
        "<tr>"
        f"<td>{esc(r['tool'])}</td>"
        f'<td><span class="pill {esc(r["level"])}">{esc(r["level"])}</span></td>'
        f"<td><code>{esc(r['ruleId'])}</code></td>"
        f"<td>{esc(r['message'])}</td>"
        f"<td><code>{esc(r['location'])}</code></td>"
        "</tr>"
        for r in sorted(rows, key=lambda r: (LEVEL_ORDER[r["level"]], r["tool"], r["ruleId"]))
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>{esc(title)}</title>
  <style>
    :root {{
      --bg: #0f1419; --panel: #1a2332; --text: #e7ecf3; --muted: #9aa7b8;
      --error: #e35d6a; --warning: #e0a800; --note: #5b9fd4; --none: #6c7a89; --line: #2a3648;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0; font-family: "Segoe UI", system-ui, sans-serif;
      background: var(--bg); color: var(--text); line-height: 1.45;
    }}
    header, main {{ max-width: 1200px; margin: 0 auto; padding: 1.25rem 1.5rem; }}
    header {{ border-bottom: 1px solid var(--line); }}
    h1 {{ margin: 0 0 .35rem; font-size: 1.6rem; }}
    .meta {{ color: var(--muted); font-size: .95rem; }}
    .cards {{ display: flex; flex-wrap: wrap; gap: .75rem; margin: 1rem 0 1.25rem; }}
    .card {{
      background: var(--panel); border: 1px solid var(--line); border-radius: 10px;
      min-width: 120px; padding: .75rem 1rem;
    }}
    .card .n {{ font-size: 1.5rem; font-weight: 700; }}
    .card .l {{ color: var(--muted); font-size: .85rem; }}
    .card.error .n {{ color: var(--error); }}
    .card.warning .n {{ color: var(--warning); }}
    .card.note .n {{ color: var(--note); }}
    section.tool {{
      background: var(--panel); border: 1px solid var(--line); border-radius: 12px;
      padding: 1rem; margin: 1rem 0;
    }}
    h2 {{ margin: 0 0 .75rem; font-size: 1.15rem; }}
    h2 small {{ color: var(--muted); font-weight: 500; }}
    table {{ width: 100%; border-collapse: collapse; font-size: .92rem; }}
    th, td {{ border-top: 1px solid var(--line); padding: .55rem .45rem; text-align: left; vertical-align: top; }}
    th {{ color: var(--muted); font-weight: 600; }}
    code {{ font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: .85em; }}
    .pill {{
      display: inline-block; border-radius: 999px; padding: .1rem .55rem;
      font-size: .75rem; font-weight: 600; text-transform: uppercase;
      background: #2a3648; color: var(--text);
    }}
    .pill.error {{ background: rgba(227,93,106,.2); color: var(--error); }}
    .pill.warning {{ background: rgba(224,168,0,.18); color: var(--warning); }}
    .pill.note {{ background: rgba(91,159,212,.2); color: var(--note); }}
    .pill.none, .pill.unknown {{ background: rgba(108,122,137,.25); color: var(--muted); }}
    ul.sources {{ color: var(--muted); }}
    footer {{ max-width: 1200px; margin: 0 auto 2rem; padding: 0 1.5rem; color: var(--muted); font-size: .85rem; }}
  </style>
</head>
<body>
  <header>
    <h1>{esc(title)}</h1>
    <div class="meta">Generated {esc(generated_at)} · {len(rows)} finding(s) from {len(sources)} SARIF file(s)</div>
    <div class="cards">{cards}</div>
    <p class="meta">Source artifacts</p>
    <ul class="sources">{source_list or "<li>None</li>"}</ul>
  </header>
  <main>
    {"".join(sections) if sections else "<p>No findings across SARIF inputs.</p>"}
    <section class="tool">
      <h2>All findings <small>({len(rows)})</small></h2>
      <table>
        <thead>
          <tr><th>Tool</th><th>Level</th><th>Rule</th><th>Message</th><th>Location</th></tr>
        </thead>
        <tbody>{all_body or '<tr><td colspan="5">No findings</td></tr>'}</tbody>
      </table>
    </section>
  </main>
  <footer>
    Evidence HTML rendered dynamically from SARIF (Semgrep / Trivy / Gitleaks / ZAP — backend + UI).
    Keep companion <code>*.sarif</code> files with this report for machine-readable audit trail.
  </footer>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "inputs",
        nargs="*",
        help="SARIF files (default: all *.sarif in --reports-dir)",
    )
    parser.add_argument(
        "--reports-dir",
        default="docker/security/reports",
        help="Directory to scan for *.sarif and write HTML",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Output HTML path (default: <reports-dir>/security-evidence.html)",
    )
    parser.add_argument("--title", default="Janatics Unified Suite security evidence")
    args = parser.parse_args()

    reports_dir = Path(args.reports_dir)
    reports_dir.mkdir(parents=True, exist_ok=True)

    if args.inputs:
        paths = [Path(p) for p in args.inputs]
    else:
        paths = sorted(reports_dir.glob("*.sarif"))

    rows: list[dict[str, Any]] = []
    sources: list[str] = []
    for path in paths:
        if not path.exists():
            print(f"Missing: {path}")
            continue
        data = load_sarif(path)
        if data is None:
            continue
        sources.append(path.name)
        rows.extend(extract_results(path, data))

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    out = Path(args.out) if args.out else reports_dir / "security-evidence.html"
    out.write_text(
        render_html(args.title, stamp, sources, rows),
        encoding="utf-8",
    )

    # Also write a stamped copy for evidence retention
    stamped = reports_dir / f"security-evidence-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.html"
    stamped.write_text(out.read_text(encoding="utf-8"), encoding="utf-8")

    print(f"Wrote {out} ({len(rows)} findings from {len(sources)} SARIF)")
    print(f"Wrote {stamped}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
