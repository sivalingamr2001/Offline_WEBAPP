#!/usr/bin/env bash
# Start Jenkins + reports nginx (Docker-only CI controller).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COMPOSE=(docker compose -f "$ROOT/docker/jenkins/docker-compose.yml")

if getent group docker >/dev/null 2>&1; then
  export DOCKER_GID="$(getent group docker | cut -d: -f3)"
else
  export DOCKER_GID="${DOCKER_GID:-984}"
  echo "Warning: 'docker' group not found; using DOCKER_GID=${DOCKER_GID}"
fi

echo "==> Building Jenkins image (docker-ce-cli + compose plugin + SVN/Git plugins)"
"${COMPOSE[@]}" build jenkins

echo "==> Starting Jenkins + reports nginx"
JENKINS_HTTP_PORT="${JENKINS_HTTP_PORT:-8085}" \
REPORTS_HTTP_PORT="${REPORTS_HTTP_PORT:-8091}" \
  "${COMPOSE[@]}" up -d

echo ""
echo "Jenkins:  http://localhost:${JENKINS_HTTP_PORT:-8085}"
echo "Reports:  http://localhost:${REPORTS_HTTP_PORT:-8091}/jusplatform-backend/latest/security-evidence.html"
echo ""
echo "Initial admin password:"
echo "  ${COMPOSE[@]} exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword"
echo ""
echo "Create a Pipeline job → Pipeline script from SCM → Jenkinsfile (Subversion or Git/Forgejo)"
