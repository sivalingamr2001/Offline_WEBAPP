#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
docker compose -f "$ROOT/docker/jenkins/docker-compose.yml" down
echo "Jenkins stopped (volumes jusplatform_jenkins_home + jusplatform_jenkins_reports kept)"
