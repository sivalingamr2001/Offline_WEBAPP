#!/usr/bin/env bash
# Start ship stack. If host already has PostgreSQL on :5432, run API only
# against host.docker.internal; otherwise start container PostgreSQL on host :5433.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COMPOSE=(docker compose -f "$ROOT/docker-compose.yml")
POSTGRES_HOST_PORT="${POSTGRES_HOST_PORT:-5433}"

port_in_use() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    ss -ltn 2>/dev/null | grep -qE ":${port}\\s" && return 0
  fi
  if command -v nc >/dev/null 2>&1; then
    nc -z 127.0.0.1 "$port" >/dev/null 2>&1 && return 0
  fi
  # bash /dev/tcp fallback
  (echo >/dev/tcp/127.0.0.1/"$port") >/dev/null 2>&1 && return 0
  return 1
}

if [[ "${FORCE_COMPOSE_DB:-0}" == "1" ]]; then
  echo "==> FORCE_COMPOSE_DB=1 — starting API + container PostgreSQL (host :${POSTGRES_HOST_PORT})"
  profiles=(--profile with-db)
  if [[ "${FORCE_COMPOSE_REDIS:-0}" == "1" ]]; then
    profiles+=(--profile with-redis)
    export REDIS_CONNECTION="${REDIS_CONNECTION:-redis:6379,abortConnect=false}"
  fi
  POSTGRES_HOST_PORT="$POSTGRES_HOST_PORT" DB_HOST=db DB_PORT=5432 \
    "${COMPOSE[@]}" "${profiles[@]}" up --build -d
  echo "API: http://localhost:8080"
  echo "DB:  localhost:${POSTGRES_HOST_PORT} (container PostgreSQL)"
  exit 0
fi

REDIS_CONNECTION="${REDIS_CONNECTION:-host.docker.internal:6379,abortConnect=false}"
if [[ "${FORCE_COMPOSE_REDIS:-0}" == "1" ]]; then
  REDIS_CONNECTION="redis:6379,abortConnect=false"
fi
export REDIS_CONNECTION

profiles=()
if [[ "${FORCE_COMPOSE_REDIS:-0}" == "1" ]]; then
  profiles+=(--profile with-redis)
fi

if [[ "${FORCE_HOST_DB:-0}" == "1" ]] || port_in_use 5432; then
  echo "==> Host PostgreSQL detected (or FORCE_HOST_DB=1) on :5432 — starting API only"
  echo "==> Redis: $REDIS_CONNECTION"
  DB_HOST=host.docker.internal DB_PORT=5432 \
    "${COMPOSE[@]}" "${profiles[@]}" up --build -d api
  echo "API: http://localhost:8080"
  echo "DB:  host :5432 via host.docker.internal (compose PostgreSQL not started)"
else
  echo "==> No listener on :5432 — starting API + container PostgreSQL (host :${POSTGRES_HOST_PORT})"
  echo "==> Redis: $REDIS_CONNECTION"
  profiles+=(--profile with-db)
  POSTGRES_HOST_PORT="$POSTGRES_HOST_PORT" DB_HOST=db DB_PORT=5432 \
    "${COMPOSE[@]}" "${profiles[@]}" up --build -d
  echo "API: http://localhost:8080"
  echo "DB:  localhost:${POSTGRES_HOST_PORT} (container PostgreSQL)"
fi
