# Start ship stack. If host already has PostgreSQL on :5432, run API only
# against host.docker.internal; otherwise start container PostgreSQL on host :5433.
#
#   .\docker\ship-up.ps1
#   $env:FORCE_COMPOSE_DB='1'; .\docker\ship-up.ps1
#   $env:FORCE_HOST_DB='1'; .\docker\ship-up.ps1

$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ComposeFile = Join-Path $Root "docker-compose.yml"
$PostgresHostPort = if ($env:POSTGRES_HOST_PORT) { $env:POSTGRES_HOST_PORT } else { "5433" }

function Test-PortInUse([int]$Port) {
    try {
        $listeners = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue
        if ($listeners) { return $true }
    } catch { }
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $async = $client.BeginConnect("127.0.0.1", $Port, $null, $null)
        $ok = $async.AsyncWaitHandle.WaitOne(300)
        if ($ok -and $client.Connected) {
            $client.Close()
            return $true
        }
        $client.Close()
    } catch { }
    return $false
}

if ($env:FORCE_COMPOSE_DB -eq "1") {
    Write-Host "==> FORCE_COMPOSE_DB=1 — starting API + container PostgreSQL (host :$PostgresHostPort)"
    $env:POSTGRES_HOST_PORT = $PostgresHostPort
    $env:DB_HOST = "db"
    $env:DB_PORT = "5432"
    docker compose -f $ComposeFile --profile with-db up --build -d
    Write-Host "API: http://localhost:8080"
    Write-Host "DB:  localhost:$PostgresHostPort (container PostgreSQL)"
    exit 0
}

if (($env:FORCE_HOST_DB -eq "1") -or (Test-PortInUse 5432)) {
    Write-Host "==> Host PostgreSQL detected (or FORCE_HOST_DB=1) on :5432 — starting API only"
    $env:DB_HOST = "host.docker.internal"
    $env:DB_PORT = "5432"
    docker compose -f $ComposeFile up --build -d api
    Write-Host "API: http://localhost:8080"
    Write-Host "DB:  host :5432 via host.docker.internal (compose PostgreSQL not started)"
} else {
    Write-Host "==> No listener on :5432 — starting API + container PostgreSQL (host :$PostgresHostPort)"
    $env:POSTGRES_HOST_PORT = $PostgresHostPort
    $env:DB_HOST = "db"
    $env:DB_PORT = "5432"
    docker compose -f $ComposeFile --profile with-db up --build -d
    Write-Host "API: http://localhost:8080"
    Write-Host "DB:  localhost:$PostgresHostPort (container PostgreSQL)"
}
