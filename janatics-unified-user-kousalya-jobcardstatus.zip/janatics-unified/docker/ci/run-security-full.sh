#!/usr/bin/env bash
# Full security: ship image + API stack + DAST + container scan (all Docker, cached).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

TARGET_URL="${TARGET_URL:-http://127.0.0.1:8080}"
export TARGET_URL

cleanup() {
  echo "==> Stopping ship stack"
  "${SHIP_COMPOSE[@]}" --profile with-db down --remove-orphans 2>/dev/null || true
}
trap cleanup EXIT

echo "==> Build ship image jusplatform:local"
docker build -f "$ROOT/JUSPlatform/Dockerfile" -t jusplatform:local "$ROOT"

echo "==> Start API + MariaDB for DAST (isolated compose DB)"
FORCE_COMPOSE_DB=1 "${ROOT}/docker/ship-up.sh"

echo "==> Wait for API"
for i in $(seq 1 90); do
  if curl -sf "${TARGET_URL}/api" >/dev/null 2>&1; then
    echo "    API ready"
    break
  fi
  if [[ "$i" -eq 90 ]]; then
    echo "API did not become ready at ${TARGET_URL}" >&2
    exit 1
  fi
  sleep 2
done

echo "==> Full security scan (SAST/SCA/secrets/DAST/image)"
SECURITY_ALL=1 RUN_DAST=1 RUN_IMAGE_SCA=1 WRITE_HTML=1 \
  "$ROOT/docker/security/run-all.sh"

echo "==> Full security scan complete"
