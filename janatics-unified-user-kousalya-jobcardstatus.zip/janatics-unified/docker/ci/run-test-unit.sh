#!/usr/bin/env bash
# Run unit tests inside Docker (no host .NET SDK required).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

TEST_PROJECT="$ROOT/tests/JUSPlatform.UnitTests/JUSPlatform.UnitTests.csproj"

echo "==> Unit tests (Docker)"
"${CI_COMPOSE[@]}" run --rm --no-deps dotnet-test-unit
echo "==> Unit tests passed"
