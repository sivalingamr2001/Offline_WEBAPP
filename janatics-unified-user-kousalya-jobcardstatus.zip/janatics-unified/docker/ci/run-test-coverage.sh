#!/usr/bin/env bash
# Unit tests + Coverlet coverage + HTML report (Coverlet + ReportGenerator).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

mkdir -p "$ROOT/artifacts/test-results" "$ROOT/artifacts/coverage-report"

echo "==> Unit tests + coverage (Docker)"
"${CI_COMPOSE[@]}" run --rm --no-deps dotnet-test-coverage

echo "==> Coverage report: $ROOT/artifacts/coverage-report/index.html"
