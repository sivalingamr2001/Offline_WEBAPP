#!/usr/bin/env bash
# Shared paths for CI scripts (Jenkins / local).
set -euo pipefail

export ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export CI_COMPOSE=(docker compose -f "$ROOT/docker/ci/docker-compose.yml")
export SECURITY_COMPOSE=(docker compose -f "$ROOT/docker/security/docker-compose.yml")
export SHIP_COMPOSE=(docker compose -f "$ROOT/docker-compose.yml")
export REPORTS_DIR="$ROOT/docker/security/reports"
export REPORTS_ARCHIVE="${REPORTS_ARCHIVE:-/var/jenkins_reports}"

mkdir -p "$REPORTS_DIR"
touch "$REPORTS_DIR/.gitkeep"
