#!/usr/bin/env bash
# Render security-evidence.html from SARIF inside Docker (no host python required).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

docker run --rm \
  -v "$ROOT:/src:ro" \
  -v "$REPORTS_DIR:/reports" \
  -w /src \
  python:3.12-alpine \
  python3 docker/security/sarif-to-html.py --reports-dir /reports

echo "==> HTML: $REPORTS_DIR/security-evidence.html"
