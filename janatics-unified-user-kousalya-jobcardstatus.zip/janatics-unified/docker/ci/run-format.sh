#!/usr/bin/env bash
# Verify dotnet format inside Docker (optional gate).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

echo "==> CI format check (Docker)"
"${CI_COMPOSE[@]}" run --rm --no-deps dotnet-format
