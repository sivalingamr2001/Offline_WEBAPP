#!/usr/bin/env bash
# Restore, build, and publish JUSPlatform inside Docker (NuGet cache volume).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

echo "==> CI build (Docker, cached NuGet)"
"${CI_COMPOSE[@]}" run --rm --no-deps dotnet-build
echo "==> Publish output: $ROOT/artifacts/publish"
