#!/usr/bin/env bash
# Fast security gate for PRs: Semgrep + Trivy fs + Gitleaks (Docker, cached).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

echo "==> Pulling scanner images (layer cache reused)"
"${SECURITY_COMPOSE[@]}" pull semgrep trivy gitleaks

echo "==> SAST Semgrep"
"${SECURITY_COMPOSE[@]}" run --rm --no-deps semgrep

echo "==> SCA Trivy filesystem"
"${SECURITY_COMPOSE[@]}" run --rm --no-deps trivy

echo "==> Secrets Gitleaks"
"${SECURITY_COMPOSE[@]}" run --rm --no-deps gitleaks

echo "==> Frontend security (Semgrep UI + Trivy UI)"
"$(dirname "$0")/run-ui-security-pr.sh"

"$(dirname "$0")/run-html.sh"

echo "==> PR security scan complete"
