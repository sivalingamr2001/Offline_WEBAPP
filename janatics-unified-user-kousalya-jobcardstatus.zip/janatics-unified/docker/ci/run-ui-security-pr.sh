#!/usr/bin/env bash
# Frontend PR security: Semgrep UI + Trivy UI (Docker, SARIF).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

chmod +x "$ROOT/docker/security/run-ui-scanners.sh" 2>/dev/null || true
"$ROOT/docker/security/run-ui-scanners.sh"
