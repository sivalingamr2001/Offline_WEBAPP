#!/usr/bin/env bash
# Frontend Secure SDLC gate: oxlint + TypeScript + production build (Docker, pnpm cache).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

echo "==> UI CI (lint + typecheck + build)"
"${CI_COMPOSE[@]}" run --rm --no-deps ui-ci
echo "==> UI CI complete"
