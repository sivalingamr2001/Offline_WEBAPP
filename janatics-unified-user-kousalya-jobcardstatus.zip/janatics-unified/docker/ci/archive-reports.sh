#!/usr/bin/env bash
# Copy SARIF + HTML to persistent volume for team sharing (Jenkins nginx).
set -euo pipefail
source "$(dirname "$0")/lib.sh"

JOB="${JOB_NAME:-jusplatform-backend}"
BUILD="${BUILD_NUMBER:-local}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DEST="${REPORTS_ARCHIVE}/${JOB}/${BUILD}_${STAMP}"
LATEST="${REPORTS_ARCHIVE}/${JOB}/latest"

if [[ ! -d "$REPORTS_DIR" ]]; then
  echo "No reports dir: $REPORTS_DIR" >&2
  exit 0
fi

if [[ ! -w "$REPORTS_ARCHIVE" ]] 2>/dev/null; then
  echo "Reports archive not writable ($REPORTS_ARCHIVE) — skipping copy (artifacts still in workspace)"
  exit 0
fi

mkdir -p "$DEST"
cp -a "$REPORTS_DIR/." "$DEST/" 2>/dev/null || true

mkdir -p "$(dirname "$LATEST")"
rm -rf "$LATEST"
cp -a "$DEST" "$LATEST"

echo "==> Reports archived"
echo "    Build:  $DEST"
echo "    Latest: $LATEST"
if [[ -f "$LATEST/security-evidence.html" ]]; then
  echo "    HTML:   $LATEST/security-evidence.html"
fi
