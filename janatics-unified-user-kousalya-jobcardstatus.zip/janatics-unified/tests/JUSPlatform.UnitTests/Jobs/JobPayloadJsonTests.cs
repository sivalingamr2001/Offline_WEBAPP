using System.Text.Json;
using FluentValidation;
using JUSPlatform.Application.Jobs;

namespace JUSPlatform.UnitTests.Jobs;

public sealed class JobPayloadJsonTests
{
    private sealed record SampleJobPayload(string Code, string Email);

    [Fact]
    public void DeserializeRequired_maps_camelCase_properties()
    {
        using var doc = JsonDocument.Parse(
            """{"code":"JOB-001","email":"a@example.com"}""");

        var request = JobPayloadJson.DeserializeRequired<SampleJobPayload>(
            doc.RootElement,
            "sample-job");

        Assert.Equal("JOB-001", request.Code);
        Assert.Equal("a@example.com", request.Email);
    }

    [Fact]
    public void DeserializeRequired_rejects_non_object_payload()
    {
        using var doc = JsonDocument.Parse("\"not-an-object\"");

        Assert.Throws<ValidationException>(() =>
            JobPayloadJson.DeserializeRequired<SampleJobPayload>(
                doc.RootElement,
                "sample-job"));
    }
}
