using System.Security.Claims;
using JUSPlatform.Authorization;
using JUSPlatform.Infrastructure.Authorization;
using Microsoft.AspNetCore.Authorization;

namespace JUSPlatform.UnitTests.Authorization;

public sealed class PermissionAuthorizationHandlerTests
{
    [Fact]
    public async Task SuperAdmin_is_granted_menu_read()
    {
        var handler = new PermissionAuthorizationHandler();
        var user = new ClaimsPrincipal(new ClaimsIdentity(
            [new Claim(ClaimTypesExt.RoleName, SystemRoles.SuperAdmin)],
            authenticationType: "test"));
        var requirement = new PermissionRequirement(Permissions.MenusRead);
        var context = new AuthorizationHandlerContext([requirement], user, null);

        await handler.HandleAsync(context);

        Assert.True(context.HasSucceeded);
    }

    [Fact]
    public async Task SuperAdmin_is_granted_role_write()
    {
        var handler = new PermissionAuthorizationHandler();
        var user = new ClaimsPrincipal(new ClaimsIdentity(
            [new Claim(ClaimTypesExt.RoleName, SystemRoles.SuperAdmin)],
            authenticationType: "test"));
        var requirement = new PermissionRequirement(Permissions.RolesWrite);
        var context = new AuthorizationHandlerContext([requirement], user, null);

        await handler.HandleAsync(context);

        Assert.True(context.HasSucceeded);
    }

    [Fact]
    public async Task SuperAdmin_is_granted_job_read()
    {
        var handler = new PermissionAuthorizationHandler();
        var user = new ClaimsPrincipal(new ClaimsIdentity(
            [new Claim(ClaimTypesExt.RoleName, SystemRoles.SuperAdmin)],
            authenticationType: "test"));
        var requirement = new PermissionRequirement(Permissions.JobsRead);
        var context = new AuthorizationHandlerContext([requirement], user, null);

        await handler.HandleAsync(context);

        Assert.True(context.HasSucceeded);
    }
}
