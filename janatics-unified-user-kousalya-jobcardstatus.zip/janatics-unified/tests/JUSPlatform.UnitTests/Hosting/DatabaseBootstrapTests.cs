using JUSPlatform.Infrastructure.Hosting;

namespace JUSPlatform.UnitTests.Hosting;

public sealed class DatabaseBootstrapTests
{
    [Fact]
    public void IsSeedCommand_requires_seed_flag()
    {
        Assert.True(DatabaseBootstrap.IsSeedCommand(["--seed"]));
        Assert.True(DatabaseBootstrap.IsSeedCommand(["--SEED"]));
        Assert.False(DatabaseBootstrap.IsSeedCommand([]));
        Assert.False(DatabaseBootstrap.IsSeedCommand(["--urls", "http://localhost:5201"]));
    }
}
