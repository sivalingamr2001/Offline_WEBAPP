using JUSPlatform.Application.AppCatalog;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.UnitTests.AppCatalog;

public sealed class AppCatalogServiceTests
{
    [Fact]
    public async Task ListModulesAsync_returns_sorted_page()
    {
        var db = await CreateDbAsync();
        db.AppModules.AddRange(
            new AppModule { Code = "B", Name = "Second", SortOrder = 20 },
            new AppModule { Code = "A", Name = "First", SortOrder = 10 });
        await db.SaveChangesAsync();

        var page = await new AppCatalogService(db).ListModulesAsync(
            new PagedListQuery { Page = 1, PageSize = 25 },
            CancellationToken.None);

        Assert.Equal(2, page.TotalItems);
        Assert.Equal("A", page.Items[0].Code);
        Assert.Equal("B", page.Items[1].Code);
    }

    [Fact]
    public async Task CreateModuleAsync_duplicate_code_throws()
    {
        var db = await CreateDbAsync();
        db.AppModules.Add(new AppModule { Code = "ADMIN", Name = "Administration" });
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<ConflictException>(() =>
            new AppCatalogService(db).CreateModuleAsync(
                new CreateAppModuleRequest("admin", "Admin", null, null, 1),
                CancellationToken.None));
    }

    [Fact]
    public async Task ListMenusAsync_filters_by_module()
    {
        var db = await CreateDbAsync();
        var admin = new AppModule { Code = "ADMIN", Name = "Administration" };
        var operate = new AppModule { Code = "OPERATE", Name = "Operate" };
        db.AppModules.AddRange(admin, operate);
        await db.SaveChangesAsync();

        db.AppMenus.AddRange(
            new AppMenu { ModuleId = admin.Id, Code = "USR", Name = "Users", Path = "/dashboard/users" },
            new AppMenu { ModuleId = operate.Id, Code = "PORT", Name = "Portfolio", Path = "/dashboard/portfolio" });
        await db.SaveChangesAsync();

        var page = await new AppCatalogService(db).ListMenusAsync(
            new AppMenuListQuery { ModuleId = admin.Id, Page = 1, PageSize = 25 },
            CancellationToken.None);

        Assert.Single(page.Items);
        Assert.Equal("USR", page.Items[0].Code);
        Assert.Equal("Administration", page.Items[0].ModuleName);
        Assert.Equal(1, page.Items[0].SortOrder);
    }

    [Fact]
    public async Task ListMenusAsync_uses_menu_path_when_path_is_null()
    {
        var db = await CreateDbAsync();
        var admin = new AppModule { Code = "ADMIN", Name = "Administration" };
        db.AppModules.Add(admin);
        await db.SaveChangesAsync();
        db.AppMenus.Add(new AppMenu
        {
            ModuleId = admin.Id,
            Code = "MNU008",
            Name = "System",
            MenuPath = "/dashboard/system",
            MenuIcon = "Cpu",
            ResourceCode = null,
            Nature = "PLATFORM",
            MenuType = "SCREEN",
            IsActive = true
        });
        await db.SaveChangesAsync();

        var page = await new AppCatalogService(db).ListMenusAsync(
            new AppMenuListQuery { Page = 1, PageSize = 25 },
            CancellationToken.None);

        Assert.Equal("/dashboard/system", page.Items[0].Path);
        Assert.Equal("Cpu", page.Items[0].Icon);
    }

    [Fact]
    public async Task ListMenusAsync_orders_by_code_and_sequences_per_module()
    {
        var db = await CreateDbAsync();
        var admin = new AppModule { Code = "ADMIN", Name = "Administration" };
        db.AppModules.Add(admin);
        await db.SaveChangesAsync();

        db.AppMenus.AddRange(
            new AppMenu { ModuleId = admin.Id, Code = "MNU010", Name = "Tenth", SortOrder = 99 },
            new AppMenu { ModuleId = admin.Id, Code = "MNU001", Name = "First", SortOrder = 50 },
            new AppMenu { ModuleId = admin.Id, Code = "MNU002", Name = "Second", SortOrder = 80 });
        await db.SaveChangesAsync();

        var page = await new AppCatalogService(db).ListMenusAsync(
            new AppMenuListQuery { Page = 1, PageSize = 25 },
            CancellationToken.None);

        Assert.Equal(["MNU001", "MNU002", "MNU010"], page.Items.Select(x => x.Code).ToArray());
        Assert.Equal([1, 2, 3], page.Items.Select(x => x.SortOrder).ToArray());
    }

    [Fact]
    public async Task CreateMenuAsync_assigns_next_mnu_code_and_sequence()
    {
        var db = await CreateDbAsync();
        var admin = new AppModule { Code = "ADMIN", Name = "Administration" };
        db.AppModules.Add(admin);
        await db.SaveChangesAsync();
        db.AppMenus.Add(new AppMenu { ModuleId = admin.Id, Code = "MNU001", Name = "First", SortOrder = 1 });
        await db.SaveChangesAsync();

        var created = await new AppCatalogService(db).CreateMenuAsync(
            new CreateAppMenuRequest(admin.Id, null, null, "Second", "/two", null, 0, null),
            CancellationToken.None);

        Assert.Equal("MNU002", created.Code);
        Assert.Equal(2, created.SortOrder);
    }

    [Fact]
    public async Task CreateMenuAsync_grants_platform_super_admin()
    {
        var db = await CreateDbAsync();
        var admin = new AppModule { Code = "ADMIN", Name = "Administration" };
        db.AppModules.Add(admin);
        var role = new Role { OrganizationId = null, Name = "SuperAdmin", IsSystem = true };
        db.Roles.Add(role);
        await db.SaveChangesAsync();

        var created = await new AppCatalogService(db).CreateMenuAsync(
            new CreateAppMenuRequest(admin.Id, null, "OU", "Operating units", "/dashboard/organizations", null, 0, null),
            CancellationToken.None);

        Assert.True(await db.RoleMenus.AnyAsync(x => x.RoleId == role.Id && x.MenuId == created.Id && x.CanCreate));
    }

    [Fact]
    public async Task CreateMenuAsync_missing_module_throws()
    {
        var db = await CreateDbAsync();

        await Assert.ThrowsAsync<NotFoundException>(() =>
            new AppCatalogService(db).CreateMenuAsync(
                new CreateAppMenuRequest(Guid.NewGuid(), null, "USR", "Users", "/users", null, 1, null),
                CancellationToken.None));
    }

    [Fact]
    public async Task UpdateMenuAsync_sets_path_and_permission()
    {
        var db = await CreateDbAsync();
        var pes = new AppModule { Code = "PES", Name = "PES" };
        db.AppModules.Add(pes);
        await db.SaveChangesAsync();
        var menu = new AppMenu
        {
            ModuleId = pes.Id,
            Code = "MNU016",
            Name = "Operations Dashboard",
            IsActive = true
        };
        db.AppMenus.Add(menu);
        await db.SaveChangesAsync();

        var updated = await new AppCatalogService(db).UpdateMenuAsync(
            menu.Id,
            new UpdateAppMenuRequest(
                pes.Id,
                "Operations Dashboard",
                "/dashboard/pes/operations-dashboard",
                "LayoutDashboard",
                "pes.view",
                true),
            CancellationToken.None);

        Assert.Equal("/dashboard/pes/operations-dashboard", updated.Path);
        Assert.Equal("pes.view", updated.PermissionCode);
        var stored = await db.AppMenus.SingleAsync(x => x.Id == menu.Id);
        Assert.Equal("/dashboard/pes/operations-dashboard", stored.MenuPath);
        Assert.Equal("Operations Dashboard", stored.DisplayName);
    }

    [Fact]
    public async Task UpdateMenuAsync_missing_menu_throws()
    {
        var db = await CreateDbAsync();
        var pes = new AppModule { Code = "PES", Name = "PES" };
        db.AppModules.Add(pes);
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<NotFoundException>(() =>
            new AppCatalogService(db).UpdateMenuAsync(
                Guid.NewGuid(),
                new UpdateAppMenuRequest(pes.Id, "Missing", "/dashboard/pes", null, null, true),
                CancellationToken.None));
    }

    private static async Task<AppDbContext> CreateDbAsync()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        var db = new AppDbContext(options, new TestCurrentUser());
        await db.Database.EnsureCreatedAsync();
        return db;
    }

    private sealed class TestCurrentUser : ICurrentUser
    {
        public Guid? UserId { get; } = Guid.NewGuid();
        public Guid? OrganizationId { get; }
        public string? RoleName { get; } = "SuperAdmin";
        public bool IsAuthenticated { get; } = true;
        public IReadOnlyCollection<string> Permissions { get; } = [];
    }
}
