using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence.Seed;
using JUSPlatform.UnitTests.Roles;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.UnitTests.AppCatalog;

public sealed class AppCatalogSeederTests
{
    [Fact]
    public async Task RemoveSeededExtrasAsync_deletes_boot_modules_keeps_live_pes()
    {
        var db = await RoleServiceUpdateTests.CreateDbAsync(Guid.NewGuid());
        var livePes = new AppModule { Code = "MOD003", Name = "PES", IsActive = true };
        var seededPes = new AppModule { Code = "PES", Name = "PES", IsActive = true };
        var admin = new AppModule { Code = "ADMIN", Name = "Administration", IsActive = true };
        db.AppModules.AddRange(livePes, seededPes, admin);
        await db.SaveChangesAsync();
        db.AppMenus.AddRange(
            new AppMenu
            {
                ModuleId = livePes.Id,
                Code = "MNU022",
                Name = "On-Time Delivery",
                Path = "/modules/pes/on-time-delivery",
                IsActive = true
            },
            new AppMenu
            {
                ModuleId = seededPes.Id,
                Code = "PES001",
                Name = "PES Overview",
                Path = "/modules/pes",
                IsActive = true
            },
            new AppMenu
            {
                ModuleId = admin.Id,
                Code = "MNU001",
                Name = "Users",
                Path = "/dashboard/users",
                IsActive = true
            });
        await db.SaveChangesAsync();

        await AppCatalogSeeder.RemoveSeededExtrasAsync(db);

        Assert.False(await db.AppModules.AnyAsync(x => x.Code == "ADMIN" || x.Code == "PES"));
        Assert.True(await db.AppModules.AnyAsync(x => x.Code == "MOD003"));
        Assert.True(await db.AppMenus.AnyAsync(x => x.Code == "MNU022"));
        Assert.False(await db.AppMenus.AnyAsync(x => x.Code == "PES001" || x.Code == "MNU001"));
    }
}
