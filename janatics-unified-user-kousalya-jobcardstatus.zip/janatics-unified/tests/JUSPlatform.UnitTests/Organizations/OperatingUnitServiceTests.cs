using JUSPlatform.Application.Organizations;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.UnitTests.Roles;

namespace JUSPlatform.UnitTests.Organizations;

public sealed class OperatingUnitServiceTests
{
    [Fact]
    public async Task CreateAsync_assigns_uuid_and_keeps_oracle_org_id()
    {
        var db = await RoleServiceUpdateTests.CreateDbAsync(Guid.NewGuid());
        var service = new OperatingUnitService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        var created = await service.CreateAsync(
            new CreateOperatingUnitRequest(81, "Janatics OU", true),
            CancellationToken.None);

        Assert.NotEqual(Guid.Empty, created.Id);
        Assert.Equal(81, created.OrgId);
        Assert.Equal("Janatics OU", created.Name);
    }

    [Fact]
    public async Task CreateAsync_duplicate_org_id_throws()
    {
        var db = await RoleServiceUpdateTests.CreateDbAsync(Guid.NewGuid());
        db.OperatingUnits.Add(new OperatingUnit { OrgId = 81, Name = "Existing" });
        await db.SaveChangesAsync();

        var service = new OperatingUnitService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        await Assert.ThrowsAsync<ConflictException>(() =>
            service.CreateAsync(new CreateOperatingUnitRequest(81, "Dup"), CancellationToken.None));
    }
}

public sealed class OrganizationServiceTests
{
    [Fact]
    public async Task CreateAsync_links_operating_unit_uuid()
    {
        var db = await RoleServiceUpdateTests.CreateDbAsync(Guid.NewGuid());
        var ou = new OperatingUnit { OrgId = 81, Name = "OU 81" };
        db.OperatingUnits.Add(ou);
        await db.SaveChangesAsync();

        var service = new OrganizationService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        var created = await service.CreateAsync(
            new CreateOrganizationRequest("North", "NORTH", ou.Id, 142, "Coimbatore"),
            CancellationToken.None);

        Assert.Equal(ou.Id, created.OperatingUnitId);
        Assert.Equal("OU 81", created.OperatingUnitName);
        Assert.Equal(142, created.OracleOrgId);
        Assert.Equal("Coimbatore", created.UnitName);
    }

    [Fact]
    public async Task CreateAsync_unknown_operating_unit_throws()
    {
        var db = await RoleServiceUpdateTests.CreateDbAsync(Guid.NewGuid());
        var service = new OrganizationService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        await Assert.ThrowsAsync<NotFoundException>(() =>
            service.CreateAsync(
                new CreateOrganizationRequest("North", "NORTH2", Guid.NewGuid()),
                CancellationToken.None));
    }
}

public sealed class CreateOperatingUnitRequestValidatorTests
{
    [Fact]
    public void Org_id_must_be_positive()
    {
        var validator = new CreateOperatingUnitRequestValidator();
        var result = validator.Validate(new CreateOperatingUnitRequest(0, "OU"));
        Assert.False(result.IsValid);
    }
}
