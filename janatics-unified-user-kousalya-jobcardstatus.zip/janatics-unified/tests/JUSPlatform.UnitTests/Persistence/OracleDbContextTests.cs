using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Oracle;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.UnitTests.Persistence;

public sealed class OracleDbContextTests
{
    [Fact]
    public void InMemory_allows_save_for_tests()
    {
        var options = new DbContextOptionsBuilder<OracleDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        using var db = new OracleDbContext(options);
        Assert.Equal(0, db.SaveChanges());
    }

    [Fact]
    public void Model_maps_jan_wip_test_and_excludes_app_entities()
    {
        var options = new DbContextOptionsBuilder<OracleDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        using var db = new OracleDbContext(options);

        Assert.Null(db.Model.FindEntityType(typeof(User)));
        var entity = db.Model.FindEntityType(typeof(JanWipTest));
        Assert.NotNull(entity);
        Assert.Equal("JAN_WIP_TEST", entity.GetTableName());
    }
}
