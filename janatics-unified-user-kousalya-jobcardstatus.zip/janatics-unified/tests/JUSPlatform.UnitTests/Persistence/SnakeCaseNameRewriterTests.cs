using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Authentication;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace JUSPlatform.UnitTests.Persistence;

public sealed class SnakeCaseNameRewriterTests
{
    [Theory]
    [InlineData("HavingThisCol", "having_this_col")]
    [InlineData("CreatedAt", "created_at")]
    [InlineData("OrganizationId", "organization_id")]
    [InlineData("Id", "id")]
    [InlineData("JobNo", "job_no")]
    [InlineData("PayloadJson", "payload_json")]
    [InlineData("created_at", "created_at")]
    [InlineData("PK_users", "pk_users")]
    [InlineData("IX_users_Email", "ix_users_email")]
    public void Rewrite_maps_pascal_to_snake(string input, string expected)
    {
        Assert.Equal(expected, SnakeCaseNameRewriter.Rewrite(input));
    }

    [Fact]
    public void AppDbContext_maps_entity_columns_to_snake_case()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        using var db = new AppDbContext(options, new NullCurrentUser());
        var entity = db.Model.FindEntityType(typeof(User));
        Assert.NotNull(entity);
        Assert.Equal("users", entity.GetTableName());

        var table = StoreObjectIdentifier.Table(entity.GetTableName()!, entity.GetSchema());
        Assert.Equal("id", entity.FindProperty(nameof(User.Id))!.GetColumnName(table));
        Assert.Equal("created_at", entity.FindProperty(nameof(User.CreatedAt))!.GetColumnName(table));
        Assert.Equal("organization_id", entity.FindProperty(nameof(User.OrganizationId))!.GetColumnName(table));
        Assert.Equal("is_deleted", entity.FindProperty(nameof(User.IsDeleted))!.GetColumnName(table));
        Assert.Equal("display_name", entity.FindProperty(nameof(User.DisplayName))!.GetColumnName(table));
    }

    [Fact]
    public void AppDbContext_keeps_explicit_role_menu_perm_column_names()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        using var db = new AppDbContext(options, new NullCurrentUser());
        var entity = db.Model.FindEntityType(typeof(RoleMenu));
        Assert.NotNull(entity);

        var table = StoreObjectIdentifier.Table(entity.GetTableName()!, entity.GetSchema());
        Assert.Equal("perm_add", entity.FindProperty(nameof(RoleMenu.CanCreate))!.GetColumnName(table));
        Assert.Equal("perm_view", entity.FindProperty(nameof(RoleMenu.CanRead))!.GetColumnName(table));
        Assert.Equal("perm_edit", entity.FindProperty(nameof(RoleMenu.CanUpdate))!.GetColumnName(table));
        Assert.Equal("perm_delete", entity.FindProperty(nameof(RoleMenu.CanDelete))!.GetColumnName(table));
        Assert.Equal("perm_export", entity.FindProperty(nameof(RoleMenu.CanExport))!.GetColumnName(table));
        Assert.Equal("perm_approve", entity.FindProperty(nameof(RoleMenu.CanApprove))!.GetColumnName(table));
    }
}
