using FluentValidation.TestHelper;
using JUSPlatform.Application.Common;

namespace JUSPlatform.UnitTests.Common;

public sealed class PagedListQueryValidatorTests
{
    private readonly PagedListQueryValidator _validator = new();

    [Fact]
    public void Valid_query_passes()
    {
        var result = _validator.TestValidate(new PagedListQuery { Page = 1, PageSize = 25 });
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Theory]
    [InlineData(0, 25)]
    [InlineData(-1, 10)]
    [InlineData(1, 0)]
    [InlineData(1, 101)]
    public void Invalid_page_or_pageSize_fails(int page, int pageSize)
    {
        var result = _validator.TestValidate(new PagedListQuery { Page = page, PageSize = pageSize });
        Assert.False(result.IsValid);
    }
}

public sealed class PagedListQueryNormalizeTests
{
    [Fact]
    public void Normalize_clamps_page_and_pageSize()
    {
        var normalized = new PagedListQuery { Page = 0, PageSize = 500 }.Normalize();
        Assert.Equal(1, normalized.Page);
        Assert.Equal(PagedListQuery.MaxPageSize, normalized.PageSize);
    }

    [Fact]
    public void IsDescending_true_only_for_desc()
    {
        Assert.True(new PagedListQuery { SortDir = SortDirection.Desc }.IsDescending());
        Assert.False(new PagedListQuery { SortDir = SortDirection.Asc }.IsDescending());
    }
}
