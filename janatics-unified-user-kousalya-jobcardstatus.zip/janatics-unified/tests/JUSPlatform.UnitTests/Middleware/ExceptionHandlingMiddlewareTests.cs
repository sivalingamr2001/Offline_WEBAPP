using System.Net;
using System.Text.Json;
using FluentValidation;
using FluentValidation.Results;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Bugsink;
using JUSPlatform.Middleware;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;

namespace JUSPlatform.UnitTests.Middleware;

public sealed class ExceptionHandlingMiddlewareTests
{
    [Fact]
    public async Task ValidationException_returns_400_json()
    {
        var context = CreateContext();
        var middleware = CreateMiddleware(_ =>
            throw new ValidationException([new ValidationFailure("email", "Required")]));

        await middleware.InvokeAsync(context);

        Assert.Equal(StatusCodes.Status400BadRequest, context.Response.StatusCode);
        var body = await ReadBodyAsync(context);
        Assert.False(body.Success);
        Assert.NotNull(body.Errors);
    }

    [Fact]
    public async Task NotFoundException_returns_404_json()
    {
        var context = CreateContext();
        var middleware = CreateMiddleware(_ => throw new NotFoundException("User", "missing-id"));

        await middleware.InvokeAsync(context);

        Assert.Equal(StatusCodes.Status404NotFound, context.Response.StatusCode);
        var body = await ReadBodyAsync(context);
        Assert.Equal("User 'missing-id' was not found.", body.Detail);
    }

    [Fact]
    public async Task Unhandled_exception_returns_500_json()
    {
        var context = CreateContext();
        var middleware = CreateMiddleware(_ => throw new InvalidOperationException("boom"));

        await middleware.InvokeAsync(context);

        Assert.Equal(StatusCodes.Status500InternalServerError, context.Response.StatusCode);
        var body = await ReadBodyAsync(context);
        Assert.Equal("An unexpected error occurred.", body.Detail);
    }

    private static ExceptionHandlingMiddleware CreateMiddleware(RequestDelegate next)
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["AppDebug"] = "false" })
            .Build();

        var bugsinkMonitor = new Mock<IOptionsMonitor<BugsinkOptions>>();
        bugsinkMonitor.Setup(x => x.CurrentValue).Returns(new BugsinkOptions { Enabled = false });

        return new ExceptionHandlingMiddleware(
            next,
            NullLogger<ExceptionHandlingMiddleware>.Instance,
            configuration,
            Options.Create(new ErrorResponseOptions()),
            bugsinkMonitor.Object);
    }

    private static DefaultHttpContext CreateContext()
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();
        context.TraceIdentifier = "trace-test";
        return context;
    }

    private static async Task<ApiErrorResponse> ReadBodyAsync(HttpContext context)
    {
        context.Response.Body.Seek(0, SeekOrigin.Begin);
        return (await JsonSerializer.DeserializeAsync<ApiErrorResponse>(
            context.Response.Body,
            ApiErrorResponseWriter.JsonOptions))!;
    }
}
