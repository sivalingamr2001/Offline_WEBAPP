using JUSPlatform.Middleware;
using Microsoft.AspNetCore.Http;

namespace JUSPlatform.UnitTests.Middleware;

public sealed class ResponseIdMiddlewareTests
{
    [Fact]
    public async Task Sets_response_id_header_and_item()
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();

        var middleware = new ResponseIdMiddleware(_ => Task.CompletedTask);
        await middleware.InvokeAsync(context);

        Assert.True(context.Response.Headers.ContainsKey(ResponseIdMiddleware.HeaderName));
        Assert.Equal(
            context.Response.Headers[ResponseIdMiddleware.HeaderName].ToString(),
            ResponseIdMiddleware.GetResponseId(context));
    }

    [Fact]
    public async Task Uses_valid_client_request_id()
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();
        context.Request.Headers[CorrelationId.RequestHeaderName] = "client-request-id";

        var middleware = new ResponseIdMiddleware(_ => Task.CompletedTask);
        await middleware.InvokeAsync(context);

        Assert.Equal("client-request-id", ResponseIdMiddleware.GetResponseId(context));
    }

    [Fact]
    public async Task Ignores_invalid_client_request_id()
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();
        context.Request.Headers[CorrelationId.RequestHeaderName] = "bad id!";

        var middleware = new ResponseIdMiddleware(_ => Task.CompletedTask);
        await middleware.InvokeAsync(context);

        var responseId = ResponseIdMiddleware.GetResponseId(context);
        Assert.NotNull(responseId);
        Assert.NotEqual("bad id!", responseId);
    }
}
