using System.Net;
using FluentValidation;
using FluentValidation.Results;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Middleware;

namespace JUSPlatform.UnitTests.Middleware;

public sealed class ApiErrorFactoryTests
{
    private static readonly ErrorResponseOptions MinimalOptions = new();

    [Fact]
    public void FromException_validation_groups_errors_by_property()
    {
        var failures = new[]
        {
            new ValidationFailure("Email", "Email is required."),
            new ValidationFailure("Email", "Email is invalid."),
            new ValidationFailure("Password", "Password is too short.")
        };

        var body = ApiErrorFactory.FromException(
            new ValidationException(failures),
            HttpStatusCode.BadRequest,
            "trace-1",
            MinimalOptions,
            appDebug: false);

        Assert.False(body.Success);
        Assert.Equal(2, body.Errors!.Count);
        Assert.Equal(2, body.Errors["Email"].Length);
        Assert.Single(body.Errors["Password"]);
    }

    [Fact]
    public void FromException_not_found_uses_message()
    {
        var body = ApiErrorFactory.FromException(
            new NotFoundException("Role", "abc"),
            HttpStatusCode.NotFound,
            null,
            MinimalOptions,
            appDebug: false);

        Assert.Equal("Role 'abc' was not found.", body.Detail);
    }

    [Fact]
    public void FromException_internal_error_hides_details_without_app_debug()
    {
        var body = ApiErrorFactory.FromException(
            new InvalidOperationException("secret internals"),
            HttpStatusCode.InternalServerError,
            "trace-2",
            MinimalOptions,
            appDebug: false);

        Assert.Equal("An unexpected error occurred.", body.Detail);
        Assert.Null(body.Exception);
    }

    [Fact]
    public void FromException_includes_exception_details_when_app_debug()
    {
        var body = ApiErrorFactory.FromException(
            new InvalidOperationException("debug detail"),
            HttpStatusCode.InternalServerError,
            "trace-3",
            MinimalOptions,
            appDebug: true);

        Assert.NotNull(body.Exception);
        Assert.Contains(body.Exception!, line => line.Contains("InvalidOperationException", StringComparison.Ordinal));
    }

    [Fact]
    public void NotFound_returns_expected_detail()
    {
        var body = ApiErrorFactory.NotFound(MinimalOptions, appDebug: false, detail: "Missing resource.");
        Assert.Equal("Missing resource.", body.Detail);
    }

    [Fact]
    public void ForStatus_with_rfc_fields_populates_title_and_status()
    {
        var options = new ErrorResponseOptions { IncludeRfcFields = true, IncludeTraceId = true };

        var body = ApiErrorFactory.ForStatus(
            HttpStatusCode.Forbidden,
            "Denied.",
            options,
            traceId: "trace-4",
            appDebug: false);

        Assert.Equal("Denied.", body.Detail);
        Assert.Equal(403, body.Status);
        Assert.Equal("Forbidden", body.Title);
        Assert.Equal("trace-4", body.TraceId);
    }

    [Fact]
    public void ForStatus_too_many_requests_uses_readable_title()
    {
        var options = new ErrorResponseOptions { IncludeRfcFields = true };

        var body = ApiErrorFactory.ForStatus(
            HttpStatusCode.TooManyRequests,
            "Too many requests. Try again later.",
            options);

        Assert.Equal(429, body.Status);
        Assert.Equal("Too Many Requests", body.Title);
    }
}
