using JUSPlatform.Middleware;

namespace JUSPlatform.UnitTests.Middleware;

public sealed class CorrelationIdTests
{
    [Theory]
    [InlineData("abc-123_test")]
    [InlineData("a")]
    [InlineData("0123456789ABCDEF")]
    public void IsValid_accepts_safe_tokens(string value)
    {
        Assert.True(CorrelationId.IsValid(value));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("has space")]
    [InlineData("bad/slash")]
    [InlineData("comma,joined")]
    public void IsValid_rejects_unsafe_tokens(string value)
    {
        Assert.False(CorrelationId.IsValid(value));
    }

    [Fact]
    public void ResolveOrGenerate_keeps_valid_client_value()
    {
        var resolved = CorrelationId.ResolveOrGenerate("client-id-01");
        Assert.Equal("client-id-01", resolved);
    }

    [Fact]
    public void ResolveOrGenerate_replaces_invalid_client_value()
    {
        var resolved = CorrelationId.ResolveOrGenerate("bad value!");
        Assert.NotEqual("bad value!", resolved);
        Assert.True(CorrelationId.IsValid(resolved));
    }

    [Fact]
    public void Generate_returns_32_char_hex_without_dashes()
    {
        var generated = CorrelationId.Generate();
        Assert.Equal(32, generated.Length);
        Assert.DoesNotContain('-', generated);
    }
}
