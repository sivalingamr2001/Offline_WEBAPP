using System.Text.Json;
using JUSPlatform.Application.Common;
using JUSPlatform.Middleware;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace JUSPlatform.UnitTests.Middleware;

public sealed class ApiErrorStatusMiddlewareTests
{
    [Theory]
    [InlineData(StatusCodes.Status401Unauthorized, "Authentication required.")]
    [InlineData(StatusCodes.Status403Forbidden, "You do not have permission to perform this action.")]
    [InlineData(StatusCodes.Status404NotFound, "Not found.")]
    public async Task Api_routes_get_json_body_for_empty_error_status(int statusCode, string expectedDetail)
    {
        var context = CreateContext("/api/v1/users", statusCode);
        var middleware = new ApiErrorStatusMiddleware(_ => Task.CompletedTask);

        await middleware.InvokeAsync(context);

        Assert.Equal(statusCode, context.Response.StatusCode);
        var body = await ReadBodyAsync(context);
        Assert.False(body.Success);
        Assert.Equal(expectedDetail, body.Detail);
    }

    [Fact]
    public async Task Non_api_routes_are_not_wrapped()
    {
        var context = CreateContext("/docs", StatusCodes.Status404NotFound);
        var middleware = new ApiErrorStatusMiddleware(_ => Task.CompletedTask);

        await middleware.InvokeAsync(context);

        Assert.Equal(0, context.Response.Body.Length);
    }

    private static DefaultHttpContext CreateContext(string path, int statusCode)
    {
        var services = new ServiceCollection();
        services.Configure<ErrorResponseOptions>(_ => { });
        services.AddSingleton<IConfiguration>(new ConfigurationBuilder().Build());

        var context = new DefaultHttpContext
        {
            RequestServices = services.BuildServiceProvider()
        };
        context.Request.Path = path;
        context.Response.Body = new MemoryStream();
        context.Response.StatusCode = statusCode;
        return context;
    }

    private static async Task<ApiErrorResponse> ReadBodyAsync(HttpContext context)
    {
        context.Response.Body.Seek(0, SeekOrigin.Begin);
        return (await JsonSerializer.DeserializeAsync<ApiErrorResponse>(
            context.Response.Body,
            ApiErrorResponseWriter.JsonOptions))!;
    }
}
