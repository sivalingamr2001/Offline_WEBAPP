using JUSPlatform.Application.CustomerComplaint;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.UnitTests.Roles;

namespace JUSPlatform.UnitTests.CustomerComplaint;

public sealed class CustomerComplaintServiceTests
{
    [Fact]
    public async Task GetComplaintsOverviewAsync_without_membership_org_keys_returns_empty()
    {
        var orgId = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var currentUser = new RoleServiceUpdateTests.TestCurrentUser(orgId, userId: userId);

        var dto = await new CustomerComplaintService(db, currentUser).GetComplaintsOverviewAsync(
            new ComplaintsOverviewQuery(),
            CancellationToken.None);

        Assert.Equal(0, dto.Kpis.TotalComplaints.Current);
        Assert.Empty(dto.Products);
        Assert.Equal(7, dto.Trend.Count);
    }

    [Fact]
    public async Task GetComplaintsOverviewAsync_super_admin_unknown_org_throws()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var currentUser = new RoleServiceUpdateTests.TestCurrentUser(null, "SuperAdmin");

        await Assert.ThrowsAsync<NotFoundException>(() =>
            new CustomerComplaintService(db, currentUser).GetComplaintsOverviewAsync(
                new ComplaintsOverviewQuery { OrganizationId = Guid.NewGuid() },
                CancellationToken.None));
    }

    [Fact]
    public async Task GetComplaintsOverviewAsync_org_user_without_custodian_codes_returns_empty()
    {
        var orgId = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var org = db.Organizations.Single();
        org.OracleOrgId = 504;
        org.OperatingUnitId = 484;
        db.Users.Add(new User
        {
            Id = userId,
            OrganizationId = orgId,
            Email = "clerk@example.local",
            DisplayName = "Clerk",
            PasswordHash = "x",
            EmpId = "E100",
        });
        db.UserAccessRights.Add(new UserAccessRight
        {
            UserId = userId,
            OrganizationId = orgId,
            OperatingUnit = 504,
            IsActive = true,
        });
        await db.SaveChangesAsync();

        var dto = await new CustomerComplaintService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId, userId: userId))
            .GetComplaintsOverviewAsync(new ComplaintsOverviewQuery(), CancellationToken.None);

        Assert.Equal(0, dto.Kpis.TotalComplaints.Current);
    }

    [Fact]
    public async Task ListAvailableWeeksAsync_without_membership_returns_empty()
    {
        var orgId = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);

        var weeks = await new CustomerComplaintService(
                db,
                new RoleServiceUpdateTests.TestCurrentUser(orgId, userId: userId))
            .ListAvailableWeeksAsync(null, CancellationToken.None);

        Assert.Empty(weeks);
    }
}
