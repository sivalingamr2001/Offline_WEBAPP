using FluentValidation.TestHelper;
using JUSPlatform.Application.CustomerComplaint;

namespace JUSPlatform.UnitTests.CustomerComplaint;

public sealed class ComplaintsOverviewQueryValidatorTests
{
    private readonly ComplaintsOverviewQueryValidator _validator = new();

    [Fact]
    public void Accepts_default_paging()
    {
        var result = _validator.TestValidate(new ComplaintsOverviewQuery());
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Rejects_page_below_one()
    {
        var result = _validator.TestValidate(new ComplaintsOverviewQuery { Page = 0 });
        result.ShouldHaveValidationErrorFor(x => x.Page);
    }
}
