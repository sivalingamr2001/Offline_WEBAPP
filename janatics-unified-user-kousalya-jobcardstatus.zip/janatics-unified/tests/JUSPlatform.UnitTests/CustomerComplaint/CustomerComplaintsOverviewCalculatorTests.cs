using JUSPlatform.Application.CustomerComplaint;

namespace JUSPlatform.UnitTests.CustomerComplaint;

public sealed class CustomerComplaintsOverviewCalculatorTests
{
    [Fact]
    public void ResolveWeekStart_snaps_sunday_to_prior_monday()
    {
        var weekStart = CustomerComplaintsOverviewCalculator.ResolveWeekStart("2026-09-20", new DateOnly(2026, 9, 18));
        Assert.Equal(new DateOnly(2026, 9, 14), weekStart);
    }

    [Fact]
    public void ResolveWeekStart_defaults_to_current_utc_week()
    {
        var weekStart = CustomerComplaintsOverviewCalculator.ResolveWeekStart(null, new DateOnly(2026, 9, 18));
        Assert.Equal(new DateOnly(2026, 9, 14), weekStart);
    }

    [Fact]
    public void Classify_closed_on_or_before_target_is_solved()
    {
        var bucket = CustomerComplaintsOverviewCalculator.Classify(
            new DateOnly(2026, 9, 16),
            new DateOnly(2026, 9, 17),
            new DateOnly(2026, 9, 20));
        Assert.Equal(ComplaintSlaBucket.SolvedWithinSla, bucket);
    }

    [Fact]
    public void Classify_open_past_target_is_breached()
    {
        var bucket = CustomerComplaintsOverviewCalculator.Classify(
            null,
            new DateOnly(2026, 9, 15),
            new DateOnly(2026, 9, 20));
        Assert.Equal(ComplaintSlaBucket.OpenOrBreached, bucket);
    }

    [Fact]
    public void Build_aggregates_kpis_and_product_rows()
    {
        var weekStart = new DateOnly(2026, 9, 14);
        var complaints = new List<ComplaintFact>
        {
            new(weekStart, "A-1", "Valve A", weekStart.AddDays(2), weekStart.AddDays(1)),
            new(weekStart, "A-1", "Valve A", weekStart.AddDays(6), null),
            new(weekStart.AddDays(1), "B-2", "Valve B", weekStart.AddDays(1), weekStart.AddDays(3)),
        };
        var sales = new List<SalesFact>
        {
            new(weekStart, "A-1", "Valve A", 100),
            new(weekStart, "B-2", "Valve B", 50),
        };

        var dto = CustomerComplaintsOverviewCalculator.Build(
            complaints,
            sales,
            weekStart,
            page: 1,
            pageSize: 10,
            asOf: new DateTimeOffset(2026, 9, 18, 12, 0, 0, TimeSpan.Zero));

        Assert.Equal("Customer Complaints Overview (WTD)", dto.Title);
        Assert.Equal(3, dto.Kpis.TotalComplaints.Current);
        Assert.Equal(1, dto.Kpis.SolvedWithinSla.Current);
        Assert.Equal(1, dto.Kpis.OpenWithinSla.Current);
        Assert.Equal(1, dto.Kpis.OpenBreachedSla.Current);
        Assert.Equal(2.00m, dto.Kpis.ComplaintRate.RatePct);
        Assert.Equal(2, dto.TotalProducts);
        Assert.Equal("A-1", dto.Products[0].ProductCode);
        Assert.Equal(2, dto.Products[0].TotalComplaints);
        Assert.Equal(150, dto.Totals.OrdersDelivered);
        Assert.Equal(7, dto.Trend.Count);
        Assert.Equal(90m, dto.Sla.TargetPct);
    }

    [Fact]
    public void Build_empty_inputs_returns_zero_kpis()
    {
        var dto = CustomerComplaintsOverviewCalculator.Build(
            [],
            [],
            new DateOnly(2026, 9, 14),
            1,
            10,
            DateTimeOffset.UnixEpoch);

        Assert.Equal(0, dto.Kpis.TotalComplaints.Current);
        Assert.Equal(0, dto.Kpis.ComplaintRate.RatePct);
        Assert.Empty(dto.Products);
        Assert.Equal(0, dto.TotalProducts);
    }

    [Fact]
    public void Build_compares_current_wtd_to_prior_week()
    {
        var weekStart = new DateOnly(2026, 9, 14);
        var complaints = new List<ComplaintFact>
        {
            new(weekStart, "A-1", "Valve A", weekStart.AddDays(2), weekStart.AddDays(1)),
            new(weekStart.AddDays(-7), "A-1", "Valve A", weekStart.AddDays(-5), weekStart.AddDays(-6)),
            new(weekStart.AddDays(-6), "B-2", "Valve B", weekStart.AddDays(-4), null),
        };
        var sales = new List<SalesFact>
        {
            new(weekStart, "A-1", "Valve A", 100),
            new(weekStart.AddDays(-7), "A-1", "Valve A", 50),
        };

        var dto = CustomerComplaintsOverviewCalculator.Build(
            complaints,
            sales,
            weekStart,
            1,
            10,
            new DateTimeOffset(2026, 9, 18, 12, 0, 0, TimeSpan.Zero));

        Assert.Equal(1, dto.Kpis.TotalComplaints.Current);
        Assert.Equal(2, dto.Kpis.TotalComplaints.Previous);
        Assert.Equal(1.00m, dto.Kpis.ComplaintRate.RatePct);
        Assert.Equal(4.00m, dto.Kpis.ComplaintRate.PreviousRatePct);
        Assert.Equal(-3.00m, dto.Kpis.ComplaintRate.DeltaPp);
    }

    [Fact]
    public void Build_product_rows_only_include_items_with_complaints()
    {
        var weekStart = new DateOnly(2026, 9, 14);
        var complaints = new List<ComplaintFact>
        {
            new(weekStart, "A-1", "Valve A", weekStart.AddDays(2), weekStart.AddDays(1)),
        };
        var sales = new List<SalesFact>
        {
            new(weekStart, "A-1", "Valve A", 100),
            new(weekStart, "Z-9", "Unrelated sale", 50000),
        };

        var dto = CustomerComplaintsOverviewCalculator.Build(
            complaints,
            sales,
            weekStart,
            1,
            10,
            new DateTimeOffset(2026, 9, 18, 12, 0, 0, TimeSpan.Zero));

        Assert.Equal(1, dto.TotalProducts);
        Assert.Equal("A-1", dto.Products[0].ProductCode);
        Assert.Equal(50100, dto.Totals.OrdersDelivered);
    }
}
