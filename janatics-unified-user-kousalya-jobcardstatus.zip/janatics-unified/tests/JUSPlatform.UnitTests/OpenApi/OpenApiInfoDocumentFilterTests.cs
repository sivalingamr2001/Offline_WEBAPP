using JUSPlatform.OpenApi;
using Microsoft.OpenApi;

namespace JUSPlatform.UnitTests.OpenApi;

public sealed class OpenApiInfoDocumentFilterTests
{
    [Fact]
    public void Apply_sets_title_and_bearer_scheme()
    {
        var options = new OpenApiOptions
        {
            Title = "Janatics Unified Suite API",
            Summary = "Business operations",
            Description = "Org and ERP APIs",
            Version = "1.0.0"
        };
        var document = new OpenApiDocument { Info = new OpenApiInfo() };

        OpenApiDocumentCustomizer.Apply(document, options);

        Assert.Equal("Janatics Unified Suite API", document.Info.Title);
        Assert.Equal("1.0.0", document.Info.Version);
        Assert.Contains("Business operations", document.Info.Description, StringComparison.Ordinal);
        Assert.Contains("Org and ERP APIs", document.Info.Description, StringComparison.Ordinal);
        Assert.True(document.Components?.SecuritySchemes?.ContainsKey("Bearer"));
    }
}
