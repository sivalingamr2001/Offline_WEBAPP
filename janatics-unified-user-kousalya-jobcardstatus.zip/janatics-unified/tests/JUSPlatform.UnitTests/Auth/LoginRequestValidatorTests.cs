using FluentValidation.TestHelper;
using JUSPlatform.Application.Auth;

namespace JUSPlatform.UnitTests.Auth;

public sealed class LoginRequestValidatorTests
{
    private readonly LoginRequestValidator _validator = new();

    [Fact]
    public void Valid_request_passes()
    {
        var result = _validator.TestValidate(new LoginRequest("admin@demo.local", "ChangeMe123!"));
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Theory]
    [InlineData("", "password123")]
    [InlineData("not-an-email", "password123")]
    [InlineData("user@example.com", "")]
    [InlineData("user@example.com", "short")]
    public void Invalid_request_fails(string email, string password)
    {
        var result = _validator.TestValidate(new LoginRequest(email, password));
        Assert.False(result.IsValid);
    }
}
