using JUSPlatform.Application.Storage;

namespace JUSPlatform.UnitTests.Storage;

public sealed class LocalDownloadTicketTests
{
    private const string SigningKey = "unit-test-download-signing-key-32chars";

    [Fact]
    public void Issue_then_validate_succeeds()
    {
        var orgId = Guid.Parse("11111111-2222-3333-4444-555555555555");
        var key = $"exports/{orgId}/report.csv";
        var ticket = LocalDownloadTickets.Issue(
            key,
            DateTimeOffset.UtcNow.AddMinutes(5),
            SigningKey,
            "Sales Report.csv",
            versionId: null);

        Assert.Equal("SalesReport.csv", ticket.FileName);
        Assert.True(LocalDownloadTickets.TryValidate(
            ticket.Key,
            ticket.ExpiresUnix.ToString(),
            ticket.Signature,
            ticket.FileName,
            ticket.VersionId,
            SigningKey,
            out var parsed));
        Assert.Equal(ticket.Key, parsed.Key);
        Assert.Equal("SalesReport.csv", parsed.FileName);
    }

    [Fact]
    public void TryValidate_rejects_tampered_signature()
    {
        var orgId = Guid.NewGuid();
        var ticket = LocalDownloadTickets.Issue(
            $"exports/{orgId}/a.csv",
            DateTimeOffset.UtcNow.AddMinutes(5),
            SigningKey,
            "a.csv");

        Assert.False(LocalDownloadTickets.TryValidate(
            ticket.Key,
            ticket.ExpiresUnix.ToString(),
            ticket.Signature + "x",
            ticket.FileName,
            null,
            SigningKey,
            out _));
    }

    [Fact]
    public void TryValidate_rejects_expired_ticket()
    {
        var orgId = Guid.NewGuid();
        var ticket = LocalDownloadTickets.Issue(
            $"exports/{orgId}/a.csv",
            DateTimeOffset.UtcNow.AddMinutes(-1),
            SigningKey,
            "a.csv");

        Assert.False(LocalDownloadTickets.TryValidate(
            ticket.Key,
            ticket.ExpiresUnix.ToString(),
            ticket.Signature,
            ticket.FileName,
            null,
            SigningKey,
            out _));
    }

    [Fact]
    public void TryValidate_rejects_avatar_key()
    {
        var ticket = LocalDownloadTickets.Issue(
            "uploads/avatars/platform/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.jpg",
            DateTimeOffset.UtcNow.AddMinutes(5),
            SigningKey,
            "avatar.jpg");

        Assert.False(LocalDownloadTickets.TryValidate(
            ticket.Key,
            ticket.ExpiresUnix.ToString(),
            ticket.Signature,
            ticket.FileName,
            null,
            SigningKey,
            out _));
    }

    [Fact]
    public void TryValidate_rejects_wrong_signing_key()
    {
        var orgId = Guid.NewGuid();
        var ticket = LocalDownloadTickets.Issue(
            $"reports/{orgId}/q.csv",
            DateTimeOffset.UtcNow.AddMinutes(5),
            SigningKey,
            "q.csv");

        Assert.False(LocalDownloadTickets.TryValidate(
            ticket.Key,
            ticket.ExpiresUnix.ToString(),
            ticket.Signature,
            ticket.FileName,
            null,
            "different-signing-key-value-32chars!!",
            out _));
    }
}
