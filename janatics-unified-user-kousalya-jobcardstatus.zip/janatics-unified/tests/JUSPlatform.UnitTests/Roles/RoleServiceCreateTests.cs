using JUSPlatform.Application.Roles;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.UnitTests.Roles;

public sealed class RoleServiceCreateTests
{
    [Fact]
    public async Task CreateAsync_creates_custom_role_with_permissions()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));

        var created = await service.CreateAsync(
            new CreateRoleRequest("Job Operator", "Job desk access", [Permissions.JobsRead, Permissions.JobsWrite]),
            CancellationToken.None);

        Assert.Equal("Job Operator", created.Name);
        Assert.False(created.IsSystem);
        Assert.Contains(Permissions.JobsRead, created.Permissions);
        Assert.Contains(Permissions.JobsWrite, created.Permissions);
    }

    [Fact]
    public async Task CreateAsync_assigns_menus_matching_permissions()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var module = new AppModule { Code = "ADMIN", Name = "Administration", IsActive = true };
        db.AppModules.Add(module);
        await db.SaveChangesAsync();
        var jobsMenu = new AppMenu
        {
            ModuleId = module.Id,
            Code = "JOB",
            Name = "Jobs",
            Path = "/dashboard/jobs",
            PermissionCode = Permissions.JobsRead,
            IsActive = true
        };
        var usersMenu = new AppMenu
        {
            ModuleId = module.Id,
            Code = "USR",
            Name = "Users",
            Path = "/dashboard/users",
            PermissionCode = Permissions.UsersRead,
            IsActive = true
        };
        db.AppMenus.AddRange(jobsMenu, usersMenu);
        await db.SaveChangesAsync();

        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));
        var created = await service.CreateAsync(
            new CreateRoleRequest("Job Operator", "Job desk access", [Permissions.JobsRead, Permissions.JobsWrite]),
            CancellationToken.None);

        Assert.Single(created.Menus);
        Assert.Equal(jobsMenu.Id, created.Menus[0].MenuId);
        Assert.True(created.Menus[0].CanRead);
    }

    [Fact]
    public async Task CreateAsync_reserved_system_role_name_throws()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreateAsync(
                new CreateRoleRequest(SystemRoles.Admin, null, [Permissions.UsersRead]),
                CancellationToken.None));
    }

    [Fact]
    public async Task CreateAsync_seeded_system_role_name_throws()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreateAsync(
                new CreateRoleRequest(SystemRoles.Manager, null, [Permissions.UsersRead]),
                CancellationToken.None));
    }

    [Fact]
    public async Task UpdateAsync_privileged_system_role_throws()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var role = new Role
        {
            OrganizationId = orgId,
            Name = SystemRoles.Admin,
            IsSystem = true
        };
        db.Roles.Add(role);
        await db.SaveChangesAsync();

        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.UpdateAsync(
                role.Id,
                new UpdateRoleRequest(SystemRoles.Admin, null, [Permissions.UsersRead]),
                CancellationToken.None));
    }

    [Fact]
    public async Task CreateAsync_super_admin_creates_global_role()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var service = new RoleService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        var created = await service.CreateAsync(
            new CreateRoleRequest("Clerk", null, [Permissions.UsersRead]),
            CancellationToken.None);

        Assert.Equal("Clerk", created.Name);
        Assert.Null(created.OrganizationId);
    }

    [Fact]
    public async Task CreateAsync_super_admin_creates_role_in_target_org()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var service = new RoleService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        var created = await service.CreateAsync(
            new CreateRoleRequest("Clerk", "Org clerk", [Permissions.UsersRead], null, orgId),
            CancellationToken.None);

        Assert.Equal("Clerk", created.Name);
        Assert.Equal(orgId, created.OrganizationId);
        Assert.Contains(Permissions.UsersRead, created.Permissions);
    }

    [Fact]
    public async Task CreatePermissionAsync_super_admin_adds_catalog_code()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);
        db.Roles.Add(new Role
        {
            OrganizationId = null,
            Name = SystemRoles.SuperAdmin,
            IsSystem = true
        });
        await db.SaveChangesAsync();

        var service = new RoleService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        var created = await service.CreatePermissionAsync(
            new CreatePermissionRequest("CUSTOMER.VIEW", "View customers", "Customers"),
            CancellationToken.None);

        Assert.Equal("customer.view", created.Code);
        Assert.Equal("View customers", created.Name);
        Assert.True(await db.RolePermissions.AnyAsync(x => x.PermissionId == created.Id));
    }

    [Fact]
    public async Task UpdatePermissionAsync_super_admin_renames_catalog_entry()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);
        var permission = db.Permissions.First(x => x.Code == Permissions.JobCardView);
        var service = new RoleService(
            db,
            new RoleServiceUpdateTests.TestCurrentUser(null, SystemRoles.SuperAdmin));

        var updated = await service.UpdatePermissionAsync(
            permission.Id,
            new UpdatePermissionRequest("jobcard.view", "Read Job Card Status", "PES"),
            CancellationToken.None);

        Assert.Equal("jobcard.view", updated.Code);
        Assert.Equal("Read Job Card Status", updated.Name);
    }

    [Fact]
    public async Task CreatePermissionAsync_org_admin_is_rejected()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.CreatePermissionAsync(
                new CreatePermissionRequest("customer.view", "View customers", "Customers"),
                CancellationToken.None));
    }

    [Fact]
    public async Task UpdatePermissionAsync_org_admin_is_rejected()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);
        var permission = db.Permissions.First();
        var service = new RoleService(db, new RoleServiceUpdateTests.TestCurrentUser(orgId));

        await Assert.ThrowsAsync<BusinessRuleException>(() =>
            service.UpdatePermissionAsync(
                permission.Id,
                new UpdatePermissionRequest(permission.Code, "Renamed", permission.Module),
                CancellationToken.None));
    }

    private static async Task SeedPermissionsAsync(AppDbContext db)
    {
        foreach (var (code, name, module) in Permissions.Catalog)
        {
            db.Permissions.Add(new Permission { Code = code, Name = name, Module = module });
        }

        await db.SaveChangesAsync();
    }
}
