using System.Text.Json;
using FluentValidation;
using JUSPlatform.Application.Jobs;
using JUSPlatform.Application.Roles;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.UnitTests.Roles;

public sealed class RoleServiceUpdateTests
{
    [Fact]
    public async Task UpdateAsync_replaces_role_permissions()
    {
        var orgId = Guid.NewGuid();
        var db = await CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var role = new Role
        {
            OrganizationId = orgId,
            Name = "Custom",
            IsSystem = false
        };
        db.Roles.Add(role);
        await db.SaveChangesAsync();

        db.RolePermissions.Add(new RolePermission
        {
            RoleId = role.Id,
            PermissionId = (await db.Permissions.SingleAsync(x => x.Code == Permissions.JobsRead)).Id
        });
        await db.SaveChangesAsync();

        var service = new RoleService(db, new TestCurrentUser(orgId));

        var updated = await service.UpdateAsync(
            role.Id,
            new UpdateRoleRequest("Custom", "Updated", [Permissions.JobsWrite]),
            CancellationToken.None);

        Assert.Contains(Permissions.JobsWrite, updated.Permissions);
        Assert.DoesNotContain(Permissions.JobsRead, updated.Permissions);
    }

    [Fact]
    public async Task UpdateAsync_unknown_permission_code_throws()
    {
        var orgId = Guid.NewGuid();
        var db = await CreateDbAsync(orgId);
        await SeedPermissionsAsync(db);

        var role = new Role { OrganizationId = orgId, Name = "Custom" };
        db.Roles.Add(role);
        await db.SaveChangesAsync();

        var service = new RoleService(db, new TestCurrentUser(orgId));

        await Assert.ThrowsAsync<JUSPlatform.Domain.Exceptions.BusinessRuleException>(() =>
            service.UpdateAsync(
                role.Id,
                new UpdateRoleRequest("Custom", null, ["not.a.real.permission"]),
                CancellationToken.None));
    }

    internal static async Task<AppDbContext> CreateDbAsync(Guid orgId)
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        var db = new AppDbContext(options, new TestCurrentUser(orgId));
        db.Organizations.Add(new Organization { Id = orgId, Name = "Test Org", Code = "TEST" });
        await db.SaveChangesAsync();
        return db;
    }

    private static async Task SeedPermissionsAsync(AppDbContext db)
    {
        foreach (var (code, name, module) in Permissions.Catalog)
        {
            db.Permissions.Add(new Permission { Code = code, Name = name, Module = module });
        }

        await db.SaveChangesAsync();
    }

    internal sealed class TestCurrentUser(Guid? organizationId, string roleName = "Admin", Guid? userId = null) : Application.Common.ICurrentUser
    {
        public Guid? UserId { get; } = userId ?? Guid.NewGuid();
        public Guid? OrganizationId { get; } = organizationId;
        public string? RoleName { get; } = roleName;
        public bool IsAuthenticated { get; } = true;
        public IReadOnlyCollection<string> Permissions { get; } = [];
    }
}
