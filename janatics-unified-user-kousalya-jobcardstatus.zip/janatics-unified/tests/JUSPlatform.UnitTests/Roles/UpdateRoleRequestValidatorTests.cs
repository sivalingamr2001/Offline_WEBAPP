using FluentValidation.TestHelper;
using JUSPlatform.Application.Roles;

namespace JUSPlatform.UnitTests.Roles;

public sealed class UpdateRoleRequestValidatorTests
{
    private readonly UpdateRoleRequestValidator _validator = new();

    [Fact]
    public void Valid_request_passes()
    {
        var result = _validator.TestValidate(new UpdateRoleRequest(
            "Manager",
            "Ops role",
            ["job.read", "job.write"]));

        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Null_permission_codes_fails()
    {
        var result = _validator.TestValidate(new UpdateRoleRequest("Manager", null, null!));
        result.ShouldHaveValidationErrorFor(x => x.PermissionCodes);
    }
}
