using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence.Seed;
using JUSPlatform.UnitTests.Roles;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.UnitTests.Access;

public sealed class PesAccessSeederTests
{
    [Fact]
    public async Task EnsureAsync_grants_catalog_pes_menus_with_paths()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);

        var pes = new AppModule { Code = "MOD003", Name = "PES", IsActive = true };
        db.AppModules.Add(pes);
        await db.SaveChangesAsync();
        db.AppMenus.AddRange(
            new AppMenu
            {
                ModuleId = pes.Id,
                Module = pes,
                Code = "MNU022",
                Name = "On-Time Delivery",
                Path = "/modules/pes/on-time-delivery",
                MenuPath = "/modules/pes/on-time-delivery",
                IsActive = true
            },
            new AppMenu
            {
                ModuleId = pes.Id,
                Module = pes,
                Code = "PES001",
                Name = "PES Overview",
                Path = "/modules/pes",
                IsActive = true
            });
        var role = new Role { OrganizationId = null, Name = "Plant Clerk" };
        db.Roles.Add(role);
        var user = new User
        {
            Email = PesAccessSeeder.OperatorEmail,
            DisplayName = "Operator",
            PasswordHash = "hash",
            RoleId = role.Id
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();

        await PesAccessSeeder.EnsureAsync(db);

        var menuCodes = await db.RoleMenus
            .Where(x => x.RoleId == role.Id)
            .Join(db.AppMenus, rm => rm.MenuId, m => m.Id, (_, m) => m.Code)
            .ToListAsync();
        Assert.Contains("MNU022", menuCodes);
        Assert.DoesNotContain("PES001", menuCodes);
        Assert.Equal(role.Id, (await db.Users.SingleAsync(x => x.Id == user.Id)).RoleId);
        var permCodes = await db.RolePermissions
            .Where(x => x.RoleId == role.Id)
            .Join(db.Permissions, rp => rp.PermissionId, p => p.Id, (_, p) => p.Code)
            .ToListAsync();
        Assert.Contains(Permissions.PesView, permCodes);
        Assert.Contains(Permissions.PesEdit, permCodes);
    }
}
