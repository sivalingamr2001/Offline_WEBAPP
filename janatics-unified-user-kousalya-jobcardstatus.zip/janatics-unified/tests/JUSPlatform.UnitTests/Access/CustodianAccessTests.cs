using JUSPlatform.Application.Access;

namespace JUSPlatform.UnitTests.Access;

public sealed class CustodianAccessTests
{
    [Theory]
    [InlineData("0486", "0486")]
    [InlineData("0486", "486")]
    [InlineData("486", "0486")]
    [InlineData(" 0486 ", "0486")]
    public void MatchesCardNo_treats_leading_zeros_as_the_same_card(string cardNo, string empId)
    {
        Assert.True(CustodianAccess.MatchesCardNo(cardNo, empId));
    }

    [Fact]
    public void DistinctCodes_returns_every_active_code_for_one_card_no()
    {
        var userId = Guid.NewGuid();
        var lines = new CustodianLineRef[]
        {
            new(null, "0486", "CG012"),
            new(null, "0486", "CG013"),
            new(null, "0486", "CG014"),
            new(null, "0486", "CG015"),
            new(null, "0999", "CG999"),
        };

        var codes = CustodianAccess.DistinctCodes(lines, userId, "486");

        Assert.Equal(4, codes.Count);
        Assert.Contains("cg012", codes);
        Assert.Contains("cg013", codes);
        Assert.Contains("cg014", codes);
        Assert.Contains("cg015", codes);
        Assert.DoesNotContain("cg999", codes);
    }
}
