using JUSPlatform.Application.Access;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;

namespace JUSPlatform.UnitTests.Access;

public sealed class NavigationAccessResolverTests
{
    [Fact]
    public void Custom_role_sees_assigned_and_permission_menus()
    {
        var admin = new AppModule { Code = "ADMIN", Name = "Administration", IsActive = true, SortOrder = 10 };
        var users = new AppMenu
        {
            ModuleId = admin.Id,
            Module = admin,
            Code = "USR",
            Name = "Users",
            Path = "/dashboard/users",
            PermissionCode = Permissions.UsersRead,
            IsActive = true,
            SortOrder = 10
        };
        var roles = new AppMenu
        {
            ModuleId = admin.Id,
            Module = admin,
            Code = "ROL",
            Name = "Roles",
            Path = "/dashboard/roles",
            PermissionCode = Permissions.RolesRead,
            IsActive = true,
            SortOrder = 20
        };
        var home = new AppMenu
        {
            ModuleId = admin.Id,
            Module = admin,
            Code = "HOME",
            Name = "Home",
            Path = "/dashboard",
            IsActive = true,
            SortOrder = 1
        };

        var modules = NavigationAccessResolver.Resolve(
            "Warehouse Clerk",
            [Permissions.UsersRead],
            [admin],
            [users, roles, home],
            [new RoleMenu { MenuId = home.Id, CanRead = true }]);

        Assert.Single(modules);
        Assert.Equal(2, modules[0].Menus.Count);
        Assert.Contains(modules[0].Menus, m => m.Code == "USR");
        Assert.Contains(modules[0].Menus, m => m.Code == "HOME");
        Assert.DoesNotContain(modules[0].Menus, m => m.Code == "ROL");
    }

    [Fact]
    public void Role_menu_grants_a_menu()
    {
        var operate = new AppModule { Code = "OPERATE", Name = "Operate", IsActive = true };
        var portfolio = new AppMenu
        {
            ModuleId = operate.Id,
            Module = operate,
            Code = "PORT",
            Name = "Portfolio",
            Path = "/dashboard/portfolio",
            IsActive = true
        };

        var granted = NavigationAccessResolver.Resolve(
            "Clerk",
            [],
            [operate],
            [portfolio],
            [new RoleMenu { MenuId = portfolio.Id, CanRead = true }]);

        Assert.Single(granted);
        Assert.Equal("PORT", granted[0].Menus[0].Code);
    }

    [Fact]
    public void SuperAdmin_sees_all_active_menus()
    {
        var admin = new AppModule { Code = "ADMIN", Name = "Administration", IsActive = true };
        var operate = new AppModule { Code = "OPERATE", Name = "Operate", IsActive = true };
        var orgs = new AppMenu
        {
            ModuleId = admin.Id,
            Module = admin,
            Code = "ORG",
            Name = "Organizations",
            Path = "/dashboard/organizations",
            Nature = AppMenuCatalog.NaturePlatform,
            IsActive = true
        };
        var roles = new AppMenu
        {
            ModuleId = admin.Id,
            Module = admin,
            Code = "MNU002",
            Name = "Roles",
            Nature = AppMenuCatalog.NatureTenant,
            IsActive = true
        };
        var system = new AppMenu
        {
            ModuleId = admin.Id,
            Module = admin,
            Code = "MNU008",
            Name = "System",
            MenuPath = "/dashboard/system",
            MenuIcon = "Cpu",
            Nature = AppMenuCatalog.NaturePlatform,
            IsActive = true,
            SortOrder = 2
        };
        var portfolio = new AppMenu
        {
            ModuleId = operate.Id,
            Module = operate,
            Code = "PORT",
            Name = "Portfolio",
            IsActive = true
        };

        var modules = NavigationAccessResolver.Resolve(
            SystemRoles.SuperAdmin,
            Permissions.SuperAdminGrant,
            [admin, operate],
            [orgs, roles, system, portfolio],
            []);

        Assert.Equal(2, modules.Count);
        Assert.Contains(modules, m => m.Code == "ADMIN");
        Assert.Contains(modules, m => m.Code == "OPERATE");
        var adminMenus = modules.Single(m => m.Code == "ADMIN").Menus;
        Assert.Contains(adminMenus, m => m.Code == "ORG");
        Assert.Contains(adminMenus, m => m.Code == "MNU002");
        var systemMenu = Assert.Single(adminMenus, m => m.Code == "MNU008");
        Assert.Equal("/dashboard/system", systemMenu.Path);
        Assert.Equal("Cpu", systemMenu.Icon);
        Assert.Contains(modules.Single(m => m.Code == "OPERATE").Menus, m => m.Code == "PORT");
    }
}
