using JUSPlatform.Application.JobCard;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Leftovers;
using JUSPlatform.Infrastructure.Persistence.Oracle;
using JUSPlatform.UnitTests.Roles;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace JUSPlatform.UnitTests.JobCard;

public sealed class JobCardStatusServiceTests
{
    [Fact]
    public async Task GetScreenAsync_without_custodian_returns_empty()
    {
        var orgId = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var org = db.Organizations.Single();
        org.OracleOrgId = 101;
        db.Users.Add(new User
        {
            Id = userId,
            OrganizationId = orgId,
            Email = "clerk@example.local",
            DisplayName = "Clerk",
            PasswordHash = "x",
            EmpId = "E100"
        });
        db.UserAccessRights.Add(new UserAccessRight
        {
            UserId = userId,
            OrganizationId = orgId,
            IsActive = true
        });
        await db.SaveChangesAsync();

        var oracle = CreateOracle();
        var sut = new JobCardStatusService(
            db,
            oracle,
            new RoleServiceUpdateTests.TestCurrentUser(orgId, userId: userId),
            Options.Create(new OracleOptions { Enabled = true }));

        var dto = await sut.GetScreenAsync(new JobCardQuery(), CancellationToken.None);

        Assert.Equal(0, dto.Kpis.TotalJobs);
        Assert.Empty(dto.Jobs);
    }

    [Fact]
    public async Task GetScreenAsync_super_admin_filters_by_oracle_org_id()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var org = db.Organizations.Single();
        org.OracleOrgId = 101;
        org.UnitName = "Pune Plant";
        await db.SaveChangesAsync();

        var oracle = CreateOracle();
        oracle.JanWipTests.Add(new JanWipTest
        {
            OrganizationId = 101,
            WipEntityId = 1,
            JobNo = "JOB-1001",
            JobDt = DateTime.UtcNow.Date.AddDays(-2),
            CustodianCode = "c-pune",
            ItemNo = "10",
            Opn1OperationSeq = 10,
            Opn1OperationDesc = "Heat Treat",
            Opn1LeadTime = 2,
            Opn1QtyQueue = 1
        });
        oracle.JanWipTests.Add(new JanWipTest
        {
            OrganizationId = 999,
            WipEntityId = 2,
            JobNo = "JOB-OTHER-ORG",
            JobDt = DateTime.UtcNow.Date.AddDays(-2),
            CustodianCode = "c-pune",
            Opn1OperationSeq = 10,
            Opn1OperationDesc = "Other"
        });
        await oracle.SaveChangesAsync();

        var sut = new JobCardStatusService(
            db,
            oracle,
            new RoleServiceUpdateTests.TestCurrentUser(null, "SuperAdmin"),
            Options.Create(new OracleOptions { Enabled = true }));

        var dto = await sut.GetScreenAsync(
            new JobCardQuery { DateRange = "all", OrganizationId = orgId },
            CancellationToken.None);

        Assert.Equal(1, dto.Kpis.TotalJobs);
        var job = Assert.Single(dto.Jobs);
        Assert.Equal("JOB-1001", job.JobNo);
        Assert.Equal("Pune Plant", job.Plant);
    }

    [Fact]
    public async Task GetScreenAsync_loads_osp_jobs_for_every_custodian_on_the_card()
    {
        var orgId = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var org = db.Organizations.Single();
        org.OracleOrgId = 101;
        org.UnitName = "Pune Plant";
        db.Users.Add(new User
        {
            Id = userId,
            OrganizationId = orgId,
            Email = "anandhi@example.local",
            DisplayName = "Anandhi",
            PasswordHash = "x",
            EmpId = "486"
        });
        db.UserAccessRights.Add(new UserAccessRight
        {
            UserId = userId,
            OrganizationId = orgId,
            IsActive = true
        });
        db.JanCustodianLines.AddRange(
            Line(23, "0486", "CG012"),
            Line(25, "0486", "CG013"),
            Line(27, "0486", "CG014"),
            Line(29, "0486", "CG015"),
            Line(99, "0999", "CG999"));
        await db.SaveChangesAsync();

        var oracle = CreateOracle();
        var jobDate = DateTime.UtcNow.Date.AddDays(-2);
        oracle.JanWipTests.AddRange(JobCardOracleMock.CreateRows(101, jobDate));
        oracle.JanWipTests.Add(new JanWipTest
        {
            OrganizationId = 101,
            WipEntityId = 9999,
            JobNo = "JOB-OTHER-CUSTODIAN",
            JobDt = jobDate,
            CustodianCode = "CG999",
            Opn1OperationSeq = 10,
            Opn1OperationDesc = "Other"
        });
        await oracle.SaveChangesAsync();

        var sut = new JobCardStatusService(
            db,
            oracle,
            new RoleServiceUpdateTests.TestCurrentUser(orgId, userId: userId),
            Options.Create(new OracleOptions { Enabled = true }));

        var dto = await sut.GetScreenAsync(new JobCardQuery { DateRange = "all" }, CancellationToken.None);

        Assert.Equal(4, dto.Kpis.TotalJobs);
        Assert.Equal(4, dto.Jobs.Count);
        Assert.Contains(dto.Jobs, x => x.JobNo == "JOB-0486-CG012");
        Assert.Contains(dto.Jobs, x => x.JobNo == "JOB-0486-CG013");
        Assert.Contains(dto.Jobs, x => x.JobNo == "JOB-0486-CG014");
        Assert.Contains(dto.Jobs, x => x.JobNo == "JOB-0486-CG015");
        Assert.DoesNotContain(dto.Jobs, x => x.JobNo == "JOB-OTHER-CUSTODIAN");
    }

    [Fact]
    public async Task GetScreenAsync_operator_uses_custodian_even_when_oracle_org_differs()
    {
        var orgId = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var org = db.Organizations.Single();
        org.OracleOrgId = 101;
        db.Users.Add(new User
        {
            Id = userId,
            OrganizationId = orgId,
            Email = "clerk@example.local",
            DisplayName = "Clerk",
            PasswordHash = "x",
            EmpId = "0486"
        });
        db.UserAccessRights.Add(new UserAccessRight
        {
            UserId = userId,
            OrganizationId = orgId,
            IsActive = true
        });
        db.JanCustodianLines.AddRange(
            Line(7, "0486", "CG007"),
            Line(8, "0486", "CG008"),
            Line(9, "0486", "CG009"));
        await db.SaveChangesAsync();

        var oracle = CreateOracle();
        oracle.JanWipTests.Add(new JanWipTest
        {
            OrganizationId = 504,
            WipEntityId = 41154629,
            JobNo = "2026-0000261983",
            JobDt = new DateTime(2026, 7, 16),
            ItemNo = "414025",
            CustodianCode = "CG007",
            AlternateRoutingDesignator = "Prod_Route",
            Opn1OperationSeq = 10,
            Opn1OperationDesc = "CU_TU1_VMC1_TU2_VMC2_PO",
            Opn1VendorName = "AMK INDUSTRIES",
            Opn1LeadTime = 28,
            Opn1QtyComp = 420,
            Opn1ProcessStartDate = new DateTime(2026, 7, 16)
        });
        await oracle.SaveChangesAsync();

        var sut = new JobCardStatusService(
            db,
            oracle,
            new RoleServiceUpdateTests.TestCurrentUser(orgId, userId: userId),
            Options.Create(new OracleOptions { Enabled = true }));

        var dto = await sut.GetScreenAsync(new JobCardQuery { DateRange = "all" }, CancellationToken.None);

        var job = Assert.Single(dto.Jobs);
        Assert.Equal("2026-0000261983", job.JobNo);
    }

    [Fact]
    public async Task GetScreenAsync_disabled_oracle_returns_empty()
    {
        var orgId = Guid.NewGuid();
        var db = await RoleServiceUpdateTests.CreateDbAsync(orgId);
        var sut = new JobCardStatusService(
            db,
            CreateOracle(),
            new RoleServiceUpdateTests.TestCurrentUser(null, "SuperAdmin"),
            Options.Create(new OracleOptions { Enabled = false }));

        var dto = await sut.GetScreenAsync(new JobCardQuery(), CancellationToken.None);

        Assert.Equal(0, dto.Kpis.TotalJobs);
    }

    private static OracleDbContext CreateOracle()
    {
        var options = new DbContextOptionsBuilder<OracleDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new OracleDbContext(options);
    }

    private static JanCustodianLine Line(decimal id, string cardNo, string code) =>
        new()
        {
            CustLineId = id,
            CardNo = cardNo,
            CustodianCode = code,
            ActiveFlag = 1
        };
}
