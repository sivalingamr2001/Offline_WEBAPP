using JUSPlatform.Infrastructure.Persistence.Oracle;

namespace JUSPlatform.UnitTests.JobCard;

public sealed class OracleValueTests
{
    [Fact]
    public void ToDecimal_accepts_oracle_numeric_shapes()
    {
        Assert.Equal(12m, OracleValue.ToDecimal(12m));
        Assert.Equal(12m, OracleValue.ToDecimal(12d));
        Assert.Equal(12m, OracleValue.ToDecimal(12L));
        Assert.Equal(12m, OracleValue.ToDecimal(12));
        Assert.Equal(12.5m, OracleValue.ToDecimal("12.5"));
        Assert.Null(OracleValue.ToDecimal(DBNull.Value));
        Assert.Null(OracleValue.ToDecimal(null));
    }

    [Fact]
    public void ToStringValue_keeps_item_codes()
    {
        Assert.Equal("A-100", OracleValue.ToStringValue("A-100"));
        Assert.Equal("10", OracleValue.ToStringValue(10m));
        Assert.Null(OracleValue.ToStringValue(DBNull.Value));
    }
}
