using JUSPlatform.Application.JobCard;
using JUSPlatform.Infrastructure.Persistence.Oracle;

namespace JUSPlatform.UnitTests.JobCard;

public sealed class JobCardJourneyMapperTests
{
    [Fact]
    public void Map_skips_empty_operations_and_marks_completed_when_qty_comp()
    {
        var row = new JanWipTest
        {
            OrganizationId = 101,
            WipEntityId = 9001,
            JobNo = "JOB-1001",
            JobDt = DateTime.UtcNow.Date.AddDays(-10),
            ItemNo = "4401",
            AlternateRoutingDesignator = "STD",
            Opn1OperationSeq = 10,
            Opn1OperationDesc = "Heat Treat",
            Opn1VendorName = "OSP Alpha",
            Opn1LeadTime = 3,
            Opn1QtyComp = 5,
            Opn1ProcessStartDate = DateTime.UtcNow.Date.AddDays(-8)
        };

        var dto = JobCardJourneyMapper.Map(row, "Pune Plant", DateTimeOffset.UtcNow);

        Assert.Equal("JOB-1001", dto.JobNo);
        Assert.Equal("STD", dto.JobType);
        Assert.Equal("Pune Plant", dto.Plant);
        Assert.Single(dto.Operations);
        Assert.Equal("Heat Treat", dto.Operations[0].Name);
        Assert.Equal(JobCardStatusCodes.Completed, dto.Operations[0].Status);
        Assert.Equal(JobCardStatusCodes.Completed, dto.OverallStatus);
        Assert.Equal(2 + 3 + 1, dto.PlanTatDays);
    }

    [Fact]
    public void Map_builds_train_from_each_osp_process_start_date()
    {
        var jobDt = new DateTime(2026, 7, 16);
        var asOf = new DateTimeOffset(new DateTime(2026, 9, 19), TimeSpan.Zero);
        var row = new JanWipTest
        {
            OrganizationId = 504,
            WipEntityId = 41154629,
            JobNo = "2026-0000261983",
            JobDt = jobDt,
            Opn1OperationSeq = 10,
            Opn1OperationDesc = "CU_TU1",
            Opn1LeadTime = 28,
            Opn1QtyComp = 420,
            Opn1ProcessStartDate = jobDt,
            Opn2OperationSeq = 20,
            Opn2OperationDesc = "OSP 2",
            Opn2LeadTime = 5,
            Opn2ProcessStartDate = new DateTime(2026, 8, 20),
            Opn3OperationSeq = 30,
            Opn3OperationDesc = "OSP 3",
            Opn3LeadTime = 4,
            Opn3ProcessStartDate = new DateTime(2026, 9, 1),
            Opn4OperationDesc = "OSP 4",
            Opn4LeadTime = 2,
            Opn4ProcessStartDate = new DateTime(2026, 9, 10),
            Opn5OperationDesc = "OSP 5",
            Opn5ProcessStartDate = new DateTime(2026, 9, 14),
            Opn6OperationDesc = "OSP 6",
            Opn6ProcessStartDate = new DateTime(2026, 9, 16)
        };

        var dto = JobCardJourneyMapper.Map(row, "Org 504", asOf);

        Assert.Equal(6, dto.Operations.Count);
        Assert.Equal(jobDt, dto.Operations[0].ProcessStartDate);
        Assert.Equal(new DateTime(2026, 8, 20), dto.Operations[1].ProcessStartDate);
        Assert.Equal(JobCardStatusCodes.Completed, dto.Operations[0].Status);
        var osp2Proc = dto.Operations[1].Phases.Single(p => p.Kind == "proc");
        Assert.Equal(JobCardStatusCodes.Delayed, osp2Proc.Status);
        Assert.Equal(30, osp2Proc.ActualDays);
    }

    [Fact]
    public void StatusFromVariance_uses_job_card_bands()
    {
        Assert.Equal(JobCardStatusCodes.OnTrack, JobCardJourneyMapper.StatusFromVariance(0, false));
        Assert.Equal(JobCardStatusCodes.Completed, JobCardJourneyMapper.StatusFromVariance(-1, true));
        Assert.Equal(JobCardStatusCodes.AtRisk, JobCardJourneyMapper.StatusFromVariance(1, false));
        Assert.Equal(JobCardStatusCodes.Delayed, JobCardJourneyMapper.StatusFromVariance(2, false));
    }
}
