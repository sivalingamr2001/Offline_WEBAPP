using JUSPlatform.Application.Oracle;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace JUSPlatform.UnitTests.Oracle;

public sealed class OracleConnectionServiceTests
{
    [Fact]
    public async Task TestAsync_returns_disabled_when_oracle_is_off()
    {
        var options = new DbContextOptionsBuilder<OracleDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        await using var db = new OracleDbContext(options);
        var sut = new OracleConnectionService(db, Options.Create(new OracleOptions { Enabled = false }));

        var result = await sut.TestAsync();

        Assert.Equal("disabled", result.Status);
        Assert.False(result.Enabled);
    }

    [Fact]
    public async Task TestAsync_returns_connected_when_enabled_and_database_is_reachable()
    {
        var options = new DbContextOptionsBuilder<OracleDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        await using var db = new OracleDbContext(options);
        var sut = new OracleConnectionService(db, Options.Create(new OracleOptions { Enabled = true }));

        var result = await sut.TestAsync();

        Assert.Equal("connected", result.Status);
        Assert.True(result.Enabled);
    }

    [Fact]
    public async Task TestAsync_returns_disconnected_when_enabled_and_database_cannot_connect()
    {
        var options = new DbContextOptionsBuilder<OracleDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        var db = new OracleDbContext(options);
        await db.DisposeAsync();
        var sut = new OracleConnectionService(db, Options.Create(new OracleOptions { Enabled = true }));

        var result = await sut.TestAsync();

        Assert.Equal("disconnected", result.Status);
        Assert.True(result.Enabled);
    }
}
