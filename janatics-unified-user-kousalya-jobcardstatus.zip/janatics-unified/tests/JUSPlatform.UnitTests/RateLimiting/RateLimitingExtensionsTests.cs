using Microsoft.AspNetCore.Http;
using JUSPlatform.Infrastructure.RateLimiting;

namespace JUSPlatform.UnitTests.RateLimiting;

public sealed class RateLimitingExtensionsTests
{
    [Theory]
    [InlineData("/api", true)]
    [InlineData("/api/heath", true)]
    [InlineData("/api/health", true)]
    [InlineData("/api/oracle/connection", true)]
    [InlineData("/docs", true)]
    [InlineData("/login", true)]
    [InlineData("/api/v1/auth/login", false)]
    [InlineData("/api/v1/users", false)]
    public void ShouldSkipApiLimit_by_path(string path, bool skip)
    {
        var context = new DefaultHttpContext();
        context.Request.Method = HttpMethods.Post;
        context.Request.Path = path;

        Assert.Equal(skip, RateLimitingExtensions.ShouldSkipApiLimit(context));
    }

    [Fact]
    public void ShouldSkipApiLimit_skips_cors_preflight()
    {
        var context = new DefaultHttpContext();
        context.Request.Method = HttpMethods.Options;
        context.Request.Path = "/api/v1/auth/login";

        Assert.True(RateLimitingExtensions.ShouldSkipApiLimit(context));
    }
}
