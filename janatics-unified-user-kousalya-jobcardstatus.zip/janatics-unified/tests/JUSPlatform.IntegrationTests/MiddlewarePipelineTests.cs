using System.Net;
using System.Net.Http.Json;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.Oracle;
using JUSPlatform.Middleware;

namespace JUSPlatform.IntegrationTests;

[Collection(IntegrationTestCollection.Name)]
public sealed class MiddlewarePipelineTests(JUSPlatformWebApplicationFactory factory)
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task Ping_includes_response_id_header()
    {
        using var response = await _client.GetAsync("/api");

        response.EnsureSuccessStatusCode();
        Assert.True(response.Headers.TryGetValues(ResponseIdMiddleware.HeaderName, out _));

        var body = await response.Content.ReadFromJsonAsync<PingResponse>();
        Assert.Equal("pong", body!.Message);
    }

    [Fact]
    public async Task Health_reports_database_up()
    {
        using var response = await _client.GetAsync("/api/heath");

        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<HealthResponse>();
        Assert.Equal("healthy", body!.Status);
        Assert.Equal("up", body.Database);
    }

    [Fact]
    public async Task Oracle_connection_reports_disabled_when_oracle_is_off()
    {
        using var response = await _client.GetAsync("/api/oracle/connection");

        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<OracleConnectionResponse>();
        Assert.Equal("disabled", body!.Status);
        Assert.False(body.Enabled);
    }

    [Fact]
    public async Task Protected_route_without_token_returns_json_401()
    {
        using var response = await _client.GetAsync("/api/v1/users");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<ApiErrorResponse>();
        Assert.False(body!.Success);
        Assert.Contains("Authentication", body.Detail!, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Unknown_api_route_returns_json_404()
    {
        using var response = await _client.GetAsync("/api/v1/does-not-exist");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<ApiErrorResponse>();
        Assert.False(body!.Success);
        Assert.Contains("Not found", body.Detail!, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Trigger_error_returns_json_500_when_app_debug()
    {
        using var response = await _client.PostAsync("/api/v1/demo/trigger-error", null);

        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<ApiErrorResponse>();
        Assert.False(body!.Success);
        Assert.Contains("unexpected error", body.Detail!, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Accepts_client_request_id_for_response_id()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api");
        request.Headers.Add(CorrelationId.RequestHeaderName, "client-correlation-id-01");

        using var response = await _client.SendAsync(request);

        response.EnsureSuccessStatusCode();
        Assert.Equal("client-correlation-id-01", response.Headers.GetValues(ResponseIdMiddleware.HeaderName).Single());
    }
}
