using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace JUSPlatform.IntegrationTests;

public sealed class JUSPlatformWebApplicationFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["UseInMemoryDatabase"] = "true",
                ["ConnectionStrings:Default"] = "JUSPlatformIntegrationTests",
                ["Oracle:Enabled"] = "true",
                ["Redis:Enabled"] = "false",
                ["Jobs:WorkerEnabled"] = "false",
                ["Hangfire:Enabled"] = "false",
                ["Observability:Enabled"] = "false",
                ["Bugsink:Enabled"] = "false",
                ["MockIntegrations:Enabled"] = "false",
                ["AppDebug"] = "true",
                ["Jwt:SigningKey"] = "integration-test-signing-key-at-least-32-chars",
                ["Seed:SuperAdminEmail"] = "admin@demo.local",
                ["Seed:SuperAdminPassword"] = "ChangeMe123!",
                ["Email:Enabled"] = "false",
                ["RateLimit:Enabled"] = "false",
            });

            config.AddJsonFile(
                Path.Combine(AppContext.BaseDirectory, "appsettings.Testing.json"),
                optional: true,
                reloadOnChange: false);
        });
    }
}
