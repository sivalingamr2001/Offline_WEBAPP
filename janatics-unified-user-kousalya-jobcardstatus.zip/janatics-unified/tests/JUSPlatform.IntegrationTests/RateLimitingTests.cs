using System.Net;
using System.Net.Http.Json;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Common;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace JUSPlatform.IntegrationTests;

public sealed class RateLimitingTests : IClassFixture<RateLimitedWebApplicationFactory>
{
    private readonly HttpClient _client;

    public RateLimitingTests(RateLimitedWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task Login_returns_429_after_auth_limit()
    {
        HttpStatusCode lastStatus = 0;
        ApiErrorResponse? lastBody = null;

        for (var i = 0; i < 3; i++)
        {
            using var response = await _client.PostAsJsonAsync(
                "/api/v1/auth/login",
                new LoginRequest("admin@demo.local", "wrong-password"));
            lastStatus = response.StatusCode;
            lastBody = await response.Content.ReadFromJsonAsync<ApiErrorResponse>();
        }

        Assert.Equal(HttpStatusCode.TooManyRequests, lastStatus);
        Assert.False(lastBody!.Success);
        Assert.Contains("Too many requests", lastBody.Detail, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Register_returns_429_after_strict_auth_limit()
    {
        HttpStatusCode lastStatus = 0;

        for (var i = 0; i < 3; i++)
        {
            using var response = await _client.PostAsJsonAsync(
                "/api/v1/auth/register",
                new RegisterRequest($"Org{i}", $"ORG{i}", $"owner{i}@limit.test", "Owner", "ChangeMe123!"));
            lastStatus = response.StatusCode;
        }

        Assert.Equal(HttpStatusCode.TooManyRequests, lastStatus);
    }
}

public sealed class RateLimitedWebApplicationFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["UseInMemoryDatabase"] = "true",
                ["ConnectionStrings:Default"] = "JUSPlatformRateLimitTests",
                ["Redis:Enabled"] = "false",
                ["Jobs:WorkerEnabled"] = "false",
                ["Hangfire:Enabled"] = "false",
                ["Observability:Enabled"] = "false",
                ["Bugsink:Enabled"] = "false",
                ["MockIntegrations:Enabled"] = "false",
                ["Email:Enabled"] = "false",
                ["AppDebug"] = "true",
                ["Jwt:SigningKey"] = "integration-test-signing-key-at-least-32-chars",
                ["Seed:SuperAdminEmail"] = "admin@demo.local",
                ["Seed:SuperAdminPassword"] = "ChangeMe123!",
                ["RateLimit:Enabled"] = "true",
                ["RateLimit:Auth:PermitLimit"] = "2",
                ["RateLimit:Auth:WindowSeconds"] = "60",
                ["RateLimit:AuthStrict:PermitLimit"] = "2",
                ["RateLimit:AuthStrict:WindowSeconds"] = "60",
                ["RateLimit:Api:PermitLimit"] = "1000",
                ["RateLimit:Api:WindowSeconds"] = "60",
                ["RateLimit:Api:ConcurrentLimit"] = "50",
            });
        });
    }
}
