namespace JUSPlatform.IntegrationTests;

[CollectionDefinition(Name)]
public sealed class IntegrationTestCollection : ICollectionFixture<JUSPlatformWebApplicationFactory>
{
    public const string Name = "JUSPlatform integration";
}
