using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Storage;
using JUSPlatform.Application.Users;
using Microsoft.Extensions.DependencyInjection;

namespace JUSPlatform.IntegrationTests;

[Collection(IntegrationTestCollection.Name)]
public sealed class StorageDownloadTests(JUSPlatformWebApplicationFactory factory)
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task Org_admin_can_download_own_export_without_jwt()
    {
        var login = await RegisterOrgAsync("DL");
        var me = await GetMeAsync(login.AccessToken);
        Assert.NotNull(me.OrganizationId);
        var key = StorageKeys.OrgExport(me.OrganizationId.Value, "sales.csv");

        await using var csv = new MemoryStream("sku,qty\nA,1\n"u8.ToArray());
        var storage = factory.Services.GetRequiredService<IObjectStorage>();
        await storage.PutAsync(key, csv, "text/csv", CancellationToken.None);

        using var issue = new HttpRequestMessage(HttpMethod.Post, "/api/v1/storage/download-urls")
        {
            Content = JsonContent.Create(new CreatePrivateDownloadRequest(key, "sales.csv", null))
        };
        issue.Headers.Authorization = new AuthenticationHeaderValue("Bearer", login.AccessToken);
        using var issued = await _client.SendAsync(issue);
        issued.EnsureSuccessStatusCode();
        var body = await issued.Content.ReadFromJsonAsync<PrivateDownloadDto>();
        Assert.False(string.IsNullOrWhiteSpace(body!.Url));
        Assert.InRange(body.ExpiresInSeconds, 1, 15 * 60);

        using var download = await _client.GetAsync(ToAppPath(body.Url));
        download.EnsureSuccessStatusCode();
        Assert.Equal("text/csv", download.Content.Headers.ContentType?.MediaType);
        Assert.Equal("sku,qty\nA,1\n", await download.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Issue_url_rejects_other_org_key()
    {
        var loginA = await RegisterOrgAsync("DA");
        var loginB = await RegisterOrgAsync("DB");
        var meA = await GetMeAsync(loginA.AccessToken);
        var key = StorageKeys.OrgExport(meA.OrganizationId!.Value, "secret.csv");

        using var issue = new HttpRequestMessage(HttpMethod.Post, "/api/v1/storage/download-urls")
        {
            Content = JsonContent.Create(new CreatePrivateDownloadRequest(key, "secret.csv", null))
        };
        issue.Headers.Authorization = new AuthenticationHeaderValue("Bearer", loginB.AccessToken);
        using var response = await _client.SendAsync(issue);
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Tampered_ticket_returns_404()
    {
        var login = await RegisterOrgAsync("DT");
        var me = await GetMeAsync(login.AccessToken);
        var key = StorageKeys.OrgExport(me.OrganizationId!.Value, "t.csv");
        await using var csv = new MemoryStream("x"u8.ToArray());
        await factory.Services.GetRequiredService<IObjectStorage>()
            .PutAsync(key, csv, "text/csv", CancellationToken.None);

        using var issue = new HttpRequestMessage(HttpMethod.Post, "/api/v1/storage/download-urls")
        {
            Content = JsonContent.Create(new CreatePrivateDownloadRequest(key, "t.csv", null))
        };
        issue.Headers.Authorization = new AuthenticationHeaderValue("Bearer", login.AccessToken);
        using var issued = await _client.SendAsync(issue);
        issued.EnsureSuccessStatusCode();
        var body = await issued.Content.ReadFromJsonAsync<PrivateDownloadDto>();
        var tampered = ToAppPath(body!.Url).Replace("s=", "s=AAAA", StringComparison.Ordinal);

        using var download = await _client.GetAsync(tampered);
        Assert.Equal(HttpStatusCode.NotFound, download.StatusCode);
    }

    [Fact]
    public async Task Anonymous_issue_returns_401()
    {
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/storage/download-urls",
            new CreatePrivateDownloadRequest("exports/x/a.csv", null, null));
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    private async Task<LoginResponse> RegisterOrgAsync(string prefix)
    {
        var code = $"{prefix}{Guid.NewGuid():N}"[..8].ToUpperInvariant();
        using var register = await _client.PostAsJsonAsync(
            "/api/v1/auth/register",
            new RegisterRequest($"{code} Org", code, $"owner@{code.ToLowerInvariant()}.test", "Owner", "ChangeMe123!"));
        register.EnsureSuccessStatusCode();
        var login = await register.Content.ReadFromJsonAsync<LoginResponse>();
        return login!;
    }

    private async Task<UserDto> GetMeAsync(string token)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/v1/users/me");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await _client.SendAsync(request);
        response.EnsureSuccessStatusCode();
        var me = await response.Content.ReadFromJsonAsync<UserDto>();
        return me!;
    }

    private static string ToAppPath(string url)
    {
        if (Uri.TryCreate(url, UriKind.Absolute, out var absolute))
        {
            return absolute.PathAndQuery;
        }

        return url;
    }
}
