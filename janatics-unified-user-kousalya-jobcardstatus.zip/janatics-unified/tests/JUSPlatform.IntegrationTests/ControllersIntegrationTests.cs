using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.Organizations;
using JUSPlatform.Application.Roles;
using JUSPlatform.Application.Users;
using JUSPlatform.Authorization;

namespace JUSPlatform.IntegrationTests;

[Collection(IntegrationTestCollection.Name)]
public sealed class ControllersIntegrationTests(JUSPlatformWebApplicationFactory factory)
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task Login_with_valid_credentials_returns_token()
    {
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/auth/login",
            new LoginRequest("admin@demo.local", "ChangeMe123!"));

        response.EnsureSuccessStatusCode();

        var body = await response.Content.ReadFromJsonAsync<LoginResponse>();
        Assert.False(string.IsNullOrWhiteSpace(body!.AccessToken));
        Assert.Equal("admin@demo.local", body.Email);
        Assert.Equal(SystemRoles.SuperAdmin, body.RoleName);
    }

    [Fact]
    public async Task Login_with_invalid_password_returns_401()
    {
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/auth/login",
            new LoginRequest("admin@demo.local", "wrong-password"));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<ApiErrorResponse>();
        Assert.False(body!.Success);
    }

    [Fact]
    public async Task Login_with_invalid_body_returns_400()
    {
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/auth/login",
            new LoginRequest("not-an-email", "short"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<ApiErrorResponse>();
        Assert.False(body!.Success);
        Assert.NotNull(body.Errors);
    }

    [Theory]
    [InlineData("/api/v1/users")]
    [InlineData("/api/v1/organizations")]
    [InlineData("/api/v1/operating-units")]
    [InlineData("/api/v1/roles")]
    public async Task SuperAdmin_platform_endpoints_return_success(string path)
    {
        var token = await LoginAsync("admin@demo.local", "ChangeMe123!");

        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        using var response = await _client.SendAsync(request);

        Assert.True(
            response.IsSuccessStatusCode,
            $"Expected success for {path}, got {(int)response.StatusCode}: {await response.Content.ReadAsStringAsync()}");
    }

    [Fact]
    public async Task SuperAdmin_current_organization_returns_400()
    {
        var token = await LoginAsync("admin@demo.local", "ChangeMe123!");

        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/v1/organizations/me");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        using var response = await _client.SendAsync(request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task SuperAdmin_jobs_endpoint_returns_success()
    {
        var token = await LoginAsync("admin@demo.local", "ChangeMe123!");

        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/v1/jobs");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        using var response = await _client.SendAsync(request);

        Assert.True(
            response.IsSuccessStatusCode,
            $"Expected success for jobs, got {(int)response.StatusCode}: {await response.Content.ReadAsStringAsync()}");
    }

    [Fact]
    public async Task Org_admin_list_endpoints_return_success()
    {
        using var register = await _client.PostAsJsonAsync(
            "/api/v1/auth/register",
            new RegisterRequest("Acme", "ACME", "owner@acme.test", "Acme Owner", "ChangeMe123!"));
        register.EnsureSuccessStatusCode();
        var login = await register.Content.ReadFromJsonAsync<LoginResponse>();
        Assert.Equal(SystemRoles.Admin, login!.RoleName);

        foreach (var path in new[]
        {
            "/api/v1/users",
            "/api/v1/roles",
            "/api/v1/jobs",
            "/api/v1/app-modules",
            "/api/v1/app-menus",
            "/api/v1/jobs",
            "/api/v1/organizations/me"
        })
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, path);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", login.AccessToken);
            using var response = await _client.SendAsync(request);
            Assert.True(
                response.IsSuccessStatusCode,
                $"Expected success for {path}, got {(int)response.StatusCode}: {await response.Content.ReadAsStringAsync()}");
        }
    }

    [Fact]
    public async Task SuperAdmin_can_create_organization()
    {
        var token = await LoginAsync("admin@demo.local", "ChangeMe123!");

        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/organizations")
        {
            Content = JsonContent.Create(new CreateOrganizationRequest("Northwind", "NORTH"))
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        using var response = await _client.SendAsync(request);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }

    [Fact]
    public async Task SuperAdmin_can_create_permission()
    {
        var token = await LoginAsync("admin@demo.local", "ChangeMe123!");
        var code = $"custom.{Guid.NewGuid():N}"[..20];

        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/roles/permissions")
        {
            Content = JsonContent.Create(new CreatePermissionRequest(code, "Custom view", "Custom"))
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        using var response = await _client.SendAsync(request);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }

    [Fact]
    public async Task Current_user_can_update_designation()
    {
        var code = $"DES{Guid.NewGuid():N}"[..8].ToUpperInvariant();
        using var register = await _client.PostAsJsonAsync(
            "/api/v1/auth/register",
            new RegisterRequest("Designation Org", code, $"owner@{code.ToLowerInvariant()}.test", "Owner", "ChangeMe123!"));
        register.EnsureSuccessStatusCode();
        var login = await register.Content.ReadFromJsonAsync<LoginResponse>();
        Assert.Null(login!.Designation);

        using var request = new HttpRequestMessage(HttpMethod.Put, "/api/v1/users/me")
        {
            Content = JsonContent.Create(new UpdateCurrentUserRequest("Sales Manager"))
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", login.AccessToken);

        using var response = await _client.SendAsync(request);
        response.EnsureSuccessStatusCode();

        var body = await response.Content.ReadFromJsonAsync<UserDto>();
        Assert.Equal("Sales Manager", body!.Designation);
    }

    private async Task<string> LoginAsync(string email, string password)
    {
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/auth/login",
            new LoginRequest(email, password));

        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<LoginResponse>();
        return body!.AccessToken;
    }
}
