using System.Diagnostics;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder(args);

var enabled = builder.Configuration.GetValue("Observability:Enabled", true)
    || builder.Configuration.GetValue("Tracing:Enabled", false);
var otlpEndpoint = builder.Configuration["Observability:OtlpEndpoint"]
    ?? builder.Configuration["Tracing:OtlpEndpoint"]
    ?? "http://otel-collector:4317";

if (enabled && !string.IsNullOrWhiteSpace(otlpEndpoint))
{
    var endpoint = new Uri(otlpEndpoint);
    builder.Services.AddOpenTelemetry()
        .ConfigureResource(r => r.AddService("MockServices"))
        .WithTracing(tracing => tracing
            .AddSource("MockServices")
            .AddAspNetCoreInstrumentation()
            .AddHttpClientInstrumentation()
            .AddOtlpExporter(o => o.Endpoint = endpoint))
        .WithMetrics(metrics => metrics
            .AddAspNetCoreInstrumentation()
            .AddHttpClientInstrumentation()
            .AddRuntimeInstrumentation()
            .AddOtlpExporter(o => o.Endpoint = endpoint))
        .WithLogging(
            logging => logging.AddOtlpExporter(o => o.Endpoint = endpoint),
            options =>
            {
                options.IncludeFormattedMessage = true;
                options.IncludeScopes = true;
            });
}

var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "MockServices" }));

app.MapPost("/oracle/query", async (OracleQueryRequest request) =>
{
    using var activity = MockActivity.Start("oracle.query");
    activity?.SetTag("db.system", "oracle");
    activity?.SetTag("customer.id", request.CustomerId);

    var delayMs = SimulateLatency(3000, 5000);
    await Task.Delay(delayMs);

    return Results.Ok(new OracleQueryResponse(
        request.CustomerId,
        12_450.75m,
        "USD",
        $"SELECT balance FROM ar_customers WHERE id = :id /* mock */",
        delayMs,
        "oracle-mock"));
});

app.MapPost("/sap/business-partner", async (SapPartnerRequest request) =>
{
    using var activity = MockActivity.Start("sap.business-partner");
    activity?.SetTag("sap.partner", request.PartnerNumber);

    var delayMs = SimulateLatency(3000, 5000);
    await Task.Delay(delayMs);

    return Results.Ok(new SapPartnerResponse(
        request.PartnerNumber,
        $"Partner {request.PartnerNumber}",
        50_000m,
        "Active",
        delayMs,
        "sap-mock"));
});

app.MapPost("/email/send", async (EmailSendRequest request) =>
{
    using var activity = MockActivity.Start("email.send");
    activity?.SetTag("email.to", request.To);
    activity?.SetTag("email.subject", request.Subject);

    var delayMs = SimulateLatency(3000, 5000);
    await Task.Delay(delayMs);

    return Results.Ok(new EmailSendResponse(
        Guid.NewGuid().ToString("N"),
        "queued",
        delayMs,
        "email-mock"));
});

app.Run();

static int SimulateLatency(int minMs, int maxMs) =>
    Random.Shared.Next(minMs, maxMs + 1);

file static class MockActivity
{
    public static readonly ActivitySource Source = new("MockServices", "1.0.0");

    public static Activity? Start(string name) =>
        Source.StartActivity(name, ActivityKind.Server);
}

file sealed record OracleQueryRequest(string CustomerId, string? Sql);
file sealed record OracleQueryResponse(
    string CustomerId,
    decimal Balance,
    string Currency,
    string SqlExecuted,
    int LatencyMs,
    string Source);

file sealed record SapPartnerRequest(string PartnerNumber);
file sealed record SapPartnerResponse(
    string PartnerNumber,
    string Name,
    decimal CreditLimit,
    string Status,
    int LatencyMs,
    string Source);

file sealed record EmailSendRequest(string To, string Subject, string Body);
file sealed record EmailSendResponse(string MessageId, string Status, int LatencyMs, string Source);
