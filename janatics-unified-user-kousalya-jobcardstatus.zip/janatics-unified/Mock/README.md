# Mock downstream systems (demo / tracing)

Simulates **Oracle**, **SAP**, and **email** services for distributed tracing demos. Not used in production (`MockIntegrations:Enabled=false` by default).

## Layout

```text
Mock/
  MockServices/     ASP.NET minimal API (Docker :8090)
    POST /oracle/query
    POST /sap/business-partner
    POST /email/send
```

JUSPlatform calls these via `JUSPlatform/Mock/` when `MockIntegrations:Enabled=true`.

## Quick start

**Windows (default):**

```powershell
.\scripts\obs-up.ps1
# Enable Observability + MockIntegrations in appsettings.Development.json
.\scripts\run-api.ps1
```

**Linux:**

```bash
./scripts/obs-up.sh
./scripts/run-api.sh
```

Then login and:

```bash
curl -s -X POST http://localhost:5201/api/v1/demo/invoice-sync \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"customerCode":"C-1001","invoiceNumber":"INV-DEMO-001","notifyEmail":"billing@demo.local"}'
```

Open http://localhost:3000 (Grafana **admin** / **admin**).

- **Explore → Tempo** — search `JUSPlatform` for the invoice-sync trace
- **Explore → Loki** — `{service_name="JUSPlatform"}`
- **Explore → Prometheus** — ASP.NET / runtime metrics

## Docker services

| Service | Port | Role |
|---------|------|------|
| grafana | 3000 | UI (Tempo + Loki + Prometheus datasources) |
| prometheus | 9090 | Metrics store |
| loki | 3100 | Log store |
| tempo | 3200 | Trace store |
| otel-collector | 4317/4318 | OTLP ingest → Tempo / Loki / Prometheus |
| mock-services | 8090 | Fake Oracle / SAP / email |

Stop: `.\scripts\obs-down.ps1` (Linux: `./scripts/obs-down.sh`)
