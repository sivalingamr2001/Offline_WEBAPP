using JUSPlatform.Application.Common;

namespace JUSPlatform.Infrastructure.Authentication;

/// <summary>Used by EF design-time factory when no HTTP user exists.</summary>
public sealed class NullCurrentUser : ICurrentUser
{
    public Guid? UserId => null;
    public Guid? OrganizationId => null;
    public string? RoleName => null;
    public bool IsAuthenticated => false;
    public IReadOnlyCollection<string> Permissions { get; } = [];
}
