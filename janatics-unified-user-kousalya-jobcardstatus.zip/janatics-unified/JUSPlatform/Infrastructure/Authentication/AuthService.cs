using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using JUSPlatform.Application.Access;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Email;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

namespace JUSPlatform.Infrastructure.Authentication;

public sealed class JwtOptions
{
    public const string SectionName = "Jwt";
    public string Issuer { get; set; } = "JUSPlatform";
    public string Audience { get; set; } = "JUSPlatform";
    public string SigningKey { get; set; } = "CHANGE_ME_TO_A_LONG_RANDOM_SECRET_KEY_32+";
    public int ExpiryMinutes { get; set; } = 60;
}

public sealed class PasswordHasher
{
    // Precomputed v1 hash used when the user is missing so login timing does not leak existence.
    private static readonly string DummyPasswordHash = CreateDummyHash();

    public string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(
            Encoding.UTF8.GetBytes(password),
            salt,
            100_000,
            HashAlgorithmName.SHA256,
            32);

        return $"v1.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    public bool Verify(string password, string stored)
    {
        var parts = stored.Split('.', 3);
        if (parts.Length != 3 || parts[0] != "v1")
        {
            return false;
        }

        var salt = Convert.FromBase64String(parts[1]);
        var expected = Convert.FromBase64String(parts[2]);
        var actual = Rfc2898DeriveBytes.Pbkdf2(
            Encoding.UTF8.GetBytes(password),
            salt,
            100_000,
            HashAlgorithmName.SHA256,
            32);

        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }

    /// <summary>
    /// Verifies the password, or burns the same PBKDF2 work against a dummy hash when no user exists.
    /// </summary>
    public bool VerifyOrDummy(string password, string? storedHash)
    {
        return Verify(password, string.IsNullOrWhiteSpace(storedHash) ? DummyPasswordHash : storedHash);
    }

    private static string CreateDummyHash()
    {
        var salt = new byte[16];
        Array.Fill(salt, (byte)0xA5);
        var hash = Rfc2898DeriveBytes.Pbkdf2(
            "dummy-password-for-timing"u8.ToArray(),
            salt,
            100_000,
            HashAlgorithmName.SHA256,
            32);
        return $"v1.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }
}

public sealed partial class AuthService(
    AppDbContext db,
    PasswordHasher passwordHasher,
    IOptions<JwtOptions> jwtOptions,
    JUSPlatform.Application.Email.IEmailSender emailSender,
    IOptions<EmailOptions> emailOptions,
    ITokenRevocationStore tokenRevocation,
    ICurrentUser currentUser) : IAuthService
{
    private const string InvalidCredentialsMessage = "Invalid email or password.";

    public async Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken cancellationToken)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await db.Users
            .Include(x => x.Role)
            .ThenInclude(x => x!.RolePermissions)
            .ThenInclude(x => x.Permission)
            .Include(x => x.UserRoles)
            .ThenInclude(x => x.Role!)
            .ThenInclude(x => x.RolePermissions)
            .ThenInclude(x => x.Permission)
            .FirstOrDefaultAsync(x => x.Email == email && x.IsActive, cancellationToken);

        // Always run password verification (dummy hash if user missing) to reduce timing/enum leaks.
        var passwordValid = passwordHasher.VerifyOrDummy(request.Password, user?.PasswordHash);
        if (user is null || !passwordValid)
        {
            throw new UnauthorizedAccessException(InvalidCredentialsMessage);
        }

        var options = jwtOptions.Value;
        var expires = DateTimeOffset.UtcNow.AddMinutes(options.ExpiryMinutes);
        return await BuildLoginResponseAsync(user.Id, cancellationToken);
    }

    private async Task<LoginResponse> BuildLoginResponseAsync(Guid userId, CancellationToken cancellationToken)
    {
        var user = await db.Users
            .Include(x => x.Role)
            .ThenInclude(x => x!.RolePermissions)
            .ThenInclude(x => x.Permission)
            .Include(x => x.UserRoles)
            .ThenInclude(x => x.Role!)
            .ThenInclude(x => x.RolePermissions)
            .ThenInclude(x => x.Permission)
            .FirstAsync(x => x.Id == userId, cancellationToken);

        var assignedRole = await ResolveAssignedRoleAsync(user, cancellationToken);
        var role = assignedRole?.Name;

        var permissions = (assignedRole?.RolePermissions ?? [])
            .Select(rp => rp.Permission?.Code)
            .Where(c => !string.IsNullOrWhiteSpace(c))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Cast<string>()
            .ToList();

        if (SystemRoles.IsSuperAdmin(role))
        {
            var catalog = await db.Permissions
                .AsNoTracking()
                .Select(x => x.Code)
                .ToListAsync(cancellationToken);
            permissions = catalog
                .Union(Permissions.SuperAdminGrant, StringComparer.OrdinalIgnoreCase)
                .OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
        else
        {
            permissions = permissions.OrderBy(c => c, StringComparer.OrdinalIgnoreCase).ToList();
        }

        var options = jwtOptions.Value;
        var expires = DateTimeOffset.UtcNow.AddMinutes(options.ExpiryMinutes);
        var token = CreateToken(user, role, permissions, options, expires);
        var modules = await LoadNavigationAsync(user.Id, role, permissions, cancellationToken);

        return new LoginResponse(
            token,
            expires,
            user.Id,
            user.Email,
            user.DisplayName,
            user.Designation,
            role,
            permissions,
            modules);
    }

    private async Task<IReadOnlyList<NavModuleDto>> LoadNavigationAsync(
        Guid userId,
        string? roleName,
        IReadOnlyList<string> permissions,
        CancellationToken cancellationToken)
    {
        var modules = await db.AppModules.AsNoTracking().ToListAsync(cancellationToken);
        var menus = await db.AppMenus.AsNoTracking().Include(x => x.Module).ToListAsync(cancellationToken);
        var roleIds = await db.UserRoles
            .AsNoTracking()
            .Where(x => x.UserId == userId)
            .Select(x => x.RoleId)
            .ToListAsync(cancellationToken);
        var columnRoleId = await db.Users
            .AsNoTracking()
            .Where(x => x.Id == userId)
            .Select(x => x.RoleId)
            .FirstOrDefaultAsync(cancellationToken);
        if (columnRoleId is { } extraRoleId && !roleIds.Contains(extraRoleId))
        {
            roleIds.Add(extraRoleId);
        }

        var roleMenus = await db.RoleMenus
            .AsNoTracking()
            .Where(x => roleIds.Contains(x.RoleId))
            .ToListAsync(cancellationToken);
        return NavigationAccessResolver.Resolve(roleName, permissions, modules, menus, roleMenus);
    }

    private async Task<Role?> ResolveAssignedRoleAsync(User user, CancellationToken cancellationToken)
    {
        var fromLink = user.UserRoles.Select(ur => ur.Role).FirstOrDefault(r => r is not null);
        if (fromLink is not null)
        {
            return fromLink;
        }

        if (user.Role is not null)
        {
            return user.Role;
        }

        if (user.RoleId is not { } roleId)
        {
            return null;
        }

        return await db.Roles
            .Include(x => x.RolePermissions)
            .ThenInclude(x => x.Permission)
            .FirstOrDefaultAsync(x => x.Id == roleId, cancellationToken);
    }

    private static string CreateToken(
        User user,
        string? roleName,
        IReadOnlyList<string> permissions,
        JwtOptions options,
        DateTimeOffset expires)
    {
        var jti = Guid.NewGuid().ToString("N");
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new(JwtRegisteredClaimNames.Email, user.Email),
            new(JwtRegisteredClaimNames.Jti, jti),
            new(ClaimTypes.Name, user.DisplayName)
        };

        if (user.OrganizationId is { } organizationId)
        {
            claims.Add(new Claim(ClaimTypesExt.OrganizationId, organizationId.ToString()));
        }

        if (!string.IsNullOrWhiteSpace(roleName))
        {
            claims.Add(new Claim(ClaimTypesExt.RoleName, roleName));
        }
        claims.AddRange(permissions.Select(p => new Claim(ClaimTypesExt.Permission, p)));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(options.SigningKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var jwt = new JwtSecurityToken(
            issuer: options.Issuer,
            audience: options.Audience,
            claims: claims,
            expires: expires.UtcDateTime,
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(jwt);
    }
}
