namespace JUSPlatform.Infrastructure.Authentication;

public interface ITokenRevocationStore
{
    Task RevokeAsync(string jti, DateTimeOffset expiresAt, CancellationToken cancellationToken = default);
    Task<bool> IsRevokedAsync(string jti, CancellationToken cancellationToken = default);
}

public sealed class MemoryTokenRevocationStore : ITokenRevocationStore
{
    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, byte> _revoked = new();

    public Task RevokeAsync(string jti, DateTimeOffset expiresAt, CancellationToken cancellationToken = default)
    {
        _revoked[jti] = 0;
        _ = Task.Delay(expiresAt - DateTimeOffset.UtcNow, cancellationToken)
            .ContinueWith(_ => _revoked.TryRemove(jti, out byte _), cancellationToken);
        return Task.CompletedTask;
    }

    public Task<bool> IsRevokedAsync(string jti, CancellationToken cancellationToken = default) =>
        Task.FromResult(_revoked.ContainsKey(jti));
}
