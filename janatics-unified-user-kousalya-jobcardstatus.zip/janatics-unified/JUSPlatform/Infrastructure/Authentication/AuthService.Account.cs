using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Email;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Email;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace JUSPlatform.Infrastructure.Authentication;

public sealed partial class AuthService
{
    private const string ResetMessage = "If an account exists, a reset link was sent to your inbox.";

    public async Task<LoginResponse> RegisterAsync(RegisterRequest request, CancellationToken cancellationToken)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var code = request.OrganizationCode.Trim().ToUpperInvariant();

        if (await db.Organizations.AnyAsync(x => x.Code == code, cancellationToken))
        {
            throw new ConflictException($"Organization code '{code}' already exists.");
        }

        if (await db.Users.AnyAsync(x => x.Email == email, cancellationToken))
        {
            throw new ConflictException($"User '{email}' already exists.");
        }

        var org = new Organization
        {
            Name = request.OrganizationName.Trim(),
            Code = code
        };
        db.Organizations.Add(org);
        await db.SaveChangesAsync(cancellationToken);
        await SystemRoleSeeder.EnsureForOrganizationAsync(db, org.Id, cancellationToken);

        var adminRole = await db.Roles.FirstAsync(
            x => x.OrganizationId == org.Id && x.Name == SystemRoles.Admin,
            cancellationToken);

        var user = new User
        {
            OrganizationId = org.Id,
            Email = email,
            DisplayName = request.DisplayName.Trim(),
            PasswordHash = passwordHasher.Hash(request.Password),
            UserRoles = [new UserRole { RoleId = adminRole.Id }]
        };
        db.Users.Add(user);
        await db.SaveChangesAsync(cancellationToken);

        await emailSender.SendAsync(
            email,
            "Welcome to JUSPlatform",
            $"<p>Hi {user.DisplayName},</p><p>Your organization <strong>{org.Name}</strong> is ready. You are the Admin user.</p>",
            cancellationToken);

        return await BuildLoginResponseAsync(user.Id, cancellationToken);
    }

    public async Task<MessageResponse> ForgotPasswordAsync(
        ForgotPasswordRequest request,
        CancellationToken cancellationToken)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await db.Users.FirstOrDefaultAsync(x => x.Email == email && x.IsActive, cancellationToken);

        if (user is not null)
        {
            var rawToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
            var tokenHash = HashToken(rawToken);
            db.PasswordResetTokens.Add(new PasswordResetToken
            {
                UserId = user.Id,
                TokenHash = tokenHash,
                ExpiresAt = DateTimeOffset.UtcNow.AddHours(1)
            });
            await db.SaveChangesAsync(cancellationToken);

            var link = $"{emailOptions.Value.FrontendBaseUrl.TrimEnd('/')}/reset-password?token={Uri.EscapeDataString(rawToken)}";
            await emailSender.SendAsync(
                email,
                "Reset your JUSPlatform password",
                $"<p>Reset your password:</p><p><a href=\"{link}\">{link}</a></p><p>This link expires in 1 hour.</p>",
                cancellationToken);
        }

        return new MessageResponse(ResetMessage);
    }

    public async Task<MessageResponse> ResetPasswordAsync(
        ResetPasswordRequest request,
        CancellationToken cancellationToken)
    {
        var tokenHash = HashToken(request.Token.Trim());
        var reset = await db.PasswordResetTokens
            .Include(x => x.User)
            .FirstOrDefaultAsync(
                x => x.TokenHash == tokenHash && x.UsedAt == null && x.ExpiresAt > DateTimeOffset.UtcNow,
                cancellationToken);

        if (reset?.User is null)
        {
            throw new UnauthorizedAccessException("Invalid or expired reset token.");
        }

        reset.User.PasswordHash = passwordHasher.Hash(request.Password);
        reset.UsedAt = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(cancellationToken);

        return new MessageResponse("Password updated.");
    }

    public Task LogoutAsync(string tokenJti, DateTimeOffset expiresAt, CancellationToken cancellationToken) =>
        tokenRevocation.RevokeAsync(tokenJti, expiresAt, cancellationToken);

    public async Task<MessageResponse> ChangePasswordAsync(
        ChangePasswordRequest request,
        CancellationToken cancellationToken)
    {
        var userId = currentUser.UserId ?? throw new UnauthorizedAccessException();
        var user = await db.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken)
            ?? throw new UnauthorizedAccessException("Invalid credentials.");

        if (!passwordHasher.Verify(request.CurrentPassword, user.PasswordHash))
        {
            throw new UnauthorizedAccessException("Current password is incorrect.");
        }

        user.PasswordHash = passwordHasher.Hash(request.NewPassword);
        await db.SaveChangesAsync(cancellationToken);
        return new MessageResponse("Password updated.");
    }

    private static string HashToken(string token)
    {
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(token));
        return Convert.ToHexString(hash);
    }
}
