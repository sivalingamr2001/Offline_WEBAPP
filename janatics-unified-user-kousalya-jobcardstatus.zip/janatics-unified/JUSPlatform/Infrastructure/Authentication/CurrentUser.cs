using System.Security.Claims;
using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;

namespace JUSPlatform.Infrastructure.Authentication;

public sealed class CurrentUser(IHttpContextAccessor httpContextAccessor) : ICurrentUser
{
    private ClaimsPrincipal? Principal => httpContextAccessor.HttpContext?.User;

    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;

    public Guid? UserId
    {
        get
        {
            var value = Principal?.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? Principal?.FindFirstValue("sub");
            return Guid.TryParse(value, out var id) ? id : null;
        }
    }

    public Guid? OrganizationId
    {
        get
        {
            var value = Principal?.FindFirstValue(ClaimTypesExt.OrganizationId);
            return Guid.TryParse(value, out var id) ? id : null;
        }
    }

    public string? RoleName => Principal?.FindFirstValue(ClaimTypesExt.RoleName);

    public IReadOnlyCollection<string> Permissions =>
        Principal?.FindAll(ClaimTypesExt.Permission).Select(c => c.Value).ToArray()
        ?? Array.Empty<string>();
}
