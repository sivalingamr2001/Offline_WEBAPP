using Sentry;
using Sentry.Extensibility;

namespace JUSPlatform.Infrastructure.Bugsink;

public static class BugsinkExtensions
{
    public static WebApplicationBuilder AddJUSPlatformBugsink(this WebApplicationBuilder builder)
    {
        var options = BugsinkOptions.Bind(builder.Configuration);
        builder.Services.Configure<BugsinkOptions>(
            builder.Configuration.GetSection(BugsinkOptions.SectionName));

        if (!options.IsActive)
        {
            return builder;
        }

        var environment = options.Environment ?? builder.Environment.EnvironmentName;

        builder.WebHost.UseSentry(sentry => ApplyOptions(sentry, options, environment));

        return builder;
    }

    public static void ApplyOptions(
        SentryOptions options,
        BugsinkOptions bugsink,
        string environment)
    {
        options.Dsn = bugsink.Dsn;
        options.Environment = environment;
        options.SendDefaultPii = bugsink.SendDefaultPii;
        options.TracesSampleRate = 0;
        options.ProfilesSampleRate = 0;
        options.AutoSessionTracking = false;
        options.AttachStacktrace = true;
        options.MaxBreadcrumbs = 100;

        options.SetBeforeSend(static (sentryEvent, _) =>
        {
            if (sentryEvent.Exception is JUSPlatform.Domain.Exceptions.BusinessRuleException
                or JUSPlatform.Domain.Exceptions.NotFoundException
                or JUSPlatform.Domain.Exceptions.ConflictException)
            {
                return null;
            }

            return sentryEvent;
        });
    }
}
