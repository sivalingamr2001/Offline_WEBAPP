using System.Diagnostics;
using JUSPlatform.Authorization;
using JUSPlatform.Infrastructure.Observability;
using Microsoft.AspNetCore.Http;
using Sentry;

namespace JUSPlatform.Infrastructure.Bugsink;

public static class BugsinkEventReporter
{
    public static void CaptureException(
        Exception exception,
        HttpContext? httpContext = null,
        string? responseId = null)
    {
        SentrySdk.CaptureException(exception, scope => EnrichScope(scope, httpContext, responseId));
    }

    public static void CaptureJobFailure(
        Guid jobId,
        string jobType,
        string errorMessage,
        string? traceId,
        Guid organizationId)
    {
        SentrySdk.CaptureMessage(
            $"Background job failed permanently ({jobType}): {errorMessage}",
            scope =>
            {
                scope.Level = SentryLevel.Error;
                scope.SetTag("job.id", jobId.ToString("N"));
                scope.SetTag("job.type", jobType);
                scope.SetTag("organization.id", organizationId.ToString("N"));
                if (!string.IsNullOrWhiteSpace(traceId))
                {
                    scope.SetTag("trace_id", traceId);
                }
            });
    }

    private static void EnrichScope(Scope scope, HttpContext? httpContext, string? responseId)
    {
        var traceId = Activity.Current?.TraceId.ToString()
            ?? JUSPlatformActivity.CurrentTraceId;

        if (!string.IsNullOrWhiteSpace(traceId))
        {
            scope.SetTag("trace_id", traceId);
        }

        if (!string.IsNullOrWhiteSpace(responseId))
        {
            scope.SetTag("response_id", responseId);
        }

        if (httpContext is null)
        {
            return;
        }

        var user = httpContext.User;
        if (user.Identity?.IsAuthenticated == true)
        {
            var userId = user.FindFirst("sub")?.Value;
            if (!string.IsNullOrWhiteSpace(userId))
            {
                scope.User = scope.User ?? new SentryUser { Id = userId };
                scope.User.Id = userId;
            }

            var orgId = user.FindFirst(ClaimTypesExt.OrganizationId)?.Value;
            if (!string.IsNullOrWhiteSpace(orgId))
            {
                scope.SetTag("organization.id", orgId);
            }

            var role = user.FindFirst(ClaimTypesExt.RoleName)?.Value;
            if (!string.IsNullOrWhiteSpace(role))
            {
                scope.SetTag("role_name", role);
            }
        }
    }
}
