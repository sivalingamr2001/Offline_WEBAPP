namespace JUSPlatform.Infrastructure.Bugsink;

/// <summary>
/// Self-hosted error tracking via Bugsink (Sentry SDK compatible).
/// Bugsink handles errors only — keep <see cref="TracesSampleRate"/> at 0; use OpenTelemetry for traces.
/// </summary>
public sealed class BugsinkOptions
{
    public const string SectionName = "Bugsink";

    public bool Enabled { get; set; }

    /// <summary>Project DSN from Bugsink project settings (http://key@host:8000/projectId).</summary>
    public string? Dsn { get; set; }

    /// <summary>Environment tag on events (defaults to ASPNETCORE_ENVIRONMENT).</summary>
    public string? Environment { get; set; }

    /// <summary>Recommended true for self-hosted — richer user/request context.</summary>
    public bool SendDefaultPii { get; set; } = true;

    /// <summary>Forward Serilog Error+ events to Bugsink.</summary>
    public bool CaptureSerilogErrors { get; set; } = true;

    public bool IsActive => Enabled && !string.IsNullOrWhiteSpace(Dsn);

    public static BugsinkOptions Bind(IConfiguration configuration) =>
        configuration.GetSection(SectionName).Get<BugsinkOptions>() ?? new();
}
