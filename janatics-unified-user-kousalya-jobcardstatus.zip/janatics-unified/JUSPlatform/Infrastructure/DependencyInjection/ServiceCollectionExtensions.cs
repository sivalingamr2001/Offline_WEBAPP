using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using FluentValidation;
using JUSPlatform.Application.AppCatalog;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.CustomerComplaint;
using JUSPlatform.Application.JobCard;
using JUSPlatform.Application.Oracle;
using JUSPlatform.Application.Organizations;
using JUSPlatform.Application.Roles;
using JUSPlatform.Application.Users;
using JUSPlatform.Infrastructure.Storage;
using JUSPlatform.Mock;
using JUSPlatform.Infrastructure.Authentication;
using JUSPlatform.Infrastructure.Authorization;
using JUSPlatform.Infrastructure.Caching;
using JUSPlatform.Infrastructure.Email;
using JUSPlatform.Infrastructure.Hangfire;
using JUSPlatform.Infrastructure.Hosting;
using JUSPlatform.Application.Email;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using JUSPlatform.Infrastructure.Jobs;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using JUSPlatform.Infrastructure.Observability;
using JUSPlatform.Infrastructure.RateLimiting;
using JUSPlatform.Middleware;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Oracle.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StackExchange.Redis;

namespace JUSPlatform.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddJUSPlatformInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<JwtOptions>(configuration.GetSection(JwtOptions.SectionName));
        services.Configure<RedisCacheOptions>(configuration.GetSection(RedisCacheOptions.SectionName));
        services.Configure<ErrorResponseOptions>(configuration.GetSection(ErrorResponseOptions.SectionName));
        services.Configure<ObservabilityOptions>(configuration.GetSection(ObservabilityOptions.SectionName));
        services.Configure<SeedOptions>(configuration.GetSection(SeedOptions.SectionName));
        services.Configure<EmailOptions>(configuration.GetSection(EmailOptions.SectionName));
        services.Configure<OracleOptions>(configuration.GetSection(OracleOptions.SectionName));
        services.AddJUSPlatformObservability(configuration);
        services.AddJUSPlatformMockIntegrations(configuration);
        services.AddJUSPlatformRateLimiting(configuration);
        services.AddHttpContextAccessor();
        services.AddScoped<ICurrentUser, CurrentUser>();
        services.AddSingleton<PasswordHasher>();
        services.AddSingleton<ITokenRevocationStore, MemoryTokenRevocationStore>();
        AddEmailSender(services, configuration);
        AddCorsPolicy(services, configuration);
        AddRedisQueryCache(services, configuration);
        services.AddJUSPlatformJobs(configuration);
        services.AddJUSPlatformHangfire(configuration);
        services.AddJUSPlatformStorage(configuration);

        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IOrganizationService, OrganizationService>();
        services.AddScoped<IOperatingUnitService, OperatingUnitService>();
        services.AddScoped<IUserService, UserService>();
        services.AddScoped<IRoleService, RoleService>();
        services.AddScoped<IAppCatalogService, AppCatalogService>();
        services.AddScoped<ICustomerComplaintService, CustomerComplaintService>();
        services.AddScoped<IOracleConnectionService, OracleConnectionService>();
        services.AddScoped<IJobCardStatusService, JobCardStatusService>();

        // Field keys in validation `errors` match JSON / frontend (email, not Email).
        ValidatorOptions.Global.PropertyNameResolver = (_, memberInfo, _) =>
            memberInfo is null ? null : JsonNamingPolicy.CamelCase.ConvertName(memberInfo.Name);

        services.AddValidatorsFromAssemblyContaining<Application.Auth.LoginRequestValidator>();
        services.AddScoped<ValidationFilter>();

        var connectionString = configuration.GetConnectionString("Default")
            ?? "Host=localhost;Port=5432;Database=jusplatform;Username=postgres;Password=";

        services.AddScoped<EntityChangeInterceptor>();
        if (configuration.GetValue("UseInMemoryDatabase", false))
        {
            services.AddDbContext<AppDbContext>((sp, options) =>
                options
                    .UseInMemoryDatabase(connectionString)
                    .AddInterceptors(sp.GetRequiredService<EntityChangeInterceptor>()));
        }
        else
        {
            services.AddDbContext<AppDbContext>((sp, options) =>
                options
                    .UseNpgsql(
                        connectionString,
                        npgsql => npgsql.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery))
                    .AddInterceptors(sp.GetRequiredService<EntityChangeInterceptor>()));
        }

        AddOracleDbContext(services, configuration);

        var jwt = configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>() ?? new JwtOptions();
        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwt.Issuer,
                    ValidAudience = jwt.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.SigningKey)),
                    NameClaimType = "sub"
                };

                options.Events = new JwtBearerEvents
                {
                    OnTokenValidated = async context =>
                    {
                        var jti = context.Principal?.FindFirst(JwtRegisteredClaimNames.Jti)?.Value;
                        if (string.IsNullOrWhiteSpace(jti))
                        {
                            return;
                        }

                        var store = context.HttpContext.RequestServices.GetRequiredService<ITokenRevocationStore>();
                        if (await store.IsRevokedAsync(jti, context.HttpContext.RequestAborted))
                        {
                            context.Fail("Token revoked.");
                        }
                    },
                    OnChallenge = async context =>
                    {
                        context.HandleResponse();
                        await ApiErrorResponseWriter.WriteAsync(
                            context.HttpContext,
                            StatusCodes.Status401Unauthorized,
                            "Authentication required.",
                            context.HttpContext.RequestAborted);
                    }
                };
            });

        services.AddSingleton<IAuthorizationMiddlewareResultHandler, ApiAuthorizationMiddlewareResultHandler>();
        services.AddPermissionPolicies();
        services.ConfigureHttpJsonOptions(options =>
        {
            options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
        });
        services.AddScoped<QueryResponseCacheFilter>();
        services.AddHostedService<DatabaseInitializationHostedService>();
        services.AddControllers(options =>
            {
                options.Filters.Add<ValidationFilter>();
                options.Filters.Add<QueryResponseCacheFilter>();
            })
            .ConfigureApiBehaviorOptions(options =>
            {
                options.InvalidModelStateResponseFactory = context =>
                {
                    var config = context.HttpContext.RequestServices.GetRequiredService<IConfiguration>();
                    var errorOptions = context.HttpContext.RequestServices
                        .GetRequiredService<IOptions<ErrorResponseOptions>>().Value;
                    var appDebug = config.GetValue("AppDebug", false);
                    var body = ApiErrorFactory.FromModelState(context, errorOptions, appDebug);
                    return new BadRequestObjectResult(body)
                    {
                        ContentTypes = { ExceptionHandlingMiddleware.Json }
                    };
                };
            })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                options.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
            });

        return services;
    }

    private static void AddOracleDbContext(IServiceCollection services, IConfiguration configuration)
    {
        var oracle = configuration.GetSection(OracleOptions.SectionName).Get<OracleOptions>()
            ?? new OracleOptions();
        var useInMemory = configuration.GetValue("UseInMemoryDatabase", false);
        var connectionString = configuration.GetConnectionString("Oracle");

        if (useInMemory || !oracle.Enabled)
        {
            services.AddDbContext<OracleDbContext>(options =>
                options.UseInMemoryDatabase("JUSPlatformOracle"));
            return;
        }

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                "ConnectionStrings:Oracle is required when Oracle:Enabled is true. "
                + "Set user-secrets or env ConnectionStrings__Oracle. "
                + "Example: User Id=<ORACLE_USER>;Password=<ORACLE_PASSWORD>;Data Source=<DB_HOST>:<PORT>/<SERVICE_NAME>;");
        }

        services.AddDbContext<OracleDbContext>(options =>
            options.UseOracle(
                connectionString,
                oracleOptions => oracleOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery)));
    }

    private static void AddRedisQueryCache(IServiceCollection services, IConfiguration configuration)
    {
        var redisOptions = configuration.GetSection(RedisCacheOptions.SectionName)
            .Get<RedisCacheOptions>() ?? new RedisCacheOptions();

        var redisConnection = configuration.GetConnectionString("Redis")
            ?? configuration["Redis:ConnectionString"]
            ?? "localhost:6379,abortConnect=false";

        if (!redisOptions.Enabled)
        {
            services.AddSingleton<IQueryCache, NullQueryCache>();
            return;
        }

        services.AddSingleton<IConnectionMultiplexer>(_ =>
            ConnectionMultiplexer.Connect(redisConnection));
        services.AddSingleton<IQueryCache, RedisQueryCache>();
    }

    private static void AddEmailSender(IServiceCollection services, IConfiguration configuration)
    {
        var email = configuration.GetSection(EmailOptions.SectionName).Get<EmailOptions>() ?? new EmailOptions();
        if (email.Enabled)
        {
            services.AddSingleton<IEmailSender, SmtpEmailSender>();
        }
        else
        {
            services.AddSingleton<IEmailSender, NullEmailSender>();
        }
    }

    private static void AddCorsPolicy(IServiceCollection services, IConfiguration configuration)
    {
        var origins = configuration.GetSection("Cors:Origins").Get<string[]>()
            ?? ["http://localhost:5173"];

        services.AddCors(options =>
        {
            options.AddPolicy(
                "JUSPlatformUi",
                policy => policy
                    .WithOrigins(origins)
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .WithExposedHeaders("Retry-After"));
        });
    }
}
