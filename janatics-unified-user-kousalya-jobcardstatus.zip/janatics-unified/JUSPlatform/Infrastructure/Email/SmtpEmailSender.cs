using System.Net;
using System.Net.Mail;
using JUSPlatform.Application.Email;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Email;

public sealed class SmtpEmailSender(
    IOptions<EmailOptions> options,
    ILogger<SmtpEmailSender> logger) : IEmailSender
{
    public async Task SendAsync(
        string toEmail,
        string subject,
        string htmlBody,
        CancellationToken cancellationToken = default)
    {
        var config = options.Value;
        if (!config.Enabled)
        {
            logger.LogInformation("Email disabled — skipped to {Email}: {Subject}", toEmail, subject);
            return;
        }

        using var message = new MailMessage
        {
            From = new MailAddress(config.FromAddress, config.FromName),
            Subject = subject,
            Body = htmlBody,
            IsBodyHtml = true
        };
        message.To.Add(toEmail);

        using var client = new SmtpClient(config.Host, config.Port)
        {
            EnableSsl = false,
            DeliveryMethod = SmtpDeliveryMethod.Network
        };

        await client.SendMailAsync(message, cancellationToken);
        logger.LogInformation("Email sent to {Email}: {Subject}", toEmail, subject);
    }
}

public sealed class NullEmailSender(ILogger<NullEmailSender> logger) : IEmailSender
{
    public Task SendAsync(string toEmail, string subject, string htmlBody, CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Email (null sender) to {Email}: {Subject}", toEmail, subject);
        return Task.CompletedTask;
    }
}
