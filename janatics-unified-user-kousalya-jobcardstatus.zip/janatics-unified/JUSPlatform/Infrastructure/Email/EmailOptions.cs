namespace JUSPlatform.Infrastructure.Email;

public sealed class EmailOptions
{
    public const string SectionName = "Email";

    public bool Enabled { get; set; } = true;
    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 1025;
    public string FromAddress { get; set; } = "noreply@jusplatform.local";
    public string FromName { get; set; } = "JUSPlatform";
    public string FrontendBaseUrl { get; set; } = "http://localhost:5173";
}
