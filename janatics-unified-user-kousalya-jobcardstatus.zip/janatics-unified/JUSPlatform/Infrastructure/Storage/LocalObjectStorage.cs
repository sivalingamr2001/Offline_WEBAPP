using JUSPlatform.Application.Storage;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Storage;

public sealed class LocalObjectStorage(
    IWebHostEnvironment environment,
    IOptions<StorageOptions> optionsAccessor,
    IConfiguration configuration,
    IHttpContextAccessor httpContextAccessor) : IObjectStorage
{
    public async Task<StoredObject> PutAsync(
        string key,
        Stream content,
        string contentType,
        CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        var options = optionsAccessor.Value;
        await using var buffer = new MemoryStream();
        await content.CopyToAsync(buffer, cancellationToken);
        var bytes = buffer.ToArray();

        var currentPath = ResolvePath(key);
        Directory.CreateDirectory(Path.GetDirectoryName(currentPath)!);

        string? versionId = null;
        if (options.Versioning)
        {
            versionId = Guid.NewGuid().ToString("N");
            var versionPath = ResolveVersionPath(key, versionId);
            Directory.CreateDirectory(Path.GetDirectoryName(versionPath)!);
            await File.WriteAllBytesAsync(versionPath, bytes, cancellationToken);
        }

        await File.WriteAllBytesAsync(currentPath, bytes, cancellationToken);
        return new StoredObject(key, versionId, contentType, bytes.LongLength);
    }

    public Task<Stream?> OpenReadAsync(string key, string? versionId, CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        var path = string.IsNullOrWhiteSpace(versionId)
            ? ResolvePath(key)
            : ResolveVersionPath(key, versionId);

        if (!File.Exists(path))
        {
            return Task.FromResult<Stream?>(null);
        }

        Stream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        return Task.FromResult<Stream?>(stream);
    }

    public Task DeleteAsync(string key, CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        var path = ResolvePath(key);
        if (File.Exists(path))
        {
            File.Delete(path);
        }

        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<StoredObjectVersion>> ListVersionsAsync(string key, CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        var dir = Path.GetDirectoryName(ResolveVersionPath(key, "x"))!;
        if (!Directory.Exists(dir))
        {
            return Task.FromResult<IReadOnlyList<StoredObjectVersion>>([]);
        }

        var currentPath = ResolvePath(key);
        var currentBytes = File.Exists(currentPath) ? new FileInfo(currentPath).Length : -1;
        var items = Directory.GetFiles(dir)
            .Select(path =>
            {
                var info = new FileInfo(path);
                var versionId = info.Name;
                return new StoredObjectVersion(
                    key,
                    versionId,
                    currentBytes >= 0 && info.Length == currentBytes,
                    new DateTimeOffset(info.LastWriteTimeUtc, TimeSpan.Zero),
                    info.Length);
            })
            .OrderByDescending(x => x.LastModified)
            .ToList();

        if (items.Count > 0)
        {
            var latest = items[0];
            items[0] = latest with { IsLatest = true };
            for (var i = 1; i < items.Count; i++)
            {
                items[i] = items[i] with { IsLatest = false };
            }
        }

        return Task.FromResult<IReadOnlyList<StoredObjectVersion>>(items);
    }

    public string? GetReadUrl(string? key, string? versionId = null)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            return null;
        }

        var normalized = StorageKeys.Normalize(key);
        if (!string.IsNullOrWhiteSpace(versionId))
        {
            return null;
        }

        return "/" + normalized;
    }

    public PresignedDownload CreatePrivateDownload(
        string key,
        TimeSpan timeToLive,
        string? downloadFileName = null,
        string? versionId = null)
    {
        var options = optionsAccessor.Value;
        var ttl = ClampTtl(timeToLive);
        var expiresAt = DateTimeOffset.UtcNow.Add(ttl);
        var signingKey = StorageSigning.ResolveKey(options, configuration);
        var ticket = LocalDownloadTickets.Issue(key, expiresAt, signingKey, downloadFileName, versionId);
        var url = $"{ResolvePublicBase()}/api/v1/storage/download?{LocalDownloadTickets.ToQueryString(ticket)}";
        return new PresignedDownload(url, expiresAt, ticket.Key, ticket.VersionId);
    }

    private static TimeSpan ClampTtl(TimeSpan timeToLive)
    {
        var minutes = Math.Clamp(timeToLive.TotalMinutes, 1, 15);
        return TimeSpan.FromMinutes(minutes);
    }

    private string ResolvePublicBase()
    {
        var request = httpContextAccessor.HttpContext?.Request;
        if (request is not null)
        {
            return $"{request.Scheme}://{request.Host.Value}{request.PathBase.Value}".TrimEnd('/');
        }

        var configured = optionsAccessor.Value.PublicBaseUrl?.Trim().TrimEnd('/');
        return string.IsNullOrWhiteSpace(configured) ? "" : configured;
    }

    private string ResolvePath(string key) => Path.Combine(ResolveRoot(), key.Replace('/', Path.DirectorySeparatorChar));

    private string ResolveVersionPath(string key, string versionId)
    {
        var safeVersion = Path.GetFileName(versionId);
        return Path.Combine(ResolveRoot(), ".versions", key.Replace('/', Path.DirectorySeparatorChar), safeVersion);
    }

    private string ResolveRoot()
    {
        var root = optionsAccessor.Value.Local.RootPath;
        if (string.IsNullOrWhiteSpace(root))
        {
            return environment.WebRootPath
                ?? Path.Combine(environment.ContentRootPath, "wwwroot");
        }

        return Path.IsPathRooted(root)
            ? root
            : Path.GetFullPath(Path.Combine(environment.ContentRootPath, root));
    }
}
