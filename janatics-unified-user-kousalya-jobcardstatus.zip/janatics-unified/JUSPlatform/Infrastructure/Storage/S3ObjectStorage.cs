using Amazon.S3;
using Amazon.S3.Model;
using JUSPlatform.Application.Storage;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Storage;

public sealed class S3ObjectStorage(IAmazonS3 client, IOptions<StorageOptions> optionsAccessor) : IObjectStorage
{
    public async Task<StoredObject> PutAsync(
        string key,
        Stream content,
        string contentType,
        CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        var s3 = optionsAccessor.Value.S3;
        var request = new PutObjectRequest
        {
            BucketName = s3.Bucket,
            Key = key,
            InputStream = content,
            ContentType = contentType,
            AutoCloseStream = false
        };

        var response = await client.PutObjectAsync(request, cancellationToken);
        var size = content.CanSeek ? content.Length : 0;
        return new StoredObject(key, response.VersionId, contentType, size);
    }

    public async Task<Stream?> OpenReadAsync(string key, string? versionId, CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        try
        {
            var request = new GetObjectRequest
            {
                BucketName = optionsAccessor.Value.S3.Bucket,
                Key = key
            };
            if (!string.IsNullOrWhiteSpace(versionId))
            {
                request.VersionId = versionId;
            }

            var response = await client.GetObjectAsync(request, cancellationToken);
            return response.ResponseStream;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }
    }

    public async Task DeleteAsync(string key, CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        await client.DeleteObjectAsync(
            new DeleteObjectRequest
            {
                BucketName = optionsAccessor.Value.S3.Bucket,
                Key = key
            },
            cancellationToken);
    }

    public async Task<IReadOnlyList<StoredObjectVersion>> ListVersionsAsync(
        string key,
        CancellationToken cancellationToken)
    {
        key = StorageKeys.Normalize(key);
        var response = await client.ListVersionsAsync(
            new ListVersionsRequest
            {
                BucketName = optionsAccessor.Value.S3.Bucket,
                Prefix = key
            },
            cancellationToken);

        return response.Versions
            .Where(v => string.Equals(v.Key, key, StringComparison.Ordinal))
            .Select(v =>
            {
                var lastModified = v.LastModified ?? DateTime.UtcNow;
                if (lastModified.Kind == DateTimeKind.Unspecified)
                {
                    lastModified = DateTime.SpecifyKind(lastModified, DateTimeKind.Utc);
                }

                return new StoredObjectVersion(
                    v.Key,
                    v.VersionId ?? "",
                    v.IsLatest ?? false,
                    lastModified,
                    v.Size ?? 0);
            })
            .ToList();
    }

    public string? GetReadUrl(string? key, string? versionId = null)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            return null;
        }

        var s3 = optionsAccessor.Value.S3;
        var request = new GetPreSignedUrlRequest
        {
            BucketName = s3.Bucket,
            Key = StorageKeys.Normalize(key),
            Verb = HttpVerb.GET,
            Expires = DateTime.UtcNow.AddMinutes(Math.Max(1, s3.ReadUrlExpiryMinutes))
        };
        if (!string.IsNullOrWhiteSpace(versionId))
        {
            request.VersionId = versionId;
        }

        ApplyProtocol(request, s3);
        return client.GetPreSignedURL(request);
    }

    public PresignedDownload CreatePrivateDownload(
        string key,
        TimeSpan timeToLive,
        string? downloadFileName = null,
        string? versionId = null)
    {
        key = StorageKeys.Normalize(key);
        var s3 = optionsAccessor.Value.S3;
        var ttl = TimeSpan.FromMinutes(Math.Clamp(timeToLive.TotalMinutes, 1, 15));
        var expiresAt = DateTime.UtcNow.Add(ttl);
        var fileName = StorageDownloadNames.SafeFileName(downloadFileName, key);
        var request = new GetPreSignedUrlRequest
        {
            BucketName = s3.Bucket,
            Key = key,
            Verb = HttpVerb.GET,
            Expires = expiresAt,
            ResponseHeaderOverrides = new ResponseHeaderOverrides
            {
                ContentDisposition = $"attachment; filename=\"{fileName}\""
            }
        };
        if (!string.IsNullOrWhiteSpace(versionId))
        {
            request.VersionId = versionId;
        }

        ApplyProtocol(request, s3);
        return new PresignedDownload(client.GetPreSignedURL(request), expiresAt, key, versionId);
    }

    private static void ApplyProtocol(GetPreSignedUrlRequest request, S3StorageOptions s3)
    {
        if (string.IsNullOrWhiteSpace(s3.ServiceUrl)
            || !Uri.TryCreate(s3.ServiceUrl, UriKind.Absolute, out var serviceUri))
        {
            return;
        }

        request.Protocol = serviceUri.Scheme.Equals("http", StringComparison.OrdinalIgnoreCase)
            ? Protocol.HTTP
            : Protocol.HTTPS;
    }
}
