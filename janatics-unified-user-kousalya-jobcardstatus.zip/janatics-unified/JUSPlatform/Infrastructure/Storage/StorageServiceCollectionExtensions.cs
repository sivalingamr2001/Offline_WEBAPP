using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using JUSPlatform.Application.Storage;
using JUSPlatform.Application.Users;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Serilog;

namespace JUSPlatform.Infrastructure.Storage;

public static class StorageServiceCollectionExtensions
{
    public static IServiceCollection AddJUSPlatformStorage(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<StorageOptions>(configuration.GetSection(StorageOptions.SectionName));
        var options = StorageOptions.Bind(configuration);

        if (options.IsS3)
        {
            if (string.IsNullOrWhiteSpace(options.S3.AccessKey)
                || string.IsNullOrWhiteSpace(options.S3.SecretKey)
                || string.IsNullOrWhiteSpace(options.S3.Bucket))
            {
                throw new InvalidOperationException(
                    "Storage:Provider is S3/MinIO but Storage:S3 Bucket, AccessKey, and SecretKey are required.");
            }

            services.AddSingleton<IAmazonS3>(_ => CreateS3Client(options.S3));
            services.AddSingleton<IObjectStorage, S3ObjectStorage>();
            services.AddHostedService<S3StorageInitializationHostedService>();
        }
        else
        {
            services.AddSingleton<IObjectStorage, LocalObjectStorage>();
        }

        services.AddSingleton<IUserAvatarStorage, ObjectUserAvatarStorage>();
        services.AddScoped<IStorageDownloadService, StorageDownloadService>();
        return services;
    }

    public static void LogStorage(IConfiguration configuration)
    {
        var options = StorageOptions.Bind(configuration);
        if (options.IsS3)
        {
            Log.Information(
                "Storage: Provider=S3, Bucket={Bucket}, ServiceUrl={ServiceUrl}, Region={Region}, Versioning={Versioning}, PathStyle={PathStyle}, AccessKeyConfigured={AccessKeyConfigured}, PrivateDownloadExpiryMinutes={PrivateDownloadExpiryMinutes}",
                options.S3.Bucket,
                string.IsNullOrWhiteSpace(options.S3.ServiceUrl) ? "(AWS default)" : options.S3.ServiceUrl,
                options.S3.Region,
                options.Versioning,
                options.S3.ForcePathStyle,
                !string.IsNullOrWhiteSpace(options.S3.AccessKey),
                options.PrivateDownloadExpiryMinutes);
            return;
        }

        Log.Information(
            "Storage: Provider=Local, RootPath={RootPath}, Versioning={Versioning}, PrivateDownloadExpiryMinutes={PrivateDownloadExpiryMinutes}",
            string.IsNullOrWhiteSpace(options.Local.RootPath) ? "(wwwroot)" : options.Local.RootPath,
            options.Versioning,
            options.PrivateDownloadExpiryMinutes);
    }

    internal static AmazonS3Client CreateS3Client(S3StorageOptions s3)
    {
        var credentials = new BasicAWSCredentials(s3.AccessKey, s3.SecretKey);
        var config = new AmazonS3Config
        {
            ForcePathStyle = s3.ForcePathStyle,
            AuthenticationRegion = s3.Region
        };

        if (!string.IsNullOrWhiteSpace(s3.ServiceUrl))
        {
            config.ServiceURL = s3.ServiceUrl.TrimEnd('/');
        }
        else if (!string.IsNullOrWhiteSpace(s3.Region))
        {
            config.RegionEndpoint = RegionEndpoint.GetBySystemName(s3.Region);
        }

        return new AmazonS3Client(credentials, config);
    }
}

public sealed class S3StorageInitializationHostedService(
    IAmazonS3 client,
    IOptions<StorageOptions> optionsAccessor,
    IConfiguration configuration) : IHostedService
{
    public async Task StartAsync(CancellationToken cancellationToken)
    {
        var options = optionsAccessor.Value;
        if (!options.IsS3 || !options.S3.EnsureBucket)
        {
            return;
        }

        var bucket = options.S3.Bucket;
        try
        {
            await client.PutBucketAsync(new PutBucketRequest { BucketName = bucket }, cancellationToken);
        }
        catch (AmazonS3Exception ex) when (
            ex.StatusCode == System.Net.HttpStatusCode.Conflict
            || string.Equals(ex.ErrorCode, "BucketAlreadyOwnedByYou", StringComparison.OrdinalIgnoreCase)
            || string.Equals(ex.ErrorCode, "BucketAlreadyExists", StringComparison.OrdinalIgnoreCase))
        {
            // Bucket already present.
        }

        if (options.Versioning)
        {
            await client.PutBucketVersioningAsync(
                new PutBucketVersioningRequest
                {
                    BucketName = bucket,
                    VersioningConfig = new S3BucketVersioningConfig { Status = VersionStatus.Enabled }
                },
                cancellationToken);
        }

        var origins = configuration.GetSection("Cors:Origins").Get<string[]>()
            ?? ["http://localhost:5173"];
        await client.PutCORSConfigurationAsync(
            new PutCORSConfigurationRequest
            {
                BucketName = bucket,
                Configuration = new CORSConfiguration
                {
                    Rules =
                    [
                        new CORSRule
                        {
                            AllowedMethods = ["GET", "HEAD"],
                            AllowedOrigins = [.. origins],
                            AllowedHeaders = ["*"],
                            ExposeHeaders = ["ETag", "x-amz-version-id"],
                            MaxAgeSeconds = 3000
                        }
                    ]
                }
            },
            cancellationToken);

        Log.Information("Storage: S3 bucket {Bucket} ready (versioning={Versioning})", bucket, options.Versioning);
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
}
