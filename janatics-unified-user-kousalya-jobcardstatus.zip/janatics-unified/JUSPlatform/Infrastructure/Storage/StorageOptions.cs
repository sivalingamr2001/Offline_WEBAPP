namespace JUSPlatform.Infrastructure.Storage;

/// <summary>
/// Object storage: local disk or S3-compatible (AWS S3 and MinIO).
/// Production default is MinIO with bucket versioning.
/// </summary>
public sealed class StorageOptions
{
    public const string SectionName = "Storage";

    /// <summary><c>local</c>, <c>s3</c>, <c>minio</c>, or <c>aws</c> (last three use the S3 API).</summary>
    public string Provider { get; set; } = "local";

    /// <summary>Keep prior writes. S3/MinIO bucket versioning; local writes under <c>.versions/</c>.</summary>
    public bool Versioning { get; set; } = true;

    /// <summary>TTL for private downloads (reports, CSV). Default 5 minutes.</summary>
    public int PrivateDownloadExpiryMinutes { get; set; } = 5;

    /// <summary>HMAC key for local download tickets. Empty = <c>Jwt:SigningKey</c>.</summary>
    public string? DownloadSigningKey { get; set; }

    /// <summary>Public API origin for local tickets when there is no HTTP request (jobs). Example: https://api.example.com</summary>
    public string? PublicBaseUrl { get; set; }

    public LocalStorageOptions Local { get; set; } = new();

    public S3StorageOptions S3 { get; set; } = new();

    public bool IsS3 =>
        Provider.Equals("s3", StringComparison.OrdinalIgnoreCase)
        || Provider.Equals("minio", StringComparison.OrdinalIgnoreCase)
        || Provider.Equals("aws", StringComparison.OrdinalIgnoreCase);

    public static StorageOptions Bind(IConfiguration configuration) =>
        configuration.GetSection(SectionName).Get<StorageOptions>() ?? new();
}

public sealed class LocalStorageOptions
{
    /// <summary>Empty = <c>wwwroot</c>. Relative paths are under content root. Absolute path for a dedicated volume.</summary>
    public string RootPath { get; set; } = "";
}

public sealed class S3StorageOptions
{
    public string Bucket { get; set; } = "jusplatform";

    /// <summary>MinIO example: <c>http://127.0.0.1:9000</c>. Empty = AWS default endpoint.</summary>
    public string? ServiceUrl { get; set; }

    public string Region { get; set; } = "us-east-1";

    public string AccessKey { get; set; } = "";

    public string SecretKey { get; set; } = "";

    /// <summary>Required for MinIO. Set false for AWS virtual-hosted buckets.</summary>
    public bool ForcePathStyle { get; set; } = true;

    /// <summary>Presigned GET for avatars / public-ish reads.</summary>
    public int ReadUrlExpiryMinutes { get; set; } = 15;

    /// <summary>When true, create the bucket and enable versioning/CORS on startup.</summary>
    public bool EnsureBucket { get; set; } = true;
}
