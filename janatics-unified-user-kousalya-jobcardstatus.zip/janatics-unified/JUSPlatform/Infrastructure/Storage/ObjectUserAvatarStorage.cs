using JUSPlatform.Application.Storage;
using JUSPlatform.Application.Users;

namespace JUSPlatform.Infrastructure.Storage;

public sealed class ObjectUserAvatarStorage(IObjectStorage storage) : IUserAvatarStorage
{
    public async Task<string> SaveAsync(
        Guid? organizationId,
        Guid userId,
        Stream content,
        CancellationToken cancellationToken)
    {
        await using var buffer = new MemoryStream();
        await content.CopyToAsync(buffer, cancellationToken);
        buffer.Position = 0;

        if (!IsJpeg(buffer))
        {
            throw new InvalidOperationException("Avatar must be a JPEG image.");
        }

        if (buffer.Length > UserAvatarRules.MaxBytes)
        {
            throw new InvalidOperationException("Avatar must be 200 KB or smaller.");
        }

        buffer.Position = 0;
        var key = StorageKeys.Avatar(organizationId, userId);
        await storage.PutAsync(key, buffer, UserAvatarRules.ContentType, cancellationToken);
        return key;
    }

    public async Task DeleteIfExistsAsync(string? relativePath, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(relativePath))
        {
            return;
        }

        await storage.DeleteAsync(relativePath, cancellationToken);
    }

    public string? GetReadUrl(string? relativePath) => storage.GetReadUrl(relativePath);

    private static bool IsJpeg(Stream stream)
    {
        var start = stream.Position;
        Span<byte> header = stackalloc byte[3];
        var read = stream.Read(header);
        stream.Position = start;
        return read == 3 && header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF;
    }
}
