using System.Globalization;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace JUSPlatform.Infrastructure.Persistence;

/// <summary>
/// PostgreSQL identifiers: C# <c>HavingThisCol</c> → <c>having_this_col</c>.
/// Tables already named in snake_case stay unchanged.
/// </summary>
internal static class SnakeCaseNameRewriter
{
    public static void Apply(ModelBuilder modelBuilder)
    {
        foreach (var entity in modelBuilder.Model.GetEntityTypes())
        {
            var tableName = entity.GetTableName();
            if (!string.IsNullOrEmpty(tableName))
            {
                entity.SetTableName(Rewrite(tableName));
            }

            foreach (var property in entity.GetProperties())
            {
                if (property.FindAnnotation(RelationalAnnotationNames.ColumnName) is not null)
                {
                    continue;
                }

                property.SetColumnName(Rewrite(property.Name));
            }

            foreach (var key in entity.GetKeys())
            {
                var name = key.GetName();
                if (!string.IsNullOrEmpty(name))
                {
                    key.SetName(Rewrite(name));
                }
            }

            foreach (var index in entity.GetIndexes())
            {
                var name = index.GetDatabaseName();
                if (!string.IsNullOrEmpty(name))
                {
                    index.SetDatabaseName(Rewrite(name));
                }
            }

            foreach (var fk in entity.GetForeignKeys())
            {
                var name = fk.GetConstraintName();
                if (!string.IsNullOrEmpty(name))
                {
                    fk.SetConstraintName(Rewrite(name));
                }
            }
        }
    }

    public static string Rewrite(string name)
    {
        if (string.IsNullOrEmpty(name))
        {
            return name;
        }

        var builder = new StringBuilder(name.Length + Math.Min(2, name.Length / 5));
        UnicodeCategory? previousCategory = null;

        for (var currentIndex = 0; currentIndex < name.Length; currentIndex++)
        {
            var currentChar = name[currentIndex];
            if (currentChar == '_')
            {
                builder.Append('_');
                previousCategory = null;
                continue;
            }

            var currentCategory = char.GetUnicodeCategory(currentChar);
            if (currentCategory is UnicodeCategory.UppercaseLetter or UnicodeCategory.TitlecaseLetter)
            {
                if (previousCategory == UnicodeCategory.SpaceSeparator
                    || previousCategory == UnicodeCategory.LowercaseLetter
                    || previousCategory != UnicodeCategory.DecimalDigitNumber
                        && previousCategory is not null
                        && currentIndex > 0
                        && currentIndex + 1 < name.Length
                        && char.GetUnicodeCategory(name[currentIndex + 1]) == UnicodeCategory.LowercaseLetter)
                {
                    builder.Append('_');
                }

                currentChar = char.ToLower(currentChar, CultureInfo.InvariantCulture);
            }

            builder.Append(currentChar);
            previousCategory = currentCategory;
        }

        return builder.ToString();
    }
}
