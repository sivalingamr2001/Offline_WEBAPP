using JUSPlatform.Application.JobCard;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace JUSPlatform.Infrastructure.Persistence.Seed;

public static class JobCardOracleMockSeeder
{
    public static async Task EnsureAsync(
        AppDbContext db,
        OracleDbContext oracle,
        CancellationToken cancellationToken = default)
    {
        if (oracle.Database.ProviderName?.Contains("InMemory", StringComparison.OrdinalIgnoreCase) != true)
        {
            return;
        }

        if (await oracle.JanWipTests.AnyAsync(cancellationToken))
        {
            return;
        }

        var orgIds = await db.Organizations.AsNoTracking()
            .Where(x => x.IsActive && x.OracleOrgId > 0)
            .Select(x => (decimal)x.OracleOrgId!.Value)
            .Distinct()
            .ToListAsync(cancellationToken);
        if (orgIds.Count == 0)
        {
            orgIds = [101];
        }

        var jobDate = DateTime.UtcNow.Date.AddDays(-2);
        foreach (var orgId in orgIds)
        {
            oracle.JanWipTests.AddRange(JobCardOracleMock.CreateRows(orgId, jobDate));
        }

        await oracle.SaveChangesAsync(cancellationToken);
        Log.Information(
            "Job card mock: seeded {JobCount} OSP jobs for {OrgCount} org id(s) and custodians {Codes}",
            orgIds.Count * JobCardOracleMock.CustodianCodes.Length,
            orgIds.Count,
            string.Join(", ", JobCardOracleMock.CustodianCodes));
    }
}
