using JUSPlatform.Application.Access;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Infrastructure.Persistence.Seed;

public static class SystemRoleSeeder
{
    public static async Task EnsureForOrganizationAsync(
        AppDbContext db,
        Guid organizationId,
        CancellationToken cancellationToken = default)
    {
        var permissions = await db.Permissions.AsNoTracking().ToListAsync(cancellationToken);
        var existing = await db.Roles
            .Where(x => x.OrganizationId == organizationId)
            .ToListAsync(cancellationToken);

        foreach (var roleName in SystemRoles.OrganizationRoles)
        {
            var role = existing.FirstOrDefault(x =>
                string.Equals(x.Name, roleName, StringComparison.OrdinalIgnoreCase));

            if (role is null)
            {
                role = new Role
                {
                    OrganizationId = organizationId,
                    Name = roleName,
                    Description = Describe(roleName),
                    IsSystem = true
                };
                db.Roles.Add(role);
                existing.Add(role);
            }
            else
            {
                role.IsSystem = true;
                if (string.IsNullOrWhiteSpace(role.Description))
                {
                    role.Description = Describe(roleName);
                }
            }

            var codes = PermissionCodesForRole(roleName, permissions);
            await SyncRolePermissionsAsync(db, role, codes, permissions, cancellationToken);
            await SyncRoleMenusAsync(db, role, roleName, codes, cancellationToken);
        }

        await db.SaveChangesAsync(cancellationToken);
        await MigrateLegacySalesRoleAsync(db, organizationId, cancellationToken);
    }

    private static async Task MigrateLegacySalesRoleAsync(
        AppDbContext db,
        Guid organizationId,
        CancellationToken cancellationToken)
    {
        var salesRole = await db.Roles
            .FirstOrDefaultAsync(
                x => x.OrganizationId == organizationId
                     && x.Name == "Sales"
                     && !x.IsDeleted,
                cancellationToken);

        if (salesRole is null)
        {
            return;
        }

        var replacement = await db.Roles
            .FirstAsync(
                x => x.OrganizationId == organizationId && x.Name == SystemRoles.DataEntryOperator,
                cancellationToken);

        var assignments = await db.UserRoles
            .Where(x => x.RoleId == salesRole.Id)
            .ToListAsync(cancellationToken);

        foreach (var assignment in assignments)
        {
            var alreadyAssigned = await db.UserRoles.AnyAsync(
                x => x.UserId == assignment.UserId && x.RoleId == replacement.Id,
                cancellationToken);

            if (alreadyAssigned)
            {
                db.UserRoles.Remove(assignment);
            }
            else
            {
                assignment.RoleId = replacement.Id;
            }
        }

        salesRole.IsDeleted = true;
        await db.SaveChangesAsync(cancellationToken);
    }

    /// <summary>
    /// Ensures default permissions exist on system roles (additive only).
    /// Does not remove permissions — API updates via PUT /roles/{id} are preserved.
    /// </summary>
    private static async Task SyncRolePermissionsAsync(
        AppDbContext db,
        Role role,
        IReadOnlyCollection<string> codes,
        IReadOnlyList<Permission> permissions,
        CancellationToken cancellationToken)
    {
        var desiredPermissions = permissions
            .Where(p => codes.Contains(p.Code, StringComparer.OrdinalIgnoreCase))
            .ToList();

        if (role.Id == Guid.Empty)
        {
            role.RolePermissions = desiredPermissions
                .Select(p => new RolePermission { PermissionId = p.Id })
                .ToList();
            return;
        }

        var desiredIds = desiredPermissions.Select(p => p.Id).ToHashSet();

        var existingIds = await db.RolePermissions
            .Where(x => x.RoleId == role.Id)
            .Select(x => x.PermissionId)
            .ToListAsync(cancellationToken);

        foreach (var permissionId in desiredIds.Where(id => !existingIds.Contains(id)))
        {
            db.RolePermissions.Add(new RolePermission
            {
                RoleId = role.Id,
                PermissionId = permissionId
            });
        }
    }

    private static async Task SyncRoleMenusAsync(
        AppDbContext db,
        Role role,
        string roleName,
        IReadOnlyCollection<string> permissionCodes,
        CancellationToken cancellationToken)
    {
        var menus = await db.AppMenus
            .Include(x => x.Module)
            .Where(x => x.IsActive)
            .ToListAsync(cancellationToken);

        IEnumerable<AppMenu> selected;
        if (SystemRoles.IsSuperAdmin(roleName) || SystemRoles.IsAdmin(roleName))
        {
            selected = menus;
        }
        else
        {
            selected = menus.Where(m =>
                string.Equals(m.Code, "HOME", StringComparison.OrdinalIgnoreCase) ||
                (!string.IsNullOrWhiteSpace(AppMenuCatalog.ResolvePermissionCode(m)) &&
                 permissionCodes.Contains(AppMenuCatalog.ResolvePermissionCode(m)!, StringComparer.OrdinalIgnoreCase)));
        }

        var desiredMenus = selected.ToList();
        var desired = desiredMenus.Select(m => m.Id).ToHashSet();
        var fullCrud = SystemRoles.IsSuperAdmin(roleName) || SystemRoles.IsAdmin(roleName);

        if (role.Id == Guid.Empty)
        {
            role.RoleMenus = desiredMenus
                .Select(menu => new RoleMenu
                {
                    ModuleId = menu.ModuleId,
                    MenuId = menu.Id,
                    CanCreate = fullCrud,
                    CanRead = true,
                    CanUpdate = fullCrud,
                    CanDelete = fullCrud,
                    CanExport = fullCrud,
                    CanApprove = fullCrud
                })
                .ToList();
            return;
        }

        var existing = await db.RoleMenus.Where(x => x.RoleId == role.Id).ToListAsync(cancellationToken);
        var existingIds = existing.Select(x => x.MenuId).ToHashSet();
        foreach (var menu in desiredMenus.Where(m => !existingIds.Contains(m.Id)))
        {
            db.RoleMenus.Add(new RoleMenu
            {
                RoleId = role.Id,
                ModuleId = menu.ModuleId,
                MenuId = menu.Id,
                CanCreate = fullCrud,
                CanRead = true,
                CanUpdate = fullCrud,
                CanDelete = fullCrud,
                CanExport = fullCrud,
                CanApprove = fullCrud
            });
        }
    }

    public static async Task SyncPlatformSuperAdminPermissionsAsync(
        AppDbContext db,
        Role role,
        CancellationToken cancellationToken)
    {
        var permissions = await db.Permissions.AsNoTracking().ToListAsync(cancellationToken);
        var codes = permissions.Select(p => p.Code).ToList();
        await SyncRolePermissionsAsync(db, role, codes, permissions, cancellationToken);
        await SyncRoleMenusAsync(db, role, SystemRoles.SuperAdmin, codes, cancellationToken);
        await db.SaveChangesAsync(cancellationToken);
    }

    public static async Task GrantMenuToPlatformSuperAdminAsync(
        AppDbContext db,
        Guid menuId,
        CancellationToken cancellationToken)
    {
        var roleId = await db.Roles
            .Where(x => x.OrganizationId == null && x.Name == SystemRoles.SuperAdmin)
            .Select(x => x.Id)
            .FirstOrDefaultAsync(cancellationToken);
        if (roleId == Guid.Empty)
        {
            return;
        }

        var exists = await db.RoleMenus.AnyAsync(x => x.RoleId == roleId && x.MenuId == menuId, cancellationToken);
        if (exists)
        {
            return;
        }

        var menu = await db.AppMenus.FirstOrDefaultAsync(x => x.Id == menuId, cancellationToken);
        if (menu is null)
        {
            return;
        }

        db.RoleMenus.Add(new RoleMenu
        {
            RoleId = roleId,
            ModuleId = menu.ModuleId,
            MenuId = menu.Id,
            CanCreate = true,
            CanRead = true,
            CanUpdate = true,
            CanDelete = true,
            CanExport = true,
            CanApprove = true
        });
        await db.SaveChangesAsync(cancellationToken);
    }

    public static async Task GrantPermissionToPlatformSuperAdminAsync(
        AppDbContext db,
        Guid permissionId,
        CancellationToken cancellationToken)
    {
        var roleId = await db.Roles
            .Where(x => x.OrganizationId == null && x.Name == SystemRoles.SuperAdmin)
            .Select(x => x.Id)
            .FirstOrDefaultAsync(cancellationToken);
        if (roleId == Guid.Empty)
        {
            return;
        }

        var exists = await db.RolePermissions.AnyAsync(
            x => x.RoleId == roleId && x.PermissionId == permissionId,
            cancellationToken);
        if (exists)
        {
            return;
        }

        db.RolePermissions.Add(new RolePermission { RoleId = roleId, PermissionId = permissionId });
        await db.SaveChangesAsync(cancellationToken);
    }

    private static IReadOnlyCollection<string> PermissionCodesForRole(
        string roleName,
        IReadOnlyList<Permission> allPermissions)
    {
        if (string.Equals(roleName, SystemRoles.Admin, StringComparison.OrdinalIgnoreCase))
        {
            return allPermissions.Select(p => p.Code).ToList();
        }

        if (string.Equals(roleName, SystemRoles.Manager, StringComparison.OrdinalIgnoreCase))
        {
            return
            [
                Permissions.OrgsRead,
                Permissions.UsersRead,
                Permissions.RolesRead,
                Permissions.JobsRead,
                Permissions.JobsWrite,
                Permissions.ModulesRead,
                Permissions.MenusRead
            ];
        }

        if (string.Equals(roleName, SystemRoles.DataEntryOperator, StringComparison.OrdinalIgnoreCase))
        {
            return
            [
                Permissions.JobsRead,
                Permissions.JobsWrite
            ];
        }

        return [];
    }

    private static string Describe(string roleName) =>
        roleName switch
        {
            SystemRoles.SuperAdmin => "Platform owner",
            SystemRoles.Admin => "Organization owner",
            SystemRoles.Manager => "Operational read/write for users, roles, and jobs",
            SystemRoles.DataEntryOperator => "Background job data entry",
            _ => roleName
        };
}
