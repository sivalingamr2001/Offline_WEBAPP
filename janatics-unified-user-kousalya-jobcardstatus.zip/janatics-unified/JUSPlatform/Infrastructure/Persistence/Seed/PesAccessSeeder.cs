using JUSPlatform.Application.Access;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace JUSPlatform.Infrastructure.Persistence.Seed;

/// <summary>
/// Ensures PES catalog permissions exist and grants PES menus to the requested operator.
/// </summary>
public static class PesAccessSeeder
{
    public const string OperatorEmail = "it-dev11@janatics.co.in";
    public const string FallbackRoleName = "PES Operator";

    public static async Task EnsureAsync(AppDbContext db, CancellationToken cancellationToken = default)
    {
        await EnsurePesPermissionsAsync(db, cancellationToken);

        var pesMenus = (await db.AppMenus
                .Include(x => x.Module)
                .Where(x => x.IsActive && x.Module != null && x.Module.IsActive)
                .ToListAsync(cancellationToken))
            .Where(IsCatalogPesMenu)
            .Where(x => !string.IsNullOrWhiteSpace(AppMenuCatalog.ResolvePath(x)))
            .ToList();
        if (pesMenus.Count == 0)
        {
            Log.Warning("No active PES catalog menus with a path; skip operator assignment");
            return;
        }

        var user = await db.Users
            .Include(x => x.UserRoles)
            .FirstOrDefaultAsync(x => x.Email == OperatorEmail, cancellationToken);
        if (user is null)
        {
            Log.Warning("PES operator user was not found; catalog only");
            return;
        }

        var role = await ResolveOrCreateRoleAsync(db, user, cancellationToken);
        await GrantPesAsync(db, role, pesMenus, cancellationToken);
        await AssignRoleAsync(db, user, role, cancellationToken);
        await db.SaveChangesAsync(cancellationToken);
        Log.Information("PES menus granted on role {Role} for operator", role.Name);
    }

    private static async Task EnsurePesPermissionsAsync(AppDbContext db, CancellationToken cancellationToken)
    {
        var codes = new[] { Permissions.PesView, Permissions.PesEdit, Permissions.JobCardView };
        var existing = await db.Permissions
            .Where(x => codes.Contains(x.Code))
            .Select(x => x.Code)
            .ToListAsync(cancellationToken);
        foreach (var (code, name, module) in Permissions.Catalog.Where(p => codes.Contains(p.Code)))
        {
            if (existing.Contains(code))
            {
                continue;
            }

            db.Permissions.Add(new Permission { Code = code, Name = name, Module = module });
        }

        await db.SaveChangesAsync(cancellationToken);
    }

    private static async Task<Role> ResolveOrCreateRoleAsync(
        AppDbContext db,
        User user,
        CancellationToken cancellationToken)
    {
        var roleId = user.RoleId
            ?? user.UserRoles.Select(x => x.RoleId).FirstOrDefault();
        if (roleId != Guid.Empty)
        {
            var existing = await db.Roles
                .Include(x => x.RoleMenus)
                .Include(x => x.RolePermissions)
                .FirstOrDefaultAsync(x => x.Id == roleId, cancellationToken);
            if (existing is not null)
            {
                return existing;
            }
        }

        var fallback = await db.Roles
            .Include(x => x.RoleMenus)
            .Include(x => x.RolePermissions)
            .FirstOrDefaultAsync(
                x => x.OrganizationId == null && x.Name == FallbackRoleName,
                cancellationToken);
        if (fallback is not null)
        {
            return fallback;
        }

        fallback = new Role
        {
            OrganizationId = null,
            Name = FallbackRoleName,
            Description = "PES workspace access"
        };
        db.Roles.Add(fallback);
        await db.SaveChangesAsync(cancellationToken);
        return fallback;
    }

    private static async Task GrantPesAsync(
        AppDbContext db,
        Role role,
        IReadOnlyList<AppMenu> pesMenus,
        CancellationToken cancellationToken)
    {
        foreach (var menu in pesMenus)
        {
            var linked = role.RoleMenus.Any(x => x.MenuId == menu.Id)
                || await db.RoleMenus.AnyAsync(x => x.RoleId == role.Id && x.MenuId == menu.Id, cancellationToken);
            if (linked)
            {
                continue;
            }

            db.RoleMenus.Add(new RoleMenu
            {
                RoleId = role.Id,
                ModuleId = menu.ModuleId,
                MenuId = menu.Id,
                CanRead = true,
                CanCreate = HasEditAccess(menu),
                CanUpdate = HasEditAccess(menu)
            });
        }

        var permissionIds = await db.Permissions
            .Where(x =>
                x.Code == Permissions.PesView
                || x.Code == Permissions.PesEdit
                || x.Code == Permissions.JobCardView)
            .Select(x => x.Id)
            .ToListAsync(cancellationToken);
        foreach (var permissionId in permissionIds)
        {
            var linked = role.RolePermissions.Any(x => x.PermissionId == permissionId)
                || await db.RolePermissions.AnyAsync(
                    x => x.RoleId == role.Id && x.PermissionId == permissionId,
                    cancellationToken);
            if (linked)
            {
                continue;
            }

            db.RolePermissions.Add(new RolePermission { RoleId = role.Id, PermissionId = permissionId });
        }
    }

    private static Task AssignRoleAsync(AppDbContext db, User user, Role role, CancellationToken _)
    {
        user.RoleId = role.Id;
        var existing = user.UserRoles.FirstOrDefault(x => x.RoleId == role.Id);
        if (existing is null)
        {
            foreach (var link in user.UserRoles.ToList())
            {
                db.UserRoles.Remove(link);
            }

            db.UserRoles.Add(new UserRole { UserId = user.Id, RoleId = role.Id });
        }

        return Task.CompletedTask;
    }

    private static bool IsCatalogPesMenu(AppMenu menu)
    {
        var module = menu.Module;
        if (module is null)
        {
            return false;
        }

        if (string.Equals(menu.Code, "PES001", StringComparison.OrdinalIgnoreCase)
            || string.Equals(menu.Code, "PES002", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        return string.Equals(module.Name, "PES", StringComparison.OrdinalIgnoreCase)
            || string.Equals(module.Code, "PES", StringComparison.OrdinalIgnoreCase)
            || string.Equals(module.Code, "MOD003", StringComparison.OrdinalIgnoreCase);
    }

    private static bool HasEditAccess(AppMenu menu) =>
        string.Equals(AppMenuCatalog.ResolvePermissionCode(menu), Permissions.PesEdit, StringComparison.OrdinalIgnoreCase);
}
