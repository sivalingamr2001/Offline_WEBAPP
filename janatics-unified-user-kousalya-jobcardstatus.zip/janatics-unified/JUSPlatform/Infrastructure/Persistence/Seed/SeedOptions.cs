namespace JUSPlatform.Infrastructure.Persistence.Seed;

/// <summary>Platform SuperAdmin seed options.</summary>
public sealed class SeedOptions
{
    public const string SectionName = "Seed";

    public string SuperAdminEmail { get; set; } = "admin@demo.local";
    public string SuperAdminPassword { get; set; } = "ChangeMe123!";
    public string SuperAdminDisplayName { get; set; } = "Super Admin";
}
