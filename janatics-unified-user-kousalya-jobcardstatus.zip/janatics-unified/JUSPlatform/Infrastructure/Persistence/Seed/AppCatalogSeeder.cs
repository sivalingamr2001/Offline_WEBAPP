using JUSPlatform.Application.Access;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace JUSPlatform.Infrastructure.Persistence.Seed;

public static class AppCatalogSeeder
{
    private static readonly CatalogMenu[] AdminMenus =
    [
        new("MNU003", "Permissions", "/dashboard/permissions", "KeyRound", 1, "permission", AppMenuCatalog.NaturePlatform, Permissions.RolesRead),
        new("MNU008", "System", "/dashboard/system", "Cpu", 2, null, AppMenuCatalog.NaturePlatform, null),
        new("MNU005", "Modules", "/dashboard/apps", "LayoutGrid", 3, "module", AppMenuCatalog.NaturePlatform, Permissions.ModulesRead),
        new("MNU004", "Settings", "/dashboard/settings", "Settings", 4, null, AppMenuCatalog.NatureTenant, null),
        new("MNU002", "Roles", "/dashboard/roles", "Shield", 5, "role", AppMenuCatalog.NaturePlatform, Permissions.RolesRead),
        new("MNU007", "Settings", "/dashboard/settings", "Settings", 6, null, AppMenuCatalog.NaturePlatform, null),
        new("MNU006", "Configuration", "/dashboard/organizations", "SlidersHorizontal", 7, "org", AppMenuCatalog.NaturePlatform, Permissions.OrgsRead),
        new("MNU001", "Users", "/dashboard/users", "UserCog", 8, "user", AppMenuCatalog.NaturePlatform, Permissions.UsersRead),
        new("MNU011", "User organizations", "/dashboard/user-organizations", "Building2", 85, "org", AppMenuCatalog.NaturePlatform, Permissions.UsersRead),
        new("MNU009", "Logs", "/dashboard/logs", "ScrollText", 9, null, AppMenuCatalog.NaturePlatform, Permissions.JobsRead),
        new("MNU010", "Menus", "/dashboard/menus", "Menu", 10, "menu", AppMenuCatalog.NaturePlatform, Permissions.MenusRead)
    ];

    public static async Task EnsureAsync(AppDbContext db, CancellationToken cancellationToken = default)
    {
        var existingModules = await db.AppModules.ToListAsync(cancellationToken);
        var existingMenus = await db.AppMenus.ToListAsync(cancellationToken);

        var admin = await EnsureModuleAsync(
            db,
            existingModules,
            "ADMIN",
            "Administration",
            "Organizations, users, roles, and catalog",
            "Building2",
            10,
            cancellationToken);

        var operate = await EnsureModuleAsync(
            db,
            existingModules,
            "OPERATE",
            "Operate",
            "Day-to-day workspace modules",
            "Briefcase",
            20,
            cancellationToken);

        var changed = 0;
        foreach (var spec in AdminMenus)
        {
            changed += await EnsureMenuAsync(db, existingMenus, admin.Id, spec, cancellationToken);
        }

        changed += await EnsureMenuAsync(
            db,
            existingMenus,
            operate.Id,
            new("HOME", "Account home", "/dashboard", "LayoutDashboard", 10, null, AppMenuCatalog.NatureTenant, null),
            cancellationToken);
        changed += await EnsureMenuAsync(
            db,
            existingMenus,
            operate.Id,
            new("PORT", "Portfolio", "/dashboard/portfolio", "Briefcase", 20, null, AppMenuCatalog.NatureTenant, null),
            cancellationToken);

        changed += RetireSeededPesPlaceholders(existingModules, existingMenus);

        foreach (var menu in existingMenus)
        {
            if (Backfill(menu))
            {
                changed++;
            }
        }

        var canonicalCodes = AdminMenus.Select(x => x.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);
        string[] legacyCodes = ["ORG", "USR", "ROL", "PERM", "MOD", "SET", "MNU"];
        if (existingMenus.Any(x => canonicalCodes.Contains(x.Code)))
        {
            foreach (var menu in existingMenus.Where(x =>
                         legacyCodes.Contains(x.Code, StringComparer.OrdinalIgnoreCase) && x.IsActive))
            {
                menu.IsActive = false;
                changed++;
            }
        }

        if (changed > 0)
        {
            await db.SaveChangesAsync(cancellationToken);
            Log.Information("Seed: synced {Count} app catalog row(s)", changed);
        }
    }

    /// <summary>
    /// Deletes platform extras inserted by an earlier Development boot (ADMIN, OPERATE, PES code, PES001/PES002).
    /// Leaves live catalog modules such as MOD003.
    /// </summary>
    public static async Task RemoveSeededExtrasAsync(AppDbContext db, CancellationToken cancellationToken = default)
    {
        var extraModuleCodes = new[] { "ADMIN", "OPERATE", "PES" };
        var extraMenuCodes = new[] { "PES001", "PES002" };

        var extraModules = await db.AppModules
            .IgnoreQueryFilters()
            .Where(x => extraModuleCodes.Contains(x.Code))
            .ToListAsync(cancellationToken);
        var extraModuleIds = extraModules.Select(x => x.Id).ToList();

        var extraMenus = await db.AppMenus
            .IgnoreQueryFilters()
            .Where(x => extraModuleIds.Contains(x.ModuleId) || extraMenuCodes.Contains(x.Code))
            .ToListAsync(cancellationToken);
        var extraMenuIds = extraMenus.Select(x => x.Id).ToList();

        if (extraMenuIds.Count == 0 && extraModules.Count == 0)
        {
            Log.Information("Catalog: no seeded extra modules or menus to remove");
            return;
        }

        var roleMenus = await db.RoleMenus
            .IgnoreQueryFilters()
            .Where(x => extraMenuIds.Contains(x.MenuId) || extraModuleIds.Contains(x.ModuleId))
            .ToListAsync(cancellationToken);
        db.RoleMenus.RemoveRange(roleMenus);

        foreach (var menu in extraMenus)
        {
            menu.ParentId = null;
            menu.ParentMenuId = null;
        }

        await db.SaveChangesAsync(cancellationToken);
        db.AppMenus.RemoveRange(extraMenus);
        db.AppModules.RemoveRange(extraModules);
        await db.SaveChangesAsync(cancellationToken);
        Log.Information(
            "Catalog: removed {ModuleCount} extra module(s) and {MenuCount} extra menu(s)",
            extraModules.Count,
            extraMenus.Count);
    }

    private static async Task<AppModule> EnsureModuleAsync(
        AppDbContext db,
        List<AppModule> existing,
        string code,
        string name,
        string description,
        string icon,
        int sortOrder,
        CancellationToken cancellationToken)
    {
        var module = existing.FirstOrDefault(x =>
            string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
        if (module is not null)
        {
            return module;
        }

        module = new AppModule
        {
            Code = code,
            Name = name,
            Description = description,
            Icon = icon,
            SortOrder = sortOrder,
            IsActive = true
        };
        db.AppModules.Add(module);
        existing.Add(module);
        await db.SaveChangesAsync(cancellationToken);
        Log.Information("Seed: added app module {Code}", code);
        return module;
    }

    private static int RetireSeededPesPlaceholders(List<AppModule> modules, List<AppMenu> menus)
    {
        var changed = 0;
        string[] placeholderCodes = ["PES001", "PES002"];
        foreach (var menu in menus.Where(x =>
                     placeholderCodes.Contains(x.Code, StringComparer.OrdinalIgnoreCase) && x.IsActive))
        {
            menu.IsActive = false;
            changed++;
        }

        var catalogPes = modules.FirstOrDefault(x =>
            string.Equals(x.Name, "PES", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(x.Code, "PES", StringComparison.OrdinalIgnoreCase));
        var seededPes = modules.FirstOrDefault(x =>
            string.Equals(x.Code, "PES", StringComparison.OrdinalIgnoreCase));
        if (catalogPes is not null && seededPes is not null && catalogPes.Id != seededPes.Id && seededPes.IsActive)
        {
            seededPes.IsActive = false;
            changed++;
        }

        return changed;
    }

    private static async Task<int> EnsureMenuAsync(
        AppDbContext db,
        List<AppMenu> existing,
        Guid moduleId,
        CatalogMenu spec,
        CancellationToken _)
    {
        var menu = existing.FirstOrDefault(x =>
            string.Equals(x.Code, spec.Code, StringComparison.OrdinalIgnoreCase));
        if (menu is null)
        {
            menu = new AppMenu
            {
                ModuleId = moduleId,
                Code = spec.Code,
                IsActive = true
            };
            Apply(menu, spec);
            db.AppMenus.Add(menu);
            existing.Add(menu);
            return 1;
        }

        return Apply(menu, spec) ? 1 : 0;
    }

    private static bool Apply(AppMenu menu, CatalogMenu spec)
    {
        var changed = false;
        changed |= Set(menu.Name, spec.Name, v => menu.Name = v);
        changed |= Set(menu.DisplayName, spec.Name, v => menu.DisplayName = v);
        changed |= Set(menu.Path, spec.Path, v => menu.Path = v);
        changed |= Set(menu.MenuPath, spec.Path, v => menu.MenuPath = v);
        changed |= Set(menu.Icon, spec.Icon, v => menu.Icon = v);
        changed |= Set(menu.MenuIcon, spec.Icon, v => menu.MenuIcon = v);
        changed |= Set(menu.MenuType, AppMenuCatalog.MenuTypeScreen, v => menu.MenuType = v);
        changed |= Set(menu.Nature, spec.Nature, v => menu.Nature = v);
        changed |= Set(menu.ResourceCode, spec.ResourceCode, v => menu.ResourceCode = v);
        changed |= Set(menu.PermissionCode, spec.PermissionCode, v => menu.PermissionCode = v);
        if (menu.SortOrder != spec.SortOrder)
        {
            menu.SortOrder = spec.SortOrder;
            changed = true;
        }

        if (!menu.IsActive)
        {
            menu.IsActive = true;
            changed = true;
        }

        return changed;
    }

    private static bool Backfill(AppMenu menu)
    {
        var changed = false;
        if (string.IsNullOrWhiteSpace(menu.Path) && !string.IsNullOrWhiteSpace(menu.MenuPath))
        {
            menu.Path = menu.MenuPath;
            changed = true;
        }

        if (string.IsNullOrWhiteSpace(menu.MenuPath) && !string.IsNullOrWhiteSpace(menu.Path))
        {
            menu.MenuPath = menu.Path;
            changed = true;
        }

        if (string.IsNullOrWhiteSpace(menu.Icon) && !string.IsNullOrWhiteSpace(menu.MenuIcon))
        {
            menu.Icon = menu.MenuIcon;
            changed = true;
        }

        if (string.IsNullOrWhiteSpace(menu.MenuIcon) && !string.IsNullOrWhiteSpace(menu.Icon))
        {
            menu.MenuIcon = menu.Icon;
            changed = true;
        }

        if (menu.ParentId is null && menu.ParentMenuId is not null)
        {
            menu.ParentId = menu.ParentMenuId;
            changed = true;
        }

        if (string.IsNullOrWhiteSpace(menu.PermissionCode))
        {
            var mapped = AppMenuCatalog.ResolvePermissionCode(menu);
            if (!string.IsNullOrWhiteSpace(mapped))
            {
                menu.PermissionCode = mapped;
                changed = true;
            }
        }

        if (string.IsNullOrWhiteSpace(menu.MenuType))
        {
            menu.MenuType = AppMenuCatalog.MenuTypeScreen;
            changed = true;
        }

        if (string.IsNullOrWhiteSpace(menu.Nature))
        {
            menu.Nature = AppMenuCatalog.NatureTenant;
            changed = true;
        }

        if (string.IsNullOrWhiteSpace(menu.DisplayName))
        {
            menu.DisplayName = menu.Name;
            changed = true;
        }

        return changed;
    }

    private static bool Set(string? current, string? next, Action<string> assign)
    {
        if (string.IsNullOrWhiteSpace(next) || string.Equals(current, next, StringComparison.Ordinal))
        {
            return false;
        }

        assign(next);
        return true;
    }

    private sealed record CatalogMenu(
        string Code,
        string Name,
        string Path,
        string Icon,
        int SortOrder,
        string? ResourceCode,
        string Nature,
        string? PermissionCode);
}
