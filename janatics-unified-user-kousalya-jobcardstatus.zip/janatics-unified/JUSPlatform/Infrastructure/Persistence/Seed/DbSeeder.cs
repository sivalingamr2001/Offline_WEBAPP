using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Authentication;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace JUSPlatform.Infrastructure.Persistence.Seed;

public static class DbSeeder
{
    public static async Task SeedAsync(
        AppDbContext db,
        PasswordHasher passwordHasher,
        SeedOptions options,
        CancellationToken cancellationToken = default)
    {
        await EnsurePermissionsAsync(db, cancellationToken);
        await AppCatalogSeeder.EnsureAsync(db, cancellationToken);
        await EnsurePlatformSuperAdminAsync(db, passwordHasher, options, cancellationToken);

        var organizationIds = await db.Organizations.Select(x => x.Id).ToListAsync(cancellationToken);
        foreach (var organizationId in organizationIds)
        {
            await SystemRoleSeeder.EnsureForOrganizationAsync(db, organizationId, cancellationToken);
        }

    }

    private static async Task EnsurePlatformSuperAdminAsync(
        AppDbContext db,
        PasswordHasher passwordHasher,
        SeedOptions options,
        CancellationToken cancellationToken)
    {
        ValidateOptions(options);

        var email = options.SuperAdminEmail.Trim().ToLowerInvariant();
        var displayName = options.SuperAdminDisplayName.Trim();

        var role = await db.Roles
            .Include(x => x.RolePermissions)
            .FirstOrDefaultAsync(
                x => x.OrganizationId == null && x.Name == SystemRoles.SuperAdmin,
                cancellationToken);

        if (role is null)
        {
            role = new Role
            {
                OrganizationId = null,
                Name = SystemRoles.SuperAdmin,
                Description = "Platform owner",
                IsSystem = true
            };
            db.Roles.Add(role);
            await db.SaveChangesAsync(cancellationToken);
        }
        else
        {
            role.IsSystem = true;
            role.Description = "Platform owner";
        }

        await SystemRoleSeeder.SyncPlatformSuperAdminPermissionsAsync(db, role, cancellationToken);

        var user = await db.Users
            .Include(x => x.UserRoles)
            .ThenInclude(x => x.Role)
            .FirstOrDefaultAsync(x => x.Email == email, cancellationToken);

        if (user is null)
        {
            user = new User
            {
                OrganizationId = null,
                Email = email,
                DisplayName = displayName,
                PasswordHash = passwordHasher.Hash(options.SuperAdminPassword),
                UserRoles = [new UserRole { RoleId = role.Id }]
            };
            db.Users.Add(user);
        }
        else
        {
            user.OrganizationId = null;
            user.DisplayName = displayName;
            user.IsActive = true;
            user.UserRoles.Clear();
            user.UserRoles.Add(new UserRole { UserId = user.Id, RoleId = role.Id });
        }

        await db.SaveChangesAsync(cancellationToken);
        await RemoveOrgScopedSuperAdminRolesAsync(db, role.Id, cancellationToken);
        await RemoveEmptyDemoOrganizationAsync(db, cancellationToken);
    }

    private static async Task RemoveOrgScopedSuperAdminRolesAsync(
        AppDbContext db,
        Guid platformRoleId,
        CancellationToken cancellationToken)
    {
        var orgRoles = await db.Roles
            .Where(x => x.OrganizationId != null && x.Name == SystemRoles.SuperAdmin)
            .ToListAsync(cancellationToken);

        if (orgRoles.Count == 0)
        {
            return;
        }

        var orgRoleIds = orgRoles.Select(x => x.Id).ToList();
        var assignments = await db.UserRoles
            .Where(x => orgRoleIds.Contains(x.RoleId))
            .ToListAsync(cancellationToken);

        foreach (var assignment in assignments)
        {
            var alreadyPlatform = await db.UserRoles.AnyAsync(
                x => x.UserId == assignment.UserId && x.RoleId == platformRoleId,
                cancellationToken);
            if (alreadyPlatform)
            {
                db.UserRoles.Remove(assignment);
            }
            else
            {
                assignment.RoleId = platformRoleId;
            }

            var user = await db.Users.FirstOrDefaultAsync(x => x.Id == assignment.UserId, cancellationToken);
            if (user is not null)
            {
                user.OrganizationId = null;
            }
        }

        db.Roles.RemoveRange(orgRoles);
        await db.SaveChangesAsync(cancellationToken);
    }

    private static async Task RemoveEmptyDemoOrganizationAsync(AppDbContext db, CancellationToken cancellationToken)
    {
        var demo = await db.Organizations.FirstOrDefaultAsync(
            x => x.Code == "DEMO",
            cancellationToken);
        if (demo is null)
        {
            return;
        }

        var hasUsers = await db.Users.AnyAsync(x => x.OrganizationId == demo.Id, cancellationToken);
        if (hasUsers)
        {
            return;
        }

        var roles = await db.Roles.Where(x => x.OrganizationId == demo.Id).ToListAsync(cancellationToken);
        db.Roles.RemoveRange(roles);
        db.Organizations.Remove(demo);
        await db.SaveChangesAsync(cancellationToken);
    }

    private static void ValidateOptions(SeedOptions options)
    {
        if (string.IsNullOrWhiteSpace(options.SuperAdminEmail)
            || string.IsNullOrWhiteSpace(options.SuperAdminPassword)
            || string.IsNullOrWhiteSpace(options.SuperAdminDisplayName))
        {
            throw new InvalidOperationException(
                "Seed section is incomplete. Set Seed:SuperAdminEmail, SuperAdminPassword, and SuperAdminDisplayName.");
        }

        if (options.SuperAdminPassword.Length < 8)
        {
            throw new InvalidOperationException("Seed:SuperAdminPassword must be at least 8 characters.");
        }
    }

    private static async Task EnsurePermissionsAsync(AppDbContext db, CancellationToken cancellationToken)
    {
        var existing = await db.Permissions.Select(x => x.Code).ToListAsync(cancellationToken);
        var missing = Permissions.Catalog
            .Where(p => !existing.Contains(p.Code))
            .Select(p => new Permission
            {
                Code = p.Code,
                Name = p.Name,
                Module = p.Module
            })
            .ToList();

        if (missing.Count == 0)
        {
            Log.Information("Seed: permission catalog already complete ({Count} codes)", existing.Count);
            return;
        }

        db.Permissions.AddRange(missing);
        await db.SaveChangesAsync(cancellationToken);
        Log.Information("Seed: added {Count} permission code(s)", missing.Count);
    }
}
