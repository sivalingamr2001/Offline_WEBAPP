using Npgsql;
using Serilog;

namespace JUSPlatform.Infrastructure.Persistence;

public static class DatabaseStartupLogger
{
    public static void LogConfiguration(IConfiguration configuration)
    {
        var useInMemory = configuration.GetValue("UseInMemoryDatabase", false);
        if (useInMemory)
        {
            var name = configuration.GetConnectionString("Default") ?? "JUSPlatformInMemory";
            Log.Information("Database: Provider=InMemory, Name={Name}", name);
            LogOracleConfiguration(configuration);
            return;
        }

        var connectionString = configuration.GetConnectionString("Default");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            Log.Warning("Database: Provider=PostgreSql, ConnectionString=(not configured)");
            LogOracleConfiguration(configuration);
            return;
        }

        try
        {
            var builder = new NpgsqlConnectionStringBuilder(connectionString);
            Log.Information(
                "Database: Provider=PostgreSql, Host={Host}, Port={Port}, Database={Database}, User={User}, PasswordConfigured={PasswordConfigured}",
                string.IsNullOrWhiteSpace(builder.Host) ? "(default)" : builder.Host,
                builder.Port,
                string.IsNullOrWhiteSpace(builder.Database)
                    ? "(empty — set Database= in ConnectionStrings:Default)"
                    : builder.Database,
                string.IsNullOrWhiteSpace(builder.Username) ? "(none)" : builder.Username,
                !string.IsNullOrEmpty(builder.Password));
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "Database: Provider=PostgreSql, ConnectionString=invalid");
        }

        LogOracleConfiguration(configuration);
    }

    private static void LogOracleConfiguration(IConfiguration configuration)
    {
        var enabled = configuration.GetValue("Oracle:Enabled", false);
        if (!enabled)
        {
            Log.Information("Database: Provider=Oracle, Enabled=false");
            return;
        }

        var connectionString = configuration.GetConnectionString("Oracle");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            Log.Warning("Database: Provider=Oracle, Enabled=true, ConnectionString=(not configured)");
            return;
        }

        var passwordConfigured = connectionString.Contains("Password=", StringComparison.OrdinalIgnoreCase);
        Log.Information(
            "Database: Provider=Oracle, Enabled=true, PasswordConfigured={PasswordConfigured}",
            passwordConfigured);
    }

    public static void EnsureConnectionStringValid(IConfiguration configuration)
    {
        if (configuration.GetValue("UseInMemoryDatabase", false))
        {
            return;
        }

        var connectionString = configuration.GetConnectionString("Default");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                "ConnectionStrings:Default is required when UseInMemoryDatabase is false.");
        }

        var builder = new NpgsqlConnectionStringBuilder(connectionString);
        if (string.IsNullOrWhiteSpace(builder.Database))
        {
            throw new InvalidOperationException(
                "ConnectionStrings:Default is missing Database=. Example: Host=localhost;Port=5432;Database=jusplatform;Username=postgres;Password=");
        }
    }
}
