using JUSPlatform.Infrastructure.Persistence.Oracle;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Infrastructure.Persistence;

public sealed class OracleDbContext(DbContextOptions<OracleDbContext> options) : DbContext(options)
{
    public DbSet<JanWipTest> JanWipTests => Set<JanWipTest>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var wip = modelBuilder.Entity<JanWipTest>();
        wip.ToTable("JAN_WIP_TEST");
        wip.HasKey(x => new { x.WipEntityId, x.OrganizationId });
        wip.Property(x => x.PrimaryItemId).HasColumnName("PRIMARY_ITEM_ID");
        wip.Property(x => x.OrganizationId).HasColumnName("ORGANIZATION_ID");
        wip.Property(x => x.ItemNo).HasColumnName("ITEM_NO").HasMaxLength(80);
        wip.Property(x => x.WipEntityId).HasColumnName("WIP_ENTITY_ID");
        wip.Property(x => x.JobNo).HasColumnName("JOB_NO").HasMaxLength(240);
        wip.Property(x => x.JobDt).HasColumnName("JOB_DT");
        wip.Property(x => x.AlternateRoutingDesignator).HasColumnName("ALTERNATE_ROUTING_DESIGNATOR").HasMaxLength(10);
        wip.Property(x => x.CustodianCode).HasColumnName("CUSTODIAN_CODE").HasMaxLength(15);
        MapOpn(wip, 1);
        MapOpn(wip, 2);
        MapOpn(wip, 3);
        MapOpn(wip, 4);
        MapOpn(wip, 5);
        MapOpn(wip, 6);
    }

    private static void MapOpn(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<JanWipTest> wip, int n)
    {
        wip.Property($"Opn{n}OperationSeq").HasColumnName($"OPN{n}_OPERATION_SEQ");
        wip.Property($"Opn{n}OperationDesc").HasColumnName($"OPN{n}_OPERATION_DESC").HasMaxLength(240);
        wip.Property($"Opn{n}QtyQueue").HasColumnName($"OPN{n}_QTY_QUEUE");
        wip.Property($"Opn{n}QtyMove").HasColumnName($"OPN{n}_QTY_MOVE");
        wip.Property($"Opn{n}QtyScrap").HasColumnName($"OPN{n}_QTY_SCRAP");
        wip.Property($"Opn{n}QtyComp").HasColumnName($"OPN{n}_QTY_COMP");
        wip.Property($"Opn{n}VendorName").HasColumnName($"OPN{n}_VENDOR_NAME").HasMaxLength(240);
        wip.Property($"Opn{n}LeadTime").HasColumnName($"OPN{n}_LEAD_TIME");
        wip.Property($"Opn{n}ProcessStartDate").HasColumnName($"OPN{n}_PROCESS_START_DATE");
    }

    public override int SaveChanges()
        => SaveIfInMemory(() => base.SaveChanges());

    public override int SaveChanges(bool acceptAllChangesOnSuccess)
        => SaveIfInMemory(() => base.SaveChanges(acceptAllChangesOnSuccess));

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        => SaveIfInMemoryAsync(() => base.SaveChangesAsync(cancellationToken));

    public override Task<int> SaveChangesAsync(
        bool acceptAllChangesOnSuccess,
        CancellationToken cancellationToken = default)
        => SaveIfInMemoryAsync(() => base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken));

    private int SaveIfInMemory(Func<int> save)
    {
        if (IsInMemory)
        {
            return save();
        }

        throw new InvalidOperationException("OracleDbContext is read-only.");
    }

    private Task<int> SaveIfInMemoryAsync(Func<Task<int>> save)
    {
        if (IsInMemory)
        {
            return save();
        }

        throw new InvalidOperationException("OracleDbContext is read-only.");
    }

    private bool IsInMemory =>
        Database.ProviderName?.Contains("InMemory", StringComparison.OrdinalIgnoreCase) == true;
}
