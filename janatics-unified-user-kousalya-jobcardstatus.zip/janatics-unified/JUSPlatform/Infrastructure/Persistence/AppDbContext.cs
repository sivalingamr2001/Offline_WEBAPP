using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence.Leftovers;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Infrastructure.Persistence;

public sealed class AppDbContext(
    DbContextOptions<AppDbContext> options,
    ICurrentUser currentUser) : DbContext(options)
{
    public DbSet<OperatingUnit> OperatingUnits => Set<OperatingUnit>();
    public DbSet<Organization> Organizations => Set<Organization>();
    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<AppModule> AppModules => Set<AppModule>();
    public DbSet<AppMenu> AppMenus => Set<AppMenu>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<RoleMenu> RoleMenus => Set<RoleMenu>();
    public DbSet<UserAccessRight> UserAccessRights => Set<UserAccessRight>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();
    public DbSet<JobRun> JobRuns => Set<JobRun>();
    public DbSet<JobLogEntry> JobLogEntries => Set<JobLogEntry>();
    public DbSet<PasswordResetToken> PasswordResetTokens => Set<PasswordResetToken>();
    public DbSet<JanCustomerComplaintTab> JanCustomerComplaints => Set<JanCustomerComplaintTab>();
    public DbSet<JanAllOuSalesTab> JanAllOuSales => Set<JanAllOuSalesTab>();
    public DbSet<JanCustodianLine> JanCustodianLines => Set<JanCustodianLine>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
        SnakeCaseNameRewriter.Apply(modelBuilder);
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var utcNow = DateTimeOffset.UtcNow;
        foreach (var entry in ChangeTracker.Entries<Domain.Common.EntityBase>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedAt = utcNow;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.UpdatedAt = utcNow;

                var deletedProp = entry.Property(x => x.IsDeleted);
                if (deletedProp.IsModified && entry.Entity.IsDeleted)
                {
                    entry.Entity.DeletedAt ??= utcNow;
                    if (entry.Entity.DeletedByUserId is null && currentUser.UserId is { } userId)
                    {
                        entry.Entity.DeletedByUserId = userId;
                    }
                }
                else if (deletedProp.IsModified && !entry.Entity.IsDeleted)
                {
                    entry.Entity.DeletedAt = null;
                    entry.Entity.DeletedByUserId = null;
                }
            }
        }

        return base.SaveChangesAsync(cancellationToken);
    }
}
