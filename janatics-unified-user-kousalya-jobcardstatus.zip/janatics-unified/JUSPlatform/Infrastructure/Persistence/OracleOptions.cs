namespace JUSPlatform.Infrastructure.Persistence;

public sealed class OracleOptions
{
    public const string SectionName = "Oracle";

    /// <summary>
    /// Open a second EF Core context against Oracle (EBS / existing schema).
    /// App tables, Hangfire, and migrations stay on PostgreSQL.
    /// </summary>
    public bool Enabled { get; set; }
}
