using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace JUSPlatform.Infrastructure.Persistence.Configurations;

internal sealed class OperatingUnitConfiguration : IEntityTypeConfiguration<OperatingUnit>
{
    public void Configure(EntityTypeBuilder<OperatingUnit> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("operating_units");
        builder.Property(x => x.OrgId).IsRequired();
        builder.Property(x => x.Name).HasMaxLength(255).IsRequired();
        builder.HasIndex(x => x.OrgId).IsUnique();
    }
}

internal sealed class OrganizationConfiguration : IEntityTypeConfiguration<Organization>
{
    public void Configure(EntityTypeBuilder<Organization> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("organizations");
        builder.Property(x => x.Name).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Code).HasMaxLength(50).IsRequired();
        builder.Property(x => x.OracleOrgId).HasColumnType("numeric(18,0)");
        builder.Property(x => x.UnitName).HasMaxLength(100);
        builder.HasIndex(x => x.Code).IsUnique();
    }
}
