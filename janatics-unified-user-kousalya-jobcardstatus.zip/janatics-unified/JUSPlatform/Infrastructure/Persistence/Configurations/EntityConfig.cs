using JUSPlatform.Domain.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace JUSPlatform.Infrastructure.Persistence.Configurations;

internal static class EntityConfig
{
    public static void ConfigureBase<T>(EntityTypeBuilder<T> builder) where T : EntityBase
    {
        builder.HasKey(x => x.Id);
        builder.Property(x => x.CreatedAt).IsRequired();
        builder.Property(x => x.IsDeleted).IsRequired();
        builder.Property(x => x.DeletedAt);
        builder.Property(x => x.DeletedByUserId);
        builder.HasQueryFilter(x => !x.IsDeleted);
    }
}
