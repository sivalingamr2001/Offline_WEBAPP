using JUSPlatform.Infrastructure.Persistence.Leftovers;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace JUSPlatform.Infrastructure.Persistence.Configurations;

internal sealed class JanCustomerComplaintTabConfiguration : IEntityTypeConfiguration<JanCustomerComplaintTab>
{
    public void Configure(EntityTypeBuilder<JanCustomerComplaintTab> builder)
    {
        builder.HasNoKey();
        builder.ToTable("jan_customer_complaint_tab", table => table.ExcludeFromMigrations());
        builder.Property(x => x.Qty).HasPrecision(18, 4);
    }
}

internal sealed class JanAllOuSalesTabConfiguration : IEntityTypeConfiguration<JanAllOuSalesTab>
{
    public void Configure(EntityTypeBuilder<JanAllOuSalesTab> builder)
    {
        builder.HasNoKey();
        builder.ToTable("jan_all_ou_sales_tab", table => table.ExcludeFromMigrations());
        builder.Property(x => x.TrxDate).HasColumnType("timestamp without time zone");
        builder.Property(x => x.OrderedDate).HasColumnType("timestamp without time zone");
        builder.Property(x => x.AsOnDate).HasColumnType("timestamp without time zone");
        builder.Property(x => x.PayDt).HasColumnType("timestamp without time zone");
        builder.Property(x => x.ItemCreatedDate).HasColumnType("timestamp without time zone");
        builder.Property(x => x.QuantityInvoiced).HasPrecision(18, 4);
        builder.Property(x => x.MPlusLAson31mar2024).HasColumnName("m_plus_l_ason31mar2024");
        builder.Property(x => x.MPlusLAson31mar2025).HasColumnName("m_plus_l_ason31mar2025");
    }
}

internal sealed class JanCustodianLineConfiguration : IEntityTypeConfiguration<JanCustodianLine>
{
    public void Configure(EntityTypeBuilder<JanCustodianLine> builder)
    {
        builder.HasKey(x => x.CustLineId);
        builder.ToTable("jan_custodian_lines", table => table.ExcludeFromMigrations());
        builder.Property(x => x.CustLineId).HasColumnName("cust_line_id");
        builder.Property(x => x.CardNo).HasColumnName("card_no").HasMaxLength(10);
        builder.Property(x => x.CustodianCode).HasMaxLength(200);
        builder.Property(x => x.UsersId).HasColumnName("users_id");
        builder.Property(x => x.ActiveFlag).HasColumnName("active_flag");
    }
}
