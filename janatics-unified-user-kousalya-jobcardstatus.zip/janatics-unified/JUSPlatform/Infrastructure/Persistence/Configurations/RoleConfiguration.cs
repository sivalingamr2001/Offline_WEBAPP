using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace JUSPlatform.Infrastructure.Persistence.Configurations;

internal sealed class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("roles");
        builder.Property(x => x.Name).HasMaxLength(100).IsRequired();
        builder.Property(x => x.Description).HasMaxLength(500);
        builder.Property(x => x.OrganizationId).IsRequired(false);
        builder.HasIndex(x => new { x.OrganizationId, x.Name }).IsUnique();
        builder.HasOne(x => x.Organization)
            .WithMany(x => x.Roles)
            .HasForeignKey(x => x.OrganizationId)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

internal sealed class PermissionConfiguration : IEntityTypeConfiguration<Permission>
{
    public void Configure(EntityTypeBuilder<Permission> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("permissions");
        builder.Property(x => x.Code).HasMaxLength(100).IsRequired();
        builder.Property(x => x.Name).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Module).HasMaxLength(100).IsRequired();
        builder.HasIndex(x => x.Code).IsUnique();
    }
}

internal sealed class RolePermissionConfiguration : IEntityTypeConfiguration<RolePermission>
{
    public void Configure(EntityTypeBuilder<RolePermission> builder)
    {
        builder.ToTable("role_permissions");
        builder.HasKey(x => new { x.RoleId, x.PermissionId });
        builder.HasOne(x => x.Role).WithMany(x => x.RolePermissions).HasForeignKey(x => x.RoleId);
        builder.HasOne(x => x.Permission).WithMany(x => x.RolePermissions).HasForeignKey(x => x.PermissionId);
        builder.HasQueryFilter(x =>
            x.Role != null && !x.Role.IsDeleted &&
            x.Permission != null && !x.Permission.IsDeleted);
    }
}

internal sealed class RoleMenuConfiguration : IEntityTypeConfiguration<RoleMenu>
{
    public void Configure(EntityTypeBuilder<RoleMenu> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("role_menus");
        builder.Property(x => x.CanCreate).HasColumnName("perm_add");
        builder.Property(x => x.CanRead).HasColumnName("perm_view");
        builder.Property(x => x.CanUpdate).HasColumnName("perm_edit");
        builder.Property(x => x.CanDelete).HasColumnName("perm_delete");
        builder.Property(x => x.CanExport).HasColumnName("perm_export");
        builder.Property(x => x.CanApprove).HasColumnName("perm_approve");
        builder.HasIndex(x => new { x.RoleId, x.MenuId }).IsUnique();
        builder.HasOne(x => x.Role).WithMany(x => x.RoleMenus).HasForeignKey(x => x.RoleId);
        builder.HasOne(x => x.Menu).WithMany(x => x.RoleMenus).HasForeignKey(x => x.MenuId);
        builder.HasOne(x => x.Module).WithMany().HasForeignKey(x => x.ModuleId);
    }
}

internal sealed class UserAccessRightConfiguration : IEntityTypeConfiguration<UserAccessRight>
{
    public void Configure(EntityTypeBuilder<UserAccessRight> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("user_access_rights");
        builder.Property(x => x.AccessChannel).HasMaxLength(10).IsRequired();
        builder.Property(x => x.Remarks).HasMaxLength(400);
        builder.Property(x => x.LimitValue).HasColumnType("numeric(15,2)");
        builder.HasIndex(x => new { x.UserId, x.OrganizationId }).IsUnique();
        builder.HasOne(x => x.User).WithMany(x => x.AccessRights).HasForeignKey(x => x.UserId);
        builder.HasOne(x => x.Organization).WithMany().HasForeignKey(x => x.OrganizationId);
    }
}
