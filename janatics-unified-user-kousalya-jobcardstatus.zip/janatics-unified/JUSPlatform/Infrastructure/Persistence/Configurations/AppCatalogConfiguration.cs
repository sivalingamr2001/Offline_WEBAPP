using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace JUSPlatform.Infrastructure.Persistence.Configurations;

internal sealed class AppModuleConfiguration : IEntityTypeConfiguration<AppModule>
{
    public void Configure(EntityTypeBuilder<AppModule> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("app_modules");
        builder.Property(x => x.Code).HasMaxLength(50).IsRequired();
        builder.Property(x => x.Name).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Description).HasMaxLength(1000);
        builder.Property(x => x.Icon).HasMaxLength(100);
        builder.HasIndex(x => x.Code).IsUnique();
    }
}

internal sealed class AppMenuConfiguration : IEntityTypeConfiguration<AppMenu>
{
    public void Configure(EntityTypeBuilder<AppMenu> builder)
    {
        EntityConfig.ConfigureBase(builder);
        builder.ToTable("app_menus");
        builder.Property(x => x.Code).HasMaxLength(50).IsRequired();
        builder.Property(x => x.Name).HasMaxLength(200).IsRequired();
        builder.Property(x => x.DisplayName).HasMaxLength(100);
        builder.Property(x => x.Path).HasMaxLength(200);
        builder.Property(x => x.MenuPath).HasMaxLength(100);
        builder.Property(x => x.Icon).HasMaxLength(100);
        builder.Property(x => x.MenuIcon).HasMaxLength(100);
        builder.Property(x => x.MenuType).HasMaxLength(20).IsRequired();
        builder.Property(x => x.Nature).HasMaxLength(20).IsRequired();
        builder.Property(x => x.ResourceCode).HasMaxLength(40);
        builder.Property(x => x.PermissionCode).HasMaxLength(100);
        builder.HasIndex(x => x.Code).IsUnique();
        builder.HasOne(x => x.Module)
            .WithMany(x => x.Menus)
            .HasForeignKey(x => x.ModuleId)
            .OnDelete(DeleteBehavior.Cascade);
        builder.HasOne(x => x.Parent)
            .WithMany(x => x.Children)
            .HasForeignKey(x => x.ParentId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
