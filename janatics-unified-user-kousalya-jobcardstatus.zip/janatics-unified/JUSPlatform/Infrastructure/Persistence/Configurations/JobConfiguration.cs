using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace JUSPlatform.Infrastructure.Persistence.Configurations;

public sealed class JobRunConfiguration : IEntityTypeConfiguration<JobRun>
{
    public void Configure(EntityTypeBuilder<JobRun> builder)
    {
        builder.ToTable("job_runs");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.JobType).HasMaxLength(64).IsRequired();
        builder.Property(x => x.PayloadJson).HasColumnType("jsonb").IsRequired();
        builder.Property(x => x.ResultJson).HasColumnType("jsonb");
        builder.Property(x => x.ErrorMessage).HasMaxLength(2000);
        builder.Property(x => x.TraceId).HasMaxLength(64);
        builder.HasIndex(x => new { x.OrganizationId, x.QueuedAt });
        builder.HasIndex(x => new { x.Status, x.NextRunAt });
        builder.HasMany(x => x.Logs).WithOne(x => x.JobRun).HasForeignKey(x => x.JobRunId);
    }
}

public sealed class JobLogEntryConfiguration : IEntityTypeConfiguration<JobLogEntry>
{
    public void Configure(EntityTypeBuilder<JobLogEntry> builder)
    {
        builder.ToTable("job_log_entries");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Level).HasMaxLength(16).IsRequired();
        builder.Property(x => x.Message).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Detail).HasMaxLength(4000);
        builder.HasIndex(x => new { x.JobRunId, x.CreatedAt });
    }
}
