using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Common;
using JUSPlatform.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace JUSPlatform.Infrastructure.Persistence;

/// <summary>
/// On every SaveChanges: write DB audit rows and invalidate paginated query-cache indexes.
/// </summary>
public sealed class EntityChangeInterceptor(
    ICurrentUser currentUser,
    IQueryCache queryCache,
    ILogger<EntityChangeInterceptor> logger) : SaveChangesInterceptor
{
    private readonly List<CacheTouch> _pendingCache = [];

    public override InterceptionResult<int> SavingChanges(
        DbContextEventData eventData,
        InterceptionResult<int> result)
    {
        Capture(eventData.Context);
        return base.SavingChanges(eventData, result);
    }

    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(
        DbContextEventData eventData,
        InterceptionResult<int> result,
        CancellationToken cancellationToken = default)
    {
        Capture(eventData.Context);
        return base.SavingChangesAsync(eventData, result, cancellationToken);
    }

    public override int SavedChanges(SaveChangesCompletedEventData eventData, int result)
    {
        FlushCache().GetAwaiter().GetResult();
        return base.SavedChanges(eventData, result);
    }

    public override async ValueTask<int> SavedChangesAsync(
        SaveChangesCompletedEventData eventData,
        int result,
        CancellationToken cancellationToken = default)
    {
        await FlushCache(cancellationToken);
        return await base.SavedChangesAsync(eventData, result, cancellationToken);
    }

    public override void SaveChangesFailed(DbContextErrorEventData eventData)
    {
        _pendingCache.Clear();
        base.SaveChangesFailed(eventData);
    }

    public override Task SaveChangesFailedAsync(
        DbContextErrorEventData eventData,
        CancellationToken cancellationToken = default)
    {
        _pendingCache.Clear();
        return base.SaveChangesFailedAsync(eventData, cancellationToken);
    }

    private void Capture(DbContext? context)
    {
        if (context is null)
        {
            return;
        }

        _pendingCache.Clear();
        var utcNow = DateTimeOffset.UtcNow;
        var actor = currentUser.UserId;
        var audits = new List<AuditEntry>();

        foreach (var entry in context.ChangeTracker.Entries())
        {
            if (entry.Entity is AuditEntry || entry.State is EntityState.Detached or EntityState.Unchanged)
            {
                continue;
            }

            if (entry.Entity is UserRole or RolePermission or RoleMenu or UserAccessRight)
            {
                CaptureJunction(entry, audits, actor, utcNow);
                continue;
            }

            if (entry.Entity is not EntityBase entity)
            {
                continue;
            }

            var action = ResolveAction(entry);
            if (action is null)
            {
                continue;
            }

            var orgId = ResolveOrganizationId(entry);
            audits.Add(new AuditEntry
            {
                OrganizationId = orgId,
                ActorUserId = actor,
                EntityName = entry.Metadata.ClrType.Name,
                EntityId = entity.Id,
                Action = action,
                Summary = BuildSummary(entry.Entity, action),
                OccurredAt = utcNow
            });

            QueueCacheInvalidations(entry, orgId);
        }

        if (audits.Count > 0)
        {
            context.Set<AuditEntry>().AddRange(audits);
        }
    }

    private void CaptureJunction(
        EntityEntry entry,
        List<AuditEntry> audits,
        Guid? actor,
        DateTimeOffset utcNow)
    {
        var action = entry.State switch
        {
            EntityState.Added => AuditActions.Created,
            EntityState.Deleted => AuditActions.Deleted,
            EntityState.Modified => AuditActions.Updated,
            _ => null
        };
        if (action is null)
        {
            return;
        }

        switch (entry.Entity)
        {
            case UserRole ur:
                audits.Add(new AuditEntry
                {
                    OrganizationId = ResolveUserOrg(entry.Context, ur.UserId) ?? currentUser.OrganizationId,
                    ActorUserId = actor,
                    EntityName = nameof(UserRole),
                    EntityId = ur.UserId,
                    Action = action,
                    Summary = $"UserRole {action.ToLowerInvariant()} (user {ur.UserId:N}, role {ur.RoleId:N})",
                    OccurredAt = utcNow
                });
                Queue(ListCacheKeys.Users, ResolveUserOrg(entry.Context, ur.UserId) ?? currentUser.OrganizationId, null);
                break;
            case RolePermission rp:
                audits.Add(new AuditEntry
                {
                    OrganizationId = ResolveRoleOrg(entry.Context, rp.RoleId) ?? currentUser.OrganizationId,
                    ActorUserId = actor,
                    EntityName = nameof(RolePermission),
                    EntityId = rp.RoleId,
                    Action = action,
                    Summary = $"RolePermission {action.ToLowerInvariant()} (role {rp.RoleId:N}, permission {rp.PermissionId:N})",
                    OccurredAt = utcNow
                });
                Queue(ListCacheKeys.Roles, ResolveRoleOrg(entry.Context, rp.RoleId) ?? currentUser.OrganizationId, null);
                break;
            case RoleMenu rm:
                audits.Add(new AuditEntry
                {
                    OrganizationId = ResolveRoleOrg(entry.Context, rm.RoleId) ?? currentUser.OrganizationId,
                    ActorUserId = actor,
                    EntityName = nameof(RoleMenu),
                    EntityId = rm.RoleId,
                    Action = action,
                    Summary = $"RoleMenu {action.ToLowerInvariant()} (role {rm.RoleId:N}, menu {rm.MenuId:N})",
                    OccurredAt = utcNow
                });
                Queue(ListCacheKeys.Roles, ResolveRoleOrg(entry.Context, rm.RoleId) ?? currentUser.OrganizationId, null);
                break;
            case UserAccessRight uar:
                audits.Add(new AuditEntry
                {
                    OrganizationId = ResolveUserOrg(entry.Context, uar.UserId) ?? currentUser.OrganizationId,
                    ActorUserId = actor,
                    EntityName = nameof(UserAccessRight),
                    EntityId = uar.UserId,
                    Action = action,
                    Summary = $"UserAccessRight {action.ToLowerInvariant()} (user {uar.UserId:N}, org {uar.OrganizationId:N})",
                    OccurredAt = utcNow
                });
                Queue(ListCacheKeys.Users, ResolveUserOrg(entry.Context, uar.UserId) ?? currentUser.OrganizationId, null);
                break;
        }
    }

    private static string? ResolveAction(EntityEntry entry)
    {
        if (entry.State == EntityState.Added)
        {
            return AuditActions.Created;
        }

        if (entry.State == EntityState.Deleted)
        {
            return AuditActions.Deleted;
        }

        if (entry.State == EntityState.Modified)
        {
            if (entry.Entity is EntityBase { IsDeleted: true }
                && entry.Property(nameof(EntityBase.IsDeleted)).IsModified)
            {
                return AuditActions.Deleted;
            }

            return AuditActions.Updated;
        }

        return null;
    }

    private static string BuildSummary(object entity, string action)
    {
        var verb = action.ToLowerInvariant();
        return entity switch
        {
            User u => $"User {u.Email} {verb}",
            Role r => $"Role {r.Name} {verb}",
            Permission perm => $"Permission {perm.Code} {verb}",
            AppModule module => $"AppModule {module.Code} {verb}",
            AppMenu menu => $"AppMenu {menu.Code} {verb}",
            OperatingUnit ou => $"OperatingUnit {ou.Name} {verb}",
            Organization o => $"Organization {o.Name} {verb}",
            EntityBase e => $"{entity.GetType().Name} {e.Id:N} {verb}",
            _ => $"{entity.GetType().Name} {verb}"
        };
    }

    private Guid? ResolveOrganizationId(EntityEntry entry) =>
        entry.Entity switch
        {
            User user => user.OrganizationId,
            Role role => role.OrganizationId,
            OrgScopedEntity orgScoped => orgScoped.OrganizationId,
            _ => currentUser.OrganizationId
        };

    private static Guid? ResolveUserOrg(DbContext db, Guid userId) =>
        db.ChangeTracker.Entries<User>().FirstOrDefault(x => x.Entity.Id == userId)?.Entity.OrganizationId;

    private static Guid? ResolveRoleOrg(DbContext db, Guid roleId) =>
        db.ChangeTracker.Entries<Role>().FirstOrDefault(x => x.Entity.Id == roleId)?.Entity.OrganizationId;

    private void QueueCacheInvalidations(EntityEntry entry, Guid? organizationId)
    {
        switch (entry.Entity)
        {
            case User:
                Queue(ListCacheKeys.Users, organizationId, null);
                break;
            case Role:
                Queue(ListCacheKeys.Roles, organizationId, null);
                break;
            case Permission:
                Queue(ListCacheKeys.Permissions, null, null);
                break;
            case AppModule:
                Queue(ListCacheKeys.AppModules, null, null);
                break;
            case AppMenu:
                Queue(ListCacheKeys.AppMenus, null, null);
                break;
        }
    }

    private void Queue(string resource, Guid? organizationId, string? suffix)
    {
        if (_pendingCache.Any(x =>
                x.Resource == resource && x.OrganizationId == organizationId && x.Suffix == suffix))
        {
            return;
        }

        _pendingCache.Add(new CacheTouch(resource, organizationId, suffix));
    }

    private async Task FlushCache(CancellationToken cancellationToken = default)
    {
        if (_pendingCache.Count == 0)
        {
            return;
        }

        var touches = _pendingCache.ToList();
        _pendingCache.Clear();

        foreach (var touch in touches)
        {
            try
            {
                await queryCache.InvalidateAsync(
                    touch.Resource,
                    touch.OrganizationId,
                    touch.Suffix,
                    cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogWarning(
                    ex,
                    "Cache invalidation failed for {Resource} org {OrgId}",
                    touch.Resource,
                    touch.OrganizationId);
            }
        }
    }

    private sealed record CacheTouch(string Resource, Guid? OrganizationId, string? Suffix);
}
