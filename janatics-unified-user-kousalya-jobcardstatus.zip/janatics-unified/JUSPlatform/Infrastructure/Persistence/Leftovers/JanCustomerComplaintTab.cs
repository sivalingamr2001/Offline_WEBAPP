namespace JUSPlatform.Infrastructure.Persistence.Leftovers;

/// <summary>Read-only map of leftover dump table jan_customer_complaint_tab. Not migrated.</summary>
public sealed class JanCustomerComplaintTab
{
    public decimal? Cusid { get; set; }
    public string? Cusname { get; set; }
    public decimal? OrgId { get; set; }
    public string? HouName { get; set; }
    public string? UnitName { get; set; }
    public decimal? Ccrno { get; set; }
    public DateOnly? Ccrdt { get; set; }
    public string? Ym { get; set; }
    public string? Wk { get; set; }
    public string? FinYr { get; set; }
    public string? CompCusName { get; set; }
    public string? Cusregion { get; set; }
    public string? Orgcode { get; set; }
    public string? ItemNo { get; set; }
    public decimal? ItemId { get; set; }
    public string? Description { get; set; }
    public decimal? Qty { get; set; }
    public string? Complaint { get; set; }
    public string? Remarks { get; set; }
    public string? Observation { get; set; }
    public string? Rectification { get; set; }
    public string? DeptObservation { get; set; }
    public string? RootCause { get; set; }
    public string? CapaDet { get; set; }
    public string? Cert { get; set; }
    public string? CustomerClassCode { get; set; }
    public DateOnly? TargetCompDt { get; set; }
    public DateOnly? CloseDt { get; set; }
    public decimal? DerivedOrgId { get; set; }
    public string? CustodianCode { get; set; }
}
