namespace JUSPlatform.Infrastructure.Persistence.Leftovers;

/// <summary>Read-only map of leftover dump table jan_custodian_lines. Not migrated.</summary>
public sealed class JanCustodianLine
{
    public decimal CustLineId { get; set; }
    public string? CardNo { get; set; }
    public string? CustodianCode { get; set; }
    public Guid? UsersId { get; set; }
    public short ActiveFlag { get; set; }
}
