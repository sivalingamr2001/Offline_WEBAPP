﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddAppCatalog : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                CREATE TABLE IF NOT EXISTS app_modules (
                    id uuid NOT NULL,
                    code character varying(50) NOT NULL,
                    name character varying(200) NOT NULL,
                    description character varying(1000),
                    icon character varying(100),
                    sort_order integer NOT NULL DEFAULT 0,
                    is_active boolean NOT NULL DEFAULT TRUE,
                    created_at timestamp with time zone NOT NULL DEFAULT now(),
                    updated_at timestamp with time zone,
                    is_deleted boolean NOT NULL DEFAULT FALSE,
                    deleted_at timestamp with time zone,
                    deleted_by_user_id uuid,
                    CONSTRAINT pk_app_modules PRIMARY KEY (id)
                );

                CREATE TABLE IF NOT EXISTS app_menus (
                    id uuid NOT NULL,
                    module_id uuid NOT NULL,
                    parent_id uuid,
                    code character varying(50) NOT NULL,
                    name character varying(200) NOT NULL,
                    path character varying(200),
                    icon character varying(100),
                    sort_order integer NOT NULL DEFAULT 0,
                    permission_code character varying(100),
                    is_active boolean NOT NULL DEFAULT TRUE,
                    created_at timestamp with time zone NOT NULL DEFAULT now(),
                    updated_at timestamp with time zone,
                    is_deleted boolean NOT NULL DEFAULT FALSE,
                    deleted_at timestamp with time zone,
                    deleted_by_user_id uuid,
                    CONSTRAINT pk_app_menus PRIMARY KEY (id)
                );

                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS description character varying(1000);
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS icon character varying(100);
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT TRUE;
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS created_at timestamp with time zone NOT NULL DEFAULT now();
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone;
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS is_deleted boolean NOT NULL DEFAULT FALSE;
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS deleted_at timestamp with time zone;
                ALTER TABLE app_modules ADD COLUMN IF NOT EXISTS deleted_by_user_id uuid;

                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS parent_id uuid;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS path character varying(200);
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS icon character varying(100);
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS permission_code character varying(100);
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT TRUE;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS created_at timestamp with time zone NOT NULL DEFAULT now();
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS is_deleted boolean NOT NULL DEFAULT FALSE;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS deleted_at timestamp with time zone;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS deleted_by_user_id uuid;

                CREATE UNIQUE INDEX IF NOT EXISTS ix_app_modules_code ON app_modules (code);
                CREATE UNIQUE INDEX IF NOT EXISTS ix_app_menus_code ON app_menus (code);
                CREATE INDEX IF NOT EXISTS ix_app_menus_module_id ON app_menus (module_id);
                CREATE INDEX IF NOT EXISTS ix_app_menus_parent_id ON app_menus (parent_id);

                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_app_menus_app_modules_module_id')
                    THEN
                        ALTER TABLE app_menus
                            ADD CONSTRAINT fk_app_menus_app_modules_module_id
                            FOREIGN KEY (module_id) REFERENCES app_modules (id) ON DELETE CASCADE;
                    END IF;

                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_app_menus_app_menus_parent_id')
                    THEN
                        ALTER TABLE app_menus
                            ADD CONSTRAINT fk_app_menus_app_menus_parent_id
                            FOREIGN KEY (parent_id) REFERENCES app_menus (id) ON DELETE RESTRICT;
                    END IF;
                END $$;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Tables may have existed before this migration; do not drop them.
        }
    }
}
