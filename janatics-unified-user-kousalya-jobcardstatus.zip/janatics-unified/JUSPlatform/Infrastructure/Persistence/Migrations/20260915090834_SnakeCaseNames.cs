﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class SnakeCaseNames : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ct_alerts_customers_CustomerId",
                table: "ct_alerts");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_alerts_organizations_OrganizationId",
                table: "ct_alerts");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_dealers_organizations_OrganizationId",
                table: "ct_dealers");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_kpi_definitions_organizations_OrganizationId",
                table: "ct_kpi_definitions");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_performance_ct_dealers_DealerId",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_performance_ct_sales_routes_SalesRouteId",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_performance_customers_CustomerId",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_performance_organizations_OrganizationId",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_performance_products_ProductId",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_report_definitions_organizations_OrganizationId",
                table: "ct_report_definitions");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_sales_routes_organizations_OrganizationId",
                table: "ct_sales_routes");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_settings_organizations_OrganizationId",
                table: "ct_settings");

            migrationBuilder.DropForeignKey(
                name: "FK_ct_workflows_organizations_OrganizationId",
                table: "ct_workflows");

            migrationBuilder.DropForeignKey(
                name: "FK_customers_organizations_OrganizationId",
                table: "customers");

            migrationBuilder.DropForeignKey(
                name: "FK_invoice_lines_invoices_InvoiceId",
                table: "invoice_lines");

            migrationBuilder.DropForeignKey(
                name: "FK_invoice_lines_products_ProductId",
                table: "invoice_lines");

            migrationBuilder.DropForeignKey(
                name: "FK_invoices_customers_CustomerId",
                table: "invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_invoices_organizations_OrganizationId",
                table: "invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_invoices_sales_orders_SalesOrderId",
                table: "invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_job_log_entries_job_runs_JobRunId",
                table: "job_log_entries");

            migrationBuilder.DropForeignKey(
                name: "FK_osp_job_operations_osp_jobs_OspJobId",
                table: "osp_job_operations");

            migrationBuilder.DropForeignKey(
                name: "FK_osp_jobs_organizations_OrganizationId",
                table: "osp_jobs");

            migrationBuilder.DropForeignKey(
                name: "FK_password_reset_tokens_users_UserId",
                table: "password_reset_tokens");

            migrationBuilder.DropForeignKey(
                name: "FK_products_organizations_OrganizationId",
                table: "products");

            migrationBuilder.DropForeignKey(
                name: "FK_purchase_order_lines_products_ProductId",
                table: "purchase_order_lines");

            migrationBuilder.DropForeignKey(
                name: "FK_purchase_order_lines_purchase_orders_PurchaseOrderId",
                table: "purchase_order_lines");

            migrationBuilder.DropForeignKey(
                name: "FK_purchase_orders_organizations_OrganizationId",
                table: "purchase_orders");

            migrationBuilder.DropForeignKey(
                name: "FK_role_permissions_permissions_PermissionId",
                table: "role_permissions");

            migrationBuilder.DropForeignKey(
                name: "FK_role_permissions_roles_RoleId",
                table: "role_permissions");

            migrationBuilder.DropForeignKey(
                name: "FK_roles_organizations_OrganizationId",
                table: "roles");

            migrationBuilder.DropForeignKey(
                name: "FK_sales_order_lines_products_ProductId",
                table: "sales_order_lines");

            migrationBuilder.DropForeignKey(
                name: "FK_sales_order_lines_sales_orders_SalesOrderId",
                table: "sales_order_lines");

            migrationBuilder.DropForeignKey(
                name: "FK_sales_orders_customers_CustomerId",
                table: "sales_orders");

            migrationBuilder.DropForeignKey(
                name: "FK_sales_orders_organizations_OrganizationId",
                table: "sales_orders");

            migrationBuilder.DropForeignKey(
                name: "FK_stock_movements_organizations_OrganizationId",
                table: "stock_movements");

            migrationBuilder.DropForeignKey(
                name: "FK_stock_movements_products_ProductId",
                table: "stock_movements");

            migrationBuilder.DropForeignKey(
                name: "FK_user_roles_roles_RoleId",
                table: "user_roles");

            migrationBuilder.DropForeignKey(
                name: "FK_user_roles_users_UserId",
                table: "user_roles");

            migrationBuilder.DropForeignKey(
                name: "FK_users_organizations_OrganizationId",
                table: "users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_users",
                table: "users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_user_roles",
                table: "user_roles");

            migrationBuilder.DropPrimaryKey(
                name: "PK_stock_movements",
                table: "stock_movements");

            migrationBuilder.DropPrimaryKey(
                name: "PK_sales_orders",
                table: "sales_orders");

            migrationBuilder.DropPrimaryKey(
                name: "PK_sales_order_lines",
                table: "sales_order_lines");

            migrationBuilder.DropPrimaryKey(
                name: "PK_roles",
                table: "roles");

            migrationBuilder.DropPrimaryKey(
                name: "PK_role_permissions",
                table: "role_permissions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_purchase_orders",
                table: "purchase_orders");

            migrationBuilder.DropPrimaryKey(
                name: "PK_purchase_order_lines",
                table: "purchase_order_lines");

            migrationBuilder.DropPrimaryKey(
                name: "PK_products",
                table: "products");

            migrationBuilder.DropPrimaryKey(
                name: "PK_permissions",
                table: "permissions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_password_reset_tokens",
                table: "password_reset_tokens");

            migrationBuilder.DropPrimaryKey(
                name: "PK_osp_jobs",
                table: "osp_jobs");

            migrationBuilder.DropPrimaryKey(
                name: "PK_osp_job_operations",
                table: "osp_job_operations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_organizations",
                table: "organizations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_job_runs",
                table: "job_runs");

            migrationBuilder.DropPrimaryKey(
                name: "PK_job_log_entries",
                table: "job_log_entries");

            migrationBuilder.DropPrimaryKey(
                name: "PK_invoices",
                table: "invoices");

            migrationBuilder.DropPrimaryKey(
                name: "PK_invoice_lines",
                table: "invoice_lines");

            migrationBuilder.DropPrimaryKey(
                name: "PK_customers",
                table: "customers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_workflows",
                table: "ct_workflows");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_settings",
                table: "ct_settings");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_sales_routes",
                table: "ct_sales_routes");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_report_definitions",
                table: "ct_report_definitions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_performance",
                table: "ct_performance");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_kpi_definitions",
                table: "ct_kpi_definitions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_dealers",
                table: "ct_dealers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ct_alerts",
                table: "ct_alerts");

            migrationBuilder.DropPrimaryKey(
                name: "PK_audit_entries",
                table: "audit_entries");

            migrationBuilder.RenameColumn(
                name: "Email",
                table: "users",
                newName: "email");

            migrationBuilder.RenameColumn(
                name: "Designation",
                table: "users",
                newName: "designation");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "users",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "users",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "PasswordHash",
                table: "users",
                newName: "password_hash");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "users",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "users",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "users",
                newName: "is_active");

            migrationBuilder.RenameColumn(
                name: "DisplayName",
                table: "users",
                newName: "display_name");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "users",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "users",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "users",
                newName: "created_at");

            migrationBuilder.RenameColumn(
                name: "AvatarPath",
                table: "users",
                newName: "avatar_path");

            migrationBuilder.RenameIndex(
                name: "IX_users_Email",
                table: "users",
                newName: "ix_users_email");

            migrationBuilder.RenameIndex(
                name: "IX_users_OrganizationId",
                table: "users",
                newName: "ix_users_organization_id");

            migrationBuilder.RenameColumn(
                name: "RoleId",
                table: "user_roles",
                newName: "role_id");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "user_roles",
                newName: "user_id");

            migrationBuilder.RenameIndex(
                name: "IX_user_roles_UserId",
                table: "user_roles",
                newName: "ix_user_roles_user_id");

            migrationBuilder.RenameIndex(
                name: "IX_user_roles_RoleId",
                table: "user_roles",
                newName: "ix_user_roles_role_id");

            migrationBuilder.RenameColumn(
                name: "Reference",
                table: "stock_movements",
                newName: "reference");

            migrationBuilder.RenameColumn(
                name: "Quantity",
                table: "stock_movements",
                newName: "quantity");

            migrationBuilder.RenameColumn(
                name: "Notes",
                table: "stock_movements",
                newName: "notes");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "stock_movements",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "stock_movements",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "stock_movements",
                newName: "product_id");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "stock_movements",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "MovementType",
                table: "stock_movements",
                newName: "movement_type");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "stock_movements",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "stock_movements",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "stock_movements",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "stock_movements",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_stock_movements_ProductId",
                table: "stock_movements",
                newName: "ix_stock_movements_product_id");

            migrationBuilder.RenameIndex(
                name: "IX_stock_movements_OrganizationId",
                table: "stock_movements",
                newName: "ix_stock_movements_organization_id");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "sales_orders",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Notes",
                table: "sales_orders",
                newName: "notes");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "sales_orders",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "sales_orders",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "TotalAmount",
                table: "sales_orders",
                newName: "total_amount");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "sales_orders",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "OrderNumber",
                table: "sales_orders",
                newName: "order_number");

            migrationBuilder.RenameColumn(
                name: "OrderDate",
                table: "sales_orders",
                newName: "order_date");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "sales_orders",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "sales_orders",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "sales_orders",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CustomerName",
                table: "sales_orders",
                newName: "customer_name");

            migrationBuilder.RenameColumn(
                name: "CustomerId",
                table: "sales_orders",
                newName: "customer_id");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "sales_orders",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_sales_orders_OrganizationId_OrderNumber",
                table: "sales_orders",
                newName: "ix_sales_orders_organization_id_order_number");

            migrationBuilder.RenameIndex(
                name: "IX_sales_orders_CustomerId",
                table: "sales_orders",
                newName: "ix_sales_orders_customer_id");

            migrationBuilder.RenameColumn(
                name: "Quantity",
                table: "sales_order_lines",
                newName: "quantity");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "sales_order_lines",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "sales_order_lines",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "UnitPrice",
                table: "sales_order_lines",
                newName: "unit_price");

            migrationBuilder.RenameColumn(
                name: "SalesOrderId",
                table: "sales_order_lines",
                newName: "sales_order_id");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "sales_order_lines",
                newName: "product_id");

            migrationBuilder.RenameColumn(
                name: "LineTotal",
                table: "sales_order_lines",
                newName: "line_total");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "sales_order_lines",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "sales_order_lines",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "sales_order_lines",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "sales_order_lines",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_sales_order_lines_SalesOrderId",
                table: "sales_order_lines",
                newName: "ix_sales_order_lines_sales_order_id");

            migrationBuilder.RenameIndex(
                name: "IX_sales_order_lines_ProductId",
                table: "sales_order_lines",
                newName: "ix_sales_order_lines_product_id");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "roles",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "roles",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "roles",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "roles",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "roles",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsSystem",
                table: "roles",
                newName: "is_system");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "roles",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "roles",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "roles",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "roles",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_roles_OrganizationId_Name",
                table: "roles",
                newName: "ix_roles_organization_id_name");

            migrationBuilder.RenameColumn(
                name: "PermissionId",
                table: "role_permissions",
                newName: "permission_id");

            migrationBuilder.RenameColumn(
                name: "RoleId",
                table: "role_permissions",
                newName: "role_id");

            migrationBuilder.RenameIndex(
                name: "IX_role_permissions_PermissionId",
                table: "role_permissions",
                newName: "ix_role_permissions_permission_id");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "purchase_orders",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Notes",
                table: "purchase_orders",
                newName: "notes");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "purchase_orders",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "purchase_orders",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "TotalAmount",
                table: "purchase_orders",
                newName: "total_amount");

            migrationBuilder.RenameColumn(
                name: "SupplierName",
                table: "purchase_orders",
                newName: "supplier_name");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "purchase_orders",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "OrderNumber",
                table: "purchase_orders",
                newName: "order_number");

            migrationBuilder.RenameColumn(
                name: "OrderDate",
                table: "purchase_orders",
                newName: "order_date");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "purchase_orders",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "purchase_orders",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "purchase_orders",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "purchase_orders",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_purchase_orders_OrganizationId_OrderNumber",
                table: "purchase_orders",
                newName: "ix_purchase_orders_organization_id_order_number");

            migrationBuilder.RenameColumn(
                name: "Quantity",
                table: "purchase_order_lines",
                newName: "quantity");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "purchase_order_lines",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "purchase_order_lines",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "UnitCost",
                table: "purchase_order_lines",
                newName: "unit_cost");

            migrationBuilder.RenameColumn(
                name: "PurchaseOrderId",
                table: "purchase_order_lines",
                newName: "purchase_order_id");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "purchase_order_lines",
                newName: "product_id");

            migrationBuilder.RenameColumn(
                name: "LineTotal",
                table: "purchase_order_lines",
                newName: "line_total");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "purchase_order_lines",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "purchase_order_lines",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "purchase_order_lines",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "purchase_order_lines",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_purchase_order_lines_PurchaseOrderId",
                table: "purchase_order_lines",
                newName: "ix_purchase_order_lines_purchase_order_id");

            migrationBuilder.RenameIndex(
                name: "IX_purchase_order_lines_ProductId",
                table: "purchase_order_lines",
                newName: "ix_purchase_order_lines_product_id");

            migrationBuilder.RenameColumn(
                name: "Unit",
                table: "products",
                newName: "unit");

            migrationBuilder.RenameColumn(
                name: "Sku",
                table: "products",
                newName: "sku");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "products",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "products",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "products",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "products",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "UnitPrice",
                table: "products",
                newName: "unit_price");

            migrationBuilder.RenameColumn(
                name: "QuantityOnHand",
                table: "products",
                newName: "quantity_on_hand");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "products",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "products",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "products",
                newName: "is_active");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "products",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "products",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "products",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_products_OrganizationId_Sku",
                table: "products",
                newName: "ix_products_organization_id_sku");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "permissions",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Module",
                table: "permissions",
                newName: "module");

            migrationBuilder.RenameColumn(
                name: "Code",
                table: "permissions",
                newName: "code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "permissions",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "permissions",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "permissions",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "permissions",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "permissions",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "permissions",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_permissions_Code",
                table: "permissions",
                newName: "ix_permissions_code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "password_reset_tokens",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "password_reset_tokens",
                newName: "user_id");

            migrationBuilder.RenameColumn(
                name: "UsedAt",
                table: "password_reset_tokens",
                newName: "used_at");

            migrationBuilder.RenameColumn(
                name: "TokenHash",
                table: "password_reset_tokens",
                newName: "token_hash");

            migrationBuilder.RenameColumn(
                name: "ExpiresAt",
                table: "password_reset_tokens",
                newName: "expires_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "password_reset_tokens",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_password_reset_tokens_UserId",
                table: "password_reset_tokens",
                newName: "ix_password_reset_tokens_user_id");

            migrationBuilder.RenameIndex(
                name: "IX_password_reset_tokens_TokenHash",
                table: "password_reset_tokens",
                newName: "ix_password_reset_tokens_token_hash");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "osp_jobs",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "osp_jobs",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "osp_jobs",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "StoreEntityId",
                table: "osp_jobs",
                newName: "store_entity_id");

            migrationBuilder.RenameColumn(
                name: "QtyToStore",
                table: "osp_jobs",
                newName: "qty_to_store");

            migrationBuilder.RenameColumn(
                name: "PlantName",
                table: "osp_jobs",
                newName: "plant_name");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "osp_jobs",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "OracleOrganizationId",
                table: "osp_jobs",
                newName: "oracle_organization_id");

            migrationBuilder.RenameColumn(
                name: "JobQuantity",
                table: "osp_jobs",
                newName: "job_quantity");

            migrationBuilder.RenameColumn(
                name: "JobNo",
                table: "osp_jobs",
                newName: "job_no");

            migrationBuilder.RenameColumn(
                name: "JobDate",
                table: "osp_jobs",
                newName: "job_date");

            migrationBuilder.RenameColumn(
                name: "ItemNo",
                table: "osp_jobs",
                newName: "item_no");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "osp_jobs",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "InventoryItemId",
                table: "osp_jobs",
                newName: "inventory_item_id");

            migrationBuilder.RenameColumn(
                name: "DispositionId",
                table: "osp_jobs",
                newName: "disposition_id");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "osp_jobs",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "osp_jobs",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "osp_jobs",
                newName: "created_at");

            migrationBuilder.RenameColumn(
                name: "AlternateRoutingDesignator",
                table: "osp_jobs",
                newName: "alternate_routing_designator");

            migrationBuilder.RenameIndex(
                name: "IX_osp_jobs_OrganizationId_JobNo",
                table: "osp_jobs",
                newName: "ix_osp_jobs_organization_id_job_no");

            migrationBuilder.RenameIndex(
                name: "IX_osp_jobs_OrganizationId_JobDate",
                table: "osp_jobs",
                newName: "ix_osp_jobs_organization_id_job_date");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "osp_job_operations",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "VendorName",
                table: "osp_job_operations",
                newName: "vendor_name");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "osp_job_operations",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "QtyScrap",
                table: "osp_job_operations",
                newName: "qty_scrap");

            migrationBuilder.RenameColumn(
                name: "QtyQueue",
                table: "osp_job_operations",
                newName: "qty_queue");

            migrationBuilder.RenameColumn(
                name: "QtyMove",
                table: "osp_job_operations",
                newName: "qty_move");

            migrationBuilder.RenameColumn(
                name: "QtyComp",
                table: "osp_job_operations",
                newName: "qty_comp");

            migrationBuilder.RenameColumn(
                name: "ProcessStartDate",
                table: "osp_job_operations",
                newName: "process_start_date");

            migrationBuilder.RenameColumn(
                name: "ProcessCompletionDate",
                table: "osp_job_operations",
                newName: "process_completion_date");

            migrationBuilder.RenameColumn(
                name: "OspJobId",
                table: "osp_job_operations",
                newName: "osp_job_id");

            migrationBuilder.RenameColumn(
                name: "OperationSeq",
                table: "osp_job_operations",
                newName: "operation_seq");

            migrationBuilder.RenameColumn(
                name: "OperationIndex",
                table: "osp_job_operations",
                newName: "operation_index");

            migrationBuilder.RenameColumn(
                name: "OperationDesc",
                table: "osp_job_operations",
                newName: "operation_desc");

            migrationBuilder.RenameColumn(
                name: "LeadTime",
                table: "osp_job_operations",
                newName: "lead_time");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "osp_job_operations",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "osp_job_operations",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "osp_job_operations",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "osp_job_operations",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_osp_job_operations_OspJobId_OperationIndex",
                table: "osp_job_operations",
                newName: "ix_osp_job_operations_osp_job_id_operation_index");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "organizations",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Code",
                table: "organizations",
                newName: "code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "organizations",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "organizations",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "organizations",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "organizations",
                newName: "is_active");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "organizations",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "organizations",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "organizations",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_organizations_Code",
                table: "organizations",
                newName: "ix_organizations_code");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "job_runs",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "job_runs",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "TraceId",
                table: "job_runs",
                newName: "trace_id");

            migrationBuilder.RenameColumn(
                name: "StartedAt",
                table: "job_runs",
                newName: "started_at");

            migrationBuilder.RenameColumn(
                name: "ResultJson",
                table: "job_runs",
                newName: "result_json");

            migrationBuilder.RenameColumn(
                name: "QueuedAt",
                table: "job_runs",
                newName: "queued_at");

            migrationBuilder.RenameColumn(
                name: "PayloadJson",
                table: "job_runs",
                newName: "payload_json");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "job_runs",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "NextRunAt",
                table: "job_runs",
                newName: "next_run_at");

            migrationBuilder.RenameColumn(
                name: "MaxAttempts",
                table: "job_runs",
                newName: "max_attempts");

            migrationBuilder.RenameColumn(
                name: "JobType",
                table: "job_runs",
                newName: "job_type");

            migrationBuilder.RenameColumn(
                name: "ErrorMessage",
                table: "job_runs",
                newName: "error_message");

            migrationBuilder.RenameColumn(
                name: "CreatedByUserId",
                table: "job_runs",
                newName: "created_by_user_id");

            migrationBuilder.RenameColumn(
                name: "CompletedAt",
                table: "job_runs",
                newName: "completed_at");

            migrationBuilder.RenameColumn(
                name: "AttemptCount",
                table: "job_runs",
                newName: "attempt_count");

            migrationBuilder.RenameIndex(
                name: "IX_job_runs_Status_NextRunAt",
                table: "job_runs",
                newName: "ix_job_runs_status_next_run_at");

            migrationBuilder.RenameIndex(
                name: "IX_job_runs_OrganizationId_QueuedAt",
                table: "job_runs",
                newName: "ix_job_runs_organization_id_queued_at");

            migrationBuilder.RenameColumn(
                name: "Message",
                table: "job_log_entries",
                newName: "message");

            migrationBuilder.RenameColumn(
                name: "Level",
                table: "job_log_entries",
                newName: "level");

            migrationBuilder.RenameColumn(
                name: "Detail",
                table: "job_log_entries",
                newName: "detail");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "job_log_entries",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "JobRunId",
                table: "job_log_entries",
                newName: "job_run_id");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "job_log_entries",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_job_log_entries_JobRunId_CreatedAt",
                table: "job_log_entries",
                newName: "ix_job_log_entries_job_run_id_created_at");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "invoices",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Notes",
                table: "invoices",
                newName: "notes");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "invoices",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "invoices",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "TotalAmount",
                table: "invoices",
                newName: "total_amount");

            migrationBuilder.RenameColumn(
                name: "SalesOrderId",
                table: "invoices",
                newName: "sales_order_id");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "invoices",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "invoices",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "InvoiceNumber",
                table: "invoices",
                newName: "invoice_number");

            migrationBuilder.RenameColumn(
                name: "InvoiceDate",
                table: "invoices",
                newName: "invoice_date");

            migrationBuilder.RenameColumn(
                name: "DueDate",
                table: "invoices",
                newName: "due_date");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "invoices",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "invoices",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CustomerName",
                table: "invoices",
                newName: "customer_name");

            migrationBuilder.RenameColumn(
                name: "CustomerId",
                table: "invoices",
                newName: "customer_id");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "invoices",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_invoices_SalesOrderId",
                table: "invoices",
                newName: "ix_invoices_sales_order_id");

            migrationBuilder.RenameIndex(
                name: "IX_invoices_OrganizationId_InvoiceNumber",
                table: "invoices",
                newName: "ix_invoices_organization_id_invoice_number");

            migrationBuilder.RenameIndex(
                name: "IX_invoices_CustomerId",
                table: "invoices",
                newName: "ix_invoices_customer_id");

            migrationBuilder.RenameColumn(
                name: "Quantity",
                table: "invoice_lines",
                newName: "quantity");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "invoice_lines",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "invoice_lines",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "invoice_lines",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "UnitPrice",
                table: "invoice_lines",
                newName: "unit_price");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "invoice_lines",
                newName: "product_id");

            migrationBuilder.RenameColumn(
                name: "LineTotal",
                table: "invoice_lines",
                newName: "line_total");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "invoice_lines",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "InvoiceId",
                table: "invoice_lines",
                newName: "invoice_id");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "invoice_lines",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "invoice_lines",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "invoice_lines",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_invoice_lines_ProductId",
                table: "invoice_lines",
                newName: "ix_invoice_lines_product_id");

            migrationBuilder.RenameIndex(
                name: "IX_invoice_lines_InvoiceId",
                table: "invoice_lines",
                newName: "ix_invoice_lines_invoice_id");

            migrationBuilder.RenameColumn(
                name: "Phone",
                table: "customers",
                newName: "phone");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "customers",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Gstin",
                table: "customers",
                newName: "gstin");

            migrationBuilder.RenameColumn(
                name: "Email",
                table: "customers",
                newName: "email");

            migrationBuilder.RenameColumn(
                name: "Address",
                table: "customers",
                newName: "address");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "customers",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "customers",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "customers",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "customers",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "customers",
                newName: "is_active");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "customers",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "customers",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "customers",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_customers_OrganizationId_Name",
                table: "customers",
                newName: "ix_customers_organization_id_name");

            migrationBuilder.RenameIndex(
                name: "IX_customers_OrganizationId_Gstin",
                table: "customers",
                newName: "ix_customers_organization_id_gstin");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "ct_workflows",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ct_workflows",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "ct_workflows",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_workflows",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_workflows",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "ProgressPercent",
                table: "ct_workflows",
                newName: "progress_percent");

            migrationBuilder.RenameColumn(
                name: "OwnerName",
                table: "ct_workflows",
                newName: "owner_name");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_workflows",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_workflows",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DueAt",
                table: "ct_workflows",
                newName: "due_at");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_workflows",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_workflows",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_workflows",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_workflows_OrganizationId_Status",
                table: "ct_workflows",
                newName: "ix_ct_workflows_organization_id_status");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_settings",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_settings",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_settings",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_settings",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "GapThresholdAlerts",
                table: "ct_settings",
                newName: "gap_threshold_alerts");

            migrationBuilder.RenameColumn(
                name: "EmailDigest",
                table: "ct_settings",
                newName: "email_digest");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_settings",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_settings",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "DefaultPeriod",
                table: "ct_settings",
                newName: "default_period");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_settings",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_settings_OrganizationId",
                table: "ct_settings",
                newName: "ix_ct_settings_organization_id");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ct_sales_routes",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Code",
                table: "ct_sales_routes",
                newName: "code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_sales_routes",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_sales_routes",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_sales_routes",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_sales_routes",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "ct_sales_routes",
                newName: "is_active");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_sales_routes",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_sales_routes",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_sales_routes",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_sales_routes_OrganizationId_Code",
                table: "ct_sales_routes",
                newName: "ix_ct_sales_routes_organization_id_code");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ct_report_definitions",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "ct_report_definitions",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Code",
                table: "ct_report_definitions",
                newName: "code");

            migrationBuilder.RenameColumn(
                name: "Category",
                table: "ct_report_definitions",
                newName: "category");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_report_definitions",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_report_definitions",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_report_definitions",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_report_definitions",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_report_definitions",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_report_definitions",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_report_definitions",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_report_definitions_OrganizationId_Code",
                table: "ct_report_definitions",
                newName: "ix_ct_report_definitions_organization_id_code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_performance",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "YearMonth",
                table: "ct_performance",
                newName: "year_month");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_performance",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "SalesRouteId",
                table: "ct_performance",
                newName: "sales_route_id");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "ct_performance",
                newName: "product_id");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_performance",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "OrdersParkedUnits",
                table: "ct_performance",
                newName: "orders_parked_units");

            migrationBuilder.RenameColumn(
                name: "OcqPlanUnits",
                table: "ct_performance",
                newName: "ocq_plan_units");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_performance",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_performance",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_performance",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "DealerId",
                table: "ct_performance",
                newName: "dealer_id");

            migrationBuilder.RenameColumn(
                name: "CustomerId",
                table: "ct_performance",
                newName: "customer_id");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_performance",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_performance_SalesRouteId",
                table: "ct_performance",
                newName: "ix_ct_performance_sales_route_id");

            migrationBuilder.RenameIndex(
                name: "IX_ct_performance_ProductId",
                table: "ct_performance",
                newName: "ix_ct_performance_product_id");

            migrationBuilder.RenameIndex(
                name: "IX_ct_performance_OrganizationId_YearMonth_DealerId_CustomerId~",
                table: "ct_performance",
                newName: "ix_ct_performance_organization_id_year_month_dealer_id_custome~");

            migrationBuilder.RenameIndex(
                name: "IX_ct_performance_DealerId",
                table: "ct_performance",
                newName: "ix_ct_performance_dealer_id");

            migrationBuilder.RenameIndex(
                name: "IX_ct_performance_CustomerId",
                table: "ct_performance",
                newName: "ix_ct_performance_customer_id");

            migrationBuilder.RenameColumn(
                name: "Unit",
                table: "ct_kpi_definitions",
                newName: "unit");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ct_kpi_definitions",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "ct_kpi_definitions",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Code",
                table: "ct_kpi_definitions",
                newName: "code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_kpi_definitions",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_kpi_definitions",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "TargetValue",
                table: "ct_kpi_definitions",
                newName: "target_value");

            migrationBuilder.RenameColumn(
                name: "SortOrder",
                table: "ct_kpi_definitions",
                newName: "sort_order");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_kpi_definitions",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_kpi_definitions",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_kpi_definitions",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_kpi_definitions",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_kpi_definitions",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_kpi_definitions_OrganizationId_Code",
                table: "ct_kpi_definitions",
                newName: "ix_ct_kpi_definitions_organization_id_code");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ct_dealers",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "Code",
                table: "ct_dealers",
                newName: "code");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_dealers",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_dealers",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_dealers",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_dealers",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "ct_dealers",
                newName: "is_active");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_dealers",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_dealers",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_dealers",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_dealers_OrganizationId_Code",
                table: "ct_dealers",
                newName: "ix_ct_dealers_organization_id_code");

            migrationBuilder.RenameColumn(
                name: "Title",
                table: "ct_alerts",
                newName: "title");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "ct_alerts",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Severity",
                table: "ct_alerts",
                newName: "severity");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "ct_alerts",
                newName: "description");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "ct_alerts",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "YearMonth",
                table: "ct_alerts",
                newName: "year_month");

            migrationBuilder.RenameColumn(
                name: "UpdatedAt",
                table: "ct_alerts",
                newName: "updated_at");

            migrationBuilder.RenameColumn(
                name: "ProductTags",
                table: "ct_alerts",
                newName: "product_tags");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "ct_alerts",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                table: "ct_alerts",
                newName: "is_deleted");

            migrationBuilder.RenameColumn(
                name: "GapUnits",
                table: "ct_alerts",
                newName: "gap_units");

            migrationBuilder.RenameColumn(
                name: "DeletedByUserId",
                table: "ct_alerts",
                newName: "deleted_by_user_id");

            migrationBuilder.RenameColumn(
                name: "DeletedAt",
                table: "ct_alerts",
                newName: "deleted_at");

            migrationBuilder.RenameColumn(
                name: "CustomerId",
                table: "ct_alerts",
                newName: "customer_id");

            migrationBuilder.RenameColumn(
                name: "CreatedAt",
                table: "ct_alerts",
                newName: "created_at");

            migrationBuilder.RenameIndex(
                name: "IX_ct_alerts_OrganizationId_Status_Severity",
                table: "ct_alerts",
                newName: "ix_ct_alerts_organization_id_status_severity");

            migrationBuilder.RenameIndex(
                name: "IX_ct_alerts_CustomerId",
                table: "ct_alerts",
                newName: "ix_ct_alerts_customer_id");

            migrationBuilder.RenameColumn(
                name: "Summary",
                table: "audit_entries",
                newName: "summary");

            migrationBuilder.RenameColumn(
                name: "Action",
                table: "audit_entries",
                newName: "action");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "audit_entries",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "OrganizationId",
                table: "audit_entries",
                newName: "organization_id");

            migrationBuilder.RenameColumn(
                name: "OccurredAt",
                table: "audit_entries",
                newName: "occurred_at");

            migrationBuilder.RenameColumn(
                name: "EntityName",
                table: "audit_entries",
                newName: "entity_name");

            migrationBuilder.RenameColumn(
                name: "EntityId",
                table: "audit_entries",
                newName: "entity_id");

            migrationBuilder.RenameColumn(
                name: "ActorUserId",
                table: "audit_entries",
                newName: "actor_user_id");

            migrationBuilder.RenameIndex(
                name: "IX_audit_entries_OrganizationId",
                table: "audit_entries",
                newName: "ix_audit_entries_organization_id");

            migrationBuilder.RenameIndex(
                name: "IX_audit_entries_OccurredAt",
                table: "audit_entries",
                newName: "ix_audit_entries_occurred_at");

            migrationBuilder.RenameIndex(
                name: "IX_audit_entries_EntityName_EntityId",
                table: "audit_entries",
                newName: "ix_audit_entries_entity_name_entity_id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_users",
                table: "users",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_user_roles",
                table: "user_roles",
                columns: new[] { "user_id", "role_id" });

            migrationBuilder.AddPrimaryKey(
                name: "pk_stock_movements",
                table: "stock_movements",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_sales_orders",
                table: "sales_orders",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_sales_order_lines",
                table: "sales_order_lines",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_roles",
                table: "roles",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_role_permissions",
                table: "role_permissions",
                columns: new[] { "role_id", "permission_id" });

            migrationBuilder.AddPrimaryKey(
                name: "pk_purchase_orders",
                table: "purchase_orders",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_purchase_order_lines",
                table: "purchase_order_lines",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_products",
                table: "products",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_permissions",
                table: "permissions",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_password_reset_tokens",
                table: "password_reset_tokens",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_osp_jobs",
                table: "osp_jobs",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_osp_job_operations",
                table: "osp_job_operations",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_organizations",
                table: "organizations",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_job_runs",
                table: "job_runs",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_job_log_entries",
                table: "job_log_entries",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_invoices",
                table: "invoices",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_invoice_lines",
                table: "invoice_lines",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_customers",
                table: "customers",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_workflows",
                table: "ct_workflows",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_settings",
                table: "ct_settings",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_sales_routes",
                table: "ct_sales_routes",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_report_definitions",
                table: "ct_report_definitions",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_performance",
                table: "ct_performance",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_kpi_definitions",
                table: "ct_kpi_definitions",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_dealers",
                table: "ct_dealers",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_ct_alerts",
                table: "ct_alerts",
                column: "id");

            migrationBuilder.AddPrimaryKey(
                name: "pk_audit_entries",
                table: "audit_entries",
                column: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_ct_alerts_customers_customer_id",
                table: "ct_alerts",
                column: "customer_id",
                principalTable: "customers",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_ct_alerts_organizations_organization_id",
                table: "ct_alerts",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_dealers_organizations_organization_id",
                table: "ct_dealers",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_kpi_definitions_organizations_organization_id",
                table: "ct_kpi_definitions",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_performance_ct_dealers_dealer_id",
                table: "ct_performance",
                column: "dealer_id",
                principalTable: "ct_dealers",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_performance_ct_sales_routes_sales_route_id",
                table: "ct_performance",
                column: "sales_route_id",
                principalTable: "ct_sales_routes",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_performance_customers_customer_id",
                table: "ct_performance",
                column: "customer_id",
                principalTable: "customers",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_performance_organizations_organization_id",
                table: "ct_performance",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_performance_products_product_id",
                table: "ct_performance",
                column: "product_id",
                principalTable: "products",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_report_definitions_organizations_organization_id",
                table: "ct_report_definitions",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_sales_routes_organizations_organization_id",
                table: "ct_sales_routes",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_settings_organizations_organization_id",
                table: "ct_settings",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_ct_workflows_organizations_organization_id",
                table: "ct_workflows",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_customers_organizations_organization_id",
                table: "customers",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_invoice_lines_invoices_invoice_id",
                table: "invoice_lines",
                column: "invoice_id",
                principalTable: "invoices",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_invoice_lines_products_product_id",
                table: "invoice_lines",
                column: "product_id",
                principalTable: "products",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_invoices_customers_customer_id",
                table: "invoices",
                column: "customer_id",
                principalTable: "customers",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_invoices_organizations_organization_id",
                table: "invoices",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_invoices_sales_orders_sales_order_id",
                table: "invoices",
                column: "sales_order_id",
                principalTable: "sales_orders",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_job_log_entries_job_runs_job_run_id",
                table: "job_log_entries",
                column: "job_run_id",
                principalTable: "job_runs",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_osp_job_operations_osp_jobs_osp_job_id",
                table: "osp_job_operations",
                column: "osp_job_id",
                principalTable: "osp_jobs",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_osp_jobs_organizations_organization_id",
                table: "osp_jobs",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_password_reset_tokens_users_user_id",
                table: "password_reset_tokens",
                column: "user_id",
                principalTable: "users",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_products_organizations_organization_id",
                table: "products",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_purchase_order_lines_products_product_id",
                table: "purchase_order_lines",
                column: "product_id",
                principalTable: "products",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_purchase_order_lines_purchase_orders_purchase_order_id",
                table: "purchase_order_lines",
                column: "purchase_order_id",
                principalTable: "purchase_orders",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_purchase_orders_organizations_organization_id",
                table: "purchase_orders",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_role_permissions_permissions_permission_id",
                table: "role_permissions",
                column: "permission_id",
                principalTable: "permissions",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_role_permissions_roles_role_id",
                table: "role_permissions",
                column: "role_id",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_roles_organizations_organization_id",
                table: "roles",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_sales_order_lines_products_product_id",
                table: "sales_order_lines",
                column: "product_id",
                principalTable: "products",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_sales_order_lines_sales_orders_sales_order_id",
                table: "sales_order_lines",
                column: "sales_order_id",
                principalTable: "sales_orders",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_sales_orders_customers_customer_id",
                table: "sales_orders",
                column: "customer_id",
                principalTable: "customers",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_sales_orders_organizations_organization_id",
                table: "sales_orders",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_stock_movements_organizations_organization_id",
                table: "stock_movements",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_stock_movements_products_product_id",
                table: "stock_movements",
                column: "product_id",
                principalTable: "products",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_user_roles_roles_role_id",
                table: "user_roles",
                column: "role_id",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_user_roles_users_user_id",
                table: "user_roles",
                column: "user_id",
                principalTable: "users",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_users_organizations_organization_id",
                table: "users",
                column: "organization_id",
                principalTable: "organizations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_ct_alerts_customers_customer_id",
                table: "ct_alerts");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_alerts_organizations_organization_id",
                table: "ct_alerts");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_dealers_organizations_organization_id",
                table: "ct_dealers");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_kpi_definitions_organizations_organization_id",
                table: "ct_kpi_definitions");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_performance_ct_dealers_dealer_id",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_performance_ct_sales_routes_sales_route_id",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_performance_customers_customer_id",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_performance_organizations_organization_id",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_performance_products_product_id",
                table: "ct_performance");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_report_definitions_organizations_organization_id",
                table: "ct_report_definitions");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_sales_routes_organizations_organization_id",
                table: "ct_sales_routes");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_settings_organizations_organization_id",
                table: "ct_settings");

            migrationBuilder.DropForeignKey(
                name: "fk_ct_workflows_organizations_organization_id",
                table: "ct_workflows");

            migrationBuilder.DropForeignKey(
                name: "fk_customers_organizations_organization_id",
                table: "customers");

            migrationBuilder.DropForeignKey(
                name: "fk_invoice_lines_invoices_invoice_id",
                table: "invoice_lines");

            migrationBuilder.DropForeignKey(
                name: "fk_invoice_lines_products_product_id",
                table: "invoice_lines");

            migrationBuilder.DropForeignKey(
                name: "fk_invoices_customers_customer_id",
                table: "invoices");

            migrationBuilder.DropForeignKey(
                name: "fk_invoices_organizations_organization_id",
                table: "invoices");

            migrationBuilder.DropForeignKey(
                name: "fk_invoices_sales_orders_sales_order_id",
                table: "invoices");

            migrationBuilder.DropForeignKey(
                name: "fk_job_log_entries_job_runs_job_run_id",
                table: "job_log_entries");

            migrationBuilder.DropForeignKey(
                name: "fk_osp_job_operations_osp_jobs_osp_job_id",
                table: "osp_job_operations");

            migrationBuilder.DropForeignKey(
                name: "fk_osp_jobs_organizations_organization_id",
                table: "osp_jobs");

            migrationBuilder.DropForeignKey(
                name: "fk_password_reset_tokens_users_user_id",
                table: "password_reset_tokens");

            migrationBuilder.DropForeignKey(
                name: "fk_products_organizations_organization_id",
                table: "products");

            migrationBuilder.DropForeignKey(
                name: "fk_purchase_order_lines_products_product_id",
                table: "purchase_order_lines");

            migrationBuilder.DropForeignKey(
                name: "fk_purchase_order_lines_purchase_orders_purchase_order_id",
                table: "purchase_order_lines");

            migrationBuilder.DropForeignKey(
                name: "fk_purchase_orders_organizations_organization_id",
                table: "purchase_orders");

            migrationBuilder.DropForeignKey(
                name: "fk_role_permissions_permissions_permission_id",
                table: "role_permissions");

            migrationBuilder.DropForeignKey(
                name: "fk_role_permissions_roles_role_id",
                table: "role_permissions");

            migrationBuilder.DropForeignKey(
                name: "fk_roles_organizations_organization_id",
                table: "roles");

            migrationBuilder.DropForeignKey(
                name: "fk_sales_order_lines_products_product_id",
                table: "sales_order_lines");

            migrationBuilder.DropForeignKey(
                name: "fk_sales_order_lines_sales_orders_sales_order_id",
                table: "sales_order_lines");

            migrationBuilder.DropForeignKey(
                name: "fk_sales_orders_customers_customer_id",
                table: "sales_orders");

            migrationBuilder.DropForeignKey(
                name: "fk_sales_orders_organizations_organization_id",
                table: "sales_orders");

            migrationBuilder.DropForeignKey(
                name: "fk_stock_movements_organizations_organization_id",
                table: "stock_movements");

            migrationBuilder.DropForeignKey(
                name: "fk_stock_movements_products_product_id",
                table: "stock_movements");

            migrationBuilder.DropForeignKey(
                name: "fk_user_roles_roles_role_id",
                table: "user_roles");

            migrationBuilder.DropForeignKey(
                name: "fk_user_roles_users_user_id",
                table: "user_roles");

            migrationBuilder.DropForeignKey(
                name: "fk_users_organizations_organization_id",
                table: "users");

            migrationBuilder.DropPrimaryKey(
                name: "pk_users",
                table: "users");

            migrationBuilder.DropPrimaryKey(
                name: "pk_user_roles",
                table: "user_roles");

            migrationBuilder.DropPrimaryKey(
                name: "pk_stock_movements",
                table: "stock_movements");

            migrationBuilder.DropPrimaryKey(
                name: "pk_sales_orders",
                table: "sales_orders");

            migrationBuilder.DropPrimaryKey(
                name: "pk_sales_order_lines",
                table: "sales_order_lines");

            migrationBuilder.DropPrimaryKey(
                name: "pk_roles",
                table: "roles");

            migrationBuilder.DropPrimaryKey(
                name: "pk_role_permissions",
                table: "role_permissions");

            migrationBuilder.DropPrimaryKey(
                name: "pk_purchase_orders",
                table: "purchase_orders");

            migrationBuilder.DropPrimaryKey(
                name: "pk_purchase_order_lines",
                table: "purchase_order_lines");

            migrationBuilder.DropPrimaryKey(
                name: "pk_products",
                table: "products");

            migrationBuilder.DropPrimaryKey(
                name: "pk_permissions",
                table: "permissions");

            migrationBuilder.DropPrimaryKey(
                name: "pk_password_reset_tokens",
                table: "password_reset_tokens");

            migrationBuilder.DropPrimaryKey(
                name: "pk_osp_jobs",
                table: "osp_jobs");

            migrationBuilder.DropPrimaryKey(
                name: "pk_osp_job_operations",
                table: "osp_job_operations");

            migrationBuilder.DropPrimaryKey(
                name: "pk_organizations",
                table: "organizations");

            migrationBuilder.DropPrimaryKey(
                name: "pk_job_runs",
                table: "job_runs");

            migrationBuilder.DropPrimaryKey(
                name: "pk_job_log_entries",
                table: "job_log_entries");

            migrationBuilder.DropPrimaryKey(
                name: "pk_invoices",
                table: "invoices");

            migrationBuilder.DropPrimaryKey(
                name: "pk_invoice_lines",
                table: "invoice_lines");

            migrationBuilder.DropPrimaryKey(
                name: "pk_customers",
                table: "customers");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_workflows",
                table: "ct_workflows");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_settings",
                table: "ct_settings");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_sales_routes",
                table: "ct_sales_routes");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_report_definitions",
                table: "ct_report_definitions");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_performance",
                table: "ct_performance");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_kpi_definitions",
                table: "ct_kpi_definitions");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_dealers",
                table: "ct_dealers");

            migrationBuilder.DropPrimaryKey(
                name: "pk_ct_alerts",
                table: "ct_alerts");

            migrationBuilder.DropPrimaryKey(
                name: "pk_audit_entries",
                table: "audit_entries");

            migrationBuilder.RenameColumn(
                name: "email",
                table: "users",
                newName: "Email");

            migrationBuilder.RenameColumn(
                name: "designation",
                table: "users",
                newName: "Designation");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "users",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "users",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "password_hash",
                table: "users",
                newName: "PasswordHash");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "users",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "users",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "is_active",
                table: "users",
                newName: "IsActive");

            migrationBuilder.RenameColumn(
                name: "display_name",
                table: "users",
                newName: "DisplayName");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "users",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "users",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "users",
                newName: "CreatedAt");

            migrationBuilder.RenameColumn(
                name: "avatar_path",
                table: "users",
                newName: "AvatarPath");

            migrationBuilder.RenameIndex(
                name: "ix_users_email",
                table: "users",
                newName: "IX_users_Email");

            migrationBuilder.RenameIndex(
                name: "ix_users_organization_id",
                table: "users",
                newName: "IX_users_OrganizationId");

            migrationBuilder.RenameColumn(
                name: "role_id",
                table: "user_roles",
                newName: "RoleId");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "user_roles",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "ix_user_roles_user_id",
                table: "user_roles",
                newName: "IX_user_roles_UserId");

            migrationBuilder.RenameIndex(
                name: "ix_user_roles_role_id",
                table: "user_roles",
                newName: "IX_user_roles_RoleId");

            migrationBuilder.RenameColumn(
                name: "reference",
                table: "stock_movements",
                newName: "Reference");

            migrationBuilder.RenameColumn(
                name: "quantity",
                table: "stock_movements",
                newName: "Quantity");

            migrationBuilder.RenameColumn(
                name: "notes",
                table: "stock_movements",
                newName: "Notes");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "stock_movements",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "stock_movements",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "product_id",
                table: "stock_movements",
                newName: "ProductId");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "stock_movements",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "movement_type",
                table: "stock_movements",
                newName: "MovementType");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "stock_movements",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "stock_movements",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "stock_movements",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "stock_movements",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_stock_movements_product_id",
                table: "stock_movements",
                newName: "IX_stock_movements_ProductId");

            migrationBuilder.RenameIndex(
                name: "ix_stock_movements_organization_id",
                table: "stock_movements",
                newName: "IX_stock_movements_OrganizationId");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "sales_orders",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "notes",
                table: "sales_orders",
                newName: "Notes");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "sales_orders",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "sales_orders",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "total_amount",
                table: "sales_orders",
                newName: "TotalAmount");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "sales_orders",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "order_number",
                table: "sales_orders",
                newName: "OrderNumber");

            migrationBuilder.RenameColumn(
                name: "order_date",
                table: "sales_orders",
                newName: "OrderDate");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "sales_orders",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "sales_orders",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "sales_orders",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "customer_name",
                table: "sales_orders",
                newName: "CustomerName");

            migrationBuilder.RenameColumn(
                name: "customer_id",
                table: "sales_orders",
                newName: "CustomerId");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "sales_orders",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_sales_orders_organization_id_order_number",
                table: "sales_orders",
                newName: "IX_sales_orders_OrganizationId_OrderNumber");

            migrationBuilder.RenameIndex(
                name: "ix_sales_orders_customer_id",
                table: "sales_orders",
                newName: "IX_sales_orders_CustomerId");

            migrationBuilder.RenameColumn(
                name: "quantity",
                table: "sales_order_lines",
                newName: "Quantity");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "sales_order_lines",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "sales_order_lines",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "unit_price",
                table: "sales_order_lines",
                newName: "UnitPrice");

            migrationBuilder.RenameColumn(
                name: "sales_order_id",
                table: "sales_order_lines",
                newName: "SalesOrderId");

            migrationBuilder.RenameColumn(
                name: "product_id",
                table: "sales_order_lines",
                newName: "ProductId");

            migrationBuilder.RenameColumn(
                name: "line_total",
                table: "sales_order_lines",
                newName: "LineTotal");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "sales_order_lines",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "sales_order_lines",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "sales_order_lines",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "sales_order_lines",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_sales_order_lines_sales_order_id",
                table: "sales_order_lines",
                newName: "IX_sales_order_lines_SalesOrderId");

            migrationBuilder.RenameIndex(
                name: "ix_sales_order_lines_product_id",
                table: "sales_order_lines",
                newName: "IX_sales_order_lines_ProductId");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "roles",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "roles",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "roles",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "roles",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "roles",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_system",
                table: "roles",
                newName: "IsSystem");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "roles",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "roles",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "roles",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "roles",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_roles_organization_id_name",
                table: "roles",
                newName: "IX_roles_OrganizationId_Name");

            migrationBuilder.RenameColumn(
                name: "permission_id",
                table: "role_permissions",
                newName: "PermissionId");

            migrationBuilder.RenameColumn(
                name: "role_id",
                table: "role_permissions",
                newName: "RoleId");

            migrationBuilder.RenameIndex(
                name: "ix_role_permissions_permission_id",
                table: "role_permissions",
                newName: "IX_role_permissions_PermissionId");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "purchase_orders",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "notes",
                table: "purchase_orders",
                newName: "Notes");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "purchase_orders",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "purchase_orders",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "total_amount",
                table: "purchase_orders",
                newName: "TotalAmount");

            migrationBuilder.RenameColumn(
                name: "supplier_name",
                table: "purchase_orders",
                newName: "SupplierName");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "purchase_orders",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "order_number",
                table: "purchase_orders",
                newName: "OrderNumber");

            migrationBuilder.RenameColumn(
                name: "order_date",
                table: "purchase_orders",
                newName: "OrderDate");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "purchase_orders",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "purchase_orders",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "purchase_orders",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "purchase_orders",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_purchase_orders_organization_id_order_number",
                table: "purchase_orders",
                newName: "IX_purchase_orders_OrganizationId_OrderNumber");

            migrationBuilder.RenameColumn(
                name: "quantity",
                table: "purchase_order_lines",
                newName: "Quantity");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "purchase_order_lines",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "purchase_order_lines",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "unit_cost",
                table: "purchase_order_lines",
                newName: "UnitCost");

            migrationBuilder.RenameColumn(
                name: "purchase_order_id",
                table: "purchase_order_lines",
                newName: "PurchaseOrderId");

            migrationBuilder.RenameColumn(
                name: "product_id",
                table: "purchase_order_lines",
                newName: "ProductId");

            migrationBuilder.RenameColumn(
                name: "line_total",
                table: "purchase_order_lines",
                newName: "LineTotal");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "purchase_order_lines",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "purchase_order_lines",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "purchase_order_lines",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "purchase_order_lines",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_purchase_order_lines_purchase_order_id",
                table: "purchase_order_lines",
                newName: "IX_purchase_order_lines_PurchaseOrderId");

            migrationBuilder.RenameIndex(
                name: "ix_purchase_order_lines_product_id",
                table: "purchase_order_lines",
                newName: "IX_purchase_order_lines_ProductId");

            migrationBuilder.RenameColumn(
                name: "unit",
                table: "products",
                newName: "Unit");

            migrationBuilder.RenameColumn(
                name: "sku",
                table: "products",
                newName: "Sku");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "products",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "products",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "products",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "products",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "unit_price",
                table: "products",
                newName: "UnitPrice");

            migrationBuilder.RenameColumn(
                name: "quantity_on_hand",
                table: "products",
                newName: "QuantityOnHand");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "products",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "products",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "is_active",
                table: "products",
                newName: "IsActive");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "products",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "products",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "products",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_products_organization_id_sku",
                table: "products",
                newName: "IX_products_OrganizationId_Sku");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "permissions",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "module",
                table: "permissions",
                newName: "Module");

            migrationBuilder.RenameColumn(
                name: "code",
                table: "permissions",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "permissions",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "permissions",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "permissions",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "permissions",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "permissions",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "permissions",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_permissions_code",
                table: "permissions",
                newName: "IX_permissions_Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "password_reset_tokens",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "password_reset_tokens",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "used_at",
                table: "password_reset_tokens",
                newName: "UsedAt");

            migrationBuilder.RenameColumn(
                name: "token_hash",
                table: "password_reset_tokens",
                newName: "TokenHash");

            migrationBuilder.RenameColumn(
                name: "expires_at",
                table: "password_reset_tokens",
                newName: "ExpiresAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "password_reset_tokens",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_password_reset_tokens_user_id",
                table: "password_reset_tokens",
                newName: "IX_password_reset_tokens_UserId");

            migrationBuilder.RenameIndex(
                name: "ix_password_reset_tokens_token_hash",
                table: "password_reset_tokens",
                newName: "IX_password_reset_tokens_TokenHash");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "osp_jobs",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "osp_jobs",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "osp_jobs",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "store_entity_id",
                table: "osp_jobs",
                newName: "StoreEntityId");

            migrationBuilder.RenameColumn(
                name: "qty_to_store",
                table: "osp_jobs",
                newName: "QtyToStore");

            migrationBuilder.RenameColumn(
                name: "plant_name",
                table: "osp_jobs",
                newName: "PlantName");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "osp_jobs",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "oracle_organization_id",
                table: "osp_jobs",
                newName: "OracleOrganizationId");

            migrationBuilder.RenameColumn(
                name: "job_quantity",
                table: "osp_jobs",
                newName: "JobQuantity");

            migrationBuilder.RenameColumn(
                name: "job_no",
                table: "osp_jobs",
                newName: "JobNo");

            migrationBuilder.RenameColumn(
                name: "job_date",
                table: "osp_jobs",
                newName: "JobDate");

            migrationBuilder.RenameColumn(
                name: "item_no",
                table: "osp_jobs",
                newName: "ItemNo");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "osp_jobs",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "inventory_item_id",
                table: "osp_jobs",
                newName: "InventoryItemId");

            migrationBuilder.RenameColumn(
                name: "disposition_id",
                table: "osp_jobs",
                newName: "DispositionId");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "osp_jobs",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "osp_jobs",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "osp_jobs",
                newName: "CreatedAt");

            migrationBuilder.RenameColumn(
                name: "alternate_routing_designator",
                table: "osp_jobs",
                newName: "AlternateRoutingDesignator");

            migrationBuilder.RenameIndex(
                name: "ix_osp_jobs_organization_id_job_no",
                table: "osp_jobs",
                newName: "IX_osp_jobs_OrganizationId_JobNo");

            migrationBuilder.RenameIndex(
                name: "ix_osp_jobs_organization_id_job_date",
                table: "osp_jobs",
                newName: "IX_osp_jobs_OrganizationId_JobDate");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "osp_job_operations",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "vendor_name",
                table: "osp_job_operations",
                newName: "VendorName");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "osp_job_operations",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "qty_scrap",
                table: "osp_job_operations",
                newName: "QtyScrap");

            migrationBuilder.RenameColumn(
                name: "qty_queue",
                table: "osp_job_operations",
                newName: "QtyQueue");

            migrationBuilder.RenameColumn(
                name: "qty_move",
                table: "osp_job_operations",
                newName: "QtyMove");

            migrationBuilder.RenameColumn(
                name: "qty_comp",
                table: "osp_job_operations",
                newName: "QtyComp");

            migrationBuilder.RenameColumn(
                name: "process_start_date",
                table: "osp_job_operations",
                newName: "ProcessStartDate");

            migrationBuilder.RenameColumn(
                name: "process_completion_date",
                table: "osp_job_operations",
                newName: "ProcessCompletionDate");

            migrationBuilder.RenameColumn(
                name: "osp_job_id",
                table: "osp_job_operations",
                newName: "OspJobId");

            migrationBuilder.RenameColumn(
                name: "operation_seq",
                table: "osp_job_operations",
                newName: "OperationSeq");

            migrationBuilder.RenameColumn(
                name: "operation_index",
                table: "osp_job_operations",
                newName: "OperationIndex");

            migrationBuilder.RenameColumn(
                name: "operation_desc",
                table: "osp_job_operations",
                newName: "OperationDesc");

            migrationBuilder.RenameColumn(
                name: "lead_time",
                table: "osp_job_operations",
                newName: "LeadTime");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "osp_job_operations",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "osp_job_operations",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "osp_job_operations",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "osp_job_operations",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_osp_job_operations_osp_job_id_operation_index",
                table: "osp_job_operations",
                newName: "IX_osp_job_operations_OspJobId_OperationIndex");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "organizations",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "code",
                table: "organizations",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "organizations",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "organizations",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "organizations",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "is_active",
                table: "organizations",
                newName: "IsActive");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "organizations",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "organizations",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "organizations",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_organizations_code",
                table: "organizations",
                newName: "IX_organizations_Code");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "job_runs",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "job_runs",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "trace_id",
                table: "job_runs",
                newName: "TraceId");

            migrationBuilder.RenameColumn(
                name: "started_at",
                table: "job_runs",
                newName: "StartedAt");

            migrationBuilder.RenameColumn(
                name: "result_json",
                table: "job_runs",
                newName: "ResultJson");

            migrationBuilder.RenameColumn(
                name: "queued_at",
                table: "job_runs",
                newName: "QueuedAt");

            migrationBuilder.RenameColumn(
                name: "payload_json",
                table: "job_runs",
                newName: "PayloadJson");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "job_runs",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "next_run_at",
                table: "job_runs",
                newName: "NextRunAt");

            migrationBuilder.RenameColumn(
                name: "max_attempts",
                table: "job_runs",
                newName: "MaxAttempts");

            migrationBuilder.RenameColumn(
                name: "job_type",
                table: "job_runs",
                newName: "JobType");

            migrationBuilder.RenameColumn(
                name: "error_message",
                table: "job_runs",
                newName: "ErrorMessage");

            migrationBuilder.RenameColumn(
                name: "created_by_user_id",
                table: "job_runs",
                newName: "CreatedByUserId");

            migrationBuilder.RenameColumn(
                name: "completed_at",
                table: "job_runs",
                newName: "CompletedAt");

            migrationBuilder.RenameColumn(
                name: "attempt_count",
                table: "job_runs",
                newName: "AttemptCount");

            migrationBuilder.RenameIndex(
                name: "ix_job_runs_status_next_run_at",
                table: "job_runs",
                newName: "IX_job_runs_Status_NextRunAt");

            migrationBuilder.RenameIndex(
                name: "ix_job_runs_organization_id_queued_at",
                table: "job_runs",
                newName: "IX_job_runs_OrganizationId_QueuedAt");

            migrationBuilder.RenameColumn(
                name: "message",
                table: "job_log_entries",
                newName: "Message");

            migrationBuilder.RenameColumn(
                name: "level",
                table: "job_log_entries",
                newName: "Level");

            migrationBuilder.RenameColumn(
                name: "detail",
                table: "job_log_entries",
                newName: "Detail");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "job_log_entries",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "job_run_id",
                table: "job_log_entries",
                newName: "JobRunId");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "job_log_entries",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_job_log_entries_job_run_id_created_at",
                table: "job_log_entries",
                newName: "IX_job_log_entries_JobRunId_CreatedAt");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "invoices",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "notes",
                table: "invoices",
                newName: "Notes");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "invoices",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "invoices",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "total_amount",
                table: "invoices",
                newName: "TotalAmount");

            migrationBuilder.RenameColumn(
                name: "sales_order_id",
                table: "invoices",
                newName: "SalesOrderId");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "invoices",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "invoices",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "invoice_number",
                table: "invoices",
                newName: "InvoiceNumber");

            migrationBuilder.RenameColumn(
                name: "invoice_date",
                table: "invoices",
                newName: "InvoiceDate");

            migrationBuilder.RenameColumn(
                name: "due_date",
                table: "invoices",
                newName: "DueDate");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "invoices",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "invoices",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "customer_name",
                table: "invoices",
                newName: "CustomerName");

            migrationBuilder.RenameColumn(
                name: "customer_id",
                table: "invoices",
                newName: "CustomerId");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "invoices",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_invoices_sales_order_id",
                table: "invoices",
                newName: "IX_invoices_SalesOrderId");

            migrationBuilder.RenameIndex(
                name: "ix_invoices_organization_id_invoice_number",
                table: "invoices",
                newName: "IX_invoices_OrganizationId_InvoiceNumber");

            migrationBuilder.RenameIndex(
                name: "ix_invoices_customer_id",
                table: "invoices",
                newName: "IX_invoices_CustomerId");

            migrationBuilder.RenameColumn(
                name: "quantity",
                table: "invoice_lines",
                newName: "Quantity");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "invoice_lines",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "invoice_lines",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "invoice_lines",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "unit_price",
                table: "invoice_lines",
                newName: "UnitPrice");

            migrationBuilder.RenameColumn(
                name: "product_id",
                table: "invoice_lines",
                newName: "ProductId");

            migrationBuilder.RenameColumn(
                name: "line_total",
                table: "invoice_lines",
                newName: "LineTotal");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "invoice_lines",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "invoice_id",
                table: "invoice_lines",
                newName: "InvoiceId");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "invoice_lines",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "invoice_lines",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "invoice_lines",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_invoice_lines_product_id",
                table: "invoice_lines",
                newName: "IX_invoice_lines_ProductId");

            migrationBuilder.RenameIndex(
                name: "ix_invoice_lines_invoice_id",
                table: "invoice_lines",
                newName: "IX_invoice_lines_InvoiceId");

            migrationBuilder.RenameColumn(
                name: "phone",
                table: "customers",
                newName: "Phone");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "customers",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "gstin",
                table: "customers",
                newName: "Gstin");

            migrationBuilder.RenameColumn(
                name: "email",
                table: "customers",
                newName: "Email");

            migrationBuilder.RenameColumn(
                name: "address",
                table: "customers",
                newName: "Address");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "customers",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "customers",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "customers",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "customers",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "is_active",
                table: "customers",
                newName: "IsActive");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "customers",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "customers",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "customers",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_customers_organization_id_name",
                table: "customers",
                newName: "IX_customers_OrganizationId_Name");

            migrationBuilder.RenameIndex(
                name: "ix_customers_organization_id_gstin",
                table: "customers",
                newName: "IX_customers_OrganizationId_Gstin");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "ct_workflows",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "ct_workflows",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "ct_workflows",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_workflows",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_workflows",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "progress_percent",
                table: "ct_workflows",
                newName: "ProgressPercent");

            migrationBuilder.RenameColumn(
                name: "owner_name",
                table: "ct_workflows",
                newName: "OwnerName");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_workflows",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_workflows",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "due_at",
                table: "ct_workflows",
                newName: "DueAt");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_workflows",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_workflows",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_workflows",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_workflows_organization_id_status",
                table: "ct_workflows",
                newName: "IX_ct_workflows_OrganizationId_Status");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_settings",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_settings",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_settings",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_settings",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "gap_threshold_alerts",
                table: "ct_settings",
                newName: "GapThresholdAlerts");

            migrationBuilder.RenameColumn(
                name: "email_digest",
                table: "ct_settings",
                newName: "EmailDigest");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_settings",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_settings",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "default_period",
                table: "ct_settings",
                newName: "DefaultPeriod");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_settings",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_settings_organization_id",
                table: "ct_settings",
                newName: "IX_ct_settings_OrganizationId");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "ct_sales_routes",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "code",
                table: "ct_sales_routes",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_sales_routes",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_sales_routes",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_sales_routes",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_sales_routes",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "is_active",
                table: "ct_sales_routes",
                newName: "IsActive");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_sales_routes",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_sales_routes",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_sales_routes",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_sales_routes_organization_id_code",
                table: "ct_sales_routes",
                newName: "IX_ct_sales_routes_OrganizationId_Code");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "ct_report_definitions",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "ct_report_definitions",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "code",
                table: "ct_report_definitions",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "category",
                table: "ct_report_definitions",
                newName: "Category");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_report_definitions",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_report_definitions",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_report_definitions",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_report_definitions",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_report_definitions",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_report_definitions",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_report_definitions",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_report_definitions_organization_id_code",
                table: "ct_report_definitions",
                newName: "IX_ct_report_definitions_OrganizationId_Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_performance",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "year_month",
                table: "ct_performance",
                newName: "YearMonth");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_performance",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "sales_route_id",
                table: "ct_performance",
                newName: "SalesRouteId");

            migrationBuilder.RenameColumn(
                name: "product_id",
                table: "ct_performance",
                newName: "ProductId");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_performance",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "orders_parked_units",
                table: "ct_performance",
                newName: "OrdersParkedUnits");

            migrationBuilder.RenameColumn(
                name: "ocq_plan_units",
                table: "ct_performance",
                newName: "OcqPlanUnits");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_performance",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_performance",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_performance",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "dealer_id",
                table: "ct_performance",
                newName: "DealerId");

            migrationBuilder.RenameColumn(
                name: "customer_id",
                table: "ct_performance",
                newName: "CustomerId");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_performance",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_performance_sales_route_id",
                table: "ct_performance",
                newName: "IX_ct_performance_SalesRouteId");

            migrationBuilder.RenameIndex(
                name: "ix_ct_performance_product_id",
                table: "ct_performance",
                newName: "IX_ct_performance_ProductId");

            migrationBuilder.RenameIndex(
                name: "ix_ct_performance_organization_id_year_month_dealer_id_custome~",
                table: "ct_performance",
                newName: "IX_ct_performance_OrganizationId_YearMonth_DealerId_CustomerId~");

            migrationBuilder.RenameIndex(
                name: "ix_ct_performance_dealer_id",
                table: "ct_performance",
                newName: "IX_ct_performance_DealerId");

            migrationBuilder.RenameIndex(
                name: "ix_ct_performance_customer_id",
                table: "ct_performance",
                newName: "IX_ct_performance_CustomerId");

            migrationBuilder.RenameColumn(
                name: "unit",
                table: "ct_kpi_definitions",
                newName: "Unit");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "ct_kpi_definitions",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "ct_kpi_definitions",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "code",
                table: "ct_kpi_definitions",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_kpi_definitions",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_kpi_definitions",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "target_value",
                table: "ct_kpi_definitions",
                newName: "TargetValue");

            migrationBuilder.RenameColumn(
                name: "sort_order",
                table: "ct_kpi_definitions",
                newName: "SortOrder");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_kpi_definitions",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_kpi_definitions",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_kpi_definitions",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_kpi_definitions",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_kpi_definitions",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_kpi_definitions_organization_id_code",
                table: "ct_kpi_definitions",
                newName: "IX_ct_kpi_definitions_OrganizationId_Code");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "ct_dealers",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "code",
                table: "ct_dealers",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_dealers",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_dealers",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_dealers",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_dealers",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "is_active",
                table: "ct_dealers",
                newName: "IsActive");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_dealers",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_dealers",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_dealers",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_dealers_organization_id_code",
                table: "ct_dealers",
                newName: "IX_ct_dealers_OrganizationId_Code");

            migrationBuilder.RenameColumn(
                name: "title",
                table: "ct_alerts",
                newName: "Title");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "ct_alerts",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "severity",
                table: "ct_alerts",
                newName: "Severity");

            migrationBuilder.RenameColumn(
                name: "description",
                table: "ct_alerts",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "ct_alerts",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "year_month",
                table: "ct_alerts",
                newName: "YearMonth");

            migrationBuilder.RenameColumn(
                name: "updated_at",
                table: "ct_alerts",
                newName: "UpdatedAt");

            migrationBuilder.RenameColumn(
                name: "product_tags",
                table: "ct_alerts",
                newName: "ProductTags");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "ct_alerts",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "is_deleted",
                table: "ct_alerts",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "gap_units",
                table: "ct_alerts",
                newName: "GapUnits");

            migrationBuilder.RenameColumn(
                name: "deleted_by_user_id",
                table: "ct_alerts",
                newName: "DeletedByUserId");

            migrationBuilder.RenameColumn(
                name: "deleted_at",
                table: "ct_alerts",
                newName: "DeletedAt");

            migrationBuilder.RenameColumn(
                name: "customer_id",
                table: "ct_alerts",
                newName: "CustomerId");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "ct_alerts",
                newName: "CreatedAt");

            migrationBuilder.RenameIndex(
                name: "ix_ct_alerts_organization_id_status_severity",
                table: "ct_alerts",
                newName: "IX_ct_alerts_OrganizationId_Status_Severity");

            migrationBuilder.RenameIndex(
                name: "ix_ct_alerts_customer_id",
                table: "ct_alerts",
                newName: "IX_ct_alerts_CustomerId");

            migrationBuilder.RenameColumn(
                name: "summary",
                table: "audit_entries",
                newName: "Summary");

            migrationBuilder.RenameColumn(
                name: "action",
                table: "audit_entries",
                newName: "Action");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "audit_entries",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "organization_id",
                table: "audit_entries",
                newName: "OrganizationId");

            migrationBuilder.RenameColumn(
                name: "occurred_at",
                table: "audit_entries",
                newName: "OccurredAt");

            migrationBuilder.RenameColumn(
                name: "entity_name",
                table: "audit_entries",
                newName: "EntityName");

            migrationBuilder.RenameColumn(
                name: "entity_id",
                table: "audit_entries",
                newName: "EntityId");

            migrationBuilder.RenameColumn(
                name: "actor_user_id",
                table: "audit_entries",
                newName: "ActorUserId");

            migrationBuilder.RenameIndex(
                name: "ix_audit_entries_organization_id",
                table: "audit_entries",
                newName: "IX_audit_entries_OrganizationId");

            migrationBuilder.RenameIndex(
                name: "ix_audit_entries_occurred_at",
                table: "audit_entries",
                newName: "IX_audit_entries_OccurredAt");

            migrationBuilder.RenameIndex(
                name: "ix_audit_entries_entity_name_entity_id",
                table: "audit_entries",
                newName: "IX_audit_entries_EntityName_EntityId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_users",
                table: "users",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_user_roles",
                table: "user_roles",
                columns: new[] { "UserId", "RoleId" });

            migrationBuilder.AddPrimaryKey(
                name: "PK_stock_movements",
                table: "stock_movements",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_sales_orders",
                table: "sales_orders",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_sales_order_lines",
                table: "sales_order_lines",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_roles",
                table: "roles",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_role_permissions",
                table: "role_permissions",
                columns: new[] { "RoleId", "PermissionId" });

            migrationBuilder.AddPrimaryKey(
                name: "PK_purchase_orders",
                table: "purchase_orders",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_purchase_order_lines",
                table: "purchase_order_lines",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_products",
                table: "products",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_permissions",
                table: "permissions",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_password_reset_tokens",
                table: "password_reset_tokens",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_osp_jobs",
                table: "osp_jobs",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_osp_job_operations",
                table: "osp_job_operations",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_organizations",
                table: "organizations",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_job_runs",
                table: "job_runs",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_job_log_entries",
                table: "job_log_entries",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_invoices",
                table: "invoices",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_invoice_lines",
                table: "invoice_lines",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_customers",
                table: "customers",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_workflows",
                table: "ct_workflows",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_settings",
                table: "ct_settings",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_sales_routes",
                table: "ct_sales_routes",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_report_definitions",
                table: "ct_report_definitions",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_performance",
                table: "ct_performance",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_kpi_definitions",
                table: "ct_kpi_definitions",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_dealers",
                table: "ct_dealers",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ct_alerts",
                table: "ct_alerts",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_audit_entries",
                table: "audit_entries",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ct_alerts_customers_CustomerId",
                table: "ct_alerts",
                column: "CustomerId",
                principalTable: "customers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ct_alerts_organizations_OrganizationId",
                table: "ct_alerts",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_dealers_organizations_OrganizationId",
                table: "ct_dealers",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_kpi_definitions_organizations_OrganizationId",
                table: "ct_kpi_definitions",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_performance_ct_dealers_DealerId",
                table: "ct_performance",
                column: "DealerId",
                principalTable: "ct_dealers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_performance_ct_sales_routes_SalesRouteId",
                table: "ct_performance",
                column: "SalesRouteId",
                principalTable: "ct_sales_routes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_performance_customers_CustomerId",
                table: "ct_performance",
                column: "CustomerId",
                principalTable: "customers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_performance_organizations_OrganizationId",
                table: "ct_performance",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_performance_products_ProductId",
                table: "ct_performance",
                column: "ProductId",
                principalTable: "products",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_report_definitions_organizations_OrganizationId",
                table: "ct_report_definitions",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_sales_routes_organizations_OrganizationId",
                table: "ct_sales_routes",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_settings_organizations_OrganizationId",
                table: "ct_settings",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ct_workflows_organizations_OrganizationId",
                table: "ct_workflows",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_customers_organizations_OrganizationId",
                table: "customers",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_invoice_lines_invoices_InvoiceId",
                table: "invoice_lines",
                column: "InvoiceId",
                principalTable: "invoices",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_invoice_lines_products_ProductId",
                table: "invoice_lines",
                column: "ProductId",
                principalTable: "products",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_invoices_customers_CustomerId",
                table: "invoices",
                column: "CustomerId",
                principalTable: "customers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_invoices_organizations_OrganizationId",
                table: "invoices",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_invoices_sales_orders_SalesOrderId",
                table: "invoices",
                column: "SalesOrderId",
                principalTable: "sales_orders",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_job_log_entries_job_runs_JobRunId",
                table: "job_log_entries",
                column: "JobRunId",
                principalTable: "job_runs",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_osp_job_operations_osp_jobs_OspJobId",
                table: "osp_job_operations",
                column: "OspJobId",
                principalTable: "osp_jobs",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_osp_jobs_organizations_OrganizationId",
                table: "osp_jobs",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_password_reset_tokens_users_UserId",
                table: "password_reset_tokens",
                column: "UserId",
                principalTable: "users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_products_organizations_OrganizationId",
                table: "products",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_purchase_order_lines_products_ProductId",
                table: "purchase_order_lines",
                column: "ProductId",
                principalTable: "products",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_purchase_order_lines_purchase_orders_PurchaseOrderId",
                table: "purchase_order_lines",
                column: "PurchaseOrderId",
                principalTable: "purchase_orders",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_purchase_orders_organizations_OrganizationId",
                table: "purchase_orders",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_role_permissions_permissions_PermissionId",
                table: "role_permissions",
                column: "PermissionId",
                principalTable: "permissions",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_role_permissions_roles_RoleId",
                table: "role_permissions",
                column: "RoleId",
                principalTable: "roles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_roles_organizations_OrganizationId",
                table: "roles",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_sales_order_lines_products_ProductId",
                table: "sales_order_lines",
                column: "ProductId",
                principalTable: "products",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_sales_order_lines_sales_orders_SalesOrderId",
                table: "sales_order_lines",
                column: "SalesOrderId",
                principalTable: "sales_orders",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_sales_orders_customers_CustomerId",
                table: "sales_orders",
                column: "CustomerId",
                principalTable: "customers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_sales_orders_organizations_OrganizationId",
                table: "sales_orders",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_stock_movements_organizations_OrganizationId",
                table: "stock_movements",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_stock_movements_products_ProductId",
                table: "stock_movements",
                column: "ProductId",
                principalTable: "products",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_user_roles_roles_RoleId",
                table: "user_roles",
                column: "RoleId",
                principalTable: "roles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_user_roles_users_UserId",
                table: "user_roles",
                column: "UserId",
                principalTable: "users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_users_organizations_OrganizationId",
                table: "users",
                column: "OrganizationId",
                principalTable: "organizations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
