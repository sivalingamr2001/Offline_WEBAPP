using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    [DbContext(typeof(AppDbContext))]
    [Migration("20260918060000_MapUsersRoleId")]
    public partial class MapUsersRoleId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                ALTER TABLE users ADD COLUMN IF NOT EXISTS role_id uuid;
                CREATE INDEX IF NOT EXISTS ix_users_role_id ON users (role_id);

                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_users_roles_role_id')
                    THEN
                        ALTER TABLE users
                            ADD CONSTRAINT fk_users_roles_role_id
                            FOREIGN KEY (role_id)
                            REFERENCES roles (id)
                            ON DELETE RESTRICT;
                    END IF;
                END $$;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Live databases already store users.role_id; do not drop it.
        }
    }
}
