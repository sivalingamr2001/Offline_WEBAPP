using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AlignAccessMappingToExistingSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Mapping-only: live role_menus / user_access_rights / organizations.operating_unit_id
            // already match this model. Do not drop or rename columns.
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
