using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class SyncAppMenuCatalogColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS display_name character varying(100);
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS menu_icon character varying(100);
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS menu_path character varying(100);
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS menu_type character varying(20) NOT NULL DEFAULT 'SCREEN';
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS nature character varying(20) NOT NULL DEFAULT 'TENANT';
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS parent_menu_id uuid;
                ALTER TABLE app_menus ADD COLUMN IF NOT EXISTS resource_code character varying(40);

                CREATE INDEX IF NOT EXISTS ix_app_menus_parent_menu_id ON app_menus (parent_menu_id);

                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_app_menus_app_menus_parent_menu_id')
                    THEN
                        ALTER TABLE app_menus
                            ADD CONSTRAINT fk_app_menus_app_menus_parent_menu_id
                            FOREIGN KEY (parent_menu_id)
                            REFERENCES app_menus (id)
                            ON DELETE RESTRICT;
                    END IF;
                END $$;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Existing databases already have these catalog columns; do not drop them.
        }
    }
}
