using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using JUSPlatform.Infrastructure.Persistence;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260918033000_AddOperatingUnitsAndOrgUserKeys")]
    public class AddOperatingUnitsAndOrgUserKeys : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                CREATE TABLE IF NOT EXISTS operating_units (
                    id uuid NOT NULL,
                    org_id integer NOT NULL,
                    name character varying(255) NOT NULL,
                    is_active boolean NOT NULL DEFAULT TRUE,
                    created_at timestamp with time zone NOT NULL DEFAULT now(),
                    updated_at timestamp with time zone,
                    is_deleted boolean NOT NULL DEFAULT FALSE,
                    deleted_at timestamp with time zone,
                    deleted_by_user_id uuid,
                    CONSTRAINT pk_operating_units PRIMARY KEY (id)
                );

                ALTER TABLE operating_units ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT TRUE;
                ALTER TABLE operating_units ADD COLUMN IF NOT EXISTS created_at timestamp with time zone NOT NULL DEFAULT now();
                ALTER TABLE operating_units ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone;
                ALTER TABLE operating_units ADD COLUMN IF NOT EXISTS is_deleted boolean NOT NULL DEFAULT FALSE;
                ALTER TABLE operating_units ADD COLUMN IF NOT EXISTS deleted_at timestamp with time zone;
                ALTER TABLE operating_units ADD COLUMN IF NOT EXISTS deleted_by_user_id uuid;

                DO $$
                BEGIN
                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'operating_units'
                          AND column_name = 'created_at' AND data_type = 'timestamp without time zone')
                    THEN
                        ALTER TABLE operating_units
                            ALTER COLUMN created_at TYPE timestamp with time zone
                            USING created_at AT TIME ZONE 'UTC';
                    END IF;

                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'operating_units'
                          AND column_name = 'updated_at' AND data_type = 'timestamp without time zone')
                    THEN
                        ALTER TABLE operating_units
                            ALTER COLUMN updated_at TYPE timestamp with time zone
                            USING updated_at AT TIME ZONE 'UTC';
                    END IF;
                END $$;

                CREATE UNIQUE INDEX IF NOT EXISTS ix_operating_units_org_id ON operating_units (org_id);

                ALTER TABLE organizations ADD COLUMN IF NOT EXISTS oracle_org_id numeric(18,0);
                ALTER TABLE organizations ADD COLUMN IF NOT EXISTS unit_name character varying(100);

                DO $$
                DECLARE
                    col_type text;
                BEGIN
                    SELECT data_type INTO col_type
                    FROM information_schema.columns
                    WHERE table_schema = 'public'
                      AND table_name = 'organizations'
                      AND column_name = 'operating_unit_id';

                    IF col_type IS NULL THEN
                        ALTER TABLE organizations ADD COLUMN operating_unit_id integer;
                    END IF;
                END $$;

                CREATE INDEX IF NOT EXISTS ix_organizations_operating_unit_id ON organizations (operating_unit_id);

                ALTER TABLE users ADD COLUMN IF NOT EXISTS user_code character varying(10);
                ALTER TABLE users ADD COLUMN IF NOT EXISTS emp_id character varying(10);
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                ALTER TABLE organizations DROP CONSTRAINT IF EXISTS fk_organizations_operating_units_operating_unit_id;
                DROP INDEX IF EXISTS ix_organizations_operating_unit_id;
                ALTER TABLE organizations DROP COLUMN IF EXISTS operating_unit_id;
                ALTER TABLE organizations DROP COLUMN IF EXISTS oracle_org_id;
                ALTER TABLE organizations DROP COLUMN IF EXISTS unit_name;
                ALTER TABLE users DROP COLUMN IF EXISTS user_code;
                ALTER TABLE users DROP COLUMN IF EXISTS emp_id;
                DROP INDEX IF EXISTS ix_operating_units_org_id;
                DROP TABLE IF EXISTS operating_units;
                """);
        }
    }
}
