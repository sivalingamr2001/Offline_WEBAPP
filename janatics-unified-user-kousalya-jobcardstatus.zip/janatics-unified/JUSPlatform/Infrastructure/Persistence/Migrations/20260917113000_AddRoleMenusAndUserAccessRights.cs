using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using JUSPlatform.Infrastructure.Persistence;

#nullable disable

namespace JUSPlatform.Infrastructure.Persistence.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260917113000_AddRoleMenusAndUserAccessRights")]
    public class AddRoleMenusAndUserAccessRights : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                CREATE TABLE IF NOT EXISTS role_menus (
                    id uuid NOT NULL,
                    role_id uuid NOT NULL,
                    module_id uuid NOT NULL,
                    menu_id uuid NOT NULL,
                    perm_view boolean NOT NULL DEFAULT FALSE,
                    perm_add boolean NOT NULL DEFAULT FALSE,
                    perm_edit boolean NOT NULL DEFAULT FALSE,
                    perm_delete boolean NOT NULL DEFAULT FALSE,
                    perm_export boolean NOT NULL DEFAULT FALSE,
                    perm_approve boolean NOT NULL DEFAULT FALSE,
                    created_at timestamp with time zone NOT NULL DEFAULT now(),
                    updated_at timestamp with time zone,
                    is_deleted boolean NOT NULL DEFAULT FALSE,
                    deleted_at timestamp with time zone,
                    deleted_by_user_id uuid,
                    CONSTRAINT pk_role_menus PRIMARY KEY (id)
                );

                CREATE TABLE IF NOT EXISTS user_access_rights (
                    id uuid NOT NULL,
                    user_id uuid NOT NULL,
                    organization_id uuid NOT NULL,
                    operating_unit integer,
                    limit_value numeric(15,2),
                    access_channel character varying(10) NOT NULL DEFAULT 'WEB',
                    is_active boolean NOT NULL DEFAULT TRUE,
                    remarks character varying(400),
                    created_at timestamp with time zone NOT NULL DEFAULT now(),
                    updated_at timestamp with time zone,
                    is_deleted boolean NOT NULL DEFAULT FALSE,
                    deleted_at timestamp with time zone,
                    deleted_by_user_id uuid,
                    CONSTRAINT pk_user_access_rights PRIMARY KEY (id)
                );

                DO $$
                BEGIN
                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'role_menus' AND column_name = 'menu_id')
                    THEN
                        CREATE INDEX IF NOT EXISTS ix_role_menus_menu_id ON role_menus (menu_id);
                    END IF;

                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'role_menus' AND column_name = 'module_id')
                    THEN
                        CREATE INDEX IF NOT EXISTS ix_role_menus_module_id ON role_menus (module_id);
                    END IF;

                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'user_access_rights' AND column_name = 'organization_id')
                    THEN
                        CREATE INDEX IF NOT EXISTS ix_user_access_rights_organization_id
                            ON user_access_rights (organization_id);
                        CREATE UNIQUE INDEX IF NOT EXISTS ix_user_access_rights_user_id_organization_id
                            ON user_access_rights (user_id, organization_id);
                    END IF;
                END $$;

                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_role_menus_roles_role_id')
                    THEN
                        ALTER TABLE role_menus
                            ADD CONSTRAINT fk_role_menus_roles_role_id
                            FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE;
                    END IF;

                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'role_menus' AND column_name = 'menu_id')
                       AND NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_role_menus_app_menus_menu_id')
                    THEN
                        ALTER TABLE role_menus
                            ADD CONSTRAINT fk_role_menus_app_menus_menu_id
                            FOREIGN KEY (menu_id) REFERENCES app_menus (id) ON DELETE CASCADE;
                    END IF;

                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_user_access_rights_users_user_id')
                    THEN
                        ALTER TABLE user_access_rights
                            ADD CONSTRAINT fk_user_access_rights_users_user_id
                            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE;
                    END IF;

                    IF EXISTS (
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = 'user_access_rights'
                          AND column_name = 'organization_id')
                       AND NOT EXISTS (
                        SELECT 1 FROM pg_constraint WHERE conname = 'fk_user_access_rights_organizations_organization_id')
                    THEN
                        ALTER TABLE user_access_rights
                            ADD CONSTRAINT fk_user_access_rights_organizations_organization_id
                            FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE CASCADE;
                    END IF;
                END $$;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
