using System.Globalization;
using Oracle.ManagedDataAccess.Types;

namespace JUSPlatform.Infrastructure.Persistence.Oracle;

internal static class OracleValue
{
    public static decimal? ToDecimal(object? value)
    {
        if (value is null or DBNull)
        {
            return null;
        }

        switch (value)
        {
            case decimal d:
                return d;
            case byte b:
                return b;
            case short s:
                return s;
            case int i:
                return i;
            case long l:
                return l;
            case float f when float.IsFinite(f):
                return Convert.ToDecimal(f);
            case double x when double.IsFinite(x):
                return Convert.ToDecimal(x);
            case OracleDecimal od:
                if (od.IsNull)
                {
                    return null;
                }

                try
                {
                    return od.Value;
                }
                catch (InvalidCastException)
                {
                    return double.IsFinite(od.ToDouble()) ? Convert.ToDecimal(od.ToDouble()) : null;
                }
            case string text:
                return decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var parsed)
                    ? parsed
                    : null;
            default:
                try
                {
                    return Convert.ToDecimal(value, CultureInfo.InvariantCulture);
                }
                catch (Exception ex) when (ex is InvalidCastException or FormatException or OverflowException)
                {
                    return decimal.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Any, CultureInfo.InvariantCulture, out var fallback)
                        ? fallback
                        : null;
                }
        }
    }

    public static decimal ToDecimalOrZero(object? value) => ToDecimal(value) ?? 0;

    public static DateTime? ToDateTime(object? value)
    {
        if (value is null or DBNull)
        {
            return null;
        }

        return value switch
        {
            DateTime dt => dt,
            DateTimeOffset dto => dto.UtcDateTime,
            OracleDate od when !od.IsNull => od.Value,
            OracleTimeStamp ts when !ts.IsNull => ts.Value,
            OracleTimeStampLTZ ltz when !ltz.IsNull => DateTime.SpecifyKind(ltz.Value, DateTimeKind.Utc),
            string text when DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var parsed) => parsed,
            _ => DateTime.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var fallback)
                ? fallback
                : null
        };
    }

    public static string? ToStringValue(object? value)
    {
        if (value is null or DBNull)
        {
            return null;
        }

        return value switch
        {
            string s => s,
            OracleString os when !os.IsNull => os.Value,
            _ => Convert.ToString(value, CultureInfo.InvariantCulture)
        };
    }
}
