using System.Data;
using System.Globalization;
using Dapper;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Infrastructure.Persistence.Oracle;

internal static class JanWipTestOracleReader
{
    public static bool IsInMemory(OracleDbContext oracle) =>
        oracle.Database.ProviderName?.Contains("InMemory", StringComparison.OrdinalIgnoreCase) == true;

    public static async Task<List<JanWipTest>> LoadScreenAsync(
        OracleDbContext oracle,
        IReadOnlyCollection<string> custodianCodes,
        IReadOnlyCollection<decimal> organizationIds,
        bool filterByOrganization,
        CancellationToken cancellationToken)
    {
        var sql = BuildSql(custodianCodes, organizationIds, filterByOrganization, wipEntityId: null);
        if (sql is null)
        {
            return [];
        }

        if (IsInMemory(oracle))
        {
            return FilterInMemory(
                await oracle.JanWipTests.AsNoTracking().ToListAsync(cancellationToken),
                custodianCodes,
                organizationIds,
                filterByOrganization,
                wipEntityId: null);
        }

        return await QueryAsync(oracle, sql, cancellationToken);
    }

    public static async Task<List<JanWipTest>> LoadJobAsync(
        OracleDbContext oracle,
        decimal wipEntityId,
        IReadOnlyCollection<string> custodianCodes,
        IReadOnlyCollection<decimal> organizationIds,
        bool filterByOrganization,
        CancellationToken cancellationToken)
    {
        var sql = BuildSql(custodianCodes, organizationIds, filterByOrganization, wipEntityId);
        if (sql is null)
        {
            return [];
        }

        if (IsInMemory(oracle))
        {
            return FilterInMemory(
                await oracle.JanWipTests.AsNoTracking().ToListAsync(cancellationToken),
                custodianCodes,
                organizationIds,
                filterByOrganization,
                wipEntityId);
        }

        return await QueryAsync(oracle, sql, cancellationToken);
    }

    private static string? BuildSql(
        IReadOnlyCollection<string> custodianCodes,
        IReadOnlyCollection<decimal> organizationIds,
        bool filterByOrganization,
        decimal? wipEntityId)
    {
        var clauses = new List<string>();
        if (wipEntityId is { } wip)
        {
            clauses.Add($"WIP_ENTITY_ID = {wip.ToString("0.####", CultureInfo.InvariantCulture)}");
        }

        var codes = SqlCustodianList(custodianCodes);
        if (codes is not null)
        {
            clauses.Add($"UPPER(TRIM(CUSTODIAN_CODE)) IN ({codes})");
        }
        else if (!filterByOrganization)
        {
            return null;
        }

        if (filterByOrganization)
        {
            if (organizationIds.Count == 0)
            {
                return null;
            }

            var orgs = string.Join(",", organizationIds.Select(id => id.ToString("0.####", CultureInfo.InvariantCulture)));
            clauses.Add($"ORGANIZATION_ID IN ({orgs})");
        }

        if (clauses.Count == 0)
        {
            return null;
        }

        return $"""
            SELECT *
            FROM JAN_WIP_TEST
            WHERE {string.Join("\n  AND ", clauses)}
            """;
    }

    private static List<JanWipTest> FilterInMemory(
        List<JanWipTest> rows,
        IReadOnlyCollection<string> custodianCodes,
        IReadOnlyCollection<decimal> organizationIds,
        bool filterByOrganization,
        decimal? wipEntityId)
    {
        IEnumerable<JanWipTest> q = rows;
        if (wipEntityId is { } wip)
        {
            q = q.Where(x => x.WipEntityId == wip);
        }

        if (custodianCodes.Count > 0)
        {
            var codes = custodianCodes.Select(x => x.Trim().ToLowerInvariant()).Where(x => x.Length > 0).ToHashSet();
            q = q.Where(x => x.CustodianCode != null && codes.Contains(x.CustodianCode.Trim().ToLowerInvariant()));
        }
        else if (!filterByOrganization)
        {
            return [];
        }

        if (filterByOrganization)
        {
            q = q.Where(x => organizationIds.Contains(x.OrganizationId));
        }

        return q.ToList();
    }

    private static string? SqlCustodianList(IReadOnlyCollection<string> codes)
    {
        var safe = codes
            .Select(x => x.Trim().ToUpperInvariant())
            .Where(x => x.Length > 0 && x.All(ch => char.IsLetterOrDigit(ch) || ch is '_' or '-' or '.'))
            .Distinct()
            .ToList();
        if (safe.Count == 0)
        {
            return null;
        }

        return string.Join(",", safe.Select(x => $"'{x}'"));
    }

    private static async Task<List<JanWipTest>> QueryAsync(
        OracleDbContext oracle,
        string sql,
        CancellationToken cancellationToken)
    {
        var connection = oracle.Database.GetDbConnection();
        var shouldClose = connection.State != ConnectionState.Open;
        if (shouldClose)
        {
            await oracle.Database.OpenConnectionAsync(cancellationToken);
        }

        try
        {
            var command = new CommandDefinition(sql, cancellationToken: cancellationToken);
            var rows = await connection.QueryAsync(command);
            return rows.Select(MapRow).ToList();
        }
        finally
        {
            if (shouldClose)
            {
                await oracle.Database.CloseConnectionAsync();
            }
        }
    }

    private static JanWipTest MapRow(dynamic row)
    {
        var values = (IDictionary<string, object>)row;
        object? Col(params string[] names)
        {
            foreach (var name in names)
            {
                if (values.TryGetValue(name, out var value))
                {
                    return value;
                }

                var match = values.Keys.FirstOrDefault(k => string.Equals(k, name, StringComparison.OrdinalIgnoreCase));
                if (match is not null)
                {
                    return values[match];
                }
            }

            return null;
        }

        return new JanWipTest
        {
            PrimaryItemId = OracleValue.ToDecimal(Col("PRIMARY_ITEM_ID")),
            OrganizationId = OracleValue.ToDecimalOrZero(Col("ORGANIZATION_ID")),
            ItemNo = OracleValue.ToStringValue(Col("ITEM_NO")),
            WipEntityId = OracleValue.ToDecimalOrZero(Col("WIP_ENTITY_ID")),
            JobNo = OracleValue.ToStringValue(Col("JOB_NO")) ?? "",
            JobDt = OracleValue.ToDateTime(Col("JOB_DT")) ?? DateTime.MinValue,
            AlternateRoutingDesignator = OracleValue.ToStringValue(Col("ALTERNATE_ROUTING_DESIGNATOR")),
            CustodianCode = OracleValue.ToStringValue(Col("CUSTODIAN_CODE")),
            Opn1OperationSeq = OracleValue.ToDecimal(Col("OPN1_OPERATION_SEQ")),
            Opn1OperationDesc = OracleValue.ToStringValue(Col("OPN1_OPERATION_DESC")),
            Opn1QtyQueue = OracleValue.ToDecimal(Col("OPN1_QTY_QUEUE")),
            Opn1QtyMove = OracleValue.ToDecimal(Col("OPN1_QTY_MOVE")),
            Opn1QtyScrap = OracleValue.ToDecimal(Col("OPN1_QTY_SCRAP")),
            Opn1QtyComp = OracleValue.ToDecimal(Col("OPN1_QTY_COMP")),
            Opn1VendorName = OracleValue.ToStringValue(Col("OPN1_VENDOR_NAME")),
            Opn1LeadTime = OracleValue.ToDecimal(Col("OPN1_LEAD_TIME")),
            Opn1ProcessStartDate = OracleValue.ToDateTime(Col("OPN1_PROCESS_START_DATE", "OPN1_PROCESS_START_DT")),
            Opn2OperationSeq = OracleValue.ToDecimal(Col("OPN2_OPERATION_SEQ")),
            Opn2OperationDesc = OracleValue.ToStringValue(Col("OPN2_OPERATION_DESC")),
            Opn2QtyQueue = OracleValue.ToDecimal(Col("OPN2_QTY_QUEUE")),
            Opn2QtyMove = OracleValue.ToDecimal(Col("OPN2_QTY_MOVE")),
            Opn2QtyScrap = OracleValue.ToDecimal(Col("OPN2_QTY_SCRAP")),
            Opn2QtyComp = OracleValue.ToDecimal(Col("OPN2_QTY_COMP")),
            Opn2VendorName = OracleValue.ToStringValue(Col("OPN2_VENDOR_NAME")),
            Opn2LeadTime = OracleValue.ToDecimal(Col("OPN2_LEAD_TIME")),
            Opn2ProcessStartDate = OracleValue.ToDateTime(Col("OPN2_PROCESS_START_DATE", "OPN2_PROCESS_START_DT")),
            Opn3OperationSeq = OracleValue.ToDecimal(Col("OPN3_OPERATION_SEQ")),
            Opn3OperationDesc = OracleValue.ToStringValue(Col("OPN3_OPERATION_DESC")),
            Opn3QtyQueue = OracleValue.ToDecimal(Col("OPN3_QTY_QUEUE")),
            Opn3QtyMove = OracleValue.ToDecimal(Col("OPN3_QTY_MOVE")),
            Opn3QtyScrap = OracleValue.ToDecimal(Col("OPN3_QTY_SCRAP")),
            Opn3QtyComp = OracleValue.ToDecimal(Col("OPN3_QTY_COMP")),
            Opn3VendorName = OracleValue.ToStringValue(Col("OPN3_VENDOR_NAME")),
            Opn3LeadTime = OracleValue.ToDecimal(Col("OPN3_LEAD_TIME")),
            Opn3ProcessStartDate = OracleValue.ToDateTime(Col("OPN3_PROCESS_START_DATE", "OPN3_PROCESS_START_DT")),
            Opn4OperationSeq = OracleValue.ToDecimal(Col("OPN4_OPERATION_SEQ")),
            Opn4OperationDesc = OracleValue.ToStringValue(Col("OPN4_OPERATION_DESC")),
            Opn4QtyQueue = OracleValue.ToDecimal(Col("OPN4_QTY_QUEUE")),
            Opn4QtyMove = OracleValue.ToDecimal(Col("OPN4_QTY_MOVE")),
            Opn4QtyScrap = OracleValue.ToDecimal(Col("OPN4_QTY_SCRAP")),
            Opn4QtyComp = OracleValue.ToDecimal(Col("OPN4_QTY_COMP")),
            Opn4VendorName = OracleValue.ToStringValue(Col("OPN4_VENDOR_NAME")),
            Opn4LeadTime = OracleValue.ToDecimal(Col("OPN4_LEAD_TIME")),
            Opn4ProcessStartDate = OracleValue.ToDateTime(Col("OPN4_PROCESS_START_DATE", "OPN4_PROCESS_START_DT")),
            Opn5OperationSeq = OracleValue.ToDecimal(Col("OPN5_OPERATION_SEQ")),
            Opn5OperationDesc = OracleValue.ToStringValue(Col("OPN5_OPERATION_DESC")),
            Opn5QtyQueue = OracleValue.ToDecimal(Col("OPN5_QTY_QUEUE")),
            Opn5QtyMove = OracleValue.ToDecimal(Col("OPN5_QTY_MOVE")),
            Opn5QtyScrap = OracleValue.ToDecimal(Col("OPN5_QTY_SCRAP")),
            Opn5QtyComp = OracleValue.ToDecimal(Col("OPN5_QTY_COMP")),
            Opn5VendorName = OracleValue.ToStringValue(Col("OPN5_VENDOR_NAME")),
            Opn5LeadTime = OracleValue.ToDecimal(Col("OPN5_LEAD_TIME")),
            Opn5ProcessStartDate = OracleValue.ToDateTime(Col("OPN5_PROCESS_START_DATE", "OPN5_PROCESS_START_DT")),
            Opn6OperationSeq = OracleValue.ToDecimal(Col("OPN6_OPERATION_SEQ")),
            Opn6OperationDesc = OracleValue.ToStringValue(Col("OPN6_OPERATION_DESC")),
            Opn6QtyQueue = OracleValue.ToDecimal(Col("OPN6_QTY_QUEUE")),
            Opn6QtyMove = OracleValue.ToDecimal(Col("OPN6_QTY_MOVE")),
            Opn6QtyScrap = OracleValue.ToDecimal(Col("OPN6_QTY_SCRAP")),
            Opn6QtyComp = OracleValue.ToDecimal(Col("OPN6_QTY_COMP")),
            Opn6VendorName = OracleValue.ToStringValue(Col("OPN6_VENDOR_NAME")),
            Opn6LeadTime = OracleValue.ToDecimal(Col("OPN6_LEAD_TIME")),
            Opn6ProcessStartDate = OracleValue.ToDateTime(Col("OPN6_PROCESS_START_DATE", "OPN6_PROCESS_START_DT")),
        };
    }
}
