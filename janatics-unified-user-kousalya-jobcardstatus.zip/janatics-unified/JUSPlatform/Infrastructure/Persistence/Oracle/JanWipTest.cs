namespace JUSPlatform.Infrastructure.Persistence.Oracle;

/// <summary>Read-only map of Oracle table JAN_WIP_TEST. Not migrated.</summary>
public sealed class JanWipTest
{
    public decimal? PrimaryItemId { get; set; }
    public decimal OrganizationId { get; set; }
    public string? ItemNo { get; set; }
    public decimal WipEntityId { get; set; }
    public string JobNo { get; set; } = string.Empty;
    public DateTime JobDt { get; set; }
    public string? AlternateRoutingDesignator { get; set; }
    public string? CustodianCode { get; set; }

    public decimal? Opn1OperationSeq { get; set; }
    public string? Opn1OperationDesc { get; set; }
    public decimal? Opn1QtyQueue { get; set; }
    public decimal? Opn1QtyMove { get; set; }
    public decimal? Opn1QtyScrap { get; set; }
    public decimal? Opn1QtyComp { get; set; }
    public string? Opn1VendorName { get; set; }
    public decimal? Opn1LeadTime { get; set; }
    public DateTime? Opn1ProcessStartDate { get; set; }

    public decimal? Opn2OperationSeq { get; set; }
    public string? Opn2OperationDesc { get; set; }
    public decimal? Opn2QtyQueue { get; set; }
    public decimal? Opn2QtyMove { get; set; }
    public decimal? Opn2QtyScrap { get; set; }
    public decimal? Opn2QtyComp { get; set; }
    public string? Opn2VendorName { get; set; }
    public decimal? Opn2LeadTime { get; set; }
    public DateTime? Opn2ProcessStartDate { get; set; }

    public decimal? Opn3OperationSeq { get; set; }
    public string? Opn3OperationDesc { get; set; }
    public decimal? Opn3QtyQueue { get; set; }
    public decimal? Opn3QtyMove { get; set; }
    public decimal? Opn3QtyScrap { get; set; }
    public decimal? Opn3QtyComp { get; set; }
    public string? Opn3VendorName { get; set; }
    public decimal? Opn3LeadTime { get; set; }
    public DateTime? Opn3ProcessStartDate { get; set; }

    public decimal? Opn4OperationSeq { get; set; }
    public string? Opn4OperationDesc { get; set; }
    public decimal? Opn4QtyQueue { get; set; }
    public decimal? Opn4QtyMove { get; set; }
    public decimal? Opn4QtyScrap { get; set; }
    public decimal? Opn4QtyComp { get; set; }
    public string? Opn4VendorName { get; set; }
    public decimal? Opn4LeadTime { get; set; }
    public DateTime? Opn4ProcessStartDate { get; set; }

    public decimal? Opn5OperationSeq { get; set; }
    public string? Opn5OperationDesc { get; set; }
    public decimal? Opn5QtyQueue { get; set; }
    public decimal? Opn5QtyMove { get; set; }
    public decimal? Opn5QtyScrap { get; set; }
    public decimal? Opn5QtyComp { get; set; }
    public string? Opn5VendorName { get; set; }
    public decimal? Opn5LeadTime { get; set; }
    public DateTime? Opn5ProcessStartDate { get; set; }

    public decimal? Opn6OperationSeq { get; set; }
    public string? Opn6OperationDesc { get; set; }
    public decimal? Opn6QtyQueue { get; set; }
    public decimal? Opn6QtyMove { get; set; }
    public decimal? Opn6QtyScrap { get; set; }
    public decimal? Opn6QtyComp { get; set; }
    public string? Opn6VendorName { get; set; }
    public decimal? Opn6LeadTime { get; set; }
    public DateTime? Opn6ProcessStartDate { get; set; }
}
