using System.Text;
using Hangfire.Dashboard;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Hangfire;

public sealed class HangfireDashboardAuthFilter(IOptionsMonitor<HangfireOptions> options) : IDashboardAuthorizationFilter
{
    public bool Authorize(DashboardContext context)
    {
        var httpContext = context.GetHttpContext();
        var hangfire = options.CurrentValue;

        if (!hangfire.IsActive)
        {
            return false;
        }

        var header = httpContext.Request.Headers.Authorization.ToString();
        if (header.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                var encoded = header["Basic ".Length..].Trim();
                var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
                var separator = decoded.IndexOf(':');
                if (separator > 0)
                {
                    var username = decoded[..separator];
                    var password = decoded[(separator + 1)..];
                    return username == hangfire.DashboardUsername
                        && password == hangfire.DashboardPassword;
                }
            }
            catch (FormatException)
            {
                // Invalid Basic auth header.
            }
        }

        httpContext.Response.Headers.WWWAuthenticate = "Basic realm=\"Hangfire Dashboard\"";
        httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
        return false;
    }
}
