using Hangfire;
using Hangfire.PostgreSql;
using JUSPlatform.Application.Jobs;
using JUSPlatform.Infrastructure.Jobs;
using Microsoft.Extensions.DependencyInjection;

namespace JUSPlatform.Infrastructure.Hangfire;

public static class HangfireServiceCollectionExtensions
{
    public static IServiceCollection AddJUSPlatformHangfire(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var options = HangfireOptions.Bind(configuration);
        services.Configure<HangfireOptions>(configuration.GetSection(HangfireOptions.SectionName));
        services.AddSingleton<HangfireDashboardAuthFilter>();

        if (!options.Enabled)
        {
            services.AddSingleton<IJobExecutionQueue, NullJobExecutionQueue>();
            return services;
        }

        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("ConnectionStrings:Default is required for Hangfire.");

        services.AddHangfire(config => config
            .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
            .UseSimpleAssemblyNameTypeSerializer()
            .UseRecommendedSerializerSettings()
            .UsePostgreSqlStorage(
                configure => configure.UseNpgsqlConnection(connectionString),
                new PostgreSqlStorageOptions
                {
                    SchemaName = HangfireOptions.SchemaName,
                    QueuePollInterval = TimeSpan.FromSeconds(5),
                    PrepareSchemaIfNecessary = true,
                    JobExpirationCheckInterval = TimeSpan.FromHours(1),
                    CountersAggregateInterval = TimeSpan.FromMinutes(5)
                }));

        services.AddHangfireServer(serverOptions =>
        {
            serverOptions.WorkerCount = Environment.ProcessorCount;
        });

        services.AddScoped<HangfireJobExecutor>();
        services.AddSingleton<IJobExecutionQueue, HangfireJobExecutionQueue>();

        return services;
    }

    public static WebApplication UseJUSPlatformHangfireDashboard(this WebApplication app)
    {
        var options = HangfireOptions.Bind(app.Configuration);
        if (!options.IsActive)
        {
            return app;
        }

        var path = options.DashboardPath.StartsWith('/')
            ? options.DashboardPath
            : $"/{options.DashboardPath}";

        app.UseHangfireDashboard(path, new DashboardOptions
        {
            Authorization = [app.Services.GetRequiredService<HangfireDashboardAuthFilter>()],
            DisplayStorageConnectionString = false
        });

        return app;
    }
}
