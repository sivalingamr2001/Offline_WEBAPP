using Hangfire;
using JUSPlatform.Domain.Enums;
using JUSPlatform.Infrastructure.Jobs;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace JUSPlatform.Infrastructure.Hangfire;

public sealed class HangfireJobExecutor(IServiceScopeFactory scopeFactory)
{
    public async Task ExecuteAsync(Guid jobRunId)
    {
        using var scope = scopeFactory.CreateScope();
        var runner = scope.ServiceProvider.GetRequiredService<JobRunner>();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        await runner.RunAsync(jobRunId, CancellationToken.None);

        var job = await db.JobRuns
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == jobRunId);

        if (job?.Status != JobStatus.Failed || job.NextRunAt is null)
        {
            return;
        }

        var delay = job.NextRunAt.Value - DateTimeOffset.UtcNow;
        if (delay <= TimeSpan.Zero)
        {
            BackgroundJob.Enqueue<HangfireJobExecutor>(x => x.ExecuteAsync(jobRunId));
            return;
        }

        BackgroundJob.Schedule<HangfireJobExecutor>(
            x => x.ExecuteAsync(jobRunId),
            delay);
    }
}
