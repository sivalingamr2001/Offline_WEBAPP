using Hangfire;
using JUSPlatform.Application.Jobs;

namespace JUSPlatform.Infrastructure.Hangfire;

public sealed class HangfireJobExecutionQueue : IJobExecutionQueue
{
    public void Enqueue(Guid jobRunId) =>
        BackgroundJob.Enqueue<HangfireJobExecutor>(x => x.ExecuteAsync(jobRunId));
}
