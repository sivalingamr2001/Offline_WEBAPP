namespace JUSPlatform.Infrastructure.Hangfire;

public sealed class HangfireOptions
{
    public const string SectionName = "Hangfire";

    /// <summary>PostgreSQL schema for Hangfire tables (not mixed with app tables).</summary>
    public const string SchemaName = "hangfire";

    /// <summary>Enable Hangfire server, storage, and dashboard.</summary>
    public bool Enabled { get; set; }

    /// <summary>Dashboard URL path (default <c>/hangfire</c>).</summary>
    public string DashboardPath { get; set; } = "/hangfire";

    /// <summary>HTTP Basic Auth username for the dashboard.</summary>
    public string DashboardUsername { get; set; } = "admin";

    /// <summary>HTTP Basic Auth password for the dashboard.</summary>
    public string DashboardPassword { get; set; } = "";

    public bool IsActive => Enabled && !string.IsNullOrWhiteSpace(DashboardPassword);

    public static HangfireOptions Bind(IConfiguration configuration) =>
        configuration.GetSection(SectionName).Get<HangfireOptions>() ?? new();
}
