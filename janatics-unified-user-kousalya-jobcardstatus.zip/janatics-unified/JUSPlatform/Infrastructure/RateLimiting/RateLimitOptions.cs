namespace JUSPlatform.Infrastructure.RateLimiting;

public sealed class RateLimitOptions
{
    public const string SectionName = "RateLimit";

    public bool Enabled { get; set; } = true;

    /// <summary>
    /// When true, client IP is taken from X-Forwarded-For. Enable only behind a trusted reverse proxy.
    /// </summary>
    public bool TrustForwardedHeaders { get; set; }

    /// <summary>Login and reset-password.</summary>
    public RateLimitWindowOptions Auth { get; set; } = new() { PermitLimit = 10, WindowSeconds = 60 };

    /// <summary>Register and forgot-password (email / org creation).</summary>
    public RateLimitWindowOptions AuthStrict { get; set; } = new() { PermitLimit = 5, WindowSeconds = 60 };

    /// <summary>All /api routes except health.</summary>
    public ApiRateLimitOptions Api { get; set; } = new();
}

public class RateLimitWindowOptions
{
    public int PermitLimit { get; set; } = 10;
    public int WindowSeconds { get; set; } = 60;
}

public sealed class ApiRateLimitOptions : RateLimitWindowOptions
{
    public ApiRateLimitOptions()
    {
        PermitLimit = 120;
        WindowSeconds = 60;
    }

    public int ConcurrentLimit { get; set; } = 25;
}

public static class RateLimitPolicies
{
    public const string Auth = "auth";
    public const string AuthStrict = "auth-strict";
}
