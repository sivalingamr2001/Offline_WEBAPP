using System.Globalization;
using System.Threading.RateLimiting;
using JUSPlatform.Middleware;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using Serilog;

namespace JUSPlatform.Infrastructure.RateLimiting;

public static class RateLimitingExtensions
{
    public static IServiceCollection AddJUSPlatformRateLimiting(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<RateLimitOptions>(configuration.GetSection(RateLimitOptions.SectionName));

        var startup = configuration.GetSection(RateLimitOptions.SectionName).Get<RateLimitOptions>()
            ?? new RateLimitOptions();
        if (startup.TrustForwardedHeaders)
        {
            services.Configure<ForwardedHeadersOptions>(forwarded =>
            {
                forwarded.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
                forwarded.KnownIPNetworks.Clear();
                forwarded.KnownProxies.Clear();
            });
        }

        // Always register so UseRateLimiter is safe. Limits are no-ops when RateLimit:Enabled=false.
        services.AddRateLimiter(limiter =>
        {
            limiter.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
            limiter.OnRejected = WriteTooManyRequestsAsync;
            limiter.GlobalLimiter = CreateApiLimiter();
            limiter.AddPolicy(RateLimitPolicies.Auth, context =>
                CreateNamedWindowPartition(context, RateLimitPolicies.Auth, static o => o.Auth));
            limiter.AddPolicy(RateLimitPolicies.AuthStrict, context =>
                CreateNamedWindowPartition(context, RateLimitPolicies.AuthStrict, static o => o.AuthStrict));
        });

        return services;
    }

    public static WebApplication UseJUSPlatformForwardedHeaders(this WebApplication app)
    {
        var options = app.Services.GetRequiredService<IOptions<RateLimitOptions>>().Value;
        if (options.TrustForwardedHeaders)
        {
            app.UseForwardedHeaders();
        }

        return app;
    }

    public static WebApplication UseJUSPlatformRateLimiting(this WebApplication app)
    {
        var options = app.Services.GetRequiredService<IOptions<RateLimitOptions>>().Value;
        Log.Information(
            "RateLimit: Enabled={Enabled}, Auth={AuthLimit}/{AuthWindow}s, AuthStrict={StrictLimit}/{StrictWindow}s, Api={ApiLimit}/{ApiWindow}s, Concurrent={Concurrent}, TrustForwardedHeaders={TrustForwardedHeaders}",
            options.Enabled,
            options.Auth.PermitLimit,
            options.Auth.WindowSeconds,
            options.AuthStrict.PermitLimit,
            options.AuthStrict.WindowSeconds,
            options.Api.PermitLimit,
            options.Api.WindowSeconds,
            options.Api.ConcurrentLimit,
            options.TrustForwardedHeaders);

        app.UseRateLimiter();
        return app;
    }

    internal static bool ShouldSkipApiLimit(HttpContext context)
    {
        if (HttpMethods.IsOptions(context.Request.Method))
        {
            return true;
        }

        var path = context.Request.Path;
        if (path.Equals("/api", StringComparison.OrdinalIgnoreCase)
            || path.Equals("/api/heath", StringComparison.OrdinalIgnoreCase)
            || path.Equals("/api/health", StringComparison.OrdinalIgnoreCase)
            || path.Equals("/api/oracle/connection", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        return !path.StartsWithSegments("/api");
    }

    internal static string GetClientKey(HttpContext context)
        => context.Connection.RemoteIpAddress?.ToString() ?? "unknown";

    private static PartitionedRateLimiter<HttpContext> CreateApiLimiter()
    {
        var concurrent = PartitionedRateLimiter.Create<HttpContext, string>(context =>
        {
            var options = ResolveOptions(context);
            if (!options.Enabled || options.Api.ConcurrentLimit <= 0 || ShouldSkipApiLimit(context))
            {
                return RateLimitPartition.GetNoLimiter("api-concurrent-skip");
            }

            return RateLimitPartition.GetConcurrencyLimiter(
                GetClientKey(context),
                _ => new ConcurrencyLimiterOptions
                {
                    PermitLimit = options.Api.ConcurrentLimit,
                    QueueLimit = 0,
                    QueueProcessingOrder = QueueProcessingOrder.OldestFirst
                });
        });

        var window = PartitionedRateLimiter.Create<HttpContext, string>(context =>
        {
            var options = ResolveOptions(context);
            if (!options.Enabled || ShouldSkipApiLimit(context))
            {
                return RateLimitPartition.GetNoLimiter("api-window-skip");
            }

            return CreateWindowPartition("api", GetClientKey(context), options.Api);
        });

        return PartitionedRateLimiter.CreateChained(concurrent, window);
    }

    private static RateLimitPartition<string> CreateNamedWindowPartition(
        HttpContext context,
        string policy,
        Func<RateLimitOptions, RateLimitWindowOptions> selector)
    {
        var options = ResolveOptions(context);
        if (!options.Enabled)
        {
            return RateLimitPartition.GetNoLimiter($"{policy}-disabled");
        }

        return CreateWindowPartition(policy, GetClientKey(context), selector(options));
    }

    private static RateLimitPartition<string> CreateWindowPartition(
        string policy,
        string clientKey,
        RateLimitWindowOptions window)
    {
        if (window.PermitLimit <= 0 || window.WindowSeconds <= 0)
        {
            return RateLimitPartition.GetNoLimiter($"{policy}-skip");
        }

        var segments = Math.Clamp(window.WindowSeconds >= 12 ? 4 : 2, 1, Math.Max(window.WindowSeconds, 1));
        return RateLimitPartition.GetSlidingWindowLimiter(
            $"{policy}:{clientKey}",
            _ => new SlidingWindowRateLimiterOptions
            {
                PermitLimit = window.PermitLimit,
                Window = TimeSpan.FromSeconds(window.WindowSeconds),
                SegmentsPerWindow = segments,
                QueueLimit = 0,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst
            });
    }

    private static RateLimitOptions ResolveOptions(HttpContext context)
        => context.RequestServices.GetRequiredService<IOptionsSnapshot<RateLimitOptions>>().Value;

    private static async ValueTask WriteTooManyRequestsAsync(
        OnRejectedContext context,
        CancellationToken cancellationToken)
    {
        var http = context.HttpContext;
        if (context.Lease.TryGetMetadata(MetadataName.RetryAfter, out var retryAfter))
        {
            http.Response.Headers.RetryAfter =
                Math.Max(1, (int)Math.Ceiling(retryAfter.TotalSeconds))
                    .ToString(CultureInfo.InvariantCulture);
        }

        var logger = http.RequestServices.GetService<ILoggerFactory>()
            ?.CreateLogger("JUSPlatform.RateLimiting");
        logger?.LogWarning(
            "Rate limit exceeded {Method} {Path} from {Client}",
            http.Request.Method,
            http.Request.Path.Value,
            GetClientKey(http));

        await ApiErrorResponseWriter.WriteAsync(
            http,
            StatusCodes.Status429TooManyRequests,
            "Too many requests. Try again later.",
            cancellationToken);
    }
}
