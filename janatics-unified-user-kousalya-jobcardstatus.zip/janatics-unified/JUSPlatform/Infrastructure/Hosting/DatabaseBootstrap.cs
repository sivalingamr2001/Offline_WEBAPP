using JUSPlatform.Infrastructure.Authentication;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Serilog;

namespace JUSPlatform.Infrastructure.Hosting;

/// <summary>
/// Schema on API boot (MigrateAsync). Platform seed is a CLI command, not a boot step.
/// Testing still EnsureCreated + seed so integration tests have SuperAdmin.
/// </summary>
public static class DatabaseBootstrap
{
    public static bool IsSeedCommand(IReadOnlyList<string> args) =>
        args.Any(a => string.Equals(a, "--seed", StringComparison.OrdinalIgnoreCase));

    public static bool IsEnsurePesCommand(IReadOnlyList<string> args) =>
        args.Any(a => string.Equals(a, "--ensure-pes", StringComparison.OrdinalIgnoreCase));

    public static async Task ApplySchemaAsync(
        IServiceProvider services,
        IHostEnvironment environment,
        IConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        DatabaseStartupLogger.EnsureConnectionStringValid(configuration);

        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        if (environment.IsEnvironment("Testing")
            || configuration.GetValue("UseInMemoryDatabase", false))
        {
            await db.Database.EnsureCreatedAsync(cancellationToken);
            Log.Information("Database: InMemory/Testing schema ensured (EnsureCreated)");
            return;
        }

        var pending = (await db.Database.GetPendingMigrationsAsync(cancellationToken)).ToList();
        if (pending.Count == 0)
        {
            Log.Information("Database: schema up to date (no pending EF migrations)");
            return;
        }

        Log.Information(
            "Database: applying {Count} pending migration(s): {Migrations}",
            pending.Count,
            pending);
        await db.Database.MigrateAsync(cancellationToken);
        Log.Information("Database: migrations applied");
    }

    public static async Task SeedAsync(
        IServiceProvider services,
        CancellationToken cancellationToken = default)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var hasher = scope.ServiceProvider.GetRequiredService<PasswordHasher>();
        var options = scope.ServiceProvider.GetRequiredService<IOptions<SeedOptions>>().Value;

        await DbSeeder.SeedAsync(db, hasher, options, cancellationToken);
        await PesAccessSeeder.EnsureAsync(db, cancellationToken);
        Log.Information("Seed: complete SuperAdmin={Email}", options.SuperAdminEmail);
    }

    public static async Task EnsurePesAccessAsync(
        IServiceProvider services,
        IHostEnvironment environment,
        IConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        await ApplySchemaAsync(services, environment, configuration, cancellationToken);
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        await AppCatalogSeeder.RemoveSeededExtrasAsync(db, cancellationToken);
        await PesAccessSeeder.EnsureAsync(db, cancellationToken);
        Log.Information("PES catalog and operator assignment finished.");
    }

    public static async Task RunSeedCommandAsync(
        IServiceProvider services,
        IHostEnvironment environment,
        IConfiguration configuration,
        IReadOnlyList<string> args,
        CancellationToken cancellationToken = default)
    {
        Log.Information("Seed command: migrate if needed, then seed. API will not listen.");
        await ApplySchemaAsync(services, environment, configuration, cancellationToken);
        await SeedAsync(services, cancellationToken);
        Log.Information("Seed command finished. Start the API with: dotnet run --project JUSPlatform");
    }
}
