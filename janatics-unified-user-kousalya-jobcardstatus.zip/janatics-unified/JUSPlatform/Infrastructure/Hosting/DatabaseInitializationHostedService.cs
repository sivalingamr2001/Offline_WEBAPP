using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using Serilog;

namespace JUSPlatform.Infrastructure.Hosting;

public sealed class DatabaseInitializationHostedService(
    IServiceProvider services,
    IHostEnvironment environment,
    IConfiguration configuration) : IHostedService
{
    public async Task StartAsync(CancellationToken cancellationToken)
    {
        await DatabaseBootstrap.ApplySchemaAsync(services, environment, configuration, cancellationToken);

        if (environment.IsEnvironment("Testing"))
        {
            await DatabaseBootstrap.SeedAsync(services, cancellationToken);
            Log.Information("Seed: applied on boot (Testing only)");
            return;
        }

        if (environment.IsDevelopment())
        {
            using var scope = services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            await AppCatalogSeeder.RemoveSeededExtrasAsync(db, cancellationToken);
            await PesAccessSeeder.EnsureAsync(db, cancellationToken);
            var oracle = scope.ServiceProvider.GetRequiredService<OracleDbContext>();
            await JobCardOracleMockSeeder.EnsureAsync(db, oracle, cancellationToken);
            Log.Information("Development: removed seeded extra catalog rows");
            return;
        }

        Log.Information(
            "Seed: skipped on API boot. First-time / after permission catalog changes: dotnet run --project JUSPlatform -- --seed  (or make seed)");
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
}
