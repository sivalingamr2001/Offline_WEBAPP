using JUSPlatform.Application.Common;
using JUSPlatform.Middleware;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Hosting;

public static class SpaHostingExtensions
{
    public static WebApplication UseJUSPlatformSpa(this WebApplication app)
    {
        app.UseDefaultFiles();
        app.UseStaticFiles(new StaticFileOptions
        {
            OnPrepareResponse = ctx =>
            {
                var name = ctx.File.Name;
                if (name.Equals("index.html", StringComparison.OrdinalIgnoreCase))
                {
                    ctx.Context.Response.Headers.CacheControl = "no-cache, no-store, must-revalidate";
                    return;
                }

                // Fingerprinted SPA assets can be cached aggressively.
                ctx.Context.Response.Headers.CacheControl = "public,max-age=31536000,immutable";
            }
        });

        return app;
    }

    public static WebApplication MapJUSPlatformSpaAndApiFallback(this WebApplication app)
    {
        // Unmatched /api/* → JSON 404 (never the SPA shell).
        app.MapFallback("/api/{**path}", (HttpContext httpContext) =>
            {
                var config = httpContext.RequestServices.GetRequiredService<IConfiguration>();
                var errorOptions = httpContext.RequestServices.GetRequiredService<IOptions<ErrorResponseOptions>>().Value;
                var appDebug = config.GetValue("AppDebug", false);
                var body = ApiErrorFactory.NotFound(
                    errorOptions,
                    appDebug,
                    System.Diagnostics.Activity.Current?.Id ?? httpContext.TraceIdentifier);
                return Results.Json(
                    body,
                    statusCode: StatusCodes.Status404NotFound,
                    contentType: ExceptionHandlingMiddleware.Json);
            })
            .ExcludeFromDescription();

        // Everything else → SPA index (client router owns "page not found", HTTP 200).
        app.MapFallbackToFile("index.html");

        return app;
    }
}
