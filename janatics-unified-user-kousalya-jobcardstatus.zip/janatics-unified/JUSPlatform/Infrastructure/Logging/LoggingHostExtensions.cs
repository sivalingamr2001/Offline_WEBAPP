using JUSPlatform.Infrastructure.Bugsink;
using JUSPlatform.Infrastructure.Observability;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.OpenTelemetry;

namespace JUSPlatform.Infrastructure.Logging;

public static class LoggingHostExtensions
{
    private const string FileOutputTemplate =
        "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{ResponseId}] {Message:lj}{NewLine}{Exception}";

    public static void UseJUSPlatformLogging(this IHostBuilder host, bool preserveStaticLogger = false)
    {
        host.UseSerilog(
            (context, services, loggerConfiguration) =>
            {
                var options = context.Configuration
                    .GetSection(LogSinkOptions.SectionName)
                    .Get<LogSinkOptions>() ?? new LogSinkOptions();

                loggerConfiguration
                    .ReadFrom.Configuration(context.Configuration)
                    .ReadFrom.Services(services)
                    .Enrich.FromLogContext()
                    .Enrich.With<TraceContextEnricher>()
                    .Enrich.WithProperty("Application", "JUSPlatform")
                    .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
                    .MinimumLevel.Override("Microsoft.EntityFrameworkCore", LogEventLevel.Warning)
                    .WriteTo.Console(outputTemplate: FileOutputTemplate);

                ConfigureObservabilityLogExport(loggerConfiguration, context.Configuration);
                ConfigureBugsinkLogExport(loggerConfiguration, context.Configuration, context.HostingEnvironment.EnvironmentName);

                switch (options.Provider)
                {
                    case LogSinkProvider.Database:
                        ConfigureDatabase(loggerConfiguration, context.Configuration, options.Database);
                        ConfigureErrorFile(loggerConfiguration, options.File);
                        break;

                    case LogSinkProvider.Seq:
                        ConfigureSeq(loggerConfiguration, options.Seq);
                        ConfigureErrorFile(loggerConfiguration, options.File);
                        break;

                    case LogSinkProvider.File:
                    default:
                        ConfigureFile(loggerConfiguration, options.File);
                        ConfigureErrorFile(loggerConfiguration, options.File);
                        break;
                }
            },
            preserveStaticLogger: preserveStaticLogger);
    }

    private static void ConfigureBugsinkLogExport(
        LoggerConfiguration loggerConfiguration,
        IConfiguration configuration,
        string environmentName)
    {
        var bugsink = BugsinkOptions.Bind(configuration);
        if (!bugsink.IsActive || !bugsink.CaptureSerilogErrors)
        {
            return;
        }

        loggerConfiguration.WriteTo.Sentry(sentry =>
        {
            BugsinkExtensions.ApplyOptions(sentry, bugsink, bugsink.Environment ?? environmentName);
            sentry.MinimumEventLevel = LogEventLevel.Error;
        });
    }

    private static void ConfigureObservabilityLogExport(
        LoggerConfiguration loggerConfiguration,
        IConfiguration configuration)
    {
        var observability = ObservabilityOptions.Bind(configuration);
        if (!observability.Enabled
            || !observability.Logs
            || string.IsNullOrWhiteSpace(observability.OtlpEndpoint))
        {
            return;
        }

        loggerConfiguration.WriteTo.OpenTelemetry(options =>
        {
            options.Endpoint = observability.OtlpEndpoint;
            options.Protocol = OtlpProtocol.Grpc;
            options.ResourceAttributes = new Dictionary<string, object>
            {
                ["service.name"] = observability.ServiceName
            };
        });
    }

    private static void ConfigureFile(LoggerConfiguration loggerConfiguration, FileLogSinkOptions file)
    {
        EnsureDirectory(file.Path);

        loggerConfiguration.WriteTo.File(
            path: file.Path,
            rollingInterval: RollingInterval.Day,
            retainedFileCountLimit: file.RetainedFileCountLimit,
            fileSizeLimitBytes: file.FileSizeLimitBytes,
            shared: true,
            outputTemplate: FileOutputTemplate);
    }

    private static void ConfigureErrorFile(LoggerConfiguration loggerConfiguration, FileLogSinkOptions file)
    {
        if (string.IsNullOrWhiteSpace(file.ErrorPath))
        {
            return;
        }

        EnsureDirectory(file.ErrorPath);

        loggerConfiguration.WriteTo.File(
            path: file.ErrorPath,
            rollingInterval: RollingInterval.Day,
            retainedFileCountLimit: file.RetainedFileCountLimit,
            fileSizeLimitBytes: file.FileSizeLimitBytes,
            shared: true,
            restrictedToMinimumLevel: LogEventLevel.Warning,
            outputTemplate: FileOutputTemplate);
    }

    private static void EnsureDirectory(string path)
    {
        var directory = Path.GetDirectoryName(path);
        if (!string.IsNullOrWhiteSpace(directory))
        {
            Directory.CreateDirectory(directory);
        }
    }

    private static void ConfigureDatabase(
        LoggerConfiguration loggerConfiguration,
        IConfiguration configuration,
        DatabaseLogSinkOptions database)
    {
        var connectionString = string.IsNullOrWhiteSpace(database.ConnectionString)
            ? configuration.GetConnectionString("Default")
            : database.ConnectionString;

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                "LogSink:Database requires ConnectionStrings:Default or LogSink:Database:ConnectionString.");
        }

        var sink = new PostgresLogSink(
            connectionString,
            database.TableName,
            database.BatchSize,
            TimeSpan.FromSeconds(Math.Max(1, database.PeriodSeconds)));

        loggerConfiguration.WriteTo.Sink(sink);
    }

    private static void ConfigureSeq(LoggerConfiguration loggerConfiguration, SeqLogSinkOptions seq)
    {
        if (string.IsNullOrWhiteSpace(seq.ServerUrl))
        {
            throw new InvalidOperationException("LogSink:Seq:ServerUrl is required when Provider=Seq.");
        }

        loggerConfiguration.WriteTo.Seq(
            serverUrl: seq.ServerUrl,
            apiKey: string.IsNullOrWhiteSpace(seq.ApiKey) ? null : seq.ApiKey);
    }
}
