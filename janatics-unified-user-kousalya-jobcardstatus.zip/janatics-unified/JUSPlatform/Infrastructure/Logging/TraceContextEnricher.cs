using System.Diagnostics;
using Serilog.Core;
using Serilog.Events;

namespace JUSPlatform.Infrastructure.Logging;

/// <summary>
/// Adds trace/span ids to Serilog events so Loki ↔ Tempo correlation works in Grafana.
/// </summary>
public sealed class TraceContextEnricher : ILogEventEnricher
{
    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        var activity = Activity.Current;
        if (activity is null)
        {
            return;
        }

        logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("TraceId", activity.TraceId.ToString()));
        logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("SpanId", activity.SpanId.ToString()));
    }
}
