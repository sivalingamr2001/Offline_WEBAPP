namespace JUSPlatform.Infrastructure.Logging;

public enum LogSinkProvider
{
    /// <summary>Rolling files under the configured path (default).</summary>
    File = 0,

    /// <summary>Append-only rows in PostgreSQL table app_logs.</summary>
    Database = 1,

    /// <summary>OSS log platform adapter (Seq today; swap ServerUrl/ApiKey when ready).</summary>
    Seq = 2
}

public sealed class LogSinkOptions
{
    public const string SectionName = "LogSink";

    /// <summary>Active sink. Always also writes to console.</summary>
    public LogSinkProvider Provider { get; set; } = LogSinkProvider.File;

    public FileLogSinkOptions File { get; set; } = new();
    public DatabaseLogSinkOptions Database { get; set; } = new();
    public SeqLogSinkOptions Seq { get; set; } = new();
}

public sealed class FileLogSinkOptions
{
    public string Path { get; set; } = "logs/jusplatform-.log";

    /// <summary>Rolling file for Warning+ (API failures / exceptions). Empty disables.</summary>
    public string ErrorPath { get; set; } = "logs/jusplatform-errors-.log";

    public int RetainedFileCountLimit { get; set; } = 14;
    public long? FileSizeLimitBytes { get; set; } = 64 * 1024 * 1024;
}

public sealed class DatabaseLogSinkOptions
{
    /// <summary>Uses ConnectionStrings:Default when empty.</summary>
    public string? ConnectionString { get; set; }

    public string TableName { get; set; } = "app_logs";
    public int BatchSize { get; set; } = 50;
    public int PeriodSeconds { get; set; } = 2;
}

public sealed class SeqLogSinkOptions
{
    public string ServerUrl { get; set; } = "http://localhost:5341";
    public string? ApiKey { get; set; }
}
