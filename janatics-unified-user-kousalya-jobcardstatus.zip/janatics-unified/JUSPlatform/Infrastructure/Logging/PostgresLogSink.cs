using System.Collections.Concurrent;
using System.Text.RegularExpressions;
using Dapper;
using Npgsql;
using Serilog.Core;
using Serilog.Events;
using Serilog.Formatting.Json;

namespace JUSPlatform.Infrastructure.Logging;

/// <summary>
/// PostgreSQL-backed Serilog sink. Batches inserts on a background timer to avoid blocking requests.
/// </summary>
public sealed class PostgresLogSink : ILogEventSink, IDisposable
{
    private static readonly Regex SafeTableName = new("^[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.Compiled);

    private readonly string _connectionString;
    private readonly string _tableName;
    private readonly int _batchSize;
    private readonly ConcurrentQueue<LogEvent> _queue = new();
    private readonly Timer _timer;
    private readonly JsonFormatter _formatter = new(renderMessage: true);
    private int _flushing;

    public PostgresLogSink(string connectionString, string tableName, int batchSize, TimeSpan period)
    {
        _connectionString = connectionString;
        _tableName = SanitizeTableName(tableName);
        _batchSize = Math.Max(1, batchSize);
        _timer = new Timer(_ => Flush(), null, period, period);
        EnsureTable();
    }

    public void Emit(LogEvent logEvent) => _queue.Enqueue(logEvent);

    private void EnsureTable()
    {
        var sql = $"""
            CREATE TABLE IF NOT EXISTS {_tableName} (
              id BIGSERIAL PRIMARY KEY,
              timestamp TIMESTAMPTZ NOT NULL,
              level VARCHAR(32) NOT NULL,
              message TEXT NOT NULL,
              exception TEXT NULL,
              properties JSONB NULL
            );
            CREATE INDEX IF NOT EXISTS ix_{_tableName}_timestamp ON {_tableName} (timestamp);
            """;

        using var connection = new NpgsqlConnection(_connectionString);
        connection.Open();
        connection.Execute(sql);
    }

    private void Flush()
    {
        if (Interlocked.Exchange(ref _flushing, 1) == 1)
        {
            return;
        }

        try
        {
            var batch = new List<LogEvent>(_batchSize);
            while (batch.Count < _batchSize && _queue.TryDequeue(out var item))
            {
                batch.Add(item);
            }

            if (batch.Count == 0)
            {
                return;
            }

            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            foreach (var logEvent in batch)
            {
                using var messageWriter = new StringWriter();
                _formatter.Format(logEvent, messageWriter);

                connection.Execute(
                    $"""
                     INSERT INTO {_tableName}
                       (timestamp, level, message, exception, properties)
                     VALUES
                       (@Timestamp, @Level, @Message, @Exception, CAST(@Properties AS jsonb))
                     """,
                    new
                    {
                        Timestamp = logEvent.Timestamp.UtcDateTime,
                        Level = logEvent.Level.ToString(),
                        Message = logEvent.RenderMessage(),
                        Exception = logEvent.Exception?.ToString(),
                        Properties = messageWriter.ToString()
                    });
            }
        }
        catch
        {
            // Never throw from a log sink into the app request path.
        }
        finally
        {
            Interlocked.Exchange(ref _flushing, 0);
        }
    }

    public void Dispose()
    {
        _timer.Dispose();
        Flush();
    }

    private static string SanitizeTableName(string tableName)
    {
        if (!SafeTableName.IsMatch(tableName))
        {
            throw new ArgumentException("LogSink table name must be a simple SQL identifier.", nameof(tableName));
        }

        return tableName;
    }
}
