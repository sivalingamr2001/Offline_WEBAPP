using JUSPlatform.Application.Common;
using Microsoft.Extensions.Options;
using StackExchange.Redis;

namespace JUSPlatform.Infrastructure.Caching;

public sealed class RedisQueryCache(
    IConnectionMultiplexer multiplexer,
    IOptions<RedisCacheOptions> options,
    ILogger<RedisQueryCache> logger) : IQueryCache
{
    public async Task<string?> TryGetJsonAsync(string cacheKey, CancellationToken cancellationToken)
    {
        if (!IsActive())
        {
            return null;
        }

        _ = cancellationToken;

        try
        {
            var value = await multiplexer.GetDatabase().StringGetAsync(cacheKey);
            return value.HasValue ? (string)value! : null;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis query cache read failed for {Key}", cacheKey);
            return null;
        }
    }

    public async Task SetJsonAsync(
        string cacheKey,
        string json,
        QueryCacheIndex index,
        TimeSpan ttl,
        CancellationToken cancellationToken)
    {
        if (!IsActive())
        {
            return;
        }

        _ = cancellationToken;

        try
        {
            var db = multiplexer.GetDatabase();
            await db.StringSetAsync(cacheKey, json, ttl);
            var indexKey = BuildIndexKey(index.Resource, index.OrganizationId, index.Suffix);
            await db.SetAddAsync(indexKey, cacheKey);
            await db.KeyExpireAsync(indexKey, ttl.Add(TimeSpan.FromMinutes(5)));
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis query cache write failed for {Key}", cacheKey);
        }
    }

    public async Task InvalidateAsync(
        string resource,
        Guid? organizationId,
        string? suffix = null,
        CancellationToken cancellationToken = default)
    {
        if (!options.Value.Enabled || !multiplexer.IsConnected)
        {
            return;
        }

        _ = cancellationToken;

        try
        {
            var db = multiplexer.GetDatabase();
            var indexKey = BuildIndexKey(resource, organizationId, suffix);
            var members = await db.SetMembersAsync(indexKey);
            if (members.Length == 0)
            {
                return;
            }

            var keys = members.Select(m => (RedisKey)m.ToString()).Append(indexKey).ToArray();
            await db.KeyDeleteAsync(keys);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis query cache invalidate failed for {Resource}", resource);
        }
    }

    private bool IsActive() =>
        options.Value.QueryCacheEnabled && options.Value.Enabled && multiplexer.IsConnected;

    internal static string BuildDataKey(string resource, Guid? organizationId, string fingerprint, string? suffix)
    {
        var orgPart = organizationId is { } id ? id.ToString("N") : "global";
        var suffixPart = string.IsNullOrWhiteSpace(suffix) ? string.Empty : $":{suffix}";
        return $"jusplatform:query:{resource}:{orgPart}{suffixPart}:{fingerprint}";
    }

    private static string BuildIndexKey(string resource, Guid? organizationId, string? suffix)
    {
        var orgPart = organizationId is { } id ? id.ToString("N") : "global";
        var suffixPart = string.IsNullOrWhiteSpace(suffix) ? string.Empty : $":{suffix}";
        return $"jusplatform:query:index:{resource}:{orgPart}{suffixPart}";
    }
}

public sealed class NullQueryCache : IQueryCache
{
    public Task<string?> TryGetJsonAsync(string cacheKey, CancellationToken cancellationToken)
        => Task.FromResult<string?>(null);

    public Task SetJsonAsync(
        string cacheKey,
        string json,
        QueryCacheIndex index,
        TimeSpan ttl,
        CancellationToken cancellationToken)
        => Task.CompletedTask;

    public Task InvalidateAsync(
        string resource,
        Guid? organizationId,
        string? suffix = null,
        CancellationToken cancellationToken = default)
        => Task.CompletedTask;
}
