namespace JUSPlatform.Infrastructure.Caching;

public sealed class RedisCacheOptions
{
    public const string SectionName = "Redis";

    /// <summary>Connect to Redis (required for query cache and future uses).</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Cache GET list endpoint responses (paginated queries). Off by default in production.
    /// </summary>
    public bool QueryCacheEnabled { get; set; }

    public int QueryCacheSeconds { get; set; } = 60;
}
