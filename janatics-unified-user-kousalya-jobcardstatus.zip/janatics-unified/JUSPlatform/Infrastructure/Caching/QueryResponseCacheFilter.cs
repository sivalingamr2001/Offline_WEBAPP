using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using JUSPlatform.Application.Common;
using JUSPlatform.Middleware;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Caching;

/// <summary>
/// Caches successful paginated list responses when <c>Redis:QueryCacheEnabled</c> is true.
/// Applies only to endpoints named <c>list*</c> — no service-layer changes.
/// </summary>
public sealed class QueryResponseCacheFilter(
    IQueryCache queryCache,
    IOptions<RedisCacheOptions> options,
    ICurrentUser currentUser) : IAsyncActionFilter
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DictionaryKeyPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    private static readonly Dictionary<string, string> EndpointResources =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["listUsers"] = ListCacheKeys.Users,
            ["listRoles"] = ListCacheKeys.Roles,
            ["listPermissions"] = ListCacheKeys.Permissions,
            ["listAppModules"] = ListCacheKeys.AppModules,
            ["listAppMenus"] = ListCacheKeys.AppMenus
        };

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        if (!options.Value.QueryCacheEnabled)
        {
            await next();
            return;
        }

        var endpointName = context.ActionDescriptor.EndpointMetadata
            .OfType<IEndpointNameMetadata>()
            .FirstOrDefault()
            ?.EndpointName;

        if (endpointName is null
            || !endpointName.StartsWith("list", StringComparison.OrdinalIgnoreCase)
            || !EndpointResources.TryGetValue(endpointName, out var resource))
        {
            await next();
            return;
        }

        var fingerprint = BuildFingerprint(context);
        var orgId = resource == ListCacheKeys.Permissions ? null : currentUser.OrganizationId;
        var cacheKey = RedisQueryCache.BuildDataKey(resource, orgId, fingerprint, null);
        var index = new QueryCacheIndex(resource, orgId, null);

        var cachedJson = await queryCache.TryGetJsonAsync(cacheKey, context.HttpContext.RequestAborted);
        if (cachedJson is not null)
        {
            context.HttpContext.Response.Headers["X-Query-Cache"] = "HIT";
            context.Result = new ContentResult
            {
                Content = cachedJson,
                ContentType = ExceptionHandlingMiddleware.Json,
                StatusCode = StatusCodes.Status200OK
            };
            return;
        }

        context.HttpContext.Response.Headers["X-Query-Cache"] = "MISS";
        var executed = await next();

        if (executed.Result is not ObjectResult { StatusCode: StatusCodes.Status200OK, Value: { } value })
        {
            return;
        }

        if (!IsPagedResponse(value.GetType()))
        {
            return;
        }

        var json = JsonSerializer.Serialize(value, JsonOptions);
        var ttl = TimeSpan.FromSeconds(Math.Max(15, options.Value.QueryCacheSeconds));
        await queryCache.SetJsonAsync(cacheKey, json, index, ttl, context.HttpContext.RequestAborted);
    }

    private static string BuildFingerprint(ActionExecutingContext context)
    {
        var routePart = string.Join(
            '&',
            context.RouteData.Values
                .Where(x => x.Key is not ("controller" or "action"))
                .OrderBy(x => x.Key, StringComparer.Ordinal)
                .Select(x => $"{x.Key}={x.Value}"));

        var queryPart = context.HttpContext.Request.QueryString.Value ?? string.Empty;
        var raw = $"{routePart}|{queryPart}";
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(raw));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static bool IsPagedResponse(Type type) =>
        type.IsGenericType && type.GetGenericTypeDefinition() == typeof(ApiPagedResponse<>);
}
