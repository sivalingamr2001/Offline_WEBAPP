using JUSPlatform.Application.Jobs;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Infrastructure.Jobs;

public sealed class JobExecutionLogger(AppDbContext db, Guid jobRunId) : IJobExecutionLogger
{
    public Task InfoAsync(string message, CancellationToken cancellationToken) =>
        WriteAsync("Info", message, null, cancellationToken);

    public Task WarningAsync(string message, CancellationToken cancellationToken) =>
        WriteAsync("Warning", message, null, cancellationToken);

    public Task ErrorAsync(string message, Exception? exception, CancellationToken cancellationToken) =>
        WriteAsync("Error", message, exception?.ToString(), cancellationToken);

    private async Task WriteAsync(
        string level,
        string message,
        string? detail,
        CancellationToken cancellationToken)
    {
        db.JobLogEntries.Add(new JobLogEntry
        {
            JobRunId = jobRunId,
            Level = level,
            Message = message.Length > 500 ? message[..500] : message,
            Detail = detail is { Length: > 4000 } ? detail[..4000] : detail,
            CreatedAt = DateTimeOffset.UtcNow
        });
        await db.SaveChangesAsync(cancellationToken);
    }
}
