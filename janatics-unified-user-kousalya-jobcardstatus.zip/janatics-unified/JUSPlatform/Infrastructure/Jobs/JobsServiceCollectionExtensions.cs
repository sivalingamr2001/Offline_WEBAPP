using JUSPlatform.Application.Jobs;
using Microsoft.Extensions.DependencyInjection;

namespace JUSPlatform.Infrastructure.Jobs;

public static class JobsServiceCollectionExtensions
{
    public static IServiceCollection AddJUSPlatformJobs(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JobsOptions>(configuration.GetSection(JobsOptions.SectionName));
        services.AddScoped<JobHandlerRegistry>();
        services.AddScoped<JobRunner>();
        services.AddScoped<IJobService, JobService>();
        services.AddHostedService<JobWorkerService>();
        return services;
    }
}
