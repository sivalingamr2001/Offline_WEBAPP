using JUSPlatform.Application.Jobs;

namespace JUSPlatform.Infrastructure.Jobs;

/// <summary>No-op queue — the polling worker picks up jobs instead.</summary>
public sealed class NullJobExecutionQueue : IJobExecutionQueue
{
    public void Enqueue(Guid jobRunId)
    {
    }
}
