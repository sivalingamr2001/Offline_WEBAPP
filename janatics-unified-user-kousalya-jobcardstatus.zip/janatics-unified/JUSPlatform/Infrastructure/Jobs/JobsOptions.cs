namespace JUSPlatform.Infrastructure.Jobs;

public sealed class JobsOptions
{
    public const string SectionName = "Jobs";

    /// <summary>Process queued jobs in the background worker.</summary>
    public bool WorkerEnabled { get; set; } = true;

    public int MaxAttempts { get; set; } = 3;

    /// <summary>Poll interval when no jobs are waiting.</summary>
    public int PollIntervalSeconds { get; set; } = 2;

    /// <summary>Retry backoff base (seconds); attempt N waits base * 2^N.</summary>
    public int RetryBackoffSeconds { get; set; } = 10;
}
