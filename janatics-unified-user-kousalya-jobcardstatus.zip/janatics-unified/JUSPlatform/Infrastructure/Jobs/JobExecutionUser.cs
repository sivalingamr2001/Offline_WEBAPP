using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;

namespace JUSPlatform.Infrastructure.Jobs;

/// <summary>ICurrentUser for background job execution (no HTTP context).</summary>
public sealed class JobExecutionUser(Guid userId, Guid organizationId) : ICurrentUser
{
    public Guid? UserId { get; } = userId;
    public Guid? OrganizationId { get; } = organizationId;
    public string? RoleName => null;
    public bool IsAuthenticated => true;
    public IReadOnlyCollection<string> Permissions { get; } = Array.Empty<string>();
}
