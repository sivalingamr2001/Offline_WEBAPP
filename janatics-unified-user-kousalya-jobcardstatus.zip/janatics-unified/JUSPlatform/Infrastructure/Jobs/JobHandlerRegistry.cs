using JUSPlatform.Application.Jobs;
using JUSPlatform.Domain.Exceptions;

namespace JUSPlatform.Infrastructure.Jobs;

public sealed class JobHandlerRegistry(IEnumerable<IJobHandler> handlers)
{
    private readonly IReadOnlyDictionary<string, IJobHandler> _handlers =
        handlers.ToDictionary(x => x.JobType, StringComparer.OrdinalIgnoreCase);

    public IJobHandler GetHandler(string jobType) =>
        _handlers.TryGetValue(jobType, out var handler)
            ? handler
            : throw new BusinessRuleException($"Unknown job type '{jobType}'.");
}
