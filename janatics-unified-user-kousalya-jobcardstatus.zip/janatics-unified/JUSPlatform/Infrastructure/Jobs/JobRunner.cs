using System.Diagnostics;
using System.Text.Json;
using JUSPlatform.Application.Jobs;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Enums;
using JUSPlatform.Infrastructure.Bugsink;
using JUSPlatform.Infrastructure.Observability;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Jobs;

public sealed class JobRunner(
    AppDbContext db,
    JobHandlerRegistry handlers,
    IOptions<JobsOptions> options,
    IOptionsMonitor<BugsinkOptions> bugsinkOptions)
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public async Task RunAsync(Guid jobRunId, CancellationToken cancellationToken)
    {
        var job = await db.JobRuns
            .FirstOrDefaultAsync(x => x.Id == jobRunId, cancellationToken);

        if (job is null
            || job.Status is JobStatus.Succeeded or JobStatus.Dead)
        {
            return;
        }

        var logger = new JobExecutionLogger(db, jobRunId);
        var attempt = job.AttemptCount + 1;
        var now = DateTimeOffset.UtcNow;

        job.Status = JobStatus.Running;
        job.AttemptCount = attempt;
        job.StartedAt = now;
        job.ErrorMessage = null;
        await db.SaveChangesAsync(cancellationToken);

        await logger.InfoAsync($"Attempt {attempt}/{job.MaxAttempts} started.", cancellationToken);

        using var activity = StartActivity(job);
        try
        {
            var handler = handlers.GetHandler(job.JobType);
            using var payloadDoc = JsonDocument.Parse(job.PayloadJson);
            var result = await handler.ExecuteAsync(payloadDoc.RootElement.Clone(), logger, cancellationToken);

            job.Status = JobStatus.Succeeded;
            job.ResultJson = result is null ? null : JsonSerializer.Serialize(result, JsonOptions);
            job.CompletedAt = DateTimeOffset.UtcNow;
            job.NextRunAt = null;
            await db.SaveChangesAsync(cancellationToken);

            await logger.InfoAsync("Job succeeded.", cancellationToken);
            activity?.SetStatus(ActivityStatusCode.Ok);
        }
        catch (Exception ex)
        {
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            activity?.AddException(ex);

            job.ErrorMessage = ex.Message.Length > 2000 ? ex.Message[..2000] : ex.Message;
            job.CompletedAt = DateTimeOffset.UtcNow;

            if (attempt >= job.MaxAttempts)
            {
                job.Status = JobStatus.Dead;
                job.NextRunAt = null;
                await db.SaveChangesAsync(cancellationToken);
                await logger.ErrorAsync($"Job failed permanently after {attempt} attempts.", ex, cancellationToken);
                if (bugsinkOptions.CurrentValue.IsActive)
                {
                    BugsinkEventReporter.CaptureJobFailure(
                        job.Id,
                        job.JobType,
                        job.ErrorMessage ?? ex.Message,
                        job.TraceId,
                        job.OrganizationId);
                }
                return;
            }

            job.Status = JobStatus.Failed;
            var backoff = TimeSpan.FromSeconds(
                options.Value.RetryBackoffSeconds * Math.Pow(2, attempt - 1));
            job.NextRunAt = DateTimeOffset.UtcNow.Add(backoff);
            await db.SaveChangesAsync(cancellationToken);
            await logger.WarningAsync(
                $"Attempt {attempt} failed; retry scheduled in {(int)backoff.TotalSeconds}s.",
                cancellationToken);
            await logger.ErrorAsync(ex.Message, ex, cancellationToken);
        }
    }

    private static Activity? StartActivity(JobRun job)
    {
        var activity = JUSPlatformActivity.Source.StartActivity(
            $"job.{job.JobType}",
            ActivityKind.Internal);

        activity?.SetTag("job.id", job.Id);
        activity?.SetTag("job.type", job.JobType);
        activity?.SetTag("job.attempt", job.AttemptCount + 1);
        if (!string.IsNullOrWhiteSpace(job.TraceId))
        {
            activity?.SetTag("job.parent_trace_id", job.TraceId);
        }

        return activity;
    }
}
