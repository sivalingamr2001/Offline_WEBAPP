using JUSPlatform.Domain.Enums;
using JUSPlatform.Infrastructure.Hangfire;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Infrastructure.Jobs;

public sealed class JobWorkerService(
    IServiceScopeFactory scopeFactory,
    IOptions<JobsOptions> options,
    IOptions<HangfireOptions> hangfireOptions,
    ILogger<JobWorkerService> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (hangfireOptions.Value.Enabled)
        {
            logger.LogInformation("Job worker disabled (Hangfire:Enabled=true).");
            return;
        }

        if (!options.Value.WorkerEnabled)
        {
            logger.LogInformation("Job worker disabled (Jobs:WorkerEnabled=false).");
            return;
        }

        logger.LogInformation("Job worker started.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var processed = await TryProcessNextAsync(stoppingToken);
                if (!processed)
                {
                    await Task.Delay(
                        TimeSpan.FromSeconds(Math.Max(1, options.Value.PollIntervalSeconds)),
                        stoppingToken);
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Job worker poll failed; retrying after delay.");
                await Task.Delay(
                    TimeSpan.FromSeconds(Math.Max(1, options.Value.PollIntervalSeconds)),
                    stoppingToken);
            }
        }
    }

    private async Task<bool> TryProcessNextAsync(CancellationToken cancellationToken)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var runner = scope.ServiceProvider.GetRequiredService<JobRunner>();
        var now = DateTimeOffset.UtcNow;

        var jobId = await db.JobRuns
            .Where(x =>
                (x.Status == JobStatus.Queued
                 || (x.Status == JobStatus.Failed && x.NextRunAt != null && x.NextRunAt <= now))
                && (x.NextRunAt == null || x.NextRunAt <= now))
            .OrderBy(x => x.QueuedAt)
            .Select(x => x.Id)
            .FirstOrDefaultAsync(cancellationToken);

        if (jobId == Guid.Empty)
        {
            return false;
        }

        try
        {
            await runner.RunAsync(jobId, cancellationToken);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected error running job {JobId}", jobId);
        }

        return true;
    }
}
