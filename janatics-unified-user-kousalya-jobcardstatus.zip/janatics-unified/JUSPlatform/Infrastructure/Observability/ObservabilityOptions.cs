namespace JUSPlatform.Infrastructure.Observability;

/// <summary>
/// OpenTelemetry export (traces, metrics, logs) via OTLP. Disabled by default.
/// Legacy <c>Tracing</c> section is merged when <c>Observability</c> is absent.
/// </summary>
public sealed class ObservabilityOptions
{
    public const string SectionName = "Observability";
    public const string LegacyTracingSectionName = "Tracing";

    public bool Enabled { get; set; }

    /// <summary>OTLP gRPC endpoint, e.g. http://localhost:4317</summary>
    public string? OtlpEndpoint { get; set; }

    public string ServiceName { get; set; } = "JUSPlatform";

    public bool Traces { get; set; } = true;
    public bool Metrics { get; set; } = true;
    public bool Logs { get; set; } = true;

    public static ObservabilityOptions Bind(IConfiguration configuration)
    {
        var options = configuration.GetSection(SectionName).Get<ObservabilityOptions>()
            ?? new ObservabilityOptions();

        if (!HasExplicitObservabilityConfig(configuration))
        {
            var legacy = configuration.GetSection(LegacyTracingSectionName).Get<LegacyTracingOptions>();
            if (legacy is not null)
            {
                options.Enabled = legacy.Enabled;
                options.OtlpEndpoint ??= legacy.OtlpEndpoint;
                if (!string.IsNullOrWhiteSpace(legacy.ServiceName))
                {
                    options.ServiceName = legacy.ServiceName;
                }
            }
        }

        return options;
    }

    private static bool HasExplicitObservabilityConfig(IConfiguration configuration)
    {
        var section = configuration.GetSection(SectionName);
        return section.Exists()
               && (section.GetValue<bool?>("Enabled") is not null
                   || !string.IsNullOrWhiteSpace(section["OtlpEndpoint"]));
    }

    private sealed class LegacyTracingOptions
    {
        public bool Enabled { get; set; }
        public string? OtlpEndpoint { get; set; }
        public string ServiceName { get; set; } = "JUSPlatform";
    }
}
