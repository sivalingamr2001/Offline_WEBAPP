using System.Diagnostics;

namespace JUSPlatform.Infrastructure.Observability;

public static class JUSPlatformActivity
{
    public const string SourceName = "JUSPlatform";

    public static readonly ActivitySource Source = new(SourceName, "1.0.0");

    public static Activity? StartOutbound(string system, string operation) =>
        Source.StartActivity($"{system}.{operation}", ActivityKind.Client);

    public static string? CurrentTraceId =>
        Activity.Current?.TraceId.ToString();
}
