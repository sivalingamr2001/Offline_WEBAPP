using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace JUSPlatform.Infrastructure.Observability;

public static class ObservabilityExtensions
{
    public static IServiceCollection AddJUSPlatformObservability(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var options = ObservabilityOptions.Bind(configuration);
        services.Configure<ObservabilityOptions>(configuration.GetSection(ObservabilityOptions.SectionName));

        if (!options.Enabled || string.IsNullOrWhiteSpace(options.OtlpEndpoint))
        {
            return services;
        }

        var otlpEndpoint = new Uri(options.OtlpEndpoint);

        services.AddOpenTelemetry()
            .ConfigureResource(resource => resource.AddService(options.ServiceName))
            .WithTracing(tracing =>
            {
                if (!options.Traces)
                {
                    return;
                }

                tracing
                    .AddSource(JUSPlatformActivity.SourceName)
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddOtlpExporter(otlp => otlp.Endpoint = otlpEndpoint);
            })
            .WithMetrics(metrics =>
            {
                if (!options.Metrics)
                {
                    return;
                }

                metrics
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddRuntimeInstrumentation()
                    .AddOtlpExporter(otlp => otlp.Endpoint = otlpEndpoint);
            })
            .WithLogging(logging =>
            {
                if (!options.Logs)
                {
                    return;
                }

                logging.AddOtlpExporter(otlp => otlp.Endpoint = otlpEndpoint);
            },
            loggerOptions =>
            {
                loggerOptions.IncludeFormattedMessage = true;
                loggerOptions.IncludeScopes = true;
            });

        return services;
    }
}
