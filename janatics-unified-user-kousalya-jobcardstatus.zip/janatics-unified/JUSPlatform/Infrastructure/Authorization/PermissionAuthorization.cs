using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;

namespace JUSPlatform.Infrastructure.Authorization;

public sealed class PermissionRequirement(string permission) : IAuthorizationRequirement
{
    public string Permission { get; } = permission;
}

public sealed class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PermissionRequirement requirement)
    {
        var roleName = context.User.FindFirst(ClaimTypesExt.RoleName)?.Value;
        if (SystemRoles.IsSuperAdmin(roleName))
        {
            context.Succeed(requirement);
            return Task.CompletedTask;
        }

        var hasPermission = context.User.Claims.Any(c =>
            c.Type == ClaimTypesExt.Permission &&
            string.Equals(c.Value, requirement.Permission, StringComparison.OrdinalIgnoreCase));

        if (hasPermission)
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

public static class AuthorizationExtensions
{
    public static IServiceCollection AddPermissionPolicies(this IServiceCollection services)
    {
        services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();
        services.AddAuthorization(options =>
        {
            void Add(string policy, string permission) =>
                options.AddPolicy(policy, p => p.Requirements.Add(new PermissionRequirement(permission)));

            Add(Policies.OrgsRead, Permissions.OrgsRead);
            Add(Policies.OrgsWrite, Permissions.OrgsWrite);
            Add(Policies.UsersRead, Permissions.UsersRead);
            Add(Policies.UsersWrite, Permissions.UsersWrite);
            Add(Policies.RolesRead, Permissions.RolesRead);
            Add(Policies.RolesWrite, Permissions.RolesWrite);
            Add(Policies.JobsRead, Permissions.JobsRead);
            Add(Policies.JobsWrite, Permissions.JobsWrite);
            Add(Policies.ModulesRead, Permissions.ModulesRead);
            Add(Policies.ModulesWrite, Permissions.ModulesWrite);
            Add(Policies.MenusRead, Permissions.MenusRead);
            Add(Policies.MenusWrite, Permissions.MenusWrite);
            Add(Policies.PesView, Permissions.PesView);
            Add(Policies.PesEdit, Permissions.PesEdit);
            Add(Policies.JobCardView, Permissions.JobCardView);
        });

        return services;
    }
}
