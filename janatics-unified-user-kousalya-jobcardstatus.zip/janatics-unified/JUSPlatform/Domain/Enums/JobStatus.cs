using System.Text.Json.Serialization;

namespace JUSPlatform.Domain.Enums;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum JobStatus
{
    Queued = 0,
    Running = 1,
    Succeeded = 2,
    Failed = 3,
    Dead = 4
}
