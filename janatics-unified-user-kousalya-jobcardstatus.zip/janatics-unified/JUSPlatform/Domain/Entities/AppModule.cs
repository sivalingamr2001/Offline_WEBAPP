using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

public sealed class AppModule : EntityBase
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Icon { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<AppMenu> Menus { get; set; } = new List<AppMenu>();
}
