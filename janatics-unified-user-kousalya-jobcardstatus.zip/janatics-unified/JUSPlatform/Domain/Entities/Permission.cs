using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

public sealed class Permission : EntityBase
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Module { get; set; } = string.Empty;

    public ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
}
