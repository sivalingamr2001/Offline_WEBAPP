using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

public sealed class Organization : EntityBase
{
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public int? OperatingUnitId { get; set; }
    public long? OracleOrgId { get; set; }
    public string? UnitName { get; set; }

    public ICollection<User> Users { get; set; } = new List<User>();
    public ICollection<Role> Roles { get; set; } = new List<Role>();
}
