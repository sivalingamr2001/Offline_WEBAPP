using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

/// <summary>
/// Platform SuperAdmin role has <see cref="OrganizationId"/> null. All other roles belong to one organization.
/// </summary>
public sealed class Role : EntityBase
{
    public Guid? OrganizationId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsSystem { get; set; }

    public Organization? Organization { get; set; }
    public ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
    public ICollection<RoleMenu> RoleMenus { get; set; } = new List<RoleMenu>();
    public ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();
}
