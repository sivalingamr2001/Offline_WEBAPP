using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

/// <summary>
/// Oracle operating unit. <see cref="OrgId"/> is the Oracle business key; <see cref="EntityBase.Id"/> is the platform PK.
/// </summary>
public sealed class OperatingUnit : EntityBase
{
    public int OrgId { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
}
