using JUSPlatform.Domain.Enums;

namespace JUSPlatform.Domain.Entities;

public sealed class JobRun
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid OrganizationId { get; set; }
    public Guid CreatedByUserId { get; set; }
    public string JobType { get; set; } = string.Empty;
    public JobStatus Status { get; set; } = JobStatus.Queued;
    public string PayloadJson { get; set; } = "{}";
    public string? ResultJson { get; set; }
    public string? ErrorMessage { get; set; }
    public string? TraceId { get; set; }
    public int AttemptCount { get; set; }
    public int MaxAttempts { get; set; } = 3;
    public DateTimeOffset QueuedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? NextRunAt { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }

    public ICollection<JobLogEntry> Logs { get; set; } = [];
}

public sealed class JobLogEntry
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid JobRunId { get; set; }
    public JobRun? JobRun { get; set; }
    public string Level { get; set; } = "Info";
    public string Message { get; set; } = string.Empty;
    public string? Detail { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
