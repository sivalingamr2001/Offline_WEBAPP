using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

public sealed class AppMenu : EntityBase
{
    public Guid ModuleId { get; set; }
    public Guid? ParentId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? DisplayName { get; set; }
    public string? Path { get; set; }
    public string? MenuPath { get; set; }
    public string? Icon { get; set; }
    public string? MenuIcon { get; set; }
    public Guid? ParentMenuId { get; set; }
    public string MenuType { get; set; } = "SCREEN";
    public string Nature { get; set; } = "TENANT";
    public string? ResourceCode { get; set; }
    public int SortOrder { get; set; }
    public string? PermissionCode { get; set; }
    public bool IsActive { get; set; } = true;

    public AppModule? Module { get; set; }
    public AppMenu? Parent { get; set; }
    public ICollection<AppMenu> Children { get; set; } = new List<AppMenu>();
    public ICollection<RoleMenu> RoleMenus { get; set; } = new List<RoleMenu>();
}
