using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

public sealed class UserAccessRight : EntityBase
{
    public Guid UserId { get; set; }
    public Guid OrganizationId { get; set; }
    public int? OperatingUnit { get; set; }
    public decimal? LimitValue { get; set; }
    public string AccessChannel { get; set; } = "WEB";
    public bool IsActive { get; set; } = true;
    public string? Remarks { get; set; }

    public User? User { get; set; }
    public Organization? Organization { get; set; }
}
