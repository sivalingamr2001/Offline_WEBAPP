using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

/// <summary>
/// Platform SuperAdmin has <see cref="OrganizationId"/> null. Org users always belong to one organization.
/// </summary>
public sealed class User : EntityBase
{
    public Guid? OrganizationId { get; set; }
    /// <summary>Live SQL stores the assigned role on <c>users.role_id</c> as well as <c>user_roles</c>.</summary>
    public Guid? RoleId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string? Designation { get; set; }
    public string PasswordHash { get; set; } = string.Empty;
    public string? AvatarPath { get; set; }
    public bool IsActive { get; set; } = true;
    public string? UserCode { get; set; }
    public string? EmpId { get; set; }

    public Organization? Organization { get; set; }
    public Role? Role { get; set; }
    public ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();
    public ICollection<UserAccessRight> AccessRights { get; set; } = new List<UserAccessRight>();
}
