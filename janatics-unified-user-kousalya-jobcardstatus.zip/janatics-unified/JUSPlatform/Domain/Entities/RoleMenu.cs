using JUSPlatform.Domain.Common;

namespace JUSPlatform.Domain.Entities;

public sealed class RoleMenu : EntityBase
{
    public Guid RoleId { get; set; }
    public Guid ModuleId { get; set; }
    public Guid MenuId { get; set; }
    public bool CanCreate { get; set; }
    public bool CanRead { get; set; } = true;
    public bool CanUpdate { get; set; }
    public bool CanDelete { get; set; }
    public bool CanExport { get; set; }
    public bool CanApprove { get; set; }

    public Role? Role { get; set; }
    public AppModule? Module { get; set; }
    public AppMenu? Menu { get; set; }
}
