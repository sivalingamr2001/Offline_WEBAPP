using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Common;
using JUSPlatform.Infrastructure.RateLimiting;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace JUSPlatform.Controllers;

public sealed partial class AuthController
{
    [HttpPost("register")]
    [AllowAnonymous]
    [EnableRateLimiting(RateLimitPolicies.AuthStrict)]
    [EndpointName("registerAccount")]
    [EndpointSummary("Register company account")]
    [EndpointDescription("Creates a new organization and the first Admin user.")]
    [ProducesResponseType<LoginResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status429TooManyRequests, "application/json")]
    public async Task<ActionResult<LoginResponse>> Register(
        [FromBody] RegisterRequest request,
        CancellationToken cancellationToken)
        => Ok(await authService.RegisterAsync(request, cancellationToken));

    [HttpPost("forgot-password")]
    [AllowAnonymous]
    [EnableRateLimiting(RateLimitPolicies.AuthStrict)]
    [EndpointName("forgotPassword")]
    [EndpointSummary("Request password reset")]
    [ProducesResponseType<MessageResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status429TooManyRequests, "application/json")]
    public async Task<ActionResult<MessageResponse>> ForgotPassword(
        [FromBody] ForgotPasswordRequest request,
        CancellationToken cancellationToken)
        => Ok(await authService.ForgotPasswordAsync(request, cancellationToken));

    [HttpPost("reset-password")]
    [AllowAnonymous]
    [EnableRateLimiting(RateLimitPolicies.Auth)]
    [EndpointName("resetPassword")]
    [EndpointSummary("Reset password")]
    [ProducesResponseType<MessageResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status429TooManyRequests, "application/json")]
    public async Task<ActionResult<MessageResponse>> ResetPassword(
        [FromBody] ResetPasswordRequest request,
        CancellationToken cancellationToken)
        => Ok(await authService.ResetPasswordAsync(request, cancellationToken));

    [HttpPost("change-password")]
    [Authorize]
    [EndpointName("changePassword")]
    [EndpointSummary("Change password")]
    [EndpointDescription("Change password for the signed-in user.")]
    [ProducesResponseType<MessageResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    public async Task<ActionResult<MessageResponse>> ChangePassword(
        [FromBody] ChangePasswordRequest request,
        CancellationToken cancellationToken)
        => Ok(await authService.ChangePasswordAsync(request, cancellationToken));

    [HttpPost("logout")]
    [Authorize]
    [EndpointName("logout")]
    [EndpointSummary("Logout")]
    [EndpointDescription("Revokes the current JWT so it cannot be reused.")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    public async Task<IActionResult> Logout(CancellationToken cancellationToken)
    {
        var jti = User.FindFirst(JwtRegisteredClaimNames.Jti)?.Value;
        var expClaim = User.FindFirst(JwtRegisteredClaimNames.Exp)?.Value;
        if (string.IsNullOrWhiteSpace(jti) || !long.TryParse(expClaim, out var expUnix))
        {
            return Unauthorized();
        }

        var expiresAt = DateTimeOffset.FromUnixTimeSeconds(expUnix);
        await authService.LogoutAsync(jti, expiresAt, cancellationToken);
        return NoContent();
    }
}
