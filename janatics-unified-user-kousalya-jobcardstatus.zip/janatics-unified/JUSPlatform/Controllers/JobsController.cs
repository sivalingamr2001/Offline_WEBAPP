using System.ComponentModel;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.Jobs;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/jobs")]
[Tags("Jobs")]
[Authorize]
[Produces("application/json")]
public sealed class JobsController(IJobService service) : ControllerBase
{
    [HttpPost]
    [Authorize(Policy = Policies.JobsWrite)]
    [EndpointName("enqueueJob")]
    [EndpointSummary("Enqueue background job")]
    [EndpointDescription(
        "Queues a durable background job. Returns 202 with a job id — poll GET /jobs/{id} until status is Succeeded, Failed, or Dead.")]
    [ProducesResponseType<JobAcceptedResponse>(StatusCodes.Status202Accepted)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<JobAcceptedResponse>> Enqueue(
        [FromBody] EnqueueJobRequest request,
        CancellationToken cancellationToken)
    {
        var accepted = await service.EnqueueAsync(request, cancellationToken);
        return AcceptedAtAction(nameof(Get), new { id = accepted.Id }, accepted);
    }

    [HttpGet]
    [Authorize(Policy = Policies.JobsRead)]
    [EndpointName("listJobs")]
    [EndpointSummary("List background jobs")]
    [EndpointDescription("Lists background jobs in your organization.")]
    [ProducesResponseType<ApiPagedResponse<JobRunDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<JobRunDto>>> List(
        [FromQuery] JobListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListAsync(query, cancellationToken));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = Policies.JobsRead)]
    [EndpointName("getJob")]
    [EndpointSummary("Get job status")]
    [EndpointDescription("Poll job status, logs, and result. Terminal states: Succeeded, Failed, Dead.")]
    [ProducesResponseType<JobRunDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<JobRunDto>> Get(
        [Description("Job id returned from enqueue.")] Guid id,
        CancellationToken cancellationToken)
    {
        var job = await service.GetAsync(id, cancellationToken);
        return job is null ? NotFound() : Ok(job);
    }
}
