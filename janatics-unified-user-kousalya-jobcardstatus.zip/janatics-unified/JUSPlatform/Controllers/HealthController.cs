using JUSPlatform.Application.Common;
using JUSPlatform.Application.Oracle;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Controllers;

[ApiController]
[AllowAnonymous]
[DisableRateLimiting]
[Tags("Health")]
[Produces("application/problem+json")]
public sealed class HealthController(AppDbContext db, IOracleConnectionService oracleConnection) : ControllerBase
{
    [HttpGet("/api")]
    [EndpointName("ping")]
    [EndpointSummary("Ping")]
    [EndpointDescription("Confirms the service is reachable.")]
    [ProducesResponseType<PingResponse>(StatusCodes.Status200OK)]
    public ActionResult<PingResponse> Ping()
        => Ok(new PingResponse("ok", "pong", DateTimeOffset.UtcNow));

    [HttpGet("/api/heath")]
    [EndpointName("getHealth")]
    [EndpointSummary("Health check")]
    [EndpointDescription("Checks whether the service is ready to handle requests.")]
    [ProducesResponseType<HealthResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<HealthResponse>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<HealthResponse>> Health(CancellationToken cancellationToken)
    {
        var databaseHealthy = await db.Database.CanConnectAsync(cancellationToken);
        var payload = new HealthResponse(
            databaseHealthy ? "healthy" : "unhealthy",
            "up",
            databaseHealthy ? "up" : "down",
            DateTimeOffset.UtcNow);

        return databaseHealthy
            ? Ok(payload)
            : StatusCode(StatusCodes.Status503ServiceUnavailable, payload);
    }

    [HttpGet("/api/oracle/connection")]
    [EndpointName("getOracleConnection")]
    [EndpointSummary("Oracle connection test")]
    [EndpointDescription("Probes Oracle when Oracle:Enabled is true. Does not return host, user, or password.")]
    [ProducesResponseType<OracleConnectionResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<OracleConnectionResponse>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<OracleConnectionResponse>> OracleConnection(CancellationToken cancellationToken)
    {
        var payload = await oracleConnection.TestAsync(cancellationToken);
        return payload.Status == "disconnected"
            ? StatusCode(StatusCodes.Status503ServiceUnavailable, payload)
            : Ok(payload);
    }
}
