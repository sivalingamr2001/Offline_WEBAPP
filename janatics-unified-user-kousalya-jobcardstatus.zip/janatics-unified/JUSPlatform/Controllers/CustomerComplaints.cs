using JUSPlatform.Application.Common;
using JUSPlatform.Application.CustomerComplaint;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/customer-complaints")]
[Tags("CustomerComplaint")]
[Authorize]
[Produces("application/json")]
public sealed class CustomerComplaintsController(ICustomerComplaintService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.PesView)]
    [EndpointName("getCustomerComplaints")]
    [EndpointSummary("Customer complaints overview")]
    [EndpointDescription("Week-to-date complaints scoped by user_access_rights (derived_org_id) and jan_custodian_lines (custodian_code via users.emp_id).")]
    [ProducesResponseType<ComplaintsOverviewDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public Task<ActionResult<ComplaintsOverviewDto>> Get(
        [FromQuery] ComplaintsOverviewQuery query,
        CancellationToken cancellationToken)
        => GetOverview(query, cancellationToken);

    [HttpGet("overview")]
    [Authorize(Policy = Policies.PesView)]
    [EndpointName("getCustomerComplaintsOverview")]
    [EndpointSummary("Customer complaints overview")]
    [ProducesResponseType<ComplaintsOverviewDto>(StatusCodes.Status200OK)]
    public async Task<ActionResult<ComplaintsOverviewDto>> GetOverview(
        [FromQuery] ComplaintsOverviewQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.GetComplaintsOverviewAsync(query, cancellationToken));

    [HttpGet("weeks")]
    [Authorize(Policy = Policies.PesView)]
    [EndpointName("listCustomerComplaintWeeks")]
    [EndpointSummary("Weeks that have complaint rows")]
    [EndpointDescription("Monday week-starts that have leftover complaint dates for the user's assigned orgs and custodian codes.")]
    [ProducesResponseType<IReadOnlyList<ComplaintsWeekOptionDto>>(StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<ComplaintsWeekOptionDto>>> ListWeeks(
        [FromQuery] Guid? organizationId,
        CancellationToken cancellationToken)
        => Ok(await service.ListAvailableWeeksAsync(organizationId, cancellationToken));
}
