using JUSPlatform.Application.Auth;
using JUSPlatform.Application.Common;
using JUSPlatform.Infrastructure.RateLimiting;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/auth")]
[Tags("Auth")]
[Produces("application/json")]
public sealed partial class AuthController(IAuthService authService) : ControllerBase
{
    [HttpPost("login")]
    [AllowAnonymous]
    [EnableRateLimiting(RateLimitPolicies.Auth)]
    [EndpointName("login")]
    [EndpointSummary("Login")]
    [EndpointDescription("Sign in with email and password. Returns an access token on success.")]
    [ProducesResponseType<LoginResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status429TooManyRequests, "application/json")]
    public async Task<ActionResult<LoginResponse>> Login(
        [FromBody] LoginRequest request,
        CancellationToken cancellationToken)
    {
        var result = await authService.LoginAsync(request, cancellationToken);
        return Ok(result);
    }
}
