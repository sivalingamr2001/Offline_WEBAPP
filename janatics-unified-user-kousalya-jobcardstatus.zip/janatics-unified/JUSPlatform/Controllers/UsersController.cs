using System.ComponentModel;
using JUSPlatform.Application.Access;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.Users;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/users")]
[Tags("Users")]
[Authorize]
[Produces("application/json")]
public sealed class UsersController(IUserService service) : ControllerBase
{
    [HttpGet("me")]
    [EndpointName("getCurrentUser")]
    [EndpointSummary("Get current user")]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    public async Task<ActionResult<UserDto>> Me(CancellationToken cancellationToken)
        => Ok(await service.GetCurrentAsync(cancellationToken));

    [HttpPut("me")]
    [EndpointName("updateCurrentUser")]
    [EndpointSummary("Update current user")]
    [EndpointDescription("Updates your profile. Any signed-in user can set their own designation.")]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<UserDto>> UpdateMine(
        [FromBody] UpdateCurrentUserRequest request,
        CancellationToken cancellationToken)
        => Ok(await service.UpdateCurrentAsync(request, cancellationToken));

    [HttpPost("me/avatar")]
    [Consumes("multipart/form-data")]
    [EndpointName("uploadUserAvatar")]
    [EndpointSummary("Upload avatar")]
    [EndpointDescription("Upload a JPEG avatar for the current user (max 200 KB).")]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    public async Task<ActionResult<UserDto>> UploadAvatar(
        IFormFile file,
        CancellationToken cancellationToken)
    {
        if (file.Length == 0)
        {
            throw new BusinessRuleException("Avatar file is required.");
        }

        await using var stream = file.OpenReadStream();
        return Ok(await service.UploadAvatarAsync(stream, cancellationToken));
    }

    [HttpGet]
    [Authorize(Policy = Policies.UsersRead)]
    [EndpointName("listUsers")]
    [EndpointSummary("List users")]
    [EndpointDescription("Lists users in your organization. SuperAdmin lists all users. Supports page, search, sort, and filters.")]
    [ProducesResponseType<ApiPagedResponse<UserDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<UserDto>>> List(
        [FromQuery] UserListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListAsync(query, cancellationToken));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = Policies.UsersRead)]
    [EndpointName("getUser")]
    [EndpointSummary("Get user")]
    [EndpointDescription("Returns a user by id.")]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<UserDto>> Get(
        [Description("User id.")] Guid id,
        CancellationToken cancellationToken)
    {
        var user = await service.GetAsync(id, cancellationToken);
        return user is null ? NotFound() : Ok(user);
    }

    [HttpPost]
    [Authorize(Policy = Policies.UsersWrite)]
    [EndpointName("createUser")]
    [EndpointSummary("Create user")]
    [EndpointDescription("Adds a user. SuperAdmin creates the person without an organization; membership is assigned separately.")]
    [ProducesResponseType<UserDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<UserDto>> Create(
        [FromBody] CreateUserRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
    }

    [HttpPut("{id:guid}")]
    [Authorize(Policy = Policies.UsersWrite)]
    [EndpointName("updateUser")]
    [EndpointSummary("Update user")]
    [EndpointDescription("Updates a user in your organization.")]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<UserDto>> Update(
        [Description("User id.")] Guid id,
        [FromBody] UpdateUserRequest request,
        CancellationToken cancellationToken)
        => Ok(await service.UpdateAsync(id, request, cancellationToken));

    [HttpGet("{id:guid}/access-rights")]
    [Authorize(Policy = Policies.UsersRead)]
    [EndpointName("listUserAccessRights")]
    [EndpointSummary("List user access rights")]
    [EndpointDescription("Lists extra menu access rights assigned directly to the user.")]
    [ProducesResponseType<IReadOnlyList<MenuAccessDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IReadOnlyList<MenuAccessDto>>> ListAccessRights(
        [Description("User id.")] Guid id,
        CancellationToken cancellationToken)
        => Ok(await service.ListAccessRightsAsync(id, cancellationToken));

    [HttpPut("{id:guid}/access-rights")]
    [Authorize(Policy = Policies.UsersWrite)]
    [EndpointName("replaceUserAccessRights")]
    [EndpointSummary("Replace user access rights")]
    [EndpointDescription("Replaces extra menu access rights for a user. These add to the menus granted by the user's role.")]
    [ProducesResponseType<IReadOnlyList<MenuAccessDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IReadOnlyList<MenuAccessDto>>> ReplaceAccessRights(
        [Description("User id.")] Guid id,
        [FromBody] IReadOnlyList<MenuAccessDto> rights,
        CancellationToken cancellationToken)
        => Ok(await service.ReplaceAccessRightsAsync(id, rights, cancellationToken));
}
