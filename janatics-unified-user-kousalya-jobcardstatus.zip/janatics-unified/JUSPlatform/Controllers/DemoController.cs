using JUSPlatform.Application.Common;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[ApiExplorerSettings(IgnoreApi = true)]
[Route("api/v1/demo")]
[Produces("application/json")]
public sealed class DemoController(IConfiguration configuration) : ControllerBase
{
    /// <summary>
    /// Throws an unhandled 500 for local Bugsink / error-response testing.
    /// Hidden (404) unless <c>AppDebug</c> is true.
    /// </summary>
    [HttpPost("trigger-error")]
    [EndpointName("triggerDebugError")]
    [EndpointSummary("Trigger intentional server error")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status500InternalServerError, "application/json")]
    public ActionResult TriggerDebugError([FromQuery] string? message = null)
    {
        if (!configuration.GetValue("AppDebug", false))
        {
            return NotFound();
        }

        throw new InvalidOperationException(
            string.IsNullOrWhiteSpace(message)
                ? "Intentional debug error for Bugsink and observability testing."
                : message.Trim());
    }
}
