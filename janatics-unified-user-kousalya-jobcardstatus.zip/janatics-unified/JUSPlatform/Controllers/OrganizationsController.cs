using JUSPlatform.Application.Common;
using JUSPlatform.Application.Organizations;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/organizations")]
[Tags("Organizations")]
[Authorize]
[Produces("application/json")]
public sealed class OrganizationsController(IOrganizationService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.OrgsRead)]
    [EndpointName("listOrganizations")]
    [EndpointSummary("List organizations")]
    [EndpointDescription("Platform owner: lists all organizations.")]
    [ProducesResponseType<ApiPagedResponse<OrganizationDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<OrganizationDto>>> List(
        [FromQuery] PagedListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListAsync(query, cancellationToken));

    [HttpGet("me")]
    [Authorize(Policy = Policies.OrgsRead)]
    [EndpointName("getCurrentOrganization")]
    [EndpointSummary("Get current organization")]
    [EndpointDescription("Returns your organization profile.")]
    [ProducesResponseType<OrganizationDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<OrganizationDto>> GetMine(CancellationToken cancellationToken)
        => Ok(await service.GetCurrentAsync(cancellationToken));

    [HttpPut("me")]
    [Authorize(Policy = Policies.OrgsWrite)]
    [EndpointName("updateCurrentOrganization")]
    [EndpointSummary("Update current organization")]
    [EndpointDescription("Updates your organization profile.")]
    [ProducesResponseType<OrganizationDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<OrganizationDto>> UpdateMine(
        [FromBody] UpdateOrganizationRequest request,
        CancellationToken cancellationToken)
        => Ok(await service.UpdateCurrentAsync(request, cancellationToken));

    [HttpPost]
    [Authorize(Policy = Policies.OrgsWrite)]
    [EndpointName("createOrganization")]
    [EndpointSummary("Create organization")]
    [EndpointDescription("Platform owner: creates a new organization.")]
    [ProducesResponseType<OrganizationDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<OrganizationDto>> Create(
        [FromBody] CreateOrganizationRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreateAsync(request, cancellationToken);
        return Created($"/api/v1/organizations/{created.Id}", created);
    }
}
