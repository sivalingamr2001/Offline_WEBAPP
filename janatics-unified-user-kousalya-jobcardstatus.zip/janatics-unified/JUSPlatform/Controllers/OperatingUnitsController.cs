using JUSPlatform.Application.Common;
using JUSPlatform.Application.Organizations;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/operating-units")]
[Tags("OperatingUnits")]
[Authorize]
[Produces("application/json")]
public sealed class OperatingUnitsController(IOperatingUnitService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.OrgsRead)]
    [EndpointName("listOperatingUnits")]
    [EndpointSummary("List operating units")]
    [EndpointDescription("Platform owner: lists Oracle operating units.")]
    [ProducesResponseType<ApiPagedResponse<OperatingUnitDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<OperatingUnitDto>>> List(
        [FromQuery] PagedListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListAsync(query, cancellationToken));

    [HttpPost]
    [Authorize(Policy = Policies.OrgsWrite)]
    [EndpointName("createOperatingUnit")]
    [EndpointSummary("Create operating unit")]
    [EndpointDescription("Platform owner: creates an operating unit. Oracle org_id is unique.")]
    [ProducesResponseType<OperatingUnitDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<OperatingUnitDto>> Create(
        [FromBody] CreateOperatingUnitRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreateAsync(request, cancellationToken);
        return Created($"/api/v1/operating-units/{created.Id}", created);
    }
}
