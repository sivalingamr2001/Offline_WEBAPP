using JUSPlatform.Application.AppCatalog;
using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/app-modules")]
[Tags("AppModules")]
[Authorize]
[Produces("application/json")]
public sealed class AppModulesController(IAppCatalogService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.ModulesRead)]
    [EndpointName("listAppModules")]
    [EndpointSummary("List app modules")]
    [EndpointDescription("Lists catalog modules from public.app_modules.")]
    [ProducesResponseType<ApiPagedResponse<AppModuleDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<AppModuleDto>>> List(
        [FromQuery] PagedListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListModulesAsync(query, cancellationToken));

    [HttpPost]
    [Authorize(Policy = Policies.ModulesWrite)]
    [EndpointName("createAppModule")]
    [EndpointSummary("Create app module")]
    [ProducesResponseType<AppModuleDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<AppModuleDto>> Create(
        [FromBody] CreateAppModuleRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreateModuleAsync(request, cancellationToken);
        return Created($"/api/v1/app-modules/{created.Id}", created);
    }
}
