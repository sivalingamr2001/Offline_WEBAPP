using System.ComponentModel;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.Users;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/users/{userId:guid}/organizations")]
[Tags("Users")]
[Authorize]
[Produces("application/json")]
public sealed class UserOrganizationsController(IUserService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.UsersRead)]
    [EndpointName("listUserOrganizations")]
    [EndpointSummary("List user organizations")]
    [EndpointDescription("Lists organizations the user may work in (user_access_rights membership).")]
    [ProducesResponseType<IReadOnlyList<UserOrganizationDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IReadOnlyList<UserOrganizationDto>>> List(
        [Description("User id.")] Guid userId,
        CancellationToken cancellationToken)
        => Ok(await service.ListOrganizationsAsync(userId, cancellationToken));

    [HttpPut]
    [Authorize(Policy = Policies.UsersWrite)]
    [EndpointName("replaceUserOrganizations")]
    [EndpointSummary("Replace user organizations")]
    [EndpointDescription("Replaces which organizations the user may work in. SuperAdmin only.")]
    [Consumes("application/json")]
    [ProducesResponseType<IReadOnlyList<UserOrganizationDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IReadOnlyList<UserOrganizationDto>>> Replace(
        [Description("User id.")] Guid userId,
        [FromBody] List<UserOrganizationAssignment>? assignments,
        CancellationToken cancellationToken)
        => Ok(await service.ReplaceOrganizationsAsync(userId, assignments ?? [], cancellationToken));
}
