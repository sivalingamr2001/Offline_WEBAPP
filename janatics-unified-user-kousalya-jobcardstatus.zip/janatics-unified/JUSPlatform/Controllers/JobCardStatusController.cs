using JUSPlatform.Application.Common;
using JUSPlatform.Application.JobCard;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/job-card-status")]
[Tags("JobCardStatus")]
[Authorize]
[Produces("application/json")]
public sealed class JobCardStatusController(IJobCardStatusService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.JobCardView)]
    [EndpointName("getJobCardStatus")]
    [EndpointSummary("OSP job-card status")]
    [EndpointDescription("Lists JAN_WIP_TEST jobs scoped by user_access_rights (oracle_org_id) and jan_custodian_lines (custodian_code via users.emp_id).")]
    [ProducesResponseType<JobCardScreenDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<JobCardScreenDto>> Get(
        [FromQuery] JobCardQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.GetScreenAsync(query, cancellationToken));

    [HttpGet("{wipEntityId}")]
    [Authorize(Policy = Policies.JobCardView)]
    [EndpointName("getJobCardStatusJob")]
    [EndpointSummary("One OSP job-card")]
    [ProducesResponseType<JobCardRowDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<JobCardRowDto>> GetJob(
        decimal wipEntityId,
        CancellationToken cancellationToken)
        => Ok(await service.GetJobAsync(wipEntityId, cancellationToken));
}
