using System.ComponentModel;
using JUSPlatform.Application.Common;
using JUSPlatform.Application.Roles;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/roles")]
[Tags("Roles")]
[Authorize]
[Produces("application/json")]
public sealed class RolesController(IRoleService service) : ControllerBase
{
    [HttpGet("permissions")]
    [Authorize(Policy = Policies.RolesRead)]
    [EndpointName("listPermissions")]
    [EndpointSummary("List permissions")]
    [EndpointDescription("Lists permissions you can assign to roles. Supports page, search, sort, and module filter.")]
    [ProducesResponseType<ApiPagedResponse<PermissionDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<PermissionDto>>> Permissions(
        [FromQuery] PermissionListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListPermissionsAsync(query, cancellationToken));

    [HttpPost("permissions")]
    [Authorize(Policy = Policies.RolesWrite)]
    [EndpointName("createPermission")]
    [EndpointSummary("Create permission")]
    [EndpointDescription("Platform owner: adds a permission code that can be assigned to roles.")]
    [ProducesResponseType<PermissionDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<PermissionDto>> CreatePermission(
        [FromBody] CreatePermissionRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreatePermissionAsync(request, cancellationToken);
        return Created($"/api/v1/roles/permissions/{created.Id}", created);
    }

    [HttpPut("permissions/{id:guid}")]
    [Authorize(Policy = Policies.RolesWrite)]
    [EndpointName("updatePermission")]
    [EndpointSummary("Update permission")]
    [EndpointDescription("Platform owner: updates a permission name, code, or module.")]
    [ProducesResponseType<PermissionDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<PermissionDto>> UpdatePermission(
        [Description("Permission id.")] Guid id,
        [FromBody] UpdatePermissionRequest request,
        CancellationToken cancellationToken)
        => Ok(await service.UpdatePermissionAsync(id, request, cancellationToken));

    [HttpGet]
    [Authorize(Policy = Policies.RolesRead)]
    [EndpointName("listRoles")]
    [EndpointSummary("List roles")]
    [EndpointDescription("Lists roles in your organization. Supports page, search, sort, and filters.")]
    [ProducesResponseType<ApiPagedResponse<RoleDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<RoleDto>>> List(
        [FromQuery] RoleListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListAsync(query, cancellationToken));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = Policies.RolesRead)]
    [EndpointName("getRole")]
    [EndpointSummary("Get role")]
    [EndpointDescription("Returns a role by id.")]
    [ProducesResponseType<RoleDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<RoleDto>> Get(
        [Description("Role id.")] Guid id,
        CancellationToken cancellationToken)
    {
        var role = await service.GetAsync(id, cancellationToken);
        return role is null ? NotFound() : Ok(role);
    }

    [HttpPost]
    [Authorize(Policy = Policies.RolesWrite)]
    [EndpointName("createRole")]
    [EndpointSummary("Create role")]
    [EndpointDescription("Creates a role in your organization.")]
    [ProducesResponseType<RoleDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<RoleDto>> Create(
        [FromBody] CreateRoleRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
    }

    [HttpPut("{id:guid}")]
    [Authorize(Policy = Policies.RolesWrite)]
    [EndpointName("updateRole")]
    [EndpointSummary("Update role")]
    [EndpointDescription("Updates a role and its permissions.")]
    [ProducesResponseType<RoleDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<RoleDto>> Update(
        [Description("Role id.")] Guid id,
        [FromBody] UpdateRoleRequest request,
        CancellationToken cancellationToken)
        => Ok(await service.UpdateAsync(id, request, cancellationToken));
}
