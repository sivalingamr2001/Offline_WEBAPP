using JUSPlatform.Application.AppCatalog;
using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/app-menus")]
[Tags("AppMenus")]
[Authorize]
[Produces("application/json")]
public sealed class AppMenusController(IAppCatalogService service) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = Policies.MenusRead)]
    [EndpointName("listAppMenus")]
    [EndpointSummary("List app menus")]
    [EndpointDescription("Lists catalog menus from public.app_menus.")]
    [ProducesResponseType<ApiPagedResponse<AppMenuDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiPagedResponse<AppMenuDto>>> List(
        [FromQuery] AppMenuListQuery query,
        CancellationToken cancellationToken)
        => Ok(await service.ListMenusAsync(query, cancellationToken));

    [HttpPost]
    [Authorize(Policy = Policies.MenusWrite)]
    [EndpointName("createAppMenu")]
    [EndpointSummary("Create app menu")]
    [ProducesResponseType<AppMenuDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status409Conflict, "application/json")]
    public async Task<ActionResult<AppMenuDto>> Create(
        [FromBody] CreateAppMenuRequest request,
        CancellationToken cancellationToken)
    {
        var created = await service.CreateMenuAsync(request, cancellationToken);
        return Created($"/api/v1/app-menus/{created.Id}", created);
    }

    [HttpPut("{id:guid}")]
    [Authorize(Policy = Policies.MenusWrite)]
    [EndpointName("updateAppMenu")]
    [EndpointSummary("Update app menu")]
    [ProducesResponseType<AppMenuDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<AppMenuDto>> Update(
        Guid id,
        [FromBody] UpdateAppMenuRequest request,
        CancellationToken cancellationToken)
        => Ok(await service.UpdateMenuAsync(id, request, cancellationToken));
}
