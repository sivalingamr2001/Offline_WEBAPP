using JUSPlatform.Application.Common;
using JUSPlatform.Application.Storage;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Controllers;

[ApiController]
[Route("api/v1/storage")]
[Tags("Storage")]
[Authorize]
[Produces("application/json")]
public sealed class StorageController(IStorageDownloadService downloads) : ControllerBase
{
    [HttpPost("download-urls")]
    [EndpointName("createStorageDownloadUrl")]
    [EndpointSummary("Issue a short-lived download URL")]
    [EndpointDescription(
        "Mints a time-limited GET URL (default 5 minutes) for a private object in your organization. "
        + "Keys must be under exports/{orgId}/, reports/{orgId}/, or private/{orgId}/. "
        + "S3/MinIO returns a native presigned URL; local storage returns an HMAC ticket.")]
    [ProducesResponseType<PrivateDownloadDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized, "application/json")]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound, "application/json")]
    public async Task<ActionResult<PrivateDownloadDto>> CreateDownloadUrl(
        [FromBody] CreatePrivateDownloadRequest request,
        CancellationToken cancellationToken)
        => Ok(await downloads.CreateAsync(request, cancellationToken));

    [HttpGet("download")]
    [AllowAnonymous]
    [EndpointName("downloadStorageObject")]
    [EndpointSummary("Download a private object via ticket")]
    [EndpointDescription(
        "Local-storage HMAC download. Anyone with a valid unexpired ticket can GET the file. "
        + "Invalid, tampered, or expired tickets return 404. S3/MinIO clients should use the presigned URL instead.")]
    [Produces("application/octet-stream")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Download(
        [FromQuery(Name = "k")] string? key,
        [FromQuery(Name = "e")] string? expiresUnix,
        [FromQuery(Name = "s")] string? signature,
        [FromQuery(Name = "n")] string? fileName,
        [FromQuery(Name = "v")] string? versionId,
        CancellationToken cancellationToken)
    {
        var file = await downloads.TryOpenLocalAsync(
            key,
            expiresUnix,
            signature,
            fileName,
            versionId,
            cancellationToken);
        if (file is null)
        {
            return NotFound();
        }

        return File(file.Stream, file.ContentType, file.FileName);
    }
}
