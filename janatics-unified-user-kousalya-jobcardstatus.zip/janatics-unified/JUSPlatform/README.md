# JUSPlatform — Developer Guide

Publisher: **Janatics India**

ASP.NET Core Web API for **Janatics Unified Suite** (JUSPlatform): **Org → User → Role/Permission → ERP** (Inventory, Sales, Purchase Orders, Invoices). Product UI is `JUSPlatformUI/`.

Stack: ASP.NET Core + EF Core + **PostgreSQL** (Npgsql), JWT auth, permission policies, FluentValidation, Serilog, OpenAPI + Scalar.

**Licensed runtime is .NET 10** (`net10.0`). See [docs/migrate-net10.md](../docs/migrate-net10.md).

**Current database is PostgreSQL.** Hangfire, the optional Database log sink, and EF migrations target that engine.

**Windows is the default OS** (PowerShell). Linux commands are listed second. Docker is optional.

---

## Prerequisites

- .NET 10 SDK (Janatics India licensed runtime). If `dotnet --version` is still 8.x, put `%USERPROFILE%\.dotnet` first on `PATH`.
- PostgreSQL on `localhost:5432` (or a DEV/UAT host via gitignored `appsettings.Development.json` / user-secrets)
- Node.js + **pnpm** for `JUSPlatformUI`
- EF Core CLI (optional, for new migrations):

```powershell
dotnet tool install --global dotnet-ef
```

```bash
# Linux
dotnet tool install --global dotnet-ef
```

Ensure `~/.dotnet/tools` (Linux) or `%USERPROFILE%\.dotnet\tools` (Windows) is on `PATH`.

---

## Configuration

Never commit real passwords, JWT signing keys, or connection strings. Use placeholders (`CHANGE_ME`, `<DB_HOST>`) in git. First boot: [First-time setup](#first-time-setup).

### Where credentials live

ASP.NET Core loads later sources **over** earlier ones. For `dotnet run` in **Development**:

| Priority | Store | On disk | In git? |
|----------|--------|---------|---------|
| 1 (lowest) | `appsettings.json` | `JUSPlatform/appsettings.json` | yes — placeholders only |
| 2 | `appsettings.Development.json` | `JUSPlatform/appsettings.Development.json` | **no** (gitignored) |
| 3 | **.NET user-secrets** (this machine) | Windows: `%APPDATA%\Microsoft\UserSecrets\<UserSecretsId>\secrets.json` · Linux: `~/.microsoft/usersecrets/<UserSecretsId>/secrets.json` | **no** (outside the repo) |
| 4 | Environment variables | IIS env / systemd `jusplatform.env` | **no** — `deploy/systemd/jusplatform.env.example` is placeholders only |
| 5 (highest) | Command-line / process env for that run | — | no |

`UserSecretsId` is in `JUSPlatform.csproj` (`jusplatform-dev-4e8c1a7b-9f2d-4b6e-a1c3-8d5e7f0b2a19`). That id is not a secret; the JSON next to it is.

**This workstation’s DEV/UAT PostgreSQL connection is in user-secrets**, not in the repo. User-secrets win over `appsettings.Development.json` when both set `ConnectionStrings:Default`.

```powershell
# Windows (default) — set or replace the local DB connection (never commit the value)
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project .\JUSPlatform\JUSPlatform.csproj
```

```bash
# Linux
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform/JUSPlatform.csproj
```

Same store for `Jwt:SigningKey` and other secrets. Production: IIS environment variables or `/etc/jusplatform/jusplatform.env` (mode `0600`) — see [deploy/iis/README.md](../deploy/iis/README.md) and [deploy/README.md](../deploy/README.md).

### Local template (optional)

Committed **localhost** shape (no password):

```text
Host=localhost;Port=5432;Database=jusplatform;Username=postgres;Password=;
```

`appsettings.Development.json` is **gitignored**. Copy the template once if you prefer a file instead of (or in addition to) user-secrets:

```powershell
# Windows (default)
Copy-Item appsettings.Development.json.example appsettings.Development.json
```

```bash
# Linux
cp appsettings.Development.json.example appsettings.Development.json
```

Create the database once if it does not exist:

```powershell
# Windows (default) — psql client on PATH
psql -U postgres -c "CREATE DATABASE jusplatform;"
```

```bash
# Linux
psql -U postgres -c "CREATE DATABASE jusplatform;"
```

Do not point `ConnectionStrings:Default` at MariaDB/MySQL, SQL Server, or SQLite. Existing migrations are PostgreSQL-only.

---

## Developer commands

From the **repo root**. Paste into **CMD** or PowerShell (Linux second). Makefile is optional.

**PostgreSQL** — set once (never commit the real string):

```
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform\JUSPlatform.csproj
```

**Migrate + seed** (exits; does not listen):

```
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
```

**API** — `http://localhost:5201` (applies pending migrations, does not seed):

```
dotnet run --project JUSPlatform\JUSPlatform.csproj
```

```
cd JUSPlatform
dotnet watch run --no-restore
```

**Frontend** — `http://localhost:5173`

```
cd JUSPlatformUI
pnpm install
pnpm run dev
```

```
cd JUSPlatformUI
pnpm run build
pnpm run lint
pnpm run typecheck
```

**New EF migration** (after entity/Fluent changes):

```
dotnet tool restore
dotnet ef migrations add <DescriptiveName> --project JUSPlatform\JUSPlatform.csproj --output-dir Infrastructure/Persistence/Migrations
```

Then `dotnet run` (or `--seed`) applies it.

**Tests**

```
dotnet test tests\JUSPlatform.UnitTests\JUSPlatform.UnitTests.csproj
dotnet test tests\JUSPlatform.IntegrationTests\JUSPlatform.IntegrationTests.csproj
```

**Linux** (same jobs):

```
cp JUSPlatform/appsettings.Development.json.example JUSPlatform/appsettings.Development.json
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform/JUSPlatform.csproj
cd JUSPlatformUI && pnpm install && pnpm run dev
dotnet test tests/JUSPlatform.UnitTests/JUSPlatform.UnitTests.csproj
```

Optional Docker (skip if Docker is not installed):

```
docker compose -f docker\observability\docker-compose.yml up -d --build
docker compose -f docker\bugsink\docker-compose.yml up -d
docker compose -f docker\minio\docker-compose.yml up -d
docker compose -f docker\mailpit\docker-compose.yml up -d
docker compose --profile with-db down
```

Linux Docker: use forward slashes (`docker compose -f docker/observability/docker-compose.yml up -d --build`).

---

## Docker (optional)

Skip this section when Docker is not installed. Use `dotnet run --project JUSPlatform` against PostgreSQL instead.

| Track | Path | Purpose |
|-------|------|---------|
| **Ship** | `JUSPlatform/Dockerfile` + root `docker-compose.yml` | Deployable API + PostgreSQL |
| **Analyze** | `docker/security/` | Semgrep / Trivy / Gitleaks / ZAP → **SARIF** |

```powershell
# Windows (default) — Docker Desktop required; skip if Docker is not installed
.\docker\ship-up.ps1
$env:SECURITY_ALL = "1"
$env:TARGET_URL = "http://127.0.0.1:8080"
.\docker\security\run-all.ps1
```

```bash
# Linux — Docker Desktop / engine required
./docker/ship-up.sh
SECURITY_ALL=1 TARGET_URL=http://127.0.0.1:8080 ./docker/security/run-all.sh
```

`.\docker\ship-up.ps1` / `./docker/ship-up.sh` detects a local PostgreSQL on **:5432** and starts **API only** (uses `host.docker.internal`). If nothing is listening, it starts container PostgreSQL on host **:5433**. Force compose DB: `$env:FORCE_COMPOSE_DB='1'; .\docker\ship-up.ps1`. Force host DB: `$env:FORCE_HOST_DB='1'; .\docker\ship-up.ps1`.

WSL2 / Git Bash can use `./scripts/*.sh` and `./docker/ship-up.sh`. Full matrix: [`docs/security.md`](../docs/security.md).

---

## Project layout

```text
JUSPlatform/
├── Controllers/          HTTP adapters (api/v1/…)
├── Application/          Use cases + DTOs by feature
├── Domain/               Entities, enums, exceptions
├── Infrastructure/       EF Core, JWT, policies, seed, migrations
├── Authorization/        Permission + policy constants
├── Middleware/           Exception + validation
└── Program.cs            Composition root
```

---

## First-time setup

From the **repo root**. Same flow as the root [README.md](../README.md#get-started-windows-default).

**1. Connection** — never commit the real value. User-secrets (recommended) or gitignored `appsettings.Development.json`:

```
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform\JUSPlatform.csproj
```

```
copy JUSPlatform\appsettings.Development.json.example JUSPlatform\appsettings.Development.json
```

Local empty database (if needed): `psql -U postgres -c "CREATE DATABASE jusplatform;"`

**2. Restore + migrate + seed** — `--seed` applies pending migrations, then SuperAdmin, then exits:

```
dotnet restore JUSPlatform\JUSPlatform.csproj
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
```

**3. API** (migrate-on-boot, no seed):

```
dotnet run --project JUSPlatform\JUSPlatform.csproj
```

**4. UI:**

```
cd JUSPlatformUI
pnpm install
pnpm run dev
```

```bash
# Linux
export PATH="$HOME/.dotnet:$PATH"
cp JUSPlatform/appsettings.Development.json.example JUSPlatform/appsettings.Development.json
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform/JUSPlatform.csproj
dotnet restore JUSPlatform/JUSPlatform.csproj
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform/JUSPlatform.csproj
cd JUSPlatformUI && pnpm install && pnpm run dev
```

Login: `admin@demo.local` / `ChangeMe123!` (see [Seeding](#seeding)). Register an org to get an Admin JWT with `org_id`.

Dev URL: **http://localhost:5201** (SPA shell at `/`)  
API ping: **http://localhost:5201/api**  
API docs (Scalar, Development): **http://localhost:5201/docs**  
OpenAPI document: **http://localhost:5201/openapi/v1.json**  
UI: **http://localhost:5173**  
Hangfire dashboard (Development, Basic Auth): **http://localhost:5201/hangfire**

---

## Migrations

All commands run from `JUSPlatform/` (or pass `--project` from repo root).

### Add a migration (after entity/config changes)

```powershell
# Windows (default) — from JUSPlatform\
dotnet ef migrations add <DescriptiveName> --output-dir Infrastructure/Persistence/Migrations
```

```bash
# Linux
dotnet ef migrations add <DescriptiveName> --output-dir Infrastructure/Persistence/Migrations
```

Examples:

```bash
dotnet ef migrations add AddProductBarcode --output-dir Infrastructure/Persistence/Migrations
dotnet ef migrations add AddInvoiceDueIndex --output-dir Infrastructure/Persistence/Migrations
```

### Apply migrations

```bash
dotnet ef database update
```

Apply up to a specific migration:

```bash
dotnet ef database update <MigrationName>
```

### Check migration status

```bash
# List migrations and which are applied
dotnet ef migrations list

# Generate SQL without applying (review before prod)
dotnet ef migrations script

# Script from/to a range
dotnet ef migrations script <FromMigration> <ToMigration>
```

### Remove last unapplied migration

```bash
dotnet ef migrations remove
```

Only remove if it has **not** been applied to shared/prod databases. If already applied, add a new migration that undoes the change instead.

### Rollback database to a previous migration

```bash
dotnet ef database update <PreviousMigrationName>
```

### Startup behavior

**Migrate on boot — yes.** `MigrateAsync` is idempotent: if `__EFMigrationsHistory` is current, it is a no-op. That is the right default for this monolith (one API process in dev and typical systemd). Logs show either `schema up to date` or the pending migration names.

**Do not** run several API replicas that all migrate at the same second on a fresh database without a lock — for scaled-out deploys, run `dotnet ef database update` (or a one-shot `dotnet JUSPlatform.dll --seed` / migrate) in the release job, then start N instances (second start is a no-op).

**Seed on boot — no** (except `Testing`, for integration tests). Platform SuperAdmin, permission catalog, and org system-role sync run only via command:

```
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
```

```bash
# Linux
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
```

The seed command applies pending migrations, seeds, then **exits** (API does not listen). Credentials come from the `Seed` config section.

On a normal `dotnet run` you should see logs like:

```text
API starting: Environment=Development ...
Database: Provider=PostgreSql, Host=localhost, Port=5432, Database=jusplatform ...
Database: migrate-on-boot=yes seed-on-boot=False
Database: schema up to date (no pending EF migrations)
Seed: skipped on API boot. ... dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
API listening: http://localhost:5201
API ping: http://localhost:5201/api
OpenAPI: http://localhost:5201/openapi/v1.json  Scalar: http://localhost:5201/docs
```

You can still run `dotnet ef database update` manually for CI or before a multi-instance deploy.

---

## Other SQL engines

This product **ships against PostgreSQL** (`UseNpgsql`, Hangfire.PostgreSql, `jsonb` job payloads). There is **no** `Database:Provider` config switch.

PostgreSQL **columns, keys, and indexes** are snake_case (`created_at`, `organization_id`). C# properties stay PascalCase (`CreatedAt`). Table names were already snake_case (`users`, `job_runs`).

Unit/integration tests use **EF InMemory**. Green tests do **not** prove PostgreSQL dialect behavior — smoke login against a real server after schema changes.

Do not point `ConnectionStrings:Default` at MariaDB/MySQL, SQL Server, or SQLite. Do not reuse old Pomelo migrations.

---

## Seeding

Seed is **not** automatic when the API starts. Run it once on a new database, and again after you add permission codes to `Authorization/Permissions.cs`.

It upserts the permission catalog, ensures the **platform SuperAdmin role + one SuperAdmin user** (no organization), and ensures org system roles (`Admin`, `Manager`, `DataEntryOperator`) for existing tenants. Register / create-organization still creates those roles for a **new** org without a full seed.

```powershell
# Windows (default)
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
# same as: dotnet run --project .\JUSPlatform\JUSPlatform.csproj -- --seed
```

```bash
# Linux
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
```

Credentials come from the **`Seed`** config section (override via env, e.g. `Seed__SuperAdminPassword`):

```json
"Seed": {
  "SuperAdminEmail": "admin@demo.local",
  "SuperAdminPassword": "ChangeMe123!",
  "SuperAdminDisplayName": "Super Admin"
}
```

| Item                | Config key                | Default            |
|---------------------|---------------------------|--------------------|
| SuperAdmin email    | `SuperAdminEmail`         | `admin@demo.local` |
| SuperAdmin password | `SuperAdminPassword`      | `ChangeMe123!`     |

Org Admins are created later via **register** or SuperAdmin inviting a user into an organization.

To re-seed from scratch: drop/recreate `jusplatform`, then seed (migrates + SuperAdmin):

```powershell
# Windows (default)
psql -U postgres -c "DROP DATABASE IF EXISTS jusplatform;"
psql -U postgres -c "CREATE DATABASE jusplatform;"
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform\JUSPlatform.csproj
```

```bash
# Linux
psql -U postgres -c "DROP DATABASE IF EXISTS jusplatform;"
psql -U postgres -c "CREATE DATABASE jusplatform;"
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform/JUSPlatform.csproj
```

---

## Run / debug

```bash
# HTTP profile (port 5201)
dotnet run

# Explicit profile
dotnet run --launch-profile http

# Watch mode (restart on file change)
dotnet watch run
```

Use Bruno (`apidocs/`) or Scalar for API calls.

---

## Bruno collection

Open the `apidocs/` folder in Bruno (OpenCollection YAML).

Suggested order:

1. `Health / Ping` and `Health / Health`
2. `Auth / Login` (stores `token` only)
3. Feature folders: Organizations, Users, Roles, Inventory, Sales, Purchase Orders, Invoices

Environment: `local` → `apiUrl=http://localhost:5201`

`organizationId` is never a client tenant parameter. Company details use `GET/PUT /api/v1/organizations/me` (JWT only).

---

## Logging sinks (configurable)

Configured under `LogSink` in `appsettings.json`. Console always on; one durable provider selected:

| Provider | Destination | When |
|----------|-------------|------|
| `File` **(default)** | `logs/jusplatform-*.log` + `logs/jusplatform-errors-*.log` (Warning+) | Local / simple host |
| `Database` | PostgreSQL `app_logs` | Query logs in SQL |
| `Seq` | OSS Seq UI (`ServerUrl`) | Team log viewer tomorrow |

Switch provider:

```json
"LogSink": {
  "Provider": "File"
}
```

```json
"LogSink": { "Provider": "Database" }
```

```json
"LogSink": {
  "Provider": "Seq",
  "Seq": { "ServerUrl": "http://localhost:5341", "ApiKey": "" }
}
```

Seq is the OSS adapter placeholder — point `ServerUrl` at your Seq (or compatible) instance when ready. File logs are gitignored via `logs/`.

---

## Observability demo (OpenTelemetry → Grafana stack)

**Production default:** observability off. **Demo stack:** `docker compose -f docker\observability\docker-compose.yml up -d --build` starts Grafana, Loki, Prometheus, Tempo, OTel Collector, and mock Oracle/SAP/email services.

```powershell
# Windows (default)
docker compose -f docker\observability\docker-compose.yml up -d --build
# Enable Observability + MockIntegrations in appsettings.Development.json, then:
dotnet run --project JUSPlatform\JUSPlatform.csproj
```

```bash
# Linux
./scripts/obs-up.sh
./scripts/run-api.sh
```

Trigger demo workflow (requires login + `invoice.write`):

```bash
POST /api/v1/demo/invoice-sync
{ "customerCode": "C-1001", "invoiceNumber": "INV-DEMO-001", "notifyEmail": "billing@demo.local" }
```

Open **http://localhost:3000** (Grafana — `admin` / `admin`):

- **Dashboards → JUSPlatform → JUSPlatform Overview** (after `docker compose -f docker\observability\docker-compose.yml up -d --build`)
- **Explore → Tempo** — tab **Search**, Service Name = `JUSPlatform`, then run your curl again
- **Explore → Prometheus** — paste:
  ```promql
  http_server_request_duration_seconds_count{http_route="api/v1/organizations/me"}
  ```
- **Explore → Loki** — paste:
  ```logql
  {service_name="JUSPlatform"} |= "organizations/me"
  ```

Use time range **Last 15 minutes**. Metrics appear after the request (Prometheus scrapes every 15s).

### What we track

| Signal | Success + error? | Where |
|--------|------------------|-------|
| **Traces** | All HTTP requests (200, 401, 500, …) | **Tempo** (Grafana → Explore → Tempo) |
| **Metrics** | All requests; filter by `http_response_status_code` | Prometheus |
| **Logs** | Information + warnings + errors (Serilog levels) | Loki |

Prometheus does **not** auto-show a chart — you must **enter a query** and click **Execute** (empty page = no query yet).

### Zipkin removed — Tempo only

Traces flow: **JUSPlatform → OTLP (:4317) → OTel Collector → Tempo → Grafana**.

Do not run a separate Zipkin container. If an old one is still up from an earlier demo:

```powershell
docker compose -f docker\observability\docker-compose.yml down
```

```bash
./scripts/obs-down.sh
```

### Grafana cannot reach Prometheus?

Grafana runs **inside Docker**. In datasource settings the URL must be:

```text
http://prometheus:9090    ✅ (Docker service name)
http://localhost:9090     ❌ (localhost = inside Grafana container → connection refused)
```

Provisioned datasources use the correct URLs. If you edited Prometheus manually in the UI, delete it and reset Grafana:

```powershell
docker compose -f docker\observability\docker-compose.yml down
docker volume rm observability_grafana-data 2>$null
docker compose -f docker\observability\docker-compose.yml up -d --build
```

```bash
./scripts/obs-down.sh
docker volume rm observability_grafana-data 2>/dev/null || true
./scripts/obs-up.sh
```

**Checklist if empty:** API startup log shows `Observability: Enabled=True`; obs stack running; restart API after enabling observability.

See `Mock/README.md` for layout and ports.

| Id | Purpose | Today |
|----|---------|-------|
| `X-Response-Id` | Support / logs (one HTTP request) | Always on |
| `X-Trace-Id` | Copy-paste into Tempo/Grafana trace search | When `Observability:Enabled=true` |
| OpenTelemetry | Traces + metrics + logs via OTLP | Demo: `Observability:Enabled=true` |

Local file logging (Serilog) always runs; when observability is enabled, logs also export to Loki via OTLP.

---

## Bugsink (error tracking)

Self-hosted [Bugsink](https://www.bugsink.com/) via the **Sentry-compatible SDK** — errors and fatals, not distributed traces (use OpenTelemetry/Tempo for traces).

```json
"Bugsink": {
  "Enabled": false,
  "Dsn": "http://YOUR_KEY@localhost:8000/PROJECT_ID",
  "Environment": "development",
  "SendDefaultPii": true,
  "CaptureSerilogErrors": true
}
```

| Setting | Meaning |
|---------|---------|
| **`Enabled`** | Master switch (+ non-empty `Dsn`) |
| `Dsn` | From Bugsink project settings after `docker compose -f docker\bugsink\docker-compose.yml up -d` |
| `CaptureSerilogErrors` | Forward Serilog `Error+` to Bugsink |

**Local stack**

```powershell
# Windows (default)
docker compose -f docker\bugsink\docker-compose.yml up -d    # http://localhost:8000  admin@example.org / admin
```

```bash
# Linux
./scripts/bugsink-up.sh
```

1. Log in → create team/project → copy **DSN**
2. Set `Bugsink:Enabled=true` and `Bugsink:Dsn=...` in `appsettings.Development.json`
3. Restart API — startup log shows `Bugsink: Enabled=True`

**What gets captured**

- Unhandled **500** exceptions (`ExceptionHandlingMiddleware`)
- **Dead** background jobs after retries (`JobRunner`)
- Serilog **Error+** when `CaptureSerilogErrors=true`

Each event is tagged with `trace_id` and `response_id` so you can jump from Bugsink → Tempo in Grafana.

**UI (JUSPlatformUI):** same Bugsink DSN protocol via `@sentry/react`. Set `VITE_BUGSINK_DSN` in `JUSPlatformUI/.env` (see `JUSPlatformUI/README.md`). Frontend reports React/router crashes only; Sentry traces stay off so Tempo/Loki remain the trace path.

**Production:** `Enabled=false` in base `appsettings.json`; enable only when you run a Bugsink instance.

---

## Paginated list endpoints

All collection endpoints share one query contract (`PagedListQuery`) and one response envelope (`ApiPagedResponse<T>`).

**Query (common, camelCase wire names):**

```text
?page=1&pageSize=25&search=...&sort=...&sortDir=asc|desc
```

Wire names are fixed via `[FromQuery(Name = "...")]` / `[JsonPropertyName]` on `PagedListQuery` — Scalar, Bruno, and Orval all see `page`, not `Page`.

- `page` — 1-based (default `1`)
- `pageSize` — default `25`, max `100`
- `search` — free text (resource-specific fields)
- `sort` / `sortDir` — whitelisted per resource (`asc` or `desc`)

**Resource filters** (examples): `isActive`, `roleId` (users); `status` (orders/invoices); `module` (permissions); `movementType` (stock movements).

**Response:**

```json
{
  "items": [],
  "page": 1,
  "pageSize": 25,
  "totalItems": 100,
  "totalPages": 4
}
```

Types live in `Application/Common/` (`PagedListQuery`, `ApiPagedResponse<T>`). Each resource extends the base query (e.g. `SalesOrderListQuery` adds `status`).

---

## Redis query cache (paginated lists)

One flag controls read caching for all `list*` endpoints — **no per-service code**.

```json
"Redis": {
  "Enabled": true,
  "QueryCacheEnabled": false,
  "QueryCacheSeconds": 60
}
```

| Setting | Meaning |
|---------|---------|
| `Enabled` | Connect to Redis (`ConnectionStrings:Redis`) |
| **`QueryCacheEnabled`** | Cache paginated list JSON (`GET` + `listUsers`, `listSalesOrders`, …) |
| `QueryCacheSeconds` | TTL per cached query (default 60s) |

**How it works**

- `QueryResponseCacheFilter` — caches by org + resource + route + query-string fingerprint
- `EntityChangeInterceptor` — invalidates that resource’s cache index on writes
- Response header `X-Query-Cache: HIT` \| `MISS` when enabled

**Default:** `QueryCacheEnabled: false` in all environments. Turn on only when measured benefit (e.g. hot dashboard page).

Optional compose Redis: `docker compose --profile with-redis up -d redis` then `REDIS_CONNECTION=redis:6379,abortConnect=false`.

---

## Object storage (local / MinIO / AWS S3)

File blobs (avatars, generated reports, CSV exports) go through `IObjectStorage`. **Provider is config, not code forks.**

| Provider | When |
|----------|------|
| `local` | Laptop / simple host. Files under `wwwroot` (or `Storage:Local:RootPath`). |
| `minio` / `s3` | S3 API. **Production: MinIO** with bucket versioning. AWS S3 uses the same settings with an empty `ServiceUrl`. |

```json
"Storage": {
  "Provider": "local",
  "Versioning": true,
  "PrivateDownloadExpiryMinutes": 5,
  "PublicBaseUrl": "",
  "Local": { "RootPath": "" },
  "S3": {
    "Bucket": "jusplatform",
    "ServiceUrl": "http://127.0.0.1:9000",
    "Region": "us-east-1",
    "AccessKey": "minioadmin",
    "SecretKey": "minioadmin",
    "ForcePathStyle": true,
    "EnsureBucket": true,
    "ReadUrlExpiryMinutes": 15
  }
}
```

| Setting | Meaning |
|---------|---------|
| `Provider` | `local`, `minio`, `s3`, or `aws` |
| `Versioning` | S3/MinIO bucket versioning; local copies under `.versions/` |
| `PrivateDownloadExpiryMinutes` | TTL for reports/CSV download URLs (default **5**, max 15) |
| `DownloadSigningKey` | HMAC key for local tickets. Empty = `Jwt:SigningKey` |
| `PublicBaseUrl` | API origin for local tickets when there is no HTTP request (jobs) |
| `S3:ServiceUrl` | MinIO endpoint. Empty = AWS default |
| `S3:ForcePathStyle` | `true` for MinIO |
| `S3:EnsureBucket` | Create bucket, turn on versioning, set GET CORS from `Cors:Origins` |
| `S3:ReadUrlExpiryMinutes` | Presigned GET for `<img>` (JWT is not sent on image tags) |

**Private downloads (reports, CSV)** — not the same as avatar `<img>` URLs.

1. Write under `exports/{orgId}/`, `reports/{orgId}/`, or `private/{orgId}/`.
2. Authenticated `POST /api/v1/storage/download-urls` with `{ key, fileName? }` returns `{ url, expiresAt, expiresInSeconds }`.
3. Browser `GET`s that URL **without** a JWT (same as S3: possession of the link is the credential until TTL).
4. **S3/MinIO:** native presigned GET (`Content-Disposition: attachment`). **Local:** HMAC ticket to `GET /api/v1/storage/download`.

Tenant check uses JWT `org_id` only. Other org’s keys return 404. SuperAdmin has no org context and cannot mint tenant downloads.

**Local MinIO**

```powershell
# Windows (default)
docker compose -f docker\minio\docker-compose.yml up -d
# Console: http://localhost:9001  minioadmin / minioadmin
```

```bash
# Linux
./scripts/minio-up.sh
```

Set `Storage:Provider` to `minio` and the `S3` keys in `appsettings.Development.json` (gitignored). Restart the API. Startup log: `Storage: Provider=S3, Bucket=jusplatform, ServiceUrl=http://127.0.0.1:9000, Versioning=True`.

Secrets stay in env / user-secrets — never commit real MinIO or AWS keys. Production env: `deploy/systemd/jusplatform.env.example`.

---

## Background jobs (deferred work)

Queue long-running work; frontend polls until done.

```text
POST /api/v1/jobs          → 202 Accepted { id, status: Queued, pollUrl, traceId }
GET  /api/v1/jobs/{id}     → status, logs[], resultJson (when Succeeded)
GET  /api/v1/jobs          → paginated history (filter status, jobType)
```

**Example enqueue**

```json
{
  "jobType": "invoice-sync-demo",
  "payload": {
    "customerCode": "CUST-001",
    "invoiceNumber": "INV-2026-001",
    "notifyEmail": "billing@example.com"
  }
}
```

**Status flow:** `Queued` → `Running` → `Succeeded` | `Failed` (retry) → `Dead` (max attempts)

| Config | Meaning |
|--------|---------|
| `Jobs:WorkerEnabled` | Background worker processes queue (default `true`) |
| `Jobs:MaxAttempts` | Retries before `Dead` (default `3`) |
| `Jobs:RetryBackoffSeconds` | Exponential backoff base (default `10`) |

**Permissions:** `job.read` (poll/list), `job.write` (enqueue)

**Observability:** enqueue captures `traceId`; worker spans `job.{jobType}` in Tempo; step logs in `job_log_entries`.

**Adding a job type:** implement `IJobHandler`, register in `JobsServiceCollectionExtensions`, add `JobTypes` constant.

### Hangfire dashboard

When `Hangfire:Enabled=true`, jobs run via **Hangfire** (PostgreSQL storage, same database). The polling worker is disabled automatically.

Hangfire uses **`ConnectionStrings:Default`** — the same PostgreSQL database as EF Core. It creates its own objects in the `hangfire` schema. App tables stay in `public`.

| Config | Meaning |
|--------|---------|
| `Hangfire:Enabled` | Hangfire server + dashboard (default `false`) |
| `Hangfire:DashboardPath` | URL path (default `/hangfire`) |
| `Hangfire:DashboardUsername` | HTTP Basic Auth user |
| `Hangfire:DashboardPassword` | HTTP Basic Auth password (required for dashboard) |

**Access (Development):** [http://localhost:5201/hangfire](http://localhost:5201/hangfire)

Sign in with the credentials from `appsettings.Development.json` (default `admin` / `dev`). The browser will prompt for HTTP Basic Auth.

**Production:** keep `Hangfire:Enabled=false` in base `appsettings.json`.

Bare-metal production (systemd + Nginx + timers): see **[deploy/README.md](../deploy/README.md)**.

---

## OpenAPI / Orval

Document: `http://localhost:5201/openapi/v1.json` (Development)  
API docs (Scalar): `http://localhost:5201/docs`

Contract includes:

- Stable `operationId` via `[EndpointName]` on every route (e.g. `login`, `listUsers`, `getCurrentOrganization`) — Orval uses these as function names
- `summary` / `description` via `[EndpointSummary]` / `[EndpointDescription]`
- Typed success/error responses via `[ProducesResponseType]`
- Shared paginated list envelope (`ApiPagedResponse<T>`) and query model (`PagedListQuery`)
- Shared error envelope (`ApiErrorResponse`) for failures
- Bearer access-token security scheme
- String enums (`DocumentStatus`, `InvoiceStatus`, `StockMovementType`)

**Minimal error body** (production default — only these keys):

```json
{
  "success": false,
  "detail": "One or more validation errors occurred.",
  "errors": {
    "email": ["'Email' must not be empty."]
  }
}
```

Optional fields via `ErrorResponse` config:

| Flag | Adds |
|------|------|
| `IncludeRfcFields` | `type`, `title`, `status` |
| `IncludeTraceId` | `traceId` |
| `IncludeException` | `exception[]` (`null` → follows `AppDebug`) |

```json
"ErrorResponse": {
  "IncludeRfcFields": false,
  "IncludeTraceId": false,
  "IncludeException": null
}
```

**Frontend:** bind `errors.<field>` on inputs; show `detail` in a toast. For support, show response header **`X-Response-Id`** on errors (`Reference: …`).

**Correlation id policy:** every response includes **`X-Response-Id`** (server-generated or a validated echo of optional client **`X-Request-Id`**). When observability is enabled, responses also include **`X-Trace-Id`** — paste that value into Grafana → Tempo to open the exact trace (no log join needed). Clients may omit `X-Request-Id` (typical for mobile). Incoming `X-Response-Id` is ignored. Client ids must be ≤64 chars, `[A-Za-z0-9_-]` only; otherwise the server assigns a new id.

Example Orval generate:

```bash
npx orval --input http://localhost:5201/openapi/v1.json --output ./src/api/jusplatform.ts
```

---

## Auth and OrgId (important)

- Login: `POST /api/v1/auth/login` → JWT
- JWT claim `org_id` is the **only** organization context
- Login response does **not** include `organizationId`
- Frontend must **not** send `organizationId` for tenant-scoped work
- Own company: `GET/PUT /api/v1/organizations/me` (no id in URL)
- Arbitrary `/organizations/{id}` was removed — it was an IDOR risk
- `POST /organizations` is provision-only (creates another org; does not switch your JWT)
- Services resolve org via `ICurrentUser.RequireOrganizationId()`
- Authorization is **permission/policy** based
- Login is enum-safe: unknown email and wrong password both return `401` with the same message

Login example:

```bash
curl -s http://localhost:5201/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@demo.local","password":"ChangeMe123!"}'
```

Use `accessToken` as `Authorization: Bearer <token>` on subsequent calls.

---

## API map (v1)

| Area            | Base route                      |
|-----------------|---------------------------------|
| SPA (React)     | `/` (`wwwroot/`)                |
| Ping            | `GET /api`                      |
| Health          | `GET /api/heath`                |
| Auth            | `/api/v1/auth`                  |
| Organizations   | `/api/v1/organizations/me`      |
| Users           | `/api/v1/users`                 |
| Roles           | `/api/v1/roles`                 |
| Inventory       | `/api/v1/inventory/products`    |
| Sales           | `/api/v1/sales/orders`          |
| Purchase orders | `/api/v1/purchase-orders`       |
| Invoices        | `/api/v1/invoices`              |

### Hosting the React build

Production static files live in `JUSPlatform/wwwroot/` (placeholder “Upload your build” page until you drop the real build there).

- **`/api/**`** — API only. Unknown paths return JSON `404` (`success: false`).
- **Everything else** — SPA. Client-side routes intentionally return **HTTP 200** + `index.html` so React Router can show its own not-found page. When testing, distinguish SPA vs API by `Content-Type` (`text/html` vs `application/json`), not status alone.

```bash
# example: copy Vite output
cp -r ../hello-web/dist/* JUSPlatform/wwwroot/
```

---

## Checking / verification checklist

```bash
# 1) Build
dotnet build

# 2) Migrations present and named
dotnet ef migrations list

# 3) DB schema up to date (or skip — API migrates on boot)
dotnet ef database update

# 3b) SuperAdmin + permission catalog (not on API boot)
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed

# 4) App starts cleanly
dotnet run --project JUSPlatform

# 5) OpenAPI / Scalar loads
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:5201/openapi/v1.json

# 6) Login works
curl -s http://localhost:5201/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@demo.local","password":"ChangeMe123!"}'

# 7) Org-scoped call with token (no organizationId in URL)
TOKEN=<accessToken from login>
curl -s http://localhost:5201/api/v1/inventory/products \
  -H "Authorization: Bearer $TOKEN"
```

Expect `200` and products for the JWT org only.

---

## Team handoff (what to keep, what not to “improve”)

Give this list to anyone continuing the product. The working contract is [`docs/policy.md`](../docs/policy.md).

### Non-negotiable

| Keep | Do not |
|------|--------|
| Tenant = JWT `org_id` only | Accept `organizationId` on ERP/user/role APIs |
| `[Authorize(Policy = …)]` | `if (role == "Admin")` in services |
| PostgreSQL + Npgsql migrations | Merge MariaDB/SQL Server/SQLite as the app database |
| Controllers thin; rules in Application | EF queries in controllers |
| Secrets in env / user-secrets | Commit real JWT keys, MinIO keys, or DB passwords |
| Feature slice (entity → Fluent → service → controller → Bruno) | New global `Helpers/` dumps |

### First week on the repo

1. Read [`docs/policy.md`](../docs/policy.md) and this README (auth, org, storage, jobs).
2. Set `ConnectionStrings:Default` with `dotnet user-secrets` (or copy `appsettings.Development.json.example` — see [Configuration](#configuration)); create the database on **PostgreSQL**.
3. `dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed` then `dotnet run --project JUSPlatform\JUSPlatform.csproj` (API `:5201`). UI: `cd JUSPlatformUI` then `pnpm run dev` (`:5173`).
4. Login with seeded SuperAdmin (`Seed` section, default `admin@demo.local`). Register an org to get an Admin JWT with `org_id`.
5. Bruno: open `apidocs/`. Scalar (Development): `/docs`.
6. `dotnet test tests\JUSPlatform.UnitTests\JUSPlatform.UnitTests.csproj`. Coverage: see `tests/README.md`.
7. Confirm `docker compose up` / local PostgreSQL on `:5432`.

### Product surfaces they will extend

| Area | Where | Note |
|------|--------|------|
| Permissions | `Authorization/Permissions.cs` + policy registration | Then controller attribute + Application org filter |
| Schema | Domain entity + Fluent config + **new** EF migration | PostgreSQL columns are snake_case (`created_at`); C# stays PascalCase |
| Private files | `exports\|reports\|private/{orgId}/` + `POST /api/v1/storage/download-urls` | 5-minute URL; not avatar `GetReadUrl` |
| Jobs | `POST /api/v1/jobs` + Hangfire on **same** PostgreSQL | Hangfire schema `hangfire` |
| UI | `JUSPlatformUI/` Orval client | Regenerate from `/openapi/v1.json` |

### Known gaps (do not assume these exist)

Tracked in `docs/policy.md` §9. Notable: refresh tokens, stock concurrency/locking, idempotency keys, FluentValidation on Sales/PO/Invoice, `/api/health` alias (route is `/api/heath` on purpose).

### AI / agents

Follow `.cursor/rules/` (tenancy, tests, no secrets in chat). Do not paste production dumps, NDA, or live tenant PII into a model.

---

## Common follow-ups after a feature change

1. Change entities / Fluent configurations under `Domain` / `Infrastructure/Persistence`
2. `dotnet ef migrations add <Name> --output-dir Infrastructure/Persistence/Migrations`
3. Review generated migration SQL
4. `dotnet ef database update` **or** just `dotnet run` (migrate-on-boot). After new permission codes: `dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed`
5. `dotnet build` and hit the affected endpoints via Scalar or Bruno (`apidocs/`)
6. Confirm org isolation (token A cannot see token B’s data)

---

## Troubleshooting

| Problem | What to check |
|---------|----------------|
| Cannot connect to DB | PostgreSQL reachable; database exists; connection string is **Npgsql** syntax (`Host=…;Port=5432;Database=…;Username=…`) |
| `MigrateAsync` / update fails | `dotnet ef migrations list`; pending migration errors; user privileges |
| `dotnet-ef` not found | Install global tool; add `~/.dotnet/tools` to `PATH` |
| 401 on APIs | Missing/expired Bearer token; login again |
| 403 Forbidden | User role lacks required permission claim |
| Cannot login SuperAdmin | Run `dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed` once; check `Seed:SuperAdminEmail` / password; API boot no longer seeds |
| Empty seed / no permissions | `dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed` after adding codes to `Permissions.Catalog` |
| Wrong org data | Token `org_id` claim; never trust client-supplied org id |

---

## Notes

- Prefer EF Core for persistence; avoid ad-hoc SQL unless justified.
- **PostgreSQL is the product database.** Other engines: [Other SQL engines](#other-sql-engines).
- Controllers stay thin; business rules live in Application services.
- Soft-delete query filters apply on `EntityBase.IsDeleted`.
- Change JWT `SigningKey` before any non-local deployment.
