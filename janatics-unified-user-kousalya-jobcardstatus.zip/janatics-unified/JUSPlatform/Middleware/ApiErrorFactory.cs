using System.Diagnostics;
using System.Net;
using FluentValidation;
using JUSPlatform.Application.Common;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Middleware;

public static class ApiErrorFactory
{
    public static ApiErrorResponse FromException(
        Exception exception,
        HttpStatusCode status,
        string? traceId,
        ErrorResponseOptions options,
        bool appDebug)
    {
        var includeException = options.IncludeException ?? appDebug;
        return Build(
            status,
            exception,
            traceId,
            options,
            exception is ValidationException validation
                ? GroupValidationErrors(validation)
                : null,
            exception is ValidationException
                ? "One or more validation errors occurred."
                : status == HttpStatusCode.InternalServerError
                    ? "An unexpected error occurred."
                    : (string.IsNullOrWhiteSpace(exception.Message) ? "Request failed." : exception.Message),
            includeException ? BuildExceptionDetails(exception) : null);
    }

    public static ApiErrorResponse FromModelState(
        ActionContext context,
        ErrorResponseOptions options,
        bool appDebug)
    {
        var errors = context.ModelState
            .Where(x => x.Value is { Errors.Count: > 0 })
            .ToDictionary(
                x => string.IsNullOrEmpty(x.Key) ? string.Empty : x.Key,
                x => x.Value!.Errors
                    .Select(e => string.IsNullOrWhiteSpace(e.ErrorMessage) ? "Invalid value." : e.ErrorMessage)
                    .ToArray(),
                StringComparer.Ordinal);

        var includeException = options.IncludeException ?? appDebug;
        var traceId = Activity.Current?.Id ?? context.HttpContext.TraceIdentifier;

        return Build(
            HttpStatusCode.BadRequest,
            null,
            traceId,
            options,
            errors,
            "One or more validation errors occurred.",
            includeException ? ["Model binding / DataAnnotations validation failed."] : null);
    }

    public static ApiErrorResponse NotFound(
        ErrorResponseOptions options,
        bool appDebug,
        string? traceId = null,
        string? detail = null) =>
        Build(HttpStatusCode.NotFound, null, traceId, options, null, detail ?? "Not found.", null);

    public static ApiErrorResponse ForStatus(
        HttpStatusCode status,
        string detail,
        ErrorResponseOptions options,
        string? traceId = null,
        bool appDebug = false) =>
        Build(status, null, traceId, options, null, detail, null);

    private static ApiErrorResponse Build(
        HttpStatusCode status,
        Exception? exception,
        string? traceId,
        ErrorResponseOptions options,
        IDictionary<string, string[]>? errors,
        string? detail,
        IReadOnlyList<string>? exceptionDetails) =>
        new()
        {
            Success = false,
            Detail = detail,
            Errors = errors is { Count: > 0 } ? errors : null,
            Type = options.IncludeRfcFields ? TypeFor(status) : null,
            Title = options.IncludeRfcFields ? TitleFor(status, exception) : null,
            Status = options.IncludeRfcFields ? (int)status : null,
            TraceId = options.IncludeTraceId && !string.IsNullOrEmpty(traceId) ? traceId : null,
            Exception = exceptionDetails is { Count: > 0 } ? exceptionDetails : null
        };

    private static IDictionary<string, string[]> GroupValidationErrors(ValidationException validation) =>
        validation.Errors
            .GroupBy(e => string.IsNullOrWhiteSpace(e.PropertyName) ? string.Empty : e.PropertyName, StringComparer.Ordinal)
            .ToDictionary(
                g => g.Key,
                g => g.Select(e => e.ErrorMessage).Distinct().ToArray(),
                StringComparer.Ordinal);

    private static string TitleFor(HttpStatusCode status, Exception? exception) =>
        exception is ValidationException
            ? "One or more validation errors occurred."
            : status switch
            {
                HttpStatusCode.BadRequest => "Bad Request",
                HttpStatusCode.Unauthorized => "Unauthorized",
                HttpStatusCode.NotFound => "Not Found",
                HttpStatusCode.Conflict => "Conflict",
                HttpStatusCode.TooManyRequests => "Too Many Requests",
                HttpStatusCode.InternalServerError => "Internal Server Error",
                _ => status.ToString()
            };

    private static string TypeFor(HttpStatusCode status) =>
        $"https://httpstatuses.com/{(int)status}";

    private static IReadOnlyList<string> BuildExceptionDetails(Exception exception)
    {
        var items = new List<string>();
        for (var current = exception; current is not null; current = current.InnerException)
        {
            items.Add($"{current.GetType().FullName}: {current.Message}");
            if (string.IsNullOrWhiteSpace(current.StackTrace))
            {
                continue;
            }

            foreach (var line in current.StackTrace.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                items.Add(line);
            }
        }

        return items;
    }
}
