using System.Diagnostics;
using System.Net;
using System.Text.Json;
using JUSPlatform.Application.Common;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Middleware;

public static class ApiErrorResponseWriter
{
    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DictionaryKeyPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
    };

    public static async Task WriteAsync(
        HttpContext context,
        int statusCode,
        string detail,
        CancellationToken cancellationToken = default)
    {
        if (context.Response.HasStarted)
        {
            return;
        }

        var errorOptions = context.RequestServices.GetRequiredService<IOptions<ErrorResponseOptions>>().Value;
        var config = context.RequestServices.GetRequiredService<IConfiguration>();
        var appDebug = config.GetValue("AppDebug", false);
        var traceId = Activity.Current?.Id ?? context.TraceIdentifier;

        var body = ApiErrorFactory.ForStatus(
            (HttpStatusCode)statusCode,
            detail,
            errorOptions,
            traceId,
            appDebug);

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = ExceptionHandlingMiddleware.Json;
        await context.Response.WriteAsync(JsonSerializer.Serialize(body, JsonOptions), cancellationToken);
    }
}
