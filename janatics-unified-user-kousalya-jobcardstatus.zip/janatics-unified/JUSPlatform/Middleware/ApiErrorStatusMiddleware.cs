namespace JUSPlatform.Middleware;

/// <summary>
/// Ensures empty <c>/api/*</c> 401/403/404 responses use <see cref="Application.Common.ApiErrorResponse"/>.
/// </summary>
public sealed class ApiErrorStatusMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        await next(context);

        if (!ShouldHandle(context))
        {
            return;
        }

        var detail = context.Response.StatusCode switch
        {
            StatusCodes.Status401Unauthorized => "Authentication required.",
            StatusCodes.Status403Forbidden => "You do not have permission to perform this action.",
            StatusCodes.Status404NotFound => "Not found.",
            _ => null
        };

        if (detail is null)
        {
            return;
        }

        await ApiErrorResponseWriter.WriteAsync(context, context.Response.StatusCode, detail, context.RequestAborted);
    }

    private static bool ShouldHandle(HttpContext context)
    {
        if (!context.Request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (context.Response.HasStarted)
        {
            return false;
        }

        if (context.Response.ContentLength is > 0)
        {
            return false;
        }

        return context.Response.StatusCode is
            StatusCodes.Status401Unauthorized or
            StatusCodes.Status403Forbidden or
            StatusCodes.Status404NotFound;
    }
}
