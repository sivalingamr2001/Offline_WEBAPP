using System.Diagnostics;
using Microsoft.Extensions.Primitives;
using Serilog.Context;

namespace JUSPlatform.Middleware;

/// <summary>
/// Assigns correlation ids per request: <c>X-Response-Id</c> (support/logs) and
/// <c>X-Trace-Id</c> (OpenTelemetry → Tempo) when a trace is active.
/// Client may optionally send <see cref="CorrelationId.RequestHeaderName"/>; it is validated and
/// never trusted verbatim. Incoming <c>X-Response-Id</c> is ignored (server-owned response header).
/// </summary>
public sealed class ResponseIdMiddleware(RequestDelegate next)
{
    public const string HeaderName = "X-Response-Id";
    public const string TraceIdHeaderName = "X-Trace-Id";
    public const string ItemKey = "ResponseId";
    public const string TraceIdItemKey = "TraceId";
    public const string LogPropertyName = "ResponseId";

    private static readonly string EmptyTraceId = new('0', 32);

    public async Task InvokeAsync(HttpContext context)
    {
        var responseId = ResolveResponseId(context);
        context.Items[ItemKey] = responseId;
        context.Response.Headers[HeaderName] = responseId;
        context.Response.OnStarting(() =>
        {
            AppendTraceIdHeader(context);
            return Task.CompletedTask;
        });

        using (LogContext.PushProperty(LogPropertyName, responseId))
        {
            var traceId = ResolveTraceId();
            if (!string.IsNullOrEmpty(traceId))
            {
                using (LogContext.PushProperty("TraceId", traceId))
                {
                    await next(context);
                    return;
                }
            }

            await next(context);
        }
    }

    private static void AppendTraceIdHeader(HttpContext context)
    {
        var traceId = ResolveTraceId();
        if (traceId is null)
        {
            return;
        }

        context.Items[TraceIdItemKey] = traceId;
        context.Response.Headers[TraceIdHeaderName] = traceId;
    }

    private static string? ResolveTraceId()
    {
        var traceId = Activity.Current?.TraceId.ToString();
        return string.IsNullOrEmpty(traceId) || traceId == EmptyTraceId ? null : traceId;
    }

    private static string ResolveResponseId(HttpContext context)
    {
        if (context.Request.Headers.TryGetValue(CorrelationId.RequestHeaderName, out var requestId))
        {
            return CorrelationId.ResolveOrGenerate(FirstHeaderValue(requestId));
        }

        return CorrelationId.Generate();
    }

    /// <summary>Use only the first header value — avoids comma-joined abuse from duplicate headers.</summary>
    private static string? FirstHeaderValue(StringValues values) =>
        values.Count > 0 ? values[0] : null;

    public static string? GetResponseId(HttpContext context) =>
        context.Items.TryGetValue(ItemKey, out var value) ? value as string : null;

    public static string? GetTraceId(HttpContext context) =>
        context.Items.TryGetValue(TraceIdItemKey, out var value)
            ? value as string
            : ResolveTraceId();
}
