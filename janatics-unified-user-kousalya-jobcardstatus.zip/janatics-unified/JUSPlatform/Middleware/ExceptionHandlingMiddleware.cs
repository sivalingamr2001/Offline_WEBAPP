using System.Diagnostics;
using System.Net;
using FluentValidation;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Bugsink;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Middleware;

public sealed class ExceptionHandlingMiddleware(
    RequestDelegate next,
    ILogger<ExceptionHandlingMiddleware> logger,
    IConfiguration configuration,
    IOptions<ErrorResponseOptions> errorResponseOptions,
    IOptionsMonitor<BugsinkOptions> bugsinkOptions)
{
    public const string Json = "application/json";

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            await WriteErrorAsync(context, ex);
        }
    }

    private async Task WriteErrorAsync(HttpContext context, Exception exception)
    {
        var status = exception switch
        {
            ValidationException => HttpStatusCode.BadRequest,
            BusinessRuleException => HttpStatusCode.BadRequest,
            NotFoundException => HttpStatusCode.NotFound,
            ConflictException => HttpStatusCode.Conflict,
            UnauthorizedAccessException => HttpStatusCode.Unauthorized,
            _ => HttpStatusCode.InternalServerError
        };

        if (status == HttpStatusCode.InternalServerError)
        {
            logger.LogError(exception, "Unhandled exception {ResponseId}", ResponseIdMiddleware.GetResponseId(context));
            if (bugsinkOptions.CurrentValue.IsActive)
            {
                BugsinkEventReporter.CaptureException(
                    exception,
                    context,
                    ResponseIdMiddleware.GetResponseId(context));
            }
        }
        else
        {
            logger.LogWarning(exception, "Handled exception ({Status}) {ResponseId}", (int)status, ResponseIdMiddleware.GetResponseId(context));
        }

        var body = ApiErrorFactory.FromException(
            exception,
            status,
            Activity.Current?.Id ?? context.TraceIdentifier,
            errorResponseOptions.Value,
            IsAppDebugEnabled());

        if (context.Response.HasStarted)
        {
            return;
        }

        context.Response.StatusCode = (int)status;
        context.Response.ContentType = Json;
        await context.Response.WriteAsJsonAsync(body, ApiErrorResponseWriter.JsonOptions, context.RequestAborted);
    }

    private bool IsAppDebugEnabled() => configuration.GetValue("AppDebug", false);
}
