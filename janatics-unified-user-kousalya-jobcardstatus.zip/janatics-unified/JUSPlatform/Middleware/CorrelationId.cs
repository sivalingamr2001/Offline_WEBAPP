namespace JUSPlatform.Middleware;

/// <summary>
/// Server-owned correlation ids. Client <c>X-Request-Id</c> is optional and validated;
/// invalid or missing values are replaced with a server-generated id.
/// </summary>
public static class CorrelationId
{
    public const string RequestHeaderName = "X-Request-Id";
    public const int MaxLength = 64;

    public static string Generate() => Guid.NewGuid().ToString("N");

    /// <summary>
    /// Accept a client-supplied id only when it is a short, safe token; otherwise generate a new one.
    /// </summary>
    public static string ResolveOrGenerate(string? clientValue)
    {
        if (string.IsNullOrWhiteSpace(clientValue))
        {
            return Generate();
        }

        var trimmed = clientValue.Trim();
        return IsValid(trimmed) ? trimmed : Generate();
    }

    public static bool IsValid(string value)
    {
        if (value.Length is 0 or > MaxLength)
        {
            return false;
        }

        foreach (var c in value)
        {
            if (char.IsAsciiLetterOrDigit(c) || c is '-' or '_')
            {
                continue;
            }

            return false;
        }

        return true;
    }
}
