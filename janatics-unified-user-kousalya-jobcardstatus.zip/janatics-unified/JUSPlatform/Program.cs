using JUSPlatform.Infrastructure.DependencyInjection;
using JUSPlatform.Infrastructure.Hangfire;
using JUSPlatform.Infrastructure.Hosting;
using JUSPlatform.Infrastructure.Logging;
using JUSPlatform.Infrastructure.Observability;
using JUSPlatform.Infrastructure.Bugsink;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.RateLimiting;
using JUSPlatform.Infrastructure.Storage;
using JUSPlatform.Mock;
using JUSPlatform.Middleware;
using JUSPlatform.OpenApi;
using Microsoft.Extensions.Options;
using Scalar.AspNetCore;
using Serilog;

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .CreateBootstrapLogger();

var builder = WebApplication.CreateBuilder(args);

builder.AddJUSPlatformBugsink();
builder.Host.UseJUSPlatformLogging(preserveStaticLogger: builder.Environment.IsEnvironment("Testing"));
builder.Services.AddJUSPlatformInfrastructure(builder.Configuration);
builder.Services.AddJUSPlatformOpenApi(builder.Configuration);

if (DatabaseBootstrap.IsSeedCommand(args))
{
    var seedApp = builder.Build();
    DatabaseStartupLogger.LogConfiguration(seedApp.Configuration);
    await DatabaseBootstrap.RunSeedCommandAsync(
        seedApp.Services,
        seedApp.Environment,
        seedApp.Configuration,
        args);
    return;
}

if (DatabaseBootstrap.IsEnsurePesCommand(args))
{
    var pesApp = builder.Build();
    DatabaseStartupLogger.LogConfiguration(pesApp.Configuration);
    await DatabaseBootstrap.EnsurePesAccessAsync(
        pesApp.Services,
        pesApp.Environment,
        pesApp.Configuration);
    return;
}

var app = builder.Build();

Log.Information(
    "API starting: Environment={Environment}, ContentRoot={ContentRoot}",
    app.Environment.EnvironmentName,
    app.Environment.ContentRootPath);

var observability = ObservabilityOptions.Bind(app.Configuration);
Log.Information(
    "Observability: Enabled={Enabled}, Otlp={Otlp}, Traces={Traces}, Metrics={Metrics}, Logs={Logs}",
    observability.Enabled,
    observability.OtlpEndpoint ?? "(none)",
    observability.Traces,
    observability.Metrics,
    observability.Logs);

var mockIntegrations = app.Services.GetRequiredService<IOptions<MockIntegrationsOptions>>().Value;
Log.Information(
    "MockIntegrations: Enabled={Enabled}, BaseUrl={BaseUrl}",
    mockIntegrations.Enabled,
    mockIntegrations.BaseUrl);

var bugsink = BugsinkOptions.Bind(app.Configuration);
Log.Information(
    "Bugsink: Enabled={Enabled}, DsnConfigured={DsnConfigured}, SerilogErrors={SerilogErrors}",
    bugsink.Enabled,
    !string.IsNullOrWhiteSpace(bugsink.Dsn),
    bugsink.CaptureSerilogErrors);

var hangfire = HangfireOptions.Bind(app.Configuration);
Log.Information(
    "Hangfire: Enabled={Enabled}, Dashboard={DashboardPath}, DashboardAuth={DashboardAuth}",
    hangfire.Enabled,
    hangfire.DashboardPath,
    hangfire.IsActive);

DatabaseStartupLogger.LogConfiguration(app.Configuration);
StorageServiceCollectionExtensions.LogStorage(app.Configuration);
Log.Information("Database: migrate-on-boot=yes seed-on-boot={SeedOnBoot}", app.Environment.IsEnvironment("Testing"));

app.Lifetime.ApplicationStarted.Register(() =>
{
    var urls = app.Urls.Count > 0
        ? string.Join(", ", app.Urls)
        : "(see ASPNETCORE_URLS or launchSettings)";
    Log.Information("API listening: {Urls}", urls);
    var origin = app.Urls.FirstOrDefault() ?? "http://localhost:5201";
    Log.Information("API ping: {Ping}", $"{origin.TrimEnd('/')}/api");
    if (app.Environment.IsDevelopment())
    {
        Log.Information("OpenAPI: {OpenApi}  Scalar: {Scalar}", $"{origin.TrimEnd('/')}/openapi/v1.json", $"{origin.TrimEnd('/')}/docs");
    }
});

app.UseJUSPlatformForwardedHeaders();
app.UseMiddleware<ResponseIdMiddleware>();
app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseCors("JUSPlatformUi");
app.UseJUSPlatformRateLimiting();
app.UseSerilogRequestLogging(options =>
{
    options.EnrichDiagnosticContext = (diagnosticContext, httpContext) =>
    {
        diagnosticContext.Set(
            "ResponseId",
            ResponseIdMiddleware.GetResponseId(httpContext) ?? string.Empty);
    };

    options.GetLevel = (httpContext, elapsed, ex) =>
    {
        if (ex is not null)
        {
            return Serilog.Events.LogEventLevel.Error;
        }

        var path = httpContext.Request.Path.Value ?? string.Empty;
        if (path.StartsWith("/docs", StringComparison.OrdinalIgnoreCase)
            || path.StartsWith("/openapi", StringComparison.OrdinalIgnoreCase)
            || path.StartsWith("/scalar", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith(".js", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith(".css", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith(".svg", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith(".ico", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith(".map", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith(".woff2", StringComparison.OrdinalIgnoreCase))
        {
            return Serilog.Events.LogEventLevel.Debug;
        }

        var status = httpContext.Response.StatusCode;
        if (status >= 500)
        {
            return Serilog.Events.LogEventLevel.Error;
        }

        if (status >= 400)
        {
            return Serilog.Events.LogEventLevel.Warning;
        }

        return Serilog.Events.LogEventLevel.Information;
    };
});

app.UseJUSPlatformSpa();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference("/docs", options =>
    {
        options
            .WithTitle("Janatics Unified Suite API")
            .DisableTelemetry()
            .HideDeveloperTools()
            .WithCustomCss(
                """
                a[href*="scalar.com"],
                .section-flare-item,
                .powered-by-badge {
                  display: none !important;
                }
                """);
    });
}

app.UseAuthentication();
app.UseAuthorization();
app.UseJUSPlatformHangfireDashboard();
app.UseMiddleware<ApiErrorStatusMiddleware>();
app.MapControllers();
app.MapJUSPlatformSpaAndApiFallback();

app.Run();

public partial class Program;
