namespace JUSPlatform.Mock;

public sealed class MockIntegrationsOptions
{
    public const string SectionName = "MockIntegrations";

    public bool Enabled { get; set; }

    /// <summary>Base URL of Mock/MockServices (e.g. http://localhost:8090).</summary>
    public string BaseUrl { get; set; } = "http://localhost:8090";
}
