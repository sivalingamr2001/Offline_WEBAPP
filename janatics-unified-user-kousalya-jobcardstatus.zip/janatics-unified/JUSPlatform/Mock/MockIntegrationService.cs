using Microsoft.Extensions.Options;

namespace JUSPlatform.Mock;

public static class MockHttpClients
{
    public const string Downstream = "mock-downstream";
}

public static class MockServiceCollectionExtensions
{
    public static IServiceCollection AddJUSPlatformMockIntegrations(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<MockIntegrationsOptions>(configuration.GetSection(MockIntegrationsOptions.SectionName));
        services.AddHttpClient(MockHttpClients.Downstream, (sp, client) =>
        {
            var opts = sp.GetRequiredService<IOptionsMonitor<MockIntegrationsOptions>>().CurrentValue;
            client.BaseAddress = new Uri(opts.BaseUrl.TrimEnd('/') + "/");
            client.Timeout = TimeSpan.FromSeconds(30);
        });
        return services;
    }
}
