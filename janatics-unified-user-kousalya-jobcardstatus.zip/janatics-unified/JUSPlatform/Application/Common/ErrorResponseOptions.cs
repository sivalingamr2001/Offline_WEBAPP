namespace JUSPlatform.Application.Common;

/// <summary>
/// Controls optional fields on <see cref="ApiErrorResponse"/>.
/// Minimal default: success, detail, errors only (+ <c>X-Response-Id</c> header).
/// </summary>
public sealed class ErrorResponseOptions
{
    public const string SectionName = "ErrorResponse";

    /// <summary>RFC 7807 fields: type, title, status.</summary>
    public bool IncludeRfcFields { get; set; }

    /// <summary>W3C / ASP.NET distributed trace id (dev/support; not for form binding).</summary>
    public bool IncludeTraceId { get; set; }

    /// <summary>Stack / exception lines in the JSON body. Falls back to <c>AppDebug</c> when unset.</summary>
    public bool? IncludeException { get; set; }
}
