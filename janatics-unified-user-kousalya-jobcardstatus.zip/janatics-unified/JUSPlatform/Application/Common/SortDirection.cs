using System.Text.Json.Serialization;

namespace JUSPlatform.Application.Common;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum SortDirection
{
    [JsonStringEnumMemberName("asc")]
    Asc,

    [JsonStringEnumMemberName("desc")]
    Desc
}
