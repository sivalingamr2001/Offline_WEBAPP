namespace JUSPlatform.Application.Common;

public static class ListCacheKeys
{
    public const string Users = "users";
    public const string Roles = "roles";
    public const string Permissions = "permissions";
    public const string AppModules = "app-modules";
    public const string AppMenus = "app-menus";
}

/// <summary>
/// Paginated list response cache (keyed by org + resource + query fingerprint).
/// Controlled by <c>Redis:QueryCacheEnabled</c>.
/// </summary>
public interface IQueryCache
{
    Task<string?> TryGetJsonAsync(string cacheKey, CancellationToken cancellationToken);

    Task SetJsonAsync(
        string cacheKey,
        string json,
        QueryCacheIndex index,
        TimeSpan ttl,
        CancellationToken cancellationToken);

    Task InvalidateAsync(
        string resource,
        Guid? organizationId,
        string? suffix = null,
        CancellationToken cancellationToken = default);
}

public sealed record QueryCacheIndex(string Resource, Guid? OrganizationId, string? Suffix);
