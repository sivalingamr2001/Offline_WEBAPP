using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Application.Common;

public static class PagedQueryExtensions
{
    public static async Task<ApiPagedResponse<T>> ToPagedResponseAsync<T>(
        this IQueryable<T> query,
        PagedListQuery paging,
        CancellationToken cancellationToken)
    {
        var normalized = paging.Normalize();
        var totalItems = await query.CountAsync(cancellationToken);
        var items = await query
            .Skip((normalized.Page - 1) * normalized.PageSize)
            .Take(normalized.PageSize)
            .ToListAsync(cancellationToken);

        return ApiPagedResponse<T>.Create(items, normalized.Page, normalized.PageSize, totalItems);
    }

    public static IQueryable<T> ApplySearch<T>(
        this IQueryable<T> query,
        string? search,
        Func<IQueryable<T>, string, IQueryable<T>> apply)
    {
        if (string.IsNullOrWhiteSpace(search))
        {
            return query;
        }

        return apply(query, search.Trim());
    }
}
