using FluentValidation;

namespace JUSPlatform.Application.Common;

public sealed class PagedListQueryValidator : AbstractValidator<PagedListQuery>
{
    public PagedListQueryValidator()
    {
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize)
            .InclusiveBetween(1, PagedListQuery.MaxPageSize)
            .When(x => x.GetType() == typeof(PagedListQuery));
    }
}
