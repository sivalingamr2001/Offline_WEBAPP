using System.ComponentModel;
using System.Text.Json.Serialization;

namespace JUSPlatform.Application.Common;

public sealed record PingResponse(
    [property: Description("Always ok when the process is reachable.")] string Status,
    [property: Description("Fixed pong message.")] string Message,
    [property: Description("Server UTC timestamp.")] DateTimeOffset Utc);

public sealed record HealthResponse(
    [property: Description("healthy or unhealthy.")] string Status,
    [property: Description("API process status.")] string Api,
    [property: Description("Database connectivity status.")] string Database,
    [property: Description("Server UTC timestamp.")] DateTimeOffset Utc);

/// <summary>Minimal API error envelope. Optional RFC / trace / exception fields are config-gated.</summary>
public sealed class ApiErrorResponse
{
    [Description("Always false for error responses.")]
    public bool Success { get; init; }

    [Description("Human-readable summary (toast / banner).")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Detail { get; init; }

    [Description("Per-field validation messages (Laravel-style). Omitted when empty.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public IDictionary<string, string[]>? Errors { get; init; }

    [Description("RFC 7807 problem type URI. Present when ErrorResponse:IncludeRfcFields is true.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Type { get; init; }

    [Description("RFC 7807 short title. Present when ErrorResponse:IncludeRfcFields is true.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Title { get; init; }

    [Description("HTTP status duplicated in body. Present when ErrorResponse:IncludeRfcFields is true.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? Status { get; init; }

    [Description("Distributed trace id. Present when ErrorResponse:IncludeTraceId is true.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? TraceId { get; init; }

    [Description("Diagnostic lines when ErrorResponse:IncludeException or AppDebug is true.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyList<string>? Exception { get; init; }
}

/// <summary>Shared paginated list envelope for all collection endpoints.</summary>
public sealed class ApiPagedResponse<T>
{
    [Description("Page items.")]
    public IReadOnlyList<T> Items { get; init; } = [];

    [Description("Current 1-based page.")]
    public int Page { get; init; }

    [Description("Requested page size.")]
    public int PageSize { get; init; }

    [Description("Total rows matching query (all pages).")]
    public int TotalItems { get; init; }

    [Description("Total pages for this page size.")]
    public int TotalPages { get; init; }

    public static ApiPagedResponse<T> Create(
        IReadOnlyList<T> items,
        int page,
        int pageSize,
        int totalItems) =>
        new()
        {
            Items = items,
            Page = page,
            PageSize = pageSize,
            TotalItems = totalItems,
            TotalPages = pageSize <= 0 ? 0 : (int)Math.Ceiling(totalItems / (double)pageSize)
        };
}

