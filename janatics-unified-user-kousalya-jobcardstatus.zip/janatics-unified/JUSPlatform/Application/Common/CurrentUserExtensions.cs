using JUSPlatform.Authorization;
using JUSPlatform.Domain.Exceptions;

namespace JUSPlatform.Application.Common;

public static class CurrentUserExtensions
{
    public static bool IsSuperAdmin(this ICurrentUser user) =>
        SystemRoles.IsSuperAdmin(user.RoleName);

    public static Guid RequireOrganizationId(this ICurrentUser user)
    {
        if (user.IsSuperAdmin())
        {
            throw new BusinessRuleException(
                "Platform owner has no organization context. Target an organization explicitly.");
        }

        if (user.OrganizationId is not { } organizationId)
        {
            throw new UnauthorizedAccessException("Organization context is missing from the access token.");
        }

        return organizationId;
    }
}
