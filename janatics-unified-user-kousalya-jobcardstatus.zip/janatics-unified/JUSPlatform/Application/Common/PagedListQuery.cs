using System.ComponentModel;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Application.Common;

/// <summary>
/// Shared query contract for all paginated list endpoints (OpenAPI / Orval).
/// Wire names are camelCase: page, pageSize, search, sort, sortDir.
/// </summary>
public record PagedListQuery
{
    public const int DefaultPageSize = 25;
    public const int MaxPageSize = 100;

    [Description("1-based page number.")]
    [FromQuery(Name = "page")]
    [JsonPropertyName("page")]
    public int Page { get; init; } = 1;

    [Description("Page size (1–100).")]
    [FromQuery(Name = "pageSize")]
    [JsonPropertyName("pageSize")]
    public int PageSize { get; init; } = DefaultPageSize;

    [Description("Free-text search.")]
    [FromQuery(Name = "search")]
    [JsonPropertyName("search")]
    public string? Search { get; init; }

    [Description("Sort field.")]
    [FromQuery(Name = "sort")]
    [JsonPropertyName("sort")]
    public string? Sort { get; init; }

    [Description("Sort direction.")]
    [FromQuery(Name = "sortDir")]
    [JsonPropertyName("sortDir")]
    public SortDirection? SortDir { get; init; }

    public PagedListQuery Normalize()
    {
        var page = Math.Max(1, Page);
        var pageSize = Math.Min(PageSize, MaxPageSize);
        return this with { Page = page, PageSize = pageSize };
    }

    public bool IsDescending() => SortDir == SortDirection.Desc;
}
