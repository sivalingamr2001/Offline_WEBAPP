using System.Globalization;

namespace JUSPlatform.Application.CustomerComplaint;

public static class CustomerComplaintsOverviewCalculator
{
    public const decimal SlaTargetPct = 90m;
    public const string Footnote = "Complaint Rate (%) = (Total Complaints / Orders Delivered) × 100";

    public static DateOnly ResolveWeekStart(string? weekStart, DateOnly today)
    {
        if (string.IsNullOrWhiteSpace(weekStart) || !DateOnly.TryParse(weekStart, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed))
        {
            parsed = today;
        }

        var offset = parsed.DayOfWeek == DayOfWeek.Sunday ? 6 : (int)parsed.DayOfWeek - 1;
        return parsed.AddDays(-offset);
    }

    public static ComplaintSlaBucket Classify(DateOnly? closeDt, DateOnly? targetCompDt, DateOnly asOf)
    {
        if (closeDt is { } closed)
        {
            if (targetCompDt is null || closed <= targetCompDt)
            {
                return ComplaintSlaBucket.SolvedWithinSla;
            }

            return ComplaintSlaBucket.OpenOrBreached;
        }

        if (targetCompDt is { } target && asOf > target)
        {
            return ComplaintSlaBucket.OpenOrBreached;
        }

        return ComplaintSlaBucket.OpenWithinSla;
    }

    public static ComplaintsOverviewDto Build(
        IReadOnlyList<ComplaintFact> complaints,
        IReadOnlyList<SalesFact> sales,
        DateOnly weekStart,
        int page,
        int pageSize,
        DateTimeOffset asOf)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize <= 0 ? 10 : pageSize, 1, 100);

        var weekEnd = weekStart.AddDays(6);
        var priorStart = weekStart.AddDays(-7);
        var priorEnd = weekStart.AddDays(-1);
        var asOfDate = weekEnd;

        var currentComplaints = complaints.Where(x => x.CcrDate >= weekStart && x.CcrDate <= weekEnd).ToList();
        var priorComplaints = complaints.Where(x => x.CcrDate >= priorStart && x.CcrDate <= priorEnd).ToList();
        var currentSales = sales.Where(x => x.TrxDate >= weekStart && x.TrxDate <= weekEnd).ToList();
        var priorSales = sales.Where(x => x.TrxDate >= priorStart && x.TrxDate <= priorEnd).ToList();

        var currentBuckets = CountBuckets(currentComplaints, asOfDate);
        var priorBuckets = CountBuckets(priorComplaints, priorEnd);
        var currentOrders = currentSales.Sum(x => x.QuantityInvoiced);
        var priorOrders = priorSales.Sum(x => x.QuantityInvoiced);

        var total = currentBuckets.Total;
        var priorTotal = priorBuckets.Total;
        var rate = Rate(total, currentOrders);
        var priorRate = Rate(priorTotal, priorOrders);
        var withinSlaPct = Pct(currentBuckets.Solved, total);
        var priorWithinSlaPct = Pct(priorBuckets.Solved, priorTotal);

        var kpis = new ComplaintsOverviewKpisDto(
            Delta(total, priorTotal, total, total),
            Delta(currentBuckets.Solved, priorBuckets.Solved, currentBuckets.Solved, total),
            Delta(currentBuckets.Open, priorBuckets.Open, currentBuckets.Open, total),
            Delta(currentBuckets.Breached, priorBuckets.Breached, currentBuckets.Breached, total),
            new ComplaintsRateKpiDto(rate, priorRate, Math.Round(rate - priorRate, 2, MidpointRounding.AwayFromZero)));

        var trend = BuildTrend(currentComplaints, currentSales, weekStart, asOfDate);
        var products = BuildProducts(currentComplaints, currentSales, asOfDate);
        var totalProducts = products.Count;
        var pageRows = products
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        var totals = new ComplaintsProductTotalDto(
            currentOrders,
            total,
            Sla(currentBuckets.Solved, total),
            Sla(currentBuckets.Open, total),
            Sla(currentBuckets.Breached, total),
            rate);

        return new ComplaintsOverviewDto(
            "Customer Complaints Overview (WTD)",
            "Product-wise view of customer complaints from Customer Complaint Portal (Source System)",
            FormatPeriodLabel(weekStart, weekEnd),
            weekStart,
            weekEnd,
            asOf,
            kpis,
            trend,
            new ComplaintsSlaGaugeDto(
                withinSlaPct,
                priorWithinSlaPct,
                Math.Round(withinSlaPct - priorWithinSlaPct, 1, MidpointRounding.AwayFromZero),
                SlaTargetPct),
            pageRows,
            totals,
            page,
            pageSize,
            totalProducts,
            Footnote);
    }

    private static ComplaintsKpiDeltaDto Delta(int current, int previous, int numerator, int total) =>
        new(current, previous, ChangePct(current, previous), Pct(numerator, total));

    private static decimal? ChangePct(int current, int previous)
    {
        if (previous == 0)
        {
            return null;
        }

        return Math.Round((current - previous) / (decimal)previous * 100m, 1, MidpointRounding.AwayFromZero);
    }

    private static decimal Pct(int count, int total) =>
        total == 0 ? 0 : Math.Round(count / (decimal)total * 100m, 1, MidpointRounding.AwayFromZero);

    private static decimal Rate(int complaints, decimal orders) =>
        orders == 0 ? 0 : Math.Round(complaints / orders * 100m, 2, MidpointRounding.AwayFromZero);

    private static ComplaintsProductSlaCountsDto Sla(int count, int total) => new(count, Pct(count, total));

    private static (int Total, int Solved, int Open, int Breached) CountBuckets(
        IReadOnlyList<ComplaintFact> rows,
        DateOnly asOf)
    {
        var solved = 0;
        var open = 0;
        var breached = 0;
        foreach (var row in rows)
        {
            switch (Classify(row.CloseDt, row.TargetCompDt, asOf))
            {
                case ComplaintSlaBucket.SolvedWithinSla:
                    solved++;
                    break;
                case ComplaintSlaBucket.OpenWithinSla:
                    open++;
                    break;
                default:
                    breached++;
                    break;
            }
        }

        return (rows.Count, solved, open, breached);
    }

    private static IReadOnlyList<ComplaintsTrendPointDto> BuildTrend(
        IReadOnlyList<ComplaintFact> complaints,
        IReadOnlyList<SalesFact> sales,
        DateOnly weekStart,
        DateOnly asOf)
    {
        var points = new List<ComplaintsTrendPointDto>(7);
        for (var i = 0; i < 7; i++)
        {
            var day = weekStart.AddDays(i);
            var dayComplaints = complaints.Where(x => x.CcrDate == day).ToList();
            var buckets = CountBuckets(dayComplaints, asOf);
            var orders = sales.Where(x => x.TrxDate == day).Sum(x => x.QuantityInvoiced);
            points.Add(new ComplaintsTrendPointDto(
                day,
                FormatDayLabel(day),
                buckets.Solved,
                buckets.Open,
                buckets.Breached,
                Rate(buckets.Total, orders)));
        }

        return points;
    }

    private static List<ComplaintsProductRowDto> BuildProducts(
        IReadOnlyList<ComplaintFact> complaints,
        IReadOnlyList<SalesFact> sales,
        DateOnly asOf)
    {
        var complaintGroups = complaints
            .GroupBy(x => NormalizeCode(x.ItemNo))
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
        var salesGroups = sales
            .GroupBy(x => NormalizeCode(x.OrderedItem))
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);

        var codes = complaintGroups.Keys.ToList();
        var rows = new List<ComplaintsProductRowDto>(codes.Count);
        foreach (var code in codes)
        {
            complaintGroups.TryGetValue(code, out var complaintRows);
            salesGroups.TryGetValue(code, out var salesRows);
            complaintRows ??= [];
            salesRows ??= [];
            var buckets = CountBuckets(complaintRows, asOf);
            var orders = salesRows.Sum(x => x.QuantityInvoiced);
            var description = complaintRows.Select(x => x.Description).FirstOrDefault(x => x.Length > 0)
                ?? salesRows.Select(x => x.Description).FirstOrDefault(x => x.Length > 0)
                ?? "";
            rows.Add(new ComplaintsProductRowDto(
                0,
                code,
                description,
                orders,
                buckets.Total,
                Sla(buckets.Solved, buckets.Total),
                Sla(buckets.Open, buckets.Total),
                Sla(buckets.Breached, buckets.Total),
                Rate(buckets.Total, orders)));
        }

        return rows
            .OrderByDescending(x => x.TotalComplaints)
            .ThenByDescending(x => x.OrdersDelivered)
            .ThenBy(x => x.ProductCode, StringComparer.OrdinalIgnoreCase)
            .Select((row, index) => row with { Rank = index + 1 })
            .ToList();
    }

    private static string NormalizeCode(string? value) => string.IsNullOrWhiteSpace(value) ? "" : value.Trim();

    private static string FormatDayLabel(DateOnly date)
    {
        var dt = date.ToDateTime(TimeOnly.MinValue, DateTimeKind.Unspecified);
        return dt.ToString("MMM dd ddd", CultureInfo.InvariantCulture);
    }

    public static string FormatPeriodLabel(DateOnly start, DateOnly end)
    {
        var startDt = start.ToDateTime(TimeOnly.MinValue, DateTimeKind.Unspecified);
        var endDt = end.ToDateTime(TimeOnly.MinValue, DateTimeKind.Unspecified);
        return $"{startDt.ToString("MMM dd", CultureInfo.InvariantCulture)} – {endDt.ToString("MMM dd, yyyy", CultureInfo.InvariantCulture)} (WTD)";
    }
}
