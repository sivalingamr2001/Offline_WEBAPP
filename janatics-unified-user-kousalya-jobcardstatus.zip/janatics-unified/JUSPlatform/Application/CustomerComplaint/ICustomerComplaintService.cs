namespace JUSPlatform.Application.CustomerComplaint;

public interface ICustomerComplaintService
{
    Task<ComplaintsOverviewDto> GetComplaintsOverviewAsync(
        ComplaintsOverviewQuery query,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<ComplaintsWeekOptionDto>> ListAvailableWeeksAsync(
        Guid? organizationId,
        CancellationToken cancellationToken);
}
