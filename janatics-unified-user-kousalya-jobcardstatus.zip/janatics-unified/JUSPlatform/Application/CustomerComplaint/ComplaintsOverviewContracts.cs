using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;

namespace JUSPlatform.Application.CustomerComplaint;

public sealed record ComplaintsOverviewQuery
{
    [Description("Monday of the WTD window as yyyy-MM-dd. Defaults to the current UTC week.")]
    [FromQuery(Name = "weekStart")]
    public string? WeekStart { get; init; }

    [FromQuery(Name = "page")]
    public int Page { get; init; } = 1;

    [FromQuery(Name = "pageSize")]
    public int PageSize { get; init; } = 10;

    [Description("SuperAdmin only: organization to read. Org users ignore this and use the JWT tenant.")]
    [FromQuery(Name = "organizationId")]
    public Guid? OrganizationId { get; init; }
}

public sealed record ComplaintsWeekOptionDto(DateOnly WeekStart, DateOnly WeekEnd, string Label);

public sealed record ComplaintFact(
    DateOnly CcrDate,
    string ItemNo,
    string Description,
    DateOnly? TargetCompDt,
    DateOnly? CloseDt);

public sealed record SalesFact(
    DateOnly TrxDate,
    string OrderedItem,
    string Description,
    decimal QuantityInvoiced);

public sealed class ComplaintExtractRow
{
    public DateOnly Ccrdt { get; set; }
    public string? ItemNo { get; set; }
    public string? Description { get; set; }
    public DateOnly? TargetCompDt { get; set; }
    public DateOnly? CloseDt { get; set; }
}

public sealed class SalesExtractRow
{
    public DateTime TrxDate { get; set; }
    public string? OrderedItem { get; set; }
    public string? Description { get; set; }
    public decimal QuantityInvoiced { get; set; }
}

public sealed class ComplaintWeekStartRow
{
    public DateOnly WeekStart { get; set; }
}

public enum ComplaintSlaBucket
{
    SolvedWithinSla = 0,
    OpenWithinSla = 1,
    OpenOrBreached = 2
}

public sealed record ComplaintsKpiDeltaDto(
    int Current,
    int Previous,
    decimal? ChangePct,
    decimal PctOfTotal);

public sealed record ComplaintsRateKpiDto(
    decimal RatePct,
    decimal PreviousRatePct,
    decimal DeltaPp);

public sealed record ComplaintsOverviewKpisDto(
    ComplaintsKpiDeltaDto TotalComplaints,
    ComplaintsKpiDeltaDto SolvedWithinSla,
    ComplaintsKpiDeltaDto OpenWithinSla,
    ComplaintsKpiDeltaDto OpenBreachedSla,
    ComplaintsRateKpiDto ComplaintRate);

public sealed record ComplaintsTrendPointDto(
    DateOnly Date,
    string Label,
    int SolvedWithinSla,
    int OpenWithinSla,
    int OpenBreachedSla,
    decimal ComplaintRatePct);

public sealed record ComplaintsSlaGaugeDto(
    decimal WithinSlaPct,
    decimal PreviousWithinSlaPct,
    decimal DeltaPct,
    decimal TargetPct);

public sealed record ComplaintsProductSlaCountsDto(int Count, decimal Pct);

public sealed record ComplaintsProductRowDto(
    int Rank,
    string ProductCode,
    string ProductDescription,
    decimal OrdersDelivered,
    int TotalComplaints,
    ComplaintsProductSlaCountsDto SolvedWithinSla,
    ComplaintsProductSlaCountsDto OpenWithinSla,
    ComplaintsProductSlaCountsDto OpenBreachedSla,
    decimal ComplaintRatePct);

public sealed record ComplaintsProductTotalDto(
    decimal OrdersDelivered,
    int TotalComplaints,
    ComplaintsProductSlaCountsDto SolvedWithinSla,
    ComplaintsProductSlaCountsDto OpenWithinSla,
    ComplaintsProductSlaCountsDto OpenBreachedSla,
    decimal ComplaintRatePct);

public sealed record ComplaintsOverviewDto(
    string Title,
    string Subtitle,
    string PeriodLabel,
    DateOnly WeekStart,
    DateOnly WeekEnd,
    DateTimeOffset AsOf,
    ComplaintsOverviewKpisDto Kpis,
    IReadOnlyList<ComplaintsTrendPointDto> Trend,
    ComplaintsSlaGaugeDto Sla,
    IReadOnlyList<ComplaintsProductRowDto> Products,
    ComplaintsProductTotalDto Totals,
    int Page,
    int PageSize,
    int TotalProducts,
    string Footnote);
