using FluentValidation;

namespace JUSPlatform.Application.CustomerComplaint;

public sealed class ComplaintsOverviewQueryValidator : AbstractValidator<ComplaintsOverviewQuery>
{
    public ComplaintsOverviewQueryValidator()
    {
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, 100);
    }
}
