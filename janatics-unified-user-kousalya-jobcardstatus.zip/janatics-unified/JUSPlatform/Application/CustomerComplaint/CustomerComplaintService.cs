using JUSPlatform.Application.Access;
using System.Globalization;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace JUSPlatform.Application.CustomerComplaint;

public sealed class CustomerComplaintService(AppDbContext db, ICurrentUser currentUser) : ICustomerComplaintService
{
    public async Task<ComplaintsOverviewDto> GetComplaintsOverviewAsync(
        ComplaintsOverviewQuery query,
        CancellationToken cancellationToken)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var weekStart = CustomerComplaintsOverviewCalculator.ResolveWeekStart(query.WeekStart, today);
        var asOf = DateTimeOffset.UtcNow;
        var page = Math.Max(1, query.Page);
        var pageSize = Math.Clamp(query.PageSize <= 0 ? 10 : query.PageSize, 1, 100);

        var derivedOrgIds = await ResolveDerivedOrgIdsAsync(query.OrganizationId, cancellationToken);
        if (derivedOrgIds.Count == 0)
        {
            return CustomerComplaintsOverviewCalculator.Build([], [], weekStart, page, pageSize, asOf);
        }

        var custodianCodes = await ResolveCustodianCodesAsync(cancellationToken);
        if (!currentUser.IsSuperAdmin() && custodianCodes.Count == 0)
        {
            return CustomerComplaintsOverviewCalculator.Build([], [], weekStart, page, pageSize, asOf);
        }

        var priorStart = weekStart.AddDays(-7);
        var currentEnd = weekStart.AddDays(6);

        try
        {
            var orgIds = derivedOrgIds.ToArray();
            var complaintRows = await LoadComplaintsAsync(
                orgIds,
                custodianCodes,
                priorStart,
                currentEnd,
                cancellationToken);
            var salesRows = await LoadSalesAsync(
                orgIds,
                custodianCodes,
                priorStart,
                currentEnd,
                cancellationToken);

            var complaints = complaintRows
                .Select(x => new ComplaintFact(
                    x.Ccrdt,
                    x.ItemNo ?? "",
                    x.Description ?? "",
                    x.TargetCompDt,
                    x.CloseDt))
                .ToList();

            var sales = salesRows
                .Select(x => new SalesFact(
                    DateOnly.FromDateTime(x.TrxDate),
                    x.OrderedItem ?? "",
                    x.Description ?? "",
                    x.QuantityInvoiced))
                .ToList();

            return CustomerComplaintsOverviewCalculator.Build(complaints, sales, weekStart, page, pageSize, asOf);
        }
        catch (Exception ex) when (IsUndefinedRelation(ex))
        {
            return CustomerComplaintsOverviewCalculator.Build([], [], weekStart, page, pageSize, asOf);
        }
    }

    public async Task<IReadOnlyList<ComplaintsWeekOptionDto>> ListAvailableWeeksAsync(
        Guid? organizationId,
        CancellationToken cancellationToken)
    {
        var derivedOrgIds = await ResolveDerivedOrgIdsAsync(organizationId, cancellationToken);
        if (derivedOrgIds.Count == 0)
        {
            return [];
        }

        var custodianCodes = await ResolveCustodianCodesAsync(cancellationToken);
        if (!currentUser.IsSuperAdmin() && custodianCodes.Count == 0)
        {
            return [];
        }

        try
        {
            var starts = await LoadWeekStartsAsync(
                derivedOrgIds.ToArray(),
                custodianCodes,
                cancellationToken);
            return starts
                .Select(start =>
                {
                    var weekStart = CustomerComplaintsOverviewCalculator.ResolveWeekStart(
                        start.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        start);
                    var weekEnd = weekStart.AddDays(6);
                    return new ComplaintsWeekOptionDto(
                        weekStart,
                        weekEnd,
                        CustomerComplaintsOverviewCalculator.FormatPeriodLabel(weekStart, weekEnd));
                })
                .GroupBy(x => x.WeekStart)
                .Select(g => g.First())
                .OrderByDescending(x => x.WeekStart)
                .ToList();
        }
        catch (Exception ex) when (IsUndefinedRelation(ex))
        {
            return [];
        }
    }

    private async Task<List<decimal>> ResolveDerivedOrgIdsAsync(Guid? requested, CancellationToken cancellationToken)
    {
        if (currentUser.IsSuperAdmin())
        {
            var organizationId = await ResolveSuperAdminOrganizationIdAsync(requested, cancellationToken);
            return await LoadDerivedOrgIdsAsync([organizationId], cancellationToken);
        }

        var userId = currentUser.UserId;
        if (userId is null)
        {
            return [];
        }

        var membership = await db.UserAccessRights.AsNoTracking()
            .Where(x => x.UserId == userId.Value && x.IsActive)
            .Select(x => x.OrganizationId)
            .Distinct()
            .ToListAsync(cancellationToken);

        var organizationIds = membership;
        if (organizationIds.Count == 0)
        {
            var homeOrgId = await db.Users.AsNoTracking()
                .Where(x => x.Id == userId.Value)
                .Select(x => x.OrganizationId)
                .FirstOrDefaultAsync(cancellationToken);
            if (homeOrgId is { } home)
            {
                organizationIds.Add(home);
            }
        }

        return await LoadDerivedOrgIdsAsync(organizationIds, cancellationToken);
    }

    private async Task<List<decimal>> LoadDerivedOrgIdsAsync(
        IReadOnlyCollection<Guid> organizationIds,
        CancellationToken cancellationToken)
    {
        if (organizationIds.Count == 0)
        {
            return [];
        }

        return await db.Organizations.AsNoTracking()
            .Where(x => organizationIds.Contains(x.Id) && x.IsActive && x.OracleOrgId > 0)
            .Select(x => (decimal)x.OracleOrgId!.Value)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    private async Task<List<string>> ResolveCustodianCodesAsync(CancellationToken cancellationToken)
    {
        if (currentUser.IsSuperAdmin())
        {
            return [];
        }

        var userId = currentUser.UserId;
        if (userId is null)
        {
            return [];
        }

        var empId = await db.Users.AsNoTracking()
            .Where(x => x.Id == userId.Value)
            .Select(x => x.EmpId)
            .FirstOrDefaultAsync(cancellationToken);
        var trimmed = string.IsNullOrWhiteSpace(empId) ? "" : empId.Trim();

        try
        {
            var lines = await db.JanCustodianLines.AsNoTracking()
                .Where(x => x.ActiveFlag == 1 && x.CustodianCode != null && x.CustodianCode != "")
                .Select(x => new CustodianLineRef(x.UsersId, x.CardNo, x.CustodianCode))
                .ToListAsync(cancellationToken);

            return CustodianAccess.DistinctCodes(lines, userId.Value, trimmed);
        }
        catch (Exception ex) when (IsUndefinedRelation(ex))
        {
            return [];
        }
    }

    private async Task<Guid> ResolveSuperAdminOrganizationIdAsync(Guid? requested, CancellationToken cancellationToken)
    {
        if (requested is { } requestedId && requestedId != Guid.Empty)
        {
            var exists = await db.Organizations.AsNoTracking()
                .AnyAsync(x => x.Id == requestedId && x.IsActive, cancellationToken);
            if (!exists)
            {
                throw new NotFoundException(nameof(Organization), requestedId);
            }

            return requestedId;
        }

        var fallbackId = await db.Organizations.AsNoTracking()
            .Where(x => x.IsActive)
            .OrderBy(x => x.Code)
            .Select(x => (Guid?)x.Id)
            .FirstOrDefaultAsync(cancellationToken);

        if (fallbackId is null)
        {
            throw new BusinessRuleException("No organization is available for customer complaints.");
        }

        return fallbackId.Value;
    }

    private Task<List<ComplaintExtractRow>> LoadComplaintsAsync(
        decimal[] orgIds,
        IReadOnlyList<string> custodianCodes,
        DateOnly priorStart,
        DateOnly currentEnd,
        CancellationToken cancellationToken)
    {
        if (custodianCodes.Count == 0)
        {
            return db.Database.SqlQuery<ComplaintExtractRow>($"""
                SELECT ccrdt AS "Ccrdt",
                       item_no AS "ItemNo",
                       description AS "Description",
                       target_comp_dt AS "TargetCompDt",
                       close_dt AS "CloseDt"
                FROM jan_customer_complaint_tab
                WHERE derived_org_id = ANY({orgIds})
                  AND ccrdt IS NOT NULL
                  AND ccrdt >= {priorStart}
                  AND ccrdt <= {currentEnd}
                """).ToListAsync(cancellationToken);
        }

        var codes = custodianCodes.ToArray();
        return db.Database.SqlQuery<ComplaintExtractRow>($"""
            SELECT ccrdt AS "Ccrdt",
                   item_no AS "ItemNo",
                   description AS "Description",
                   target_comp_dt AS "TargetCompDt",
                   close_dt AS "CloseDt"
            FROM jan_customer_complaint_tab
            WHERE derived_org_id = ANY({orgIds})
              AND ccrdt IS NOT NULL
              AND ccrdt >= {priorStart}
              AND ccrdt <= {currentEnd}
              AND LOWER(BTRIM(custodian_code)) = ANY({codes})
            """).ToListAsync(cancellationToken);
    }

    private Task<List<SalesExtractRow>> LoadSalesAsync(
        decimal[] orgIds,
        IReadOnlyList<string> custodianCodes,
        DateOnly priorStart,
        DateOnly currentEnd,
        CancellationToken cancellationToken)
    {
        if (custodianCodes.Count == 0)
        {
            return db.Database.SqlQuery<SalesExtractRow>($"""
                SELECT (trx_date::date) AS "TrxDate",
                       ordered_item AS "OrderedItem",
                       MAX(description) AS "Description",
                       COALESCE(SUM(quantity_invoiced), 0) AS "QuantityInvoiced"
                FROM jan_all_ou_sales_tab
                WHERE org_id = ANY({orgIds})
                  AND trx_date::date >= {priorStart}
                  AND trx_date::date <= {currentEnd}
                GROUP BY trx_date::date, ordered_item
                """).ToListAsync(cancellationToken);
        }

        var codes = custodianCodes.ToArray();
        return db.Database.SqlQuery<SalesExtractRow>($"""
            SELECT (trx_date::date) AS "TrxDate",
                   ordered_item AS "OrderedItem",
                   MAX(description) AS "Description",
                   COALESCE(SUM(quantity_invoiced), 0) AS "QuantityInvoiced"
            FROM jan_all_ou_sales_tab
            WHERE org_id = ANY({orgIds})
              AND trx_date::date >= {priorStart}
              AND trx_date::date <= {currentEnd}
              AND ordered_item IN (
                  SELECT item_no
                  FROM jan_customer_complaint_tab
                  WHERE derived_org_id = ANY({orgIds})
                    AND ccrdt IS NOT NULL
                    AND ccrdt >= {priorStart}
                    AND ccrdt <= {currentEnd}
                    AND item_no IS NOT NULL
                    AND LOWER(BTRIM(custodian_code)) = ANY({codes})
              )
            GROUP BY trx_date::date, ordered_item
            """).ToListAsync(cancellationToken);
    }

    private Task<List<DateOnly>> LoadWeekStartsAsync(
        decimal[] orgIds,
        IReadOnlyList<string> custodianCodes,
        CancellationToken cancellationToken)
    {
        async Task<List<DateOnly>> MapAsync(IQueryable<ComplaintWeekStartRow> query)
        {
            var rows = await query.ToListAsync(cancellationToken);
            return rows.Select(x => x.WeekStart).Distinct().OrderByDescending(x => x).ToList();
        }

        if (custodianCodes.Count == 0)
        {
            return MapAsync(db.Database.SqlQuery<ComplaintWeekStartRow>($"""
                SELECT DISTINCT (date_trunc('week', ccrdt::timestamp)::date) AS "WeekStart"
                FROM jan_customer_complaint_tab
                WHERE derived_org_id = ANY({orgIds})
                  AND ccrdt IS NOT NULL
                """));
        }

        var codes = custodianCodes.ToArray();
        return MapAsync(db.Database.SqlQuery<ComplaintWeekStartRow>($"""
            SELECT DISTINCT (date_trunc('week', ccrdt::timestamp)::date) AS "WeekStart"
            FROM jan_customer_complaint_tab
            WHERE derived_org_id = ANY({orgIds})
              AND ccrdt IS NOT NULL
              AND LOWER(BTRIM(custodian_code)) = ANY({codes})
            """));
    }

    private static bool IsUndefinedRelation(Exception ex)
    {
        for (var current = ex; current is not null; current = current.InnerException)
        {
            if (current is PostgresException pg &&
                (pg.SqlState == PostgresErrorCodes.UndefinedTable || pg.SqlState == PostgresErrorCodes.UndefinedColumn))
            {
                return true;
            }
        }

        return false;
    }
}
