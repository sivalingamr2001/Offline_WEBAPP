using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Authentication;
using JUSPlatform.Infrastructure.Storage;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Application.Storage;

public sealed class StorageDownloadService(
    IObjectStorage storage,
    ICurrentUser currentUser,
    IOptions<StorageOptions> optionsAccessor,
    IConfiguration configuration) : IStorageDownloadService
{
    public Task<PrivateDownloadDto> CreateAsync(
        CreatePrivateDownloadRequest request,
        CancellationToken cancellationToken)
    {
        var organizationId = currentUser.RequireOrganizationId();
        string key;
        try
        {
            key = StorageKeys.Normalize(request.Key);
        }
        catch (InvalidOperationException)
        {
            throw new NotFoundException("Object", request.Key);
        }

        if (!StorageKeys.IsOrgPrivateObject(key, organizationId))
        {
            throw new NotFoundException("Object", key);
        }

        var minutes = Math.Clamp(optionsAccessor.Value.PrivateDownloadExpiryMinutes, 1, 15);
        var ttl = TimeSpan.FromMinutes(minutes);
        var download = storage.CreatePrivateDownload(key, ttl, request.FileName, request.VersionId);
        var expiresIn = Math.Max(1, (int)Math.Round((download.ExpiresAt - DateTimeOffset.UtcNow).TotalSeconds));
        return Task.FromResult(new PrivateDownloadDto(
            download.Url,
            download.ExpiresAt,
            expiresIn,
            download.Key,
            download.VersionId));
    }

    public async Task<LocalPrivateFile?> TryOpenLocalAsync(
        string? key,
        string? expiresUnix,
        string? signature,
        string? downloadFileName,
        string? versionId,
        CancellationToken cancellationToken)
    {
        string signingKey;
        try
        {
            signingKey = StorageSigning.ResolveKey(optionsAccessor.Value, configuration);
        }
        catch (InvalidOperationException)
        {
            return null;
        }

        if (!LocalDownloadTickets.TryValidate(
                key,
                expiresUnix,
                signature,
                downloadFileName,
                versionId,
                signingKey,
                out var ticket))
        {
            return null;
        }

        var stream = await storage.OpenReadAsync(ticket.Key, ticket.VersionId, cancellationToken);
        if (stream is null)
        {
            return null;
        }

        return new LocalPrivateFile(
            stream,
            ticket.FileName,
            StorageDownloadNames.ContentType(ticket.FileName));
    }
}

internal static class StorageSigning
{
    public static string ResolveKey(StorageOptions options, IConfiguration configuration)
    {
        if (!string.IsNullOrWhiteSpace(options.DownloadSigningKey))
        {
            return options.DownloadSigningKey.Trim();
        }

        var jwt = configuration[$"{JwtOptions.SectionName}:SigningKey"];
        if (!string.IsNullOrWhiteSpace(jwt))
        {
            return jwt.Trim();
        }

        throw new InvalidOperationException(
            "Set Storage:DownloadSigningKey or Jwt:SigningKey for local private downloads.");
    }
}
