namespace JUSPlatform.Application.Storage;

public interface IStorageDownloadService
{
    Task<PrivateDownloadDto> CreateAsync(CreatePrivateDownloadRequest request, CancellationToken cancellationToken);

    Task<LocalPrivateFile?> TryOpenLocalAsync(
        string? key,
        string? expiresUnix,
        string? signature,
        string? downloadFileName,
        string? versionId,
        CancellationToken cancellationToken);
}
