using System.Text;

namespace JUSPlatform.Application.Storage;

public static class StorageDownloadNames
{
    public static string SafeFileName(string? fileName, string? fallbackKey = null)
    {
        var raw = Path.GetFileName(string.IsNullOrWhiteSpace(fileName) ? fallbackKey : fileName) ?? "download";
        var builder = new StringBuilder(raw.Length);
        foreach (var c in raw)
        {
            if (char.IsAsciiLetterOrDigit(c) || c is '.' or '-' or '_')
            {
                builder.Append(c);
            }
        }

        var safe = builder.ToString().Trim('.');
        return string.IsNullOrWhiteSpace(safe) ? "download" : safe;
    }

    public static string ContentType(string fileName) =>
        Path.GetExtension(fileName).ToLowerInvariant() switch
        {
            ".csv" => "text/csv",
            ".pdf" => "application/pdf",
            ".txt" => "text/plain",
            ".json" => "application/json",
            ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".zip" => "application/zip",
            _ => "application/octet-stream"
        };
}
