using System.ComponentModel;

namespace JUSPlatform.Application.Storage;

public sealed record CreatePrivateDownloadRequest(
    [property: Description("Object key under exports|reports|private/{orgId}/.")] string Key,
    [property: Description("Download file name (Content-Disposition).")] string? FileName,
    [property: Description("Optional object version id.")] string? VersionId);

public sealed record PrivateDownloadDto(
    [property: Description("Time-limited GET URL. S3/MinIO presign, or local HMAC ticket.")] string Url,
    DateTimeOffset ExpiresAt,
    int ExpiresInSeconds,
    string Key,
    string? VersionId);

public sealed record LocalPrivateFile(Stream Stream, string FileName, string ContentType);
