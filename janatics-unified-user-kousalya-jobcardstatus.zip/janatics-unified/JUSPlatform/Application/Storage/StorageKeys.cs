namespace JUSPlatform.Application.Storage;

public static class StorageKeys
{
    public static string Normalize(string key)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new InvalidOperationException("Storage key is required.");
        }

        var normalized = key.Replace('\\', '/').Trim().TrimStart('/');
        if (normalized.Length == 0
            || normalized.Contains("..", StringComparison.Ordinal)
            || Path.IsPathRooted(normalized)
            || normalized.StartsWith(".versions/", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Storage key is not allowed.");
        }

        return normalized;
    }

    public static string Avatar(Guid? organizationId, Guid userId) =>
        $"uploads/avatars/{organizationId?.ToString() ?? "platform"}/{userId}.jpg";

    public static bool IsPrivateDownloadPrefix(string key)
    {
        var normalized = Normalize(key);
        return normalized.StartsWith("exports/", StringComparison.OrdinalIgnoreCase)
            || normalized.StartsWith("reports/", StringComparison.OrdinalIgnoreCase)
            || normalized.StartsWith("private/", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Restricted objects (reports, CSV exports). Key must be
    /// <c>exports|reports|private/{organizationId}/...</c>
    /// </summary>
    public static bool IsOrgPrivateObject(string key, Guid organizationId)
    {
        var normalized = Normalize(key);
        var org = organizationId.ToString();
        return normalized.StartsWith($"exports/{org}/", StringComparison.OrdinalIgnoreCase)
            || normalized.StartsWith($"reports/{org}/", StringComparison.OrdinalIgnoreCase)
            || normalized.StartsWith($"private/{org}/", StringComparison.OrdinalIgnoreCase);
    }

    public static string OrgExport(Guid organizationId, string fileName) =>
        $"exports/{organizationId}/{StorageDownloadNames.SafeFileName(fileName)}";
}
