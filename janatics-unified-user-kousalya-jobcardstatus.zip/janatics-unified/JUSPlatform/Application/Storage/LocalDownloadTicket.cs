using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace JUSPlatform.Application.Storage;

public sealed record LocalDownloadTicket(
    string Key,
    long ExpiresUnix,
    string Signature,
    string FileName,
    string? VersionId);

public static class LocalDownloadTickets
{
    public static LocalDownloadTicket Issue(
        string key,
        DateTimeOffset expiresAt,
        string signingKey,
        string? downloadFileName = null,
        string? versionId = null)
    {
        var normalized = StorageKeys.Normalize(key);
        var name = StorageDownloadNames.SafeFileName(downloadFileName, normalized);
        var version = string.IsNullOrWhiteSpace(versionId) ? null : versionId.Trim();
        var unix = expiresAt.ToUnixTimeSeconds();
        var signature = Sign(normalized, unix, version, name, signingKey);
        return new LocalDownloadTicket(normalized, unix, signature, name, version);
    }

    public static string ToQueryString(LocalDownloadTicket ticket)
    {
        var query = $"k={Uri.EscapeDataString(ticket.Key)}"
            + $"&e={ticket.ExpiresUnix.ToString(CultureInfo.InvariantCulture)}"
            + $"&s={Uri.EscapeDataString(ticket.Signature)}"
            + $"&n={Uri.EscapeDataString(ticket.FileName)}";
        if (!string.IsNullOrWhiteSpace(ticket.VersionId))
        {
            query += $"&v={Uri.EscapeDataString(ticket.VersionId)}";
        }

        return query;
    }

    public static bool TryValidate(
        string? key,
        string? expiresUnix,
        string? signature,
        string? downloadFileName,
        string? versionId,
        string signingKey,
        out LocalDownloadTicket ticket)
    {
        ticket = null!;
        if (string.IsNullOrWhiteSpace(key)
            || string.IsNullOrWhiteSpace(expiresUnix)
            || string.IsNullOrWhiteSpace(signature)
            || string.IsNullOrWhiteSpace(signingKey))
        {
            return false;
        }

        if (!long.TryParse(expiresUnix, NumberStyles.Integer, CultureInfo.InvariantCulture, out var unix)
            || unix <= 0)
        {
            return false;
        }

        string normalized;
        try
        {
            normalized = StorageKeys.Normalize(key);
        }
        catch (InvalidOperationException)
        {
            return false;
        }

        if (!StorageKeys.IsPrivateDownloadPrefix(normalized))
        {
            return false;
        }

        if (DateTimeOffset.UtcNow.ToUnixTimeSeconds() > unix)
        {
            return false;
        }

        var name = StorageDownloadNames.SafeFileName(downloadFileName, normalized);
        var version = string.IsNullOrWhiteSpace(versionId) ? null : versionId.Trim();
        var expected = Sign(normalized, unix, version, name, signingKey);
        if (!SignaturesEqual(expected, signature))
        {
            return false;
        }

        ticket = new LocalDownloadTicket(normalized, unix, expected, name, version);
        return true;
    }

    private static string Sign(
        string key,
        long expiresUnix,
        string? versionId,
        string fileName,
        string signingKey)
    {
        var payload = $"{key}\n{expiresUnix.ToString(CultureInfo.InvariantCulture)}\n{versionId ?? ""}\n{fileName}";
        var hash = HMACSHA256.HashData(Encoding.UTF8.GetBytes(signingKey), Encoding.UTF8.GetBytes(payload));
        return ToBase64Url(hash);
    }

    private static bool SignaturesEqual(string expectedBase64Url, string provided)
    {
        var expected = Encoding.UTF8.GetBytes(expectedBase64Url);
        var actual = Encoding.UTF8.GetBytes(provided.Trim());
        if (expected.Length != actual.Length)
        {
            CryptographicOperations.FixedTimeEquals(expected, expected);
            return false;
        }

        return CryptographicOperations.FixedTimeEquals(expected, actual);
    }

    private static string ToBase64Url(byte[] bytes) =>
        Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
}
