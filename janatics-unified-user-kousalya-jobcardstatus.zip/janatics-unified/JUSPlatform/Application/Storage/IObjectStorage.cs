namespace JUSPlatform.Application.Storage;

public sealed record StoredObject(string Key, string? VersionId, string ContentType, long Size);

public sealed record StoredObjectVersion(string Key, string VersionId, bool IsLatest, DateTimeOffset LastModified, long Size);

public interface IObjectStorage
{
    Task<StoredObject> PutAsync(string key, Stream content, string contentType, CancellationToken cancellationToken);

    Task<Stream?> OpenReadAsync(string key, string? versionId, CancellationToken cancellationToken);

    Task DeleteAsync(string key, CancellationToken cancellationToken);

    Task<IReadOnlyList<StoredObjectVersion>> ListVersionsAsync(string key, CancellationToken cancellationToken);

    /// <summary>Browser-usable URL: local static path, or a time-limited S3/MinIO presigned GET (avatars).</summary>
    string? GetReadUrl(string? key, string? versionId = null);

    /// <summary>
    /// Short-lived download link for private files (reports, CSV).
    /// S3/MinIO: native presigned GET. Local: HMAC ticket to <c>/api/v1/storage/download</c>.
    /// </summary>
    PresignedDownload CreatePrivateDownload(
        string key,
        TimeSpan timeToLive,
        string? downloadFileName = null,
        string? versionId = null);
}
