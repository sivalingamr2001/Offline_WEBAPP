namespace JUSPlatform.Application.Storage;

public sealed record PresignedDownload(
    string Url,
    DateTimeOffset ExpiresAt,
    string Key,
    string? VersionId);
