using FluentValidation;

namespace JUSPlatform.Application.Storage;

public sealed class CreatePrivateDownloadRequestValidator : AbstractValidator<CreatePrivateDownloadRequest>
{
    public CreatePrivateDownloadRequestValidator()
    {
        RuleFor(x => x.Key).NotEmpty().MaximumLength(512);
        RuleFor(x => x.FileName).MaximumLength(200);
        RuleFor(x => x.VersionId).MaximumLength(128);
    }
}
