using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;

namespace JUSPlatform.Application.Access;

public sealed record MenuAccessDto(
    Guid MenuId,
    bool CanCreate,
    bool CanRead,
    bool CanUpdate,
    bool CanDelete);

public sealed record NavMenuDto(
    Guid Id,
    Guid? ParentId,
    string Code,
    string Name,
    string? Path,
    string? Icon,
    int SortOrder,
    string? PermissionCode,
    bool CanCreate,
    bool CanRead,
    bool CanUpdate,
    bool CanDelete);

public sealed record NavModuleDto(
    Guid Id,
    string Code,
    string Name,
    string? Icon,
    int SortOrder,
    IReadOnlyList<NavMenuDto> Menus);

public static class NavigationAccessResolver
{
    public static IReadOnlyList<NavModuleDto> Resolve(
        string? roleName,
        IReadOnlyCollection<string> permissions,
        IReadOnlyList<AppModule> modules,
        IReadOnlyList<AppMenu> menus,
        IReadOnlyList<RoleMenu> roleMenus)
    {
        var flags = BuildFlags(roleName, permissions, menus, roleMenus);
        if (flags.Count == 0)
        {
            return [];
        }

        IncludeParents(menus, flags);

        var menusByModule = menus
            .Where(m => m.IsActive && flags.ContainsKey(m.Id))
            .GroupBy(m => m.ModuleId)
            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.SortOrder).ThenBy(x => x.Name).ToList());

        return modules
            .Where(m => m.IsActive && menusByModule.ContainsKey(m.Id))
            .OrderBy(m => m.SortOrder)
            .ThenBy(m => m.Name)
            .Select(module => new NavModuleDto(
                module.Id,
                module.Code,
                module.Name,
                module.Icon,
                module.SortOrder,
                menusByModule[module.Id]
                    .Select(menu => MapMenu(menu, flags[menu.Id]))
                    .ToList()))
            .ToList();
    }

    private static Dictionary<Guid, AccessFlags> BuildFlags(
        string? roleName,
        IReadOnlyCollection<string> permissions,
        IReadOnlyList<AppMenu> menus,
        IReadOnlyList<RoleMenu> roleMenus)
    {
        var flags = new Dictionary<Guid, AccessFlags>();
        var permissionSet = permissions.ToHashSet(StringComparer.OrdinalIgnoreCase);

        if (SystemRoles.IsSuperAdmin(roleName) || SystemRoles.IsAdmin(roleName))
        {
            foreach (var menu in menus.Where(m => m.IsActive))
            {
                flags[menu.Id] = AccessFlags.Full();
            }

            return flags;
        }

        foreach (var link in roleMenus)
        {
            Merge(flags, link.MenuId, new AccessFlags(link.CanCreate, link.CanRead, link.CanUpdate, link.CanDelete));
        }

        foreach (var menu in menus.Where(m => m.IsActive && !string.IsNullOrWhiteSpace(AppMenuCatalog.ResolvePermissionCode(m))))
        {
            if (permissionSet.Contains(AppMenuCatalog.ResolvePermissionCode(menu)!))
            {
                Merge(flags, menu.Id, AccessFlags.ReadOnly());
            }
        }

        return flags;
    }

    private static void IncludeParents(IReadOnlyList<AppMenu> menus, Dictionary<Guid, AccessFlags> flags)
    {
        var byId = menus.ToDictionary(m => m.Id);
        foreach (var menuId in flags.Keys.ToList())
        {
            var current = byId.GetValueOrDefault(menuId);
            while (current is not null)
            {
                var parentId = AppMenuCatalog.ResolveParentId(current);
                if (parentId is not { } id)
                {
                    break;
                }

                Merge(flags, id, AccessFlags.ReadOnly());
                current = byId.GetValueOrDefault(id);
            }
        }
    }

    private static void Merge(Dictionary<Guid, AccessFlags> flags, Guid menuId, AccessFlags incoming)
    {
        flags[menuId] = flags.TryGetValue(menuId, out var existing)
            ? existing.Or(incoming)
            : incoming;
    }

    private static NavMenuDto MapMenu(AppMenu menu, AccessFlags access) =>
        new(
            menu.Id,
            AppMenuCatalog.ResolveParentId(menu),
            menu.Code,
            AppMenuCatalog.ResolveName(menu),
            AppMenuCatalog.ResolvePath(menu),
            AppMenuCatalog.ResolveIcon(menu),
            menu.SortOrder,
            AppMenuCatalog.ResolvePermissionCode(menu),
            access.CanCreate,
            access.CanRead,
            access.CanUpdate,
            access.CanDelete);

    private readonly record struct AccessFlags(bool CanCreate, bool CanRead, bool CanUpdate, bool CanDelete)
    {
        public bool IsVisible => CanCreate || CanRead || CanUpdate || CanDelete;

        public static AccessFlags Full() => new(true, true, true, true);

        public static AccessFlags ReadOnly() => new(false, true, false, false);

        public AccessFlags Or(AccessFlags other) =>
            new(
                CanCreate || other.CanCreate,
                CanRead || other.CanRead,
                CanUpdate || other.CanUpdate,
                CanDelete || other.CanDelete);
    }
}
