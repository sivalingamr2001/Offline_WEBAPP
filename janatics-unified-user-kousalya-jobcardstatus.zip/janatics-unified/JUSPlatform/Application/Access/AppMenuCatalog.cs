using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;

namespace JUSPlatform.Application.Access;

public static class AppMenuCatalog
{
    public const string NaturePlatform = "PLATFORM";
    public const string NatureTenant = "TENANT";
    public const string MenuTypeScreen = "SCREEN";

    public static string? ResolvePath(AppMenu menu) =>
        FirstNonEmpty(menu.Path, menu.MenuPath);

    public static string? ResolveIcon(AppMenu menu) =>
        FirstNonEmpty(menu.Icon, menu.MenuIcon);

    public static Guid? ResolveParentId(AppMenu menu) =>
        menu.ParentId ?? menu.ParentMenuId;

    public static string ResolveName(AppMenu menu) =>
        FirstNonEmpty(menu.DisplayName, menu.Name) ?? menu.Code;

    public static string? ResolvePermissionCode(AppMenu menu)
    {
        if (!string.IsNullOrWhiteSpace(menu.PermissionCode))
        {
            return menu.PermissionCode;
        }

        return menu.ResourceCode?.Trim().ToLowerInvariant() switch
        {
            "user" => Permissions.UsersRead,
            "role" => Permissions.RolesRead,
            "permission" => Permissions.RolesRead,
            "module" => Permissions.ModulesRead,
            "org" => Permissions.OrgsRead,
            "menu" => Permissions.MenusRead,
            _ => null
        };
    }

    public static bool IsPlatformMenu(AppMenu menu) =>
        string.Equals(menu.Nature, NaturePlatform, StringComparison.OrdinalIgnoreCase)
        || string.IsNullOrWhiteSpace(menu.Nature);

    public static bool IsTenantMenu(AppMenu menu) =>
        string.Equals(menu.Nature, NatureTenant, StringComparison.OrdinalIgnoreCase);

    public static bool IsRolesCatalogMenu(AppMenu menu)
    {
        if (string.Equals(menu.Code, "MNU002", StringComparison.OrdinalIgnoreCase)
            || string.Equals(menu.Code, "ROL", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        var path = ResolvePath(menu);
        return string.Equals(path, "/dashboard/roles", StringComparison.OrdinalIgnoreCase);
    }

    private static string? FirstNonEmpty(params string?[] values)
    {
        foreach (var value in values)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                return value.Trim();
            }
        }

        return null;
    }
}
