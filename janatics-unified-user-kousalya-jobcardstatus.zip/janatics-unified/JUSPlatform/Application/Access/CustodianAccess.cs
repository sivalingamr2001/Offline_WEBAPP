namespace JUSPlatform.Application.Access;

/// <summary>
/// One card_no (users.emp_id) can map to many jan_custodian_lines rows.
/// All active custodian_code values must be used when loading OSP jobs.
/// </summary>
public static class CustodianAccess
{
    public static bool MatchesCardNo(string? cardNo, string? empId)
    {
        if (string.IsNullOrWhiteSpace(cardNo) || string.IsNullOrWhiteSpace(empId))
        {
            return false;
        }

        return NormalizeCardNo(cardNo) == NormalizeCardNo(empId);
    }

    public static string NormalizeCardNo(string value)
    {
        var trimmed = value.Trim();
        var stripped = trimmed.TrimStart('0');
        return stripped.Length == 0 ? "0" : stripped;
    }

    public static List<string> DistinctCodes(
        IEnumerable<CustodianLineRef> lines,
        Guid userId,
        string? empId)
    {
        var trimmed = string.IsNullOrWhiteSpace(empId) ? "" : empId.Trim();
        return lines
            .Where(x => !string.IsNullOrWhiteSpace(x.CustodianCode))
            .Where(x =>
                x.UsersId == userId
                || (trimmed.Length > 0 && MatchesCardNo(x.CardNo, trimmed)))
            .Select(x => x.CustodianCode!.Trim().ToLowerInvariant())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.Ordinal)
            .ToList();
    }

    public static bool MatchesCustodianCode(string? wipCode, IReadOnlyCollection<string> codes)
    {
        if (string.IsNullOrWhiteSpace(wipCode) || codes.Count == 0)
        {
            return false;
        }

        return codes.Contains(wipCode.Trim().ToLowerInvariant());
    }
}

public readonly record struct CustodianLineRef(Guid? UsersId, string? CardNo, string? CustodianCode);
