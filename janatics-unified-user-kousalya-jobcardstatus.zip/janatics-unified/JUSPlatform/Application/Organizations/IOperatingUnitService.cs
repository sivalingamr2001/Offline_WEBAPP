using JUSPlatform.Application.Common;

namespace JUSPlatform.Application.Organizations;

public sealed record OperatingUnitDto(
    Guid Id,
    int OrgId,
    string Name,
    bool IsActive,
    DateTimeOffset CreatedAt);

public sealed record CreateOperatingUnitRequest(int OrgId, string Name, bool IsActive = true);

public interface IOperatingUnitService
{
    Task<ApiPagedResponse<OperatingUnitDto>> ListAsync(PagedListQuery query, CancellationToken cancellationToken);
    Task<OperatingUnitDto> CreateAsync(CreateOperatingUnitRequest request, CancellationToken cancellationToken);
}
