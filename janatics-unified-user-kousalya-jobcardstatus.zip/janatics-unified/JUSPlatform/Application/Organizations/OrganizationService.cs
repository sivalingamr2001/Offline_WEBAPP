using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Application.Organizations;

public sealed class OrganizationService(AppDbContext db, ICurrentUser currentUser) : IOrganizationService
{
    public async Task<ApiPagedResponse<OrganizationDto>> ListAsync(
        PagedListQuery query,
        CancellationToken cancellationToken)
    {
        EnsureSuperAdmin();
        var paging = query.Normalize();

        var q = db.Organizations.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(paging.Search))
        {
            var term = paging.Search.Trim();
            q = q.Where(x =>
                x.Name.Contains(term) ||
                x.Code.Contains(term) ||
                (x.UnitName != null && x.UnitName.Contains(term)));
        }

        q = paging.IsDescending()
            ? q.OrderByDescending(x => x.Name)
            : q.OrderBy(x => x.Name);

        return await Project(q).ToPagedResponseAsync(paging, cancellationToken);
    }

    public async Task<OrganizationDto> GetCurrentAsync(CancellationToken cancellationToken)
    {
        var organizationId = currentUser.RequireOrganizationId();
        var org = await Project(db.Organizations.AsNoTracking().Where(x => x.Id == organizationId))
            .FirstOrDefaultAsync(cancellationToken);

        return org ?? throw new NotFoundException(nameof(Organization), organizationId);
    }

    public async Task<OrganizationDto> UpdateCurrentAsync(
        UpdateOrganizationRequest request,
        CancellationToken cancellationToken)
    {
        var organizationId = currentUser.RequireOrganizationId();
        var org = await db.Organizations.FirstOrDefaultAsync(x => x.Id == organizationId, cancellationToken)
            ?? throw new NotFoundException(nameof(Organization), organizationId);

        org.Name = request.Name.Trim();
        org.IsActive = request.IsActive;
        await db.SaveChangesAsync(cancellationToken);

        return await GetMappedAsync(org.Id, cancellationToken);
    }

    public async Task<OrganizationDto> CreateAsync(CreateOrganizationRequest request, CancellationToken cancellationToken)
    {
        EnsureSuperAdmin();

        var code = request.Code.Trim().ToUpperInvariant();
        if (await db.Organizations.AnyAsync(x => x.Code == code, cancellationToken))
        {
            throw new ConflictException($"Organization code '{code}' already exists.");
        }

        await EnsureOperatingUnitExistsAsync(request.OperatingUnitId, cancellationToken);

        int? operatingUnitOrgId = null;
        if (request.OperatingUnitId is { } operatingUnitId)
        {
            operatingUnitOrgId = await db.OperatingUnits
                .Where(x => x.Id == operatingUnitId)
                .Select(x => (int?)x.OrgId)
                .FirstAsync(cancellationToken);
        }

        var org = new Organization
        {
            Name = request.Name.Trim(),
            Code = code,
            OperatingUnitId = operatingUnitOrgId,
            OracleOrgId = request.OracleOrgId,
            UnitName = NormalizeOptional(request.UnitName)
        };

        db.Organizations.Add(org);
        await db.SaveChangesAsync(cancellationToken);
        await SystemRoleSeeder.EnsureForOrganizationAsync(db, org.Id, cancellationToken);

        return await GetMappedAsync(org.Id, cancellationToken);
    }

    private async Task EnsureOperatingUnitExistsAsync(Guid? operatingUnitId, CancellationToken cancellationToken)
    {
        if (operatingUnitId is null)
        {
            return;
        }

        var exists = await db.OperatingUnits.AnyAsync(x => x.Id == operatingUnitId, cancellationToken);
        if (!exists)
        {
            throw new NotFoundException(nameof(OperatingUnit), operatingUnitId.Value);
        }
    }

    private async Task<OrganizationDto> GetMappedAsync(Guid id, CancellationToken cancellationToken)
    {
        return await Project(db.Organizations.AsNoTracking().Where(x => x.Id == id))
            .FirstAsync(cancellationToken);
    }

    private IQueryable<OrganizationDto> Project(IQueryable<Organization> query) =>
        from o in query
        join ou in db.OperatingUnits.AsNoTracking() on o.OperatingUnitId equals ou.OrgId into ous
        from ou in ous.DefaultIfEmpty()
        select new OrganizationDto(
            o.Id,
            o.Name,
            o.Code,
            o.IsActive,
            o.CreatedAt,
            ou != null ? ou.Id : null,
            ou != null ? ou.Name : null,
            o.OracleOrgId,
            o.UnitName);

    private static string? NormalizeOptional(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private void EnsureSuperAdmin()
    {
        if (!currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Only the platform owner can manage all organizations.");
        }
    }
}
