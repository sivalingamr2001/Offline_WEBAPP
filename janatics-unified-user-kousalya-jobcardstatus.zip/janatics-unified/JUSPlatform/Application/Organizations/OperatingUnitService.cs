using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Application.Organizations;

public sealed class OperatingUnitService(AppDbContext db, ICurrentUser currentUser) : IOperatingUnitService
{
    public async Task<ApiPagedResponse<OperatingUnitDto>> ListAsync(
        PagedListQuery query,
        CancellationToken cancellationToken)
    {
        EnsureSuperAdmin();
        var paging = query.Normalize();
        var q = db.OperatingUnits.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(paging.Search))
        {
            var term = paging.Search.Trim();
            q = q.Where(x => x.Name.Contains(term) || x.OrgId.ToString() == term);
        }

        q = paging.IsDescending()
            ? q.OrderByDescending(x => x.Name)
            : q.OrderBy(x => x.Name);

        return await q
            .Select(x => new OperatingUnitDto(x.Id, x.OrgId, x.Name, x.IsActive, x.CreatedAt))
            .ToPagedResponseAsync(paging, cancellationToken);
    }

    public async Task<OperatingUnitDto> CreateAsync(
        CreateOperatingUnitRequest request,
        CancellationToken cancellationToken)
    {
        EnsureSuperAdmin();

        if (await db.OperatingUnits.AnyAsync(x => x.OrgId == request.OrgId, cancellationToken))
        {
            throw new ConflictException($"Operating unit org_id '{request.OrgId}' already exists.");
        }

        var entity = new OperatingUnit
        {
            OrgId = request.OrgId,
            Name = request.Name.Trim(),
            IsActive = request.IsActive
        };
        db.OperatingUnits.Add(entity);
        await db.SaveChangesAsync(cancellationToken);
        return new OperatingUnitDto(entity.Id, entity.OrgId, entity.Name, entity.IsActive, entity.CreatedAt);
    }

    private void EnsureSuperAdmin()
    {
        if (!currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Only the platform owner can manage operating units.");
        }
    }
}
