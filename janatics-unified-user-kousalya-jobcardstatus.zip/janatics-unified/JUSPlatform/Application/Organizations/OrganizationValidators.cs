using FluentValidation;

namespace JUSPlatform.Application.Organizations;

public sealed class CreateOrganizationRequestValidator : AbstractValidator<CreateOrganizationRequest>
{
    public CreateOrganizationRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Code).NotEmpty().MaximumLength(50);
        RuleFor(x => x.UnitName).MaximumLength(100);
        RuleFor(x => x.OracleOrgId).GreaterThan(0).When(x => x.OracleOrgId.HasValue);
    }
}

public sealed class UpdateOrganizationRequestValidator : AbstractValidator<UpdateOrganizationRequest>
{
    public UpdateOrganizationRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
    }
}

public sealed class CreateOperatingUnitRequestValidator : AbstractValidator<CreateOperatingUnitRequest>
{
    public CreateOperatingUnitRequestValidator()
    {
        RuleFor(x => x.OrgId).GreaterThan(0);
        RuleFor(x => x.Name).NotEmpty().MaximumLength(255);
    }
}
