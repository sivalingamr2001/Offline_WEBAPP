using JUSPlatform.Application.Common;

namespace JUSPlatform.Application.Organizations;

public sealed record OrganizationDto(
    Guid Id,
    string Name,
    string Code,
    bool IsActive,
    DateTimeOffset CreatedAt,
    Guid? OperatingUnitId,
    string? OperatingUnitName,
    long? OracleOrgId,
    string? UnitName);

public sealed record CreateOrganizationRequest(
    string Name,
    string Code,
    Guid? OperatingUnitId = null,
    long? OracleOrgId = null,
    string? UnitName = null);

public sealed record UpdateOrganizationRequest(
    string Name,
    bool IsActive);

public interface IOrganizationService
{
    /// <summary>Platform SuperAdmin: lists all organizations.</summary>
    Task<ApiPagedResponse<OrganizationDto>> ListAsync(PagedListQuery query, CancellationToken cancellationToken);

    /// <summary>Returns the caller's organization from JWT org_id. No client-supplied id.</summary>
    Task<OrganizationDto> GetCurrentAsync(CancellationToken cancellationToken);

    /// <summary>Updates the caller's organization from JWT org_id. No client-supplied id.</summary>
    Task<OrganizationDto> UpdateCurrentAsync(UpdateOrganizationRequest request, CancellationToken cancellationToken);

    /// <summary>
    /// SuperAdmin provisions a new organization. Does not switch the caller's JWT tenant.
    /// </summary>
    Task<OrganizationDto> CreateAsync(CreateOrganizationRequest request, CancellationToken cancellationToken);
}
