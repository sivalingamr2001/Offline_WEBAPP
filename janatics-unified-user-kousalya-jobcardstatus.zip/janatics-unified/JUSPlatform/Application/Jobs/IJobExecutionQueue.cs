namespace JUSPlatform.Application.Jobs;

/// <summary>Dispatches a persisted job run for background execution.</summary>
public interface IJobExecutionQueue
{
    void Enqueue(Guid jobRunId);
}
