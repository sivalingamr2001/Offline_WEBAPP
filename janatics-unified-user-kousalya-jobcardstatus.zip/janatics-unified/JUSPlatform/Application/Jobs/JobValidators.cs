namespace JUSPlatform.Application.Jobs;

using System.Text.Json;
using FluentValidation;
using JUSPlatform.Application.Common;

public sealed class EnqueueJobRequestValidator : AbstractValidator<EnqueueJobRequest>
{
    public EnqueueJobRequestValidator()
    {
        RuleFor(x => x.JobType).NotEmpty().MaximumLength(64);
        RuleFor(x => x.Payload.ValueKind).NotEqual(JsonValueKind.Undefined);
    }
}

public sealed class JobListQueryValidator : AbstractValidator<JobListQuery>
{
    public JobListQueryValidator() => Include(new PagedListQueryValidator());
}
