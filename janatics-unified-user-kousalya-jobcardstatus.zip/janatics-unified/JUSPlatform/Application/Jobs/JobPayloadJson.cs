using System.Text.Json;
using FluentValidation;

namespace JUSPlatform.Application.Jobs;

internal static class JobPayloadJson
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };

    public static T DeserializeRequired<T>(JsonElement payload, string context)
    {
        if (payload.ValueKind != JsonValueKind.Object)
        {
            throw new ValidationException($"Invalid {context} payload.");
        }

        return payload.Deserialize<T>(Options)
            ?? throw new ValidationException($"Invalid {context} payload.");
    }
}
