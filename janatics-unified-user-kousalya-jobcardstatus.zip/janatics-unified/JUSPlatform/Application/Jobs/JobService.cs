using System.Text.Json;
using FluentValidation;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Enums;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Jobs;
using JUSPlatform.Infrastructure.Observability;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Application.Jobs;

public sealed class JobService(
    AppDbContext db,
    ICurrentUser currentUser,
    JobHandlerRegistry handlers,
    IOptions<JobsOptions> options,
    IJobExecutionQueue executionQueue) : IJobService
{
    public async Task<JobAcceptedResponse> EnqueueAsync(
        EnqueueJobRequest request,
        CancellationToken cancellationToken)
    {
        var organizationId = currentUser.RequireOrganizationId();
        var userId = currentUser.UserId
            ?? throw new BusinessRuleException("Authenticated user id is required to enqueue jobs.");

        var handler = handlers.GetHandler(request.JobType);
        handler.ValidatePayload(request.Payload);

        var payloadJson = request.Payload.GetRawText();
        var traceId = JUSPlatformActivity.CurrentTraceId;
        var now = DateTimeOffset.UtcNow;

        var job = new JobRun
        {
            OrganizationId = organizationId,
            CreatedByUserId = userId,
            JobType = request.JobType.Trim(),
            Status = JobStatus.Queued,
            PayloadJson = payloadJson,
            TraceId = traceId,
            MaxAttempts = Math.Max(1, options.Value.MaxAttempts),
            QueuedAt = now,
            NextRunAt = now
        };

        db.JobRuns.Add(job);
        await db.SaveChangesAsync(cancellationToken);

        db.JobLogEntries.Add(new JobLogEntry
        {
            JobRunId = job.Id,
            Level = "Info",
            Message = $"Job queued ({job.JobType}).",
            CreatedAt = now
        });
        await db.SaveChangesAsync(cancellationToken);

        executionQueue.Enqueue(job.Id);

        return new JobAcceptedResponse(
            job.Id,
            job.Status,
            $"/api/v1/jobs/{job.Id}",
            traceId);
    }

    public async Task<JobRunDto?> GetAsync(Guid id, CancellationToken cancellationToken)
    {
        var q = db.JobRuns
            .AsNoTracking()
            .Include(x => x.Logs.OrderBy(l => l.CreatedAt))
            .Where(x => x.Id == id);

        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        var job = await q.FirstOrDefaultAsync(cancellationToken);
        return job is null ? null : Map(job);
    }

    public async Task<ApiPagedResponse<JobRunDto>> ListAsync(
        JobListQuery query,
        CancellationToken cancellationToken)
    {
        var paging = query.Normalize();
        var q = db.JobRuns.AsNoTracking();
        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        if (query.Status is { } status)
        {
            q = q.Where(x => x.Status == status);
        }

        if (!string.IsNullOrWhiteSpace(query.JobType))
        {
            var jobType = query.JobType.Trim();
            q = q.Where(x => x.JobType == jobType);
        }

        q = ApplySort(q, paging.Sort, paging.IsDescending());

        var page = await q.ToPagedResponseAsync(paging, cancellationToken);
        return ApiPagedResponse<JobRunDto>.Create(
            page.Items.Select(MapSummary).ToList(),
            page.Page,
            page.PageSize,
            page.TotalItems);
    }

    private static IQueryable<JobRun> ApplySort(IQueryable<JobRun> query, string? sort, bool descending) =>
        (sort?.Trim().ToLowerInvariant()) switch
        {
            "jobtype" => descending ? query.OrderByDescending(x => x.JobType) : query.OrderBy(x => x.JobType),
            "status" => descending ? query.OrderByDescending(x => x.Status) : query.OrderBy(x => x.Status),
            "startedat" => descending ? query.OrderByDescending(x => x.StartedAt) : query.OrderBy(x => x.StartedAt),
            "completedat" => descending ? query.OrderByDescending(x => x.CompletedAt) : query.OrderBy(x => x.CompletedAt),
            _ => descending ? query.OrderByDescending(x => x.QueuedAt) : query.OrderBy(x => x.QueuedAt)
        };

    private static JobRunDto Map(JobRun job) =>
        new(
            job.Id,
            job.OrganizationId,
            job.CreatedByUserId,
            job.JobType,
            job.Status,
            job.PayloadJson,
            job.ResultJson,
            job.ErrorMessage,
            job.TraceId,
            job.AttemptCount,
            job.MaxAttempts,
            job.QueuedAt,
            job.NextRunAt,
            job.StartedAt,
            job.CompletedAt,
            job.Logs.Select(l => new JobLogDto(l.Id, l.Level, l.Message, l.Detail, l.CreatedAt)).ToList());

    private static JobRunDto MapSummary(JobRun job) =>
        new(
            job.Id,
            job.OrganizationId,
            job.CreatedByUserId,
            job.JobType,
            job.Status,
            job.PayloadJson,
            job.ResultJson,
            job.ErrorMessage,
            job.TraceId,
            job.AttemptCount,
            job.MaxAttempts,
            job.QueuedAt,
            job.NextRunAt,
            job.StartedAt,
            job.CompletedAt,
            []);
}
