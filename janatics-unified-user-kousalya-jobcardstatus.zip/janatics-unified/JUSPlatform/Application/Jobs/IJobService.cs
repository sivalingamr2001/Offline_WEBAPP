using System.Text.Json;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Enums;

namespace JUSPlatform.Application.Jobs;

public interface IJobService
{
    Task<JobAcceptedResponse> EnqueueAsync(EnqueueJobRequest request, CancellationToken cancellationToken);
    Task<JobRunDto?> GetAsync(Guid id, CancellationToken cancellationToken);
    Task<ApiPagedResponse<JobRunDto>> ListAsync(JobListQuery query, CancellationToken cancellationToken);
}

public interface IJobHandler
{
    string JobType { get; }
    void ValidatePayload(JsonElement payload);
    Task<object?> ExecuteAsync(JsonElement payload, IJobExecutionLogger logger, CancellationToken cancellationToken);
}

public interface IJobExecutionLogger
{
    Task InfoAsync(string message, CancellationToken cancellationToken);
    Task WarningAsync(string message, CancellationToken cancellationToken);
    Task ErrorAsync(string message, Exception? exception, CancellationToken cancellationToken);
}
