namespace JUSPlatform.Application.Jobs;

using System.Text.Json.Serialization;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Enums;
using Microsoft.AspNetCore.Mvc;

public sealed record JobListQuery : PagedListQuery
{
    [FromQuery(Name = "status")]
    [JsonPropertyName("status")]
    public JobStatus? Status { get; init; }

    [FromQuery(Name = "jobType")]
    [JsonPropertyName("jobType")]
    public string? JobType { get; init; }
}
