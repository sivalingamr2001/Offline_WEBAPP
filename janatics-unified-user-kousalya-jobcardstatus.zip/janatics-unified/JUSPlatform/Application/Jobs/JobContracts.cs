using System.Text.Json;
using JUSPlatform.Domain.Enums;

namespace JUSPlatform.Application.Jobs;

public sealed record EnqueueJobRequest(string JobType, JsonElement Payload);

public sealed record JobLogDto(
    Guid Id,
    string Level,
    string Message,
    string? Detail,
    DateTimeOffset CreatedAt);

public sealed record JobRunDto(
    Guid Id,
    Guid OrganizationId,
    Guid CreatedByUserId,
    string JobType,
    JobStatus Status,
    string PayloadJson,
    string? ResultJson,
    string? ErrorMessage,
    string? TraceId,
    int AttemptCount,
    int MaxAttempts,
    DateTimeOffset QueuedAt,
    DateTimeOffset? NextRunAt,
    DateTimeOffset? StartedAt,
    DateTimeOffset? CompletedAt,
    IReadOnlyList<JobLogDto> Logs);

public sealed record JobAcceptedResponse(
    Guid Id,
    JobStatus Status,
    string PollUrl,
    string? TraceId);
