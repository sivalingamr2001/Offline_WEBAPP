using JUSPlatform.Application.Access;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Application.AppCatalog;

public sealed class AppCatalogService(AppDbContext db) : IAppCatalogService
{
    public async Task<ApiPagedResponse<AppModuleDto>> ListModulesAsync(
        PagedListQuery query,
        CancellationToken cancellationToken)
    {
        var paging = query.Normalize();
        var q = db.AppModules.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(paging.Search))
        {
            var term = paging.Search.Trim();
            q = q.Where(x => x.Code.Contains(term) || x.Name.Contains(term));
        }

        q = (paging.Sort?.Trim().ToLowerInvariant()) switch
        {
            "code" => paging.IsDescending() ? q.OrderByDescending(x => x.Code) : q.OrderBy(x => x.Code),
            "name" => paging.IsDescending() ? q.OrderByDescending(x => x.Name) : q.OrderBy(x => x.Name),
            _ => paging.IsDescending()
                ? q.OrderByDescending(x => x.SortOrder).ThenByDescending(x => x.Name)
                : q.OrderBy(x => x.SortOrder).ThenBy(x => x.Name)
        };

        return await q
            .Select(x => new AppModuleDto(x.Id, x.Code, x.Name, x.Description, x.Icon, x.SortOrder, x.IsActive))
            .ToPagedResponseAsync(paging, cancellationToken);
    }

    public async Task<AppModuleDto> CreateModuleAsync(
        CreateAppModuleRequest request,
        CancellationToken cancellationToken)
    {
        var code = request.Code.Trim().ToUpperInvariant();
        var exists = await db.AppModules.AnyAsync(x => x.Code == code, cancellationToken);
        if (exists)
        {
            throw new ConflictException($"Module code '{code}' already exists.");
        }

        var entity = new AppModule
        {
            Code = code,
            Name = request.Name.Trim(),
            Description = string.IsNullOrWhiteSpace(request.Description) ? null : request.Description.Trim(),
            Icon = string.IsNullOrWhiteSpace(request.Icon) ? null : request.Icon.Trim(),
            SortOrder = request.SortOrder,
            IsActive = true
        };
        db.AppModules.Add(entity);
        await db.SaveChangesAsync(cancellationToken);
        return new AppModuleDto(
            entity.Id, entity.Code, entity.Name, entity.Description, entity.Icon, entity.SortOrder, entity.IsActive);
    }

    public async Task<ApiPagedResponse<AppMenuDto>> ListMenusAsync(
        AppMenuListQuery query,
        CancellationToken cancellationToken)
    {
        var page = Math.Max(1, query.Page);
        var pageSize = query.PageSize <= 0
            ? PagedListQuery.DefaultPageSize
            : Math.Min(query.PageSize, AppMenuListQuery.MenuMaxPageSize);
        var q = db.AppMenus.AsNoTracking().Include(x => x.Module).AsQueryable();

        if (query.ModuleId is { } moduleId)
        {
            q = q.Where(x => x.ModuleId == moduleId);
        }

        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var term = query.Search.Trim();
            q = q.Where(x =>
                x.Code.Contains(term)
                || x.Name.Contains(term)
                || (x.DisplayName != null && x.DisplayName.Contains(term))
                || (x.Path != null && x.Path.Contains(term))
                || (x.MenuPath != null && x.MenuPath.Contains(term)));
        }

        var menus = await q.ToListAsync(cancellationToken);
        var sequenceById = menus
            .GroupBy(x => x.ModuleId)
            .SelectMany(group => group
                .OrderBy(x => x.Code, StringComparer.OrdinalIgnoreCase)
                .Select((menu, index) => (menu.Id, Sequence: index + 1)))
            .ToDictionary(x => x.Id, x => x.Sequence);

        var descending = query.IsDescending();
        IEnumerable<AppMenu> ordered = (query.Sort?.Trim().ToLowerInvariant()) switch
        {
            "name" => descending
                ? menus.OrderByDescending(x => x.Name).ThenByDescending(x => x.Code)
                : menus.OrderBy(x => x.Name).ThenBy(x => x.Code),
            "path" => descending
                ? menus.OrderByDescending(x => AppMenuCatalog.ResolvePath(x)).ThenByDescending(x => x.Code)
                : menus.OrderBy(x => AppMenuCatalog.ResolvePath(x)).ThenBy(x => x.Code),
            "sortorder" or "order" or "sequence" => descending
                ? menus.OrderByDescending(x => sequenceById[x.Id]).ThenByDescending(x => x.Code)
                : menus.OrderBy(x => x.Module?.Name).ThenBy(x => sequenceById[x.Id]).ThenBy(x => x.Code),
            _ => descending
                ? menus.OrderByDescending(x => x.Code, StringComparer.OrdinalIgnoreCase)
                : menus.OrderBy(x => x.Code, StringComparer.OrdinalIgnoreCase)
        };

        var items = ordered
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(menu => MapMenu(menu, sequenceById[menu.Id]))
            .ToList();

        return ApiPagedResponse<AppMenuDto>.Create(items, page, pageSize, menus.Count);
    }

    public async Task<AppMenuDto> CreateMenuAsync(
        CreateAppMenuRequest request,
        CancellationToken cancellationToken)
    {
        var module = await db.AppModules.FirstOrDefaultAsync(x => x.Id == request.ModuleId, cancellationToken)
            ?? throw new NotFoundException("AppModule", request.ModuleId);

        if (request.ParentId is { } parentId)
        {
            var parent = await db.AppMenus.FirstOrDefaultAsync(x => x.Id == parentId, cancellationToken)
                ?? throw new NotFoundException("AppMenu", parentId);
            if (parent.ModuleId != module.Id)
            {
                throw new BusinessRuleException("Parent menu must belong to the same module.");
            }
        }

        var existingCodes = await db.AppMenus.Select(x => x.Code).ToListAsync(cancellationToken);
        var code = string.IsNullOrWhiteSpace(request.Code)
            ? NextMenuCode(existingCodes)
            : request.Code.Trim().ToUpperInvariant();
        if (existingCodes.Any(x => string.Equals(x, code, StringComparison.OrdinalIgnoreCase)))
        {
            throw new ConflictException($"Menu code '{code}' already exists.");
        }

        var nextSequence = await db.AppMenus.CountAsync(x => x.ModuleId == module.Id, cancellationToken) + 1;
        var sortOrder = request.SortOrder > 0 ? request.SortOrder : nextSequence;

        var entity = new AppMenu
        {
            ModuleId = module.Id,
            ParentId = request.ParentId,
            Code = code,
            Name = request.Name.Trim(),
            DisplayName = request.Name.Trim(),
            Path = string.IsNullOrWhiteSpace(request.Path) ? null : request.Path.Trim(),
            MenuPath = string.IsNullOrWhiteSpace(request.Path) ? null : request.Path.Trim(),
            Icon = string.IsNullOrWhiteSpace(request.Icon) ? null : request.Icon.Trim(),
            MenuIcon = string.IsNullOrWhiteSpace(request.Icon) ? null : request.Icon.Trim(),
            MenuType = AppMenuCatalog.MenuTypeScreen,
            Nature = AppMenuCatalog.NatureTenant,
            SortOrder = sortOrder,
            PermissionCode = string.IsNullOrWhiteSpace(request.PermissionCode) ? null : request.PermissionCode.Trim(),
            IsActive = true
        };
        db.AppMenus.Add(entity);
        await db.SaveChangesAsync(cancellationToken);
        await SystemRoleSeeder.GrantMenuToPlatformSuperAdminAsync(db, entity.Id, cancellationToken);
        return new AppMenuDto(
            entity.Id,
            entity.ModuleId,
            module.Name,
            AppMenuCatalog.ResolveParentId(entity),
            entity.Code,
            AppMenuCatalog.ResolveName(entity),
            AppMenuCatalog.ResolvePath(entity),
            AppMenuCatalog.ResolveIcon(entity),
            entity.SortOrder,
            AppMenuCatalog.ResolvePermissionCode(entity),
            entity.IsActive);
    }

    public async Task<AppMenuDto> UpdateMenuAsync(
        Guid id,
        UpdateAppMenuRequest request,
        CancellationToken cancellationToken)
    {
        var entity = await db.AppMenus
            .Include(x => x.Module)
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken)
            ?? throw new NotFoundException("AppMenu", id);

        var module = await db.AppModules.FirstOrDefaultAsync(x => x.Id == request.ModuleId, cancellationToken)
            ?? throw new NotFoundException("AppModule", request.ModuleId);

        var parentId = AppMenuCatalog.ResolveParentId(entity);
        if (parentId is { } existingParentId)
        {
            var parent = await db.AppMenus.FirstOrDefaultAsync(x => x.Id == existingParentId, cancellationToken)
                ?? throw new NotFoundException("AppMenu", existingParentId);
            if (parent.ModuleId != module.Id)
            {
                throw new BusinessRuleException("Parent menu must belong to the same module.");
            }
        }

        var path = string.IsNullOrWhiteSpace(request.Path) ? null : request.Path.Trim();
        var icon = string.IsNullOrWhiteSpace(request.Icon) ? null : request.Icon.Trim();
        var permission = string.IsNullOrWhiteSpace(request.PermissionCode)
            ? null
            : request.PermissionCode.Trim();
        var name = request.Name.Trim();

        entity.ModuleId = module.Id;
        entity.Name = name;
        entity.DisplayName = name;
        entity.Path = path;
        entity.MenuPath = path;
        entity.Icon = icon ?? entity.Icon;
        entity.MenuIcon = icon ?? entity.MenuIcon;
        entity.PermissionCode = permission;
        entity.IsActive = request.IsActive;

        await db.SaveChangesAsync(cancellationToken);
        entity.Module = module;
        return MapMenu(entity, entity.SortOrder);
    }

    internal static string NextMenuCode(IEnumerable<string> existingCodes)
    {
        var max = 0;
        foreach (var existing in existingCodes)
        {
            if (existing.StartsWith("MNU", StringComparison.OrdinalIgnoreCase)
                && existing.Length > 3
                && int.TryParse(existing.AsSpan(3), out var number))
            {
                max = Math.Max(max, number);
            }
        }

        return $"MNU{max + 1:000}";
    }

    private static AppMenuDto MapMenu(AppMenu menu, int sequence) =>
        new(
            menu.Id,
            menu.ModuleId,
            menu.Module?.Name ?? string.Empty,
            AppMenuCatalog.ResolveParentId(menu),
            menu.Code,
            AppMenuCatalog.ResolveName(menu),
            AppMenuCatalog.ResolvePath(menu),
            AppMenuCatalog.ResolveIcon(menu),
            sequence,
            AppMenuCatalog.ResolvePermissionCode(menu),
            menu.IsActive);
}
