using FluentValidation;
using JUSPlatform.Application.Common;

namespace JUSPlatform.Application.AppCatalog;

public sealed class CreateAppModuleRequestValidator : AbstractValidator<CreateAppModuleRequest>
{
    public CreateAppModuleRequestValidator()
    {
        RuleFor(x => x.Code).NotEmpty().MaximumLength(50);
        RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Description).MaximumLength(1000);
        RuleFor(x => x.Icon).MaximumLength(100);
    }
}

public sealed class CreateAppMenuRequestValidator : AbstractValidator<CreateAppMenuRequest>
{
    public CreateAppMenuRequestValidator()
    {
        RuleFor(x => x.ModuleId).NotEmpty();
        RuleFor(x => x.Code).MaximumLength(50);
        RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Path).MaximumLength(200);
        RuleFor(x => x.Icon).MaximumLength(100);
        RuleFor(x => x.PermissionCode).MaximumLength(100);
    }
}

public sealed class UpdateAppMenuRequestValidator : AbstractValidator<UpdateAppMenuRequest>
{
    public UpdateAppMenuRequestValidator()
    {
        RuleFor(x => x.ModuleId).NotEmpty();
        RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Path).MaximumLength(200);
        RuleFor(x => x.Icon).MaximumLength(100);
        RuleFor(x => x.PermissionCode).MaximumLength(100);
    }
}

public sealed class AppMenuListQueryValidator : AbstractValidator<AppMenuListQuery>
{
    public AppMenuListQueryValidator()
    {
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, AppMenuListQuery.MenuMaxPageSize);
    }
}
