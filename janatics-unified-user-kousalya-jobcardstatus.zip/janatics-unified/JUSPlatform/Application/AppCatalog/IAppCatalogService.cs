using JUSPlatform.Application.Common;

namespace JUSPlatform.Application.AppCatalog;

public sealed record AppModuleDto(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    string? Icon,
    int SortOrder,
    bool IsActive);

public sealed record AppMenuDto(
    Guid Id,
    Guid ModuleId,
    string ModuleName,
    Guid? ParentId,
    string Code,
    string Name,
    string? Path,
    string? Icon,
    int SortOrder,
    string? PermissionCode,
    bool IsActive);

public sealed record CreateAppModuleRequest(
    string Code,
    string Name,
    string? Description,
    string? Icon,
    int SortOrder);

public sealed record CreateAppMenuRequest(
    Guid ModuleId,
    Guid? ParentId,
    string? Code,
    string Name,
    string? Path,
    string? Icon,
    int SortOrder,
    string? PermissionCode);

public sealed record UpdateAppMenuRequest(
    Guid ModuleId,
    string Name,
    string? Path,
    string? Icon,
    string? PermissionCode,
    bool IsActive);

public sealed record AppMenuListQuery : PagedListQuery
{
    public const int MenuMaxPageSize = 250;

    public Guid? ModuleId { get; init; }
}

public interface IAppCatalogService
{
    Task<ApiPagedResponse<AppModuleDto>> ListModulesAsync(PagedListQuery query, CancellationToken cancellationToken);
    Task<AppModuleDto> CreateModuleAsync(CreateAppModuleRequest request, CancellationToken cancellationToken);
    Task<ApiPagedResponse<AppMenuDto>> ListMenusAsync(AppMenuListQuery query, CancellationToken cancellationToken);
    Task<AppMenuDto> CreateMenuAsync(CreateAppMenuRequest request, CancellationToken cancellationToken);
    Task<AppMenuDto> UpdateMenuAsync(Guid id, UpdateAppMenuRequest request, CancellationToken cancellationToken);
}
