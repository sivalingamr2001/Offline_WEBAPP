namespace JUSPlatform.Application.Oracle;

public interface IOracleConnectionService
{
    Task<OracleConnectionResponse> TestAsync(CancellationToken cancellationToken = default);
}
