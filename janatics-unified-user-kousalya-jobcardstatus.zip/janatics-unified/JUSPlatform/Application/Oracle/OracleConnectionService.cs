using JUSPlatform.Infrastructure.Persistence;
using Microsoft.Extensions.Options;

namespace JUSPlatform.Application.Oracle;

public sealed class OracleConnectionService(
    OracleDbContext db,
    IOptions<OracleOptions> options) : IOracleConnectionService
{
    public async Task<OracleConnectionResponse> TestAsync(CancellationToken cancellationToken = default)
    {
        var utc = DateTimeOffset.UtcNow;
        if (!options.Value.Enabled)
        {
            return new OracleConnectionResponse("disabled", false, utc);
        }

        var connected = await TryConnectAsync(cancellationToken);
        return new OracleConnectionResponse(
            connected ? "connected" : "disconnected",
            true,
            utc);
    }

    private async Task<bool> TryConnectAsync(CancellationToken cancellationToken)
    {
        try
        {
            return await db.Database.CanConnectAsync(cancellationToken);
        }
        catch (Exception)
        {
            return false;
        }
    }
}
