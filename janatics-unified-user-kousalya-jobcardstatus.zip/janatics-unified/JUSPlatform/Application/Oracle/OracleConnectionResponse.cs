using System.ComponentModel;

namespace JUSPlatform.Application.Oracle;

public sealed record OracleConnectionResponse(
    [property: Description("connected, disconnected, or disabled.")] string Status,
    [property: Description("Whether Oracle:Enabled is true.")] bool Enabled,
    [property: Description("Server UTC timestamp.")] DateTimeOffset Utc);
