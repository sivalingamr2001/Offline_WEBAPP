using JUSPlatform.Infrastructure.Persistence.Oracle;

namespace JUSPlatform.Application.JobCard;

internal static class JobCardJourneyMapper
{
    public const decimal PrePlanDays = 2;
    public const decimal PostPlanDays = 1;

    public static JobCardRowDto Map(
        JanWipTest row,
        string plant,
        DateTimeOffset asOf)
    {
        var operations = ExtractOperations(row, asOf);
        var plan = operations.Sum(x => x.Phases.Sum(p => p.PlanDays));
        var actual = operations.Sum(x => x.Phases.Sum(p => p.ActualDays));
        var variance = actual - plan;
        var allComplete = operations.Count > 0 && operations.All(x => x.Status == JobCardStatusCodes.Completed);
        var overall = Rollup(operations, allComplete);

        var description = string.IsNullOrWhiteSpace(row.ItemNo) ? row.JobNo : $"Item {row.ItemNo.Trim()}";
        var jobType = string.IsNullOrWhiteSpace(row.AlternateRoutingDesignator)
            ? ""
            : row.AlternateRoutingDesignator.Trim();
        return new JobCardRowDto(
            row.WipEntityId.ToString("0"),
            row.JobNo,
            description,
            jobType,
            plant,
            operations.Count,
            plan,
            actual,
            variance,
            overall,
            operations);
    }

    public static IReadOnlyList<JobCardOperationDto> ExtractOperations(JanWipTest row, DateTimeOffset asOf)
    {
        var ops = new List<JobCardOperationDto>(6);
        var preFrom = row.JobDt;
        foreach (var slot in OperationSlots(row))
        {
            if (!TryAdd(
                    ops,
                    slot.Index,
                    slot.Seq,
                    slot.Desc,
                    slot.Queue,
                    slot.Move,
                    slot.Scrap,
                    slot.Comp,
                    slot.Vendor,
                    slot.Lead,
                    slot.ProcessStart,
                    preFrom,
                    asOf))
            {
                continue;
            }

            if (slot.ProcessStart is { } started)
            {
                preFrom = started;
            }
        }

        return ops;
    }

    private static (int Index, decimal? Seq, string? Desc, decimal? Queue, decimal? Move, decimal? Scrap, decimal? Comp, string? Vendor, decimal? Lead, DateTime? ProcessStart)[] OperationSlots(
        JanWipTest row) =>
    [
        (1, row.Opn1OperationSeq, row.Opn1OperationDesc, row.Opn1QtyQueue, row.Opn1QtyMove, row.Opn1QtyScrap, row.Opn1QtyComp, row.Opn1VendorName, row.Opn1LeadTime, row.Opn1ProcessStartDate),
        (2, row.Opn2OperationSeq, row.Opn2OperationDesc, row.Opn2QtyQueue, row.Opn2QtyMove, row.Opn2QtyScrap, row.Opn2QtyComp, row.Opn2VendorName, row.Opn2LeadTime, row.Opn2ProcessStartDate),
        (3, row.Opn3OperationSeq, row.Opn3OperationDesc, row.Opn3QtyQueue, row.Opn3QtyMove, row.Opn3QtyScrap, row.Opn3QtyComp, row.Opn3VendorName, row.Opn3LeadTime, row.Opn3ProcessStartDate),
        (4, row.Opn4OperationSeq, row.Opn4OperationDesc, row.Opn4QtyQueue, row.Opn4QtyMove, row.Opn4QtyScrap, row.Opn4QtyComp, row.Opn4VendorName, row.Opn4LeadTime, row.Opn4ProcessStartDate),
        (5, row.Opn5OperationSeq, row.Opn5OperationDesc, row.Opn5QtyQueue, row.Opn5QtyMove, row.Opn5QtyScrap, row.Opn5QtyComp, row.Opn5VendorName, row.Opn5LeadTime, row.Opn5ProcessStartDate),
        (6, row.Opn6OperationSeq, row.Opn6OperationDesc, row.Opn6QtyQueue, row.Opn6QtyMove, row.Opn6QtyScrap, row.Opn6QtyComp, row.Opn6VendorName, row.Opn6LeadTime, row.Opn6ProcessStartDate)
    ];

    public static string StatusFromVariance(decimal varianceDays, bool completed)
    {
        if (varianceDays <= 0)
        {
            return completed ? JobCardStatusCodes.Completed : JobCardStatusCodes.OnTrack;
        }

        if (varianceDays <= 1)
        {
            return JobCardStatusCodes.AtRisk;
        }

        return JobCardStatusCodes.Delayed;
    }

    public static JobCardKpisDto BuildKpis(
        IReadOnlyList<JobCardRowDto> current,
        IReadOnlyList<JobCardRowDto> prior)
    {
        var total = current.Count;
        var onTrack = current.Count(x => x.OverallStatus is JobCardStatusCodes.OnTrack or JobCardStatusCodes.Completed);
        var atRisk = current.Count(x => x.OverallStatus == JobCardStatusCodes.AtRisk);
        var delayed = current.Count(x => x.OverallStatus == JobCardStatusCodes.Delayed);
        decimal Pct(int n) => total == 0 ? 0 : Math.Round(100m * n / total, 1);

        var avgPlan = total == 0 ? 0 : Math.Round(current.Average(x => x.PlanTatDays), 1);
        var avgActual = total == 0 ? 0 : Math.Round(current.Average(x => x.ActualTatDays), 1);
        var avgVar = total == 0 ? 0 : Math.Round(current.Average(x => x.VarianceDays), 1);

        var onTime = OnTimePct(current);
        var priorOnTime = OnTimePct(prior);
        return new JobCardKpisDto(
            total,
            onTrack,
            Pct(onTrack),
            atRisk,
            Pct(atRisk),
            delayed,
            Pct(delayed),
            avgPlan,
            avgActual,
            avgVar,
            onTime,
            Math.Round(onTime - priorOnTime, 1));
    }

    private static decimal OnTimePct(IReadOnlyList<JobCardRowDto> jobs)
    {
        var completed = jobs.Where(x => x.OverallStatus == JobCardStatusCodes.Completed).ToList();
        if (completed.Count == 0)
        {
            return 0;
        }

        var onTime = completed.Count(x => x.VarianceDays <= 0);
        return Math.Round(100m * onTime / completed.Count, 1);
    }

    private static bool TryAdd(
        List<JobCardOperationDto> ops,
        int index,
        decimal? seq,
        string? desc,
        decimal? queue,
        decimal? move,
        decimal? scrap,
        decimal? comp,
        string? vendor,
        decimal? lead,
        DateTime? processStart,
        DateTime preFrom,
        DateTimeOffset asOf)
    {
        var name = string.IsNullOrWhiteSpace(desc) ? null : desc.Trim();
        var present = seq is > 0 || name is not null
            || (queue ?? 0) + (move ?? 0) + (scrap ?? 0) + (comp ?? 0) > 0
            || processStart is not null;
        if (!present)
        {
            return false;
        }

        var leadDays = lead ?? 0;
        var phases = MapPhases(queue ?? 0, comp ?? 0, leadDays, processStart, preFrom, asOf);
        var status = RollupPhases(phases);
        ops.Add(new JobCardOperationDto(
            index,
            name ?? $"OSP {index}",
            string.IsNullOrWhiteSpace(vendor) ? null : vendor.Trim(),
            queue ?? 0,
            move ?? 0,
            scrap ?? 0,
            comp ?? 0,
            leadDays,
            status,
            processStart,
            phases));
        return true;
    }

    private static IReadOnlyList<JobCardPhaseDto> MapPhases(
        decimal queue,
        decimal comp,
        decimal leadDays,
        DateTime? processStart,
        DateTime preFrom,
        DateTimeOffset asOf)
    {
        var asOfDate = asOf.UtcDateTime.Date;
        var origin = preFrom.Date;
        var completed = comp > 0;

        if (processStart is null && !completed && queue <= 0)
        {
            return
            [
                new JobCardPhaseDto("pre", PrePlanDays, 0, JobCardStatusCodes.NotStarted),
                new JobCardPhaseDto("proc", leadDays, 0, JobCardStatusCodes.NotStarted),
                new JobCardPhaseDto("post", PostPlanDays, 0, JobCardStatusCodes.NotStarted)
            ];
        }

        var start = (processStart ?? preFrom).Date;
        var preActual = Days(origin, start);
        var preStatus = StatusFromVariance(preActual - PrePlanDays, processStart is not null || completed);

        decimal procActual;
        string procStatus;
        decimal postActual;
        string postStatus;
        if (completed)
        {
            procActual = leadDays;
            procStatus = JobCardStatusCodes.Completed;
            postActual = PostPlanDays;
            postStatus = JobCardStatusCodes.Completed;
        }
        else if (processStart is not null)
        {
            procActual = Days(start, asOfDate);
            procStatus = StatusFromVariance(procActual - leadDays, false);
            postActual = 0;
            postStatus = JobCardStatusCodes.NotStarted;
        }
        else
        {
            procActual = 0;
            procStatus = JobCardStatusCodes.NotStarted;
            postActual = 0;
            postStatus = JobCardStatusCodes.NotStarted;
            preStatus = StatusFromVariance(Days(origin, asOfDate) - PrePlanDays, false);
        }

        return
        [
            new JobCardPhaseDto("pre", PrePlanDays, preActual, preStatus),
            new JobCardPhaseDto("proc", leadDays, procActual, procStatus),
            new JobCardPhaseDto("post", PostPlanDays, postActual, postStatus)
        ];
    }

    private static decimal Days(DateTime from, DateTime to)
        => Math.Max(0, (decimal)(to.Date - from.Date).TotalDays);

    private static string RollupPhases(IReadOnlyList<JobCardPhaseDto> phases)
    {
        if (phases.All(x => x.Status == JobCardStatusCodes.NotStarted))
        {
            return JobCardStatusCodes.NotStarted;
        }

        if (phases.Any(x => x.Status == JobCardStatusCodes.Delayed))
        {
            return JobCardStatusCodes.Delayed;
        }

        if (phases.Any(x => x.Status == JobCardStatusCodes.AtRisk))
        {
            return JobCardStatusCodes.AtRisk;
        }

        if (phases.All(x => x.Status is JobCardStatusCodes.Completed or JobCardStatusCodes.OnTrack))
        {
            return phases.All(x => x.Status == JobCardStatusCodes.Completed)
                ? JobCardStatusCodes.Completed
                : JobCardStatusCodes.OnTrack;
        }

        return JobCardStatusCodes.OnTrack;
    }

    private static string Rollup(IReadOnlyList<JobCardOperationDto> operations, bool allComplete)
    {
        if (operations.Count == 0)
        {
            return JobCardStatusCodes.NotStarted;
        }

        if (operations.Any(x => x.Status == JobCardStatusCodes.Delayed))
        {
            return JobCardStatusCodes.Delayed;
        }

        if (operations.Any(x => x.Status == JobCardStatusCodes.AtRisk))
        {
            return JobCardStatusCodes.AtRisk;
        }

        if (allComplete)
        {
            return JobCardStatusCodes.Completed;
        }

        if (operations.All(x => x.Status == JobCardStatusCodes.NotStarted))
        {
            return JobCardStatusCodes.NotStarted;
        }

        return JobCardStatusCodes.OnTrack;
    }
}
