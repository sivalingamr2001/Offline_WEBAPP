using JUSPlatform.Application.Access;
using JUSPlatform.Application.Common;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Oracle;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Npgsql;

namespace JUSPlatform.Application.JobCard;

public sealed class JobCardStatusService(
    AppDbContext db,
    OracleDbContext oracle,
    ICurrentUser currentUser,
    IOptions<OracleOptions> oracleOptions) : IJobCardStatusService
{
    public async Task<JobCardScreenDto> GetScreenAsync(JobCardQuery query, CancellationToken cancellationToken = default)
    {
        var asOf = DateTimeOffset.UtcNow;
        if (!CanQueryOracle())
        {
            return Empty(asOf);
        }

        var (orgIds, codes) = await ResolveScopeAsync(query.OrganizationId, cancellationToken);
        var filterByOrganization = currentUser.IsSuperAdmin();
        if ((!filterByOrganization && codes.Count == 0) || (filterByOrganization && orgIds.Count == 0))
        {
            return Empty(asOf);
        }

        List<JanWipTest> rows;
        try
        {
            rows = await LoadRowsAsync(orgIds, codes, filterByOrganization, cancellationToken);
        }
        catch (Exception ex) when (IsOracleUnavailable(ex))
        {
            return Empty(asOf);
        }

        var plantOrgIds = rows.Select(x => x.OrganizationId).Concat(orgIds).Distinct().ToList();
        var plantsByOrg = await LoadPlantNamesAsync(plantOrgIds, cancellationToken);
        var mapped = rows
            .Select(row => JobCardJourneyMapper.Map(row, PlantName(plantsByOrg, row.OrganizationId), asOf))
            .ToList();

        var currentStart = RangeStart(query.DateRange, asOf.UtcDateTime.Date);
        var spanDays = currentStart is { } start
            ? (asOf.UtcDateTime.Date - start).TotalDays
            : 0;
        var current = mapped.Where(job => InRange(rows, job, currentStart, asOf.UtcDateTime.Date)).ToList();
        current = ApplyUiFilters(current, query);

        var prior = currentStart is { } cs
            ? mapped.Where(job =>
            {
                var dt = JobDate(rows, job);
                return dt >= cs.AddDays(-spanDays) && dt < cs;
            }).ToList()
            : [];

        var optionSource = mapped;
        var filteredForOptions = ApplyUiFilters(mapped, new JobCardQuery
        {
            DateRange = query.DateRange,
            OrganizationId = query.OrganizationId
        });

        var kpis = JobCardJourneyMapper.BuildKpis(current, prior);
        return new JobCardScreenDto(
            kpis,
            current.OrderByDescending(x => x.JobNo).ToList(),
            VarianceByStage(current),
            TopDelayed(current),
            StatusSlices(current),
            filteredForOptions.Select(x => x.Plant).Where(x => x.Length > 0).Distinct().OrderBy(x => x).ToList(),
            filteredForOptions.Select(x => x.JobType).Where(x => x.Length > 0).Distinct().OrderBy(x => x).ToList(),
            filteredForOptions.Select(x => x.Description).Distinct().OrderBy(x => x).ToList(),
            asOf);
    }

    public async Task<JobCardRowDto> GetJobAsync(decimal wipEntityId, CancellationToken cancellationToken = default)
    {
        if (!CanQueryOracle())
        {
            throw new NotFoundException("JobCard", wipEntityId);
        }

        var (orgIds, codes) = await ResolveScopeAsync(null, cancellationToken);
        var filterByOrganization = currentUser.IsSuperAdmin();
        if ((!filterByOrganization && codes.Count == 0) || (filterByOrganization && orgIds.Count == 0))
        {
            throw new NotFoundException("JobCard", wipEntityId);
        }

        JanWipTest? row;
        try
        {
            var matches = await JanWipTestOracleReader.LoadJobAsync(
                oracle,
                wipEntityId,
                codes,
                orgIds,
                filterByOrganization,
                cancellationToken);
            row = matches.FirstOrDefault();
        }
        catch (Exception ex) when (IsOracleUnavailable(ex))
        {
            throw new NotFoundException("JobCard", wipEntityId);
        }

        if (row is null)
        {
            throw new NotFoundException("JobCard", wipEntityId);
        }

        var plants = await LoadPlantNamesAsync([row.OrganizationId], cancellationToken);
        return JobCardJourneyMapper.Map(row, PlantName(plants, row.OrganizationId), DateTimeOffset.UtcNow);
    }

    private async Task<(List<decimal> OrgIds, List<string> Codes)> ResolveScopeAsync(
        Guid? requestedOrg,
        CancellationToken cancellationToken)
    {
        var orgIds = await ResolveOracleOrgIdsAsync(requestedOrg, cancellationToken);
        var codes = await ResolveCustodianCodesAsync(cancellationToken);
        return (orgIds, codes);
    }

    private async Task<List<decimal>> ResolveOracleOrgIdsAsync(Guid? requested, CancellationToken cancellationToken)
    {
        if (currentUser.IsSuperAdmin())
        {
            Guid organizationId;
            if (requested is { } requestedId && requestedId != Guid.Empty)
            {
                var exists = await db.Organizations.AsNoTracking()
                    .AnyAsync(x => x.Id == requestedId && x.IsActive, cancellationToken);
                if (!exists)
                {
                    throw new NotFoundException(nameof(Organization), requestedId);
                }

                organizationId = requestedId;
            }
            else
            {
                var fallbackId = await db.Organizations.AsNoTracking()
                    .Where(x => x.IsActive)
                    .OrderBy(x => x.Code)
                    .Select(x => (Guid?)x.Id)
                    .FirstOrDefaultAsync(cancellationToken);
                if (fallbackId is null)
                {
                    return [];
                }

                organizationId = fallbackId.Value;
            }

            return await LoadOracleOrgIdsAsync([organizationId], cancellationToken);
        }

        var userId = currentUser.UserId;
        if (userId is null)
        {
            return [];
        }

        var membership = await db.UserAccessRights.AsNoTracking()
            .Where(x => x.UserId == userId.Value && x.IsActive)
            .Select(x => x.OrganizationId)
            .Distinct()
            .ToListAsync(cancellationToken);

        if (membership.Count == 0)
        {
            var homeOrgId = await db.Users.AsNoTracking()
                .Where(x => x.Id == userId.Value)
                .Select(x => x.OrganizationId)
                .FirstOrDefaultAsync(cancellationToken);
            if (homeOrgId is { } home)
            {
                membership.Add(home);
            }
        }

        return await LoadOracleOrgIdsAsync(membership, cancellationToken);
    }

    private async Task<List<decimal>> LoadOracleOrgIdsAsync(
        IReadOnlyCollection<Guid> organizationIds,
        CancellationToken cancellationToken)
    {
        if (organizationIds.Count == 0)
        {
            return [];
        }

        return await db.Organizations.AsNoTracking()
            .Where(x => organizationIds.Contains(x.Id) && x.IsActive && x.OracleOrgId > 0)
            .Select(x => (decimal)x.OracleOrgId!.Value)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    private async Task<List<string>> ResolveCustodianCodesAsync(CancellationToken cancellationToken)
    {
        if (currentUser.IsSuperAdmin())
        {
            return [];
        }

        var userId = currentUser.UserId;
        if (userId is null)
        {
            return [];
        }

        var empId = await db.Users.AsNoTracking()
            .Where(x => x.Id == userId.Value)
            .Select(x => x.EmpId)
            .FirstOrDefaultAsync(cancellationToken);
        var trimmed = string.IsNullOrWhiteSpace(empId) ? "" : empId.Trim();

        try
        {
            var lines = await db.JanCustodianLines.AsNoTracking()
                .Where(x => x.ActiveFlag == 1 && x.CustodianCode != null && x.CustodianCode != "")
                .Select(x => new CustodianLineRef(x.UsersId, x.CardNo, x.CustodianCode))
                .ToListAsync(cancellationToken);

            return CustodianAccess.DistinctCodes(lines, userId.Value, trimmed);
        }
        catch (Exception ex) when (IsUndefinedRelation(ex))
        {
            return [];
        }
    }

    private async Task<List<JanWipTest>> LoadRowsAsync(
        List<decimal> orgIds,
        List<string> codes,
        bool filterByOrganization,
        CancellationToken cancellationToken)
        => await JanWipTestOracleReader.LoadScreenAsync(
            oracle,
            codes,
            orgIds,
            filterByOrganization,
            cancellationToken);

    private async Task<Dictionary<decimal, string>> LoadPlantNamesAsync(
        IReadOnlyCollection<decimal> orgIds,
        CancellationToken cancellationToken)
    {
        if (orgIds.Count == 0)
        {
            return [];
        }

        var orgs = await db.Organizations.AsNoTracking()
            .Where(x => x.OracleOrgId != null && orgIds.Contains((decimal)x.OracleOrgId.Value))
            .Select(x => new { x.OracleOrgId, x.UnitName, x.Name })
            .ToListAsync(cancellationToken);

        return orgs
            .GroupBy(x => (decimal)x.OracleOrgId!.Value)
            .ToDictionary(
                g => g.Key,
                g => g.Select(x => x.UnitName ?? x.Name).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "");
    }

    private static List<JobCardRowDto> ApplyUiFilters(List<JobCardRowDto> jobs, JobCardQuery query)
    {
        IEnumerable<JobCardRowDto> q = jobs;
        if (!string.IsNullOrWhiteSpace(query.Plant))
        {
            q = q.Where(x => x.Plant.Equals(query.Plant, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(query.Product))
        {
            q = q.Where(x => x.Description.Equals(query.Product, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(query.JobType))
        {
            q = q.Where(x => x.JobType.Equals(query.JobType, StringComparison.OrdinalIgnoreCase));
        }

        return q.ToList();
    }

    private static bool InRange(List<JanWipTest> rows, JobCardRowDto job, DateTime? start, DateTime end)
    {
        if (start is null)
        {
            return true;
        }

        var dt = JobDate(rows, job);
        return dt >= start && dt <= end;
    }

    private static DateTime JobDate(List<JanWipTest> rows, JobCardRowDto job)
    {
        if (!decimal.TryParse(job.Id, out var id))
        {
            return DateTime.MinValue;
        }

        return rows.FirstOrDefault(x => x.WipEntityId == id)?.JobDt.Date ?? DateTime.MinValue;
    }

    private static string PlantName(IReadOnlyDictionary<decimal, string> plants, decimal orgId)
        => plants.TryGetValue(orgId, out var name) && name.Length > 0 ? name : $"Org {orgId:0}";

    private static DateTime? RangeStart(string? dateRange, DateTime today) =>
        dateRange?.Trim().ToLowerInvariant() switch
        {
            "all" => null,
            "last90" => today.AddDays(-90),
            "ytd" => new DateTime(today.Year, 1, 1),
            _ => today.AddDays(-30)
        };

    private static IReadOnlyList<JobCardStageVarianceDto> VarianceByStage(IReadOnlyList<JobCardRowDto> jobs)
    {
        static decimal Avg(IEnumerable<JobCardPhaseDto> phases) =>
            phases.Any() ? Math.Round(phases.Average(p => p.ActualDays - p.PlanDays), 1) : 0;

        var phases = jobs.SelectMany(j => j.Operations.SelectMany(o => o.Phases)).ToList();
        return
        [
            new JobCardStageVarianceDto("Pre", Avg(phases.Where(p => p.Kind == "pre"))),
            new JobCardStageVarianceDto("Processing", Avg(phases.Where(p => p.Kind == "proc"))),
            new JobCardStageVarianceDto("Post", Avg(phases.Where(p => p.Kind == "post")))
        ];
    }

    private static IReadOnlyList<JobCardDelayedOspDto> TopDelayed(IReadOnlyList<JobCardRowDto> jobs)
        => jobs.SelectMany(j => j.Operations)
            .Select(op => new
            {
                op.Name,
                op.Vendor,
                Variance = op.Phases.Sum(p => p.ActualDays - p.PlanDays)
            })
            .Where(x => x.Variance > 0)
            .GroupBy(x => string.IsNullOrWhiteSpace(x.Vendor) ? x.Name : $"{x.Name} ({x.Vendor})")
            .Select(g => new JobCardDelayedOspDto(g.Key, Math.Round(g.Average(x => x.Variance), 1)))
            .OrderByDescending(x => x.AvgVarianceDays)
            .Take(8)
            .ToList();

    private static IReadOnlyList<JobCardStatusSliceDto> StatusSlices(IReadOnlyList<JobCardRowDto> jobs)
    {
        var total = jobs.Count;
        decimal Pct(int n) => total == 0 ? 0 : Math.Round(100m * n / total, 0);
        var groups = new[]
        {
            JobCardStatusCodes.OnTrack,
            JobCardStatusCodes.AtRisk,
            JobCardStatusCodes.Delayed,
            JobCardStatusCodes.Completed
        };
        return groups.Select(status =>
        {
            var count = jobs.Count(x => x.OverallStatus == status
                || (status == JobCardStatusCodes.OnTrack && x.OverallStatus == JobCardStatusCodes.NotStarted));
            if (status == JobCardStatusCodes.OnTrack)
            {
                count = jobs.Count(x => x.OverallStatus is JobCardStatusCodes.OnTrack or JobCardStatusCodes.NotStarted);
            }

            return new JobCardStatusSliceDto(status, count, Pct(count));
        }).ToList();
    }

    private bool CanQueryOracle() =>
        oracleOptions.Value.Enabled
        || oracle.Database.ProviderName?.Contains("InMemory", StringComparison.OrdinalIgnoreCase) == true;

    private static JobCardScreenDto Empty(DateTimeOffset asOf) =>
        new(
            new JobCardKpisDto(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            [],
            [
                new JobCardStageVarianceDto("Pre", 0),
                new JobCardStageVarianceDto("Processing", 0),
                new JobCardStageVarianceDto("Post", 0)
            ],
            [],
            [
                new JobCardStatusSliceDto(JobCardStatusCodes.OnTrack, 0, 0),
                new JobCardStatusSliceDto(JobCardStatusCodes.AtRisk, 0, 0),
                new JobCardStatusSliceDto(JobCardStatusCodes.Delayed, 0, 0),
                new JobCardStatusSliceDto(JobCardStatusCodes.Completed, 0, 0)
            ],
            [],
            [],
            [],
            asOf);

    private static bool IsUndefinedRelation(Exception ex)
    {
        for (var current = ex; current is not null; current = current.InnerException)
        {
            if (current is PostgresException pg &&
                (pg.SqlState == PostgresErrorCodes.UndefinedTable || pg.SqlState == PostgresErrorCodes.UndefinedColumn))
            {
                return true;
            }
        }

        return false;
    }

    private static bool IsOracleUnavailable(Exception ex)
    {
        for (var current = ex; current is not null; current = current.InnerException)
        {
            if (current.GetType().FullName?.Contains("Oracle", StringComparison.OrdinalIgnoreCase) == true)
            {
                return true;
            }
        }

        return false;
    }
}
