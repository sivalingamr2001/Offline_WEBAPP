using System.ComponentModel;

namespace JUSPlatform.Application.JobCard;

public sealed class JobCardQuery
{
    [Description("last30, last90, ytd, or all.")]
    public string? DateRange { get; set; }

    public string? JobType { get; set; }
    public string? Product { get; set; }
    public string? Plant { get; set; }
    public Guid? OrganizationId { get; set; }
}

public static class JobCardStatusCodes
{
    public const string OnTrack = "onTrack";
    public const string AtRisk = "atRisk";
    public const string Delayed = "delayed";
    public const string Completed = "completed";
    public const string NotStarted = "notStarted";
}

public sealed record JobCardPhaseDto(
    string Kind,
    decimal PlanDays,
    decimal ActualDays,
    string Status);

public sealed record JobCardOperationDto(
    int Index,
    string Name,
    string? Vendor,
    decimal QtyQueue,
    decimal QtyMove,
    decimal QtyScrap,
    decimal QtyComp,
    decimal LeadTimeDays,
    string Status,
    DateTime? ProcessStartDate,
    IReadOnlyList<JobCardPhaseDto> Phases);

public sealed record JobCardRowDto(
    string Id,
    string JobNo,
    string Description,
    string JobType,
    string Plant,
    int OspCount,
    decimal PlanTatDays,
    decimal ActualTatDays,
    decimal VarianceDays,
    string OverallStatus,
    IReadOnlyList<JobCardOperationDto> Operations);

public sealed record JobCardKpisDto(
    int TotalJobs,
    int OnTrack,
    decimal OnTrackPct,
    int AtRisk,
    decimal AtRiskPct,
    int Delayed,
    decimal DelayedPct,
    decimal AvgPlanTatDays,
    decimal AvgActualTatDays,
    decimal AvgVarianceDays,
    decimal OnTimeCompletionPct,
    decimal OnTimeCompletionDeltaPct);

public sealed record JobCardStageVarianceDto(string Stage, decimal AvgVarianceDays);

public sealed record JobCardDelayedOspDto(string Label, decimal AvgVarianceDays);

public sealed record JobCardStatusSliceDto(string Status, int Count, decimal Pct);

public sealed record JobCardScreenDto(
    JobCardKpisDto Kpis,
    IReadOnlyList<JobCardRowDto> Jobs,
    IReadOnlyList<JobCardStageVarianceDto> VarianceByStage,
    IReadOnlyList<JobCardDelayedOspDto> TopDelayedOsps,
    IReadOnlyList<JobCardStatusSliceDto> JobsByStatus,
    IReadOnlyList<string> Plants,
    IReadOnlyList<string> JobTypes,
    IReadOnlyList<string> Products,
    DateTimeOffset LastUpdated);
