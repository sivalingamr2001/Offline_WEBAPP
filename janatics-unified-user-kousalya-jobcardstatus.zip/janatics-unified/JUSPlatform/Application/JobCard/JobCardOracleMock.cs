using JUSPlatform.Infrastructure.Persistence.Oracle;

namespace JUSPlatform.Application.JobCard;

/// <summary>
/// Sample JAN_WIP_TEST rows for card_no 0486 → CG012, CG013, CG014, CG015.
/// Used when Oracle is the in-memory stand-in (Oracle:Enabled false or UseInMemoryDatabase).
/// </summary>
public static class JobCardOracleMock
{
    public static readonly string[] CustodianCodes = ["CG012", "CG013", "CG014", "CG015"];

    public static IReadOnlyList<JanWipTest> CreateRows(decimal organizationId, DateTime jobDate)
    {
        JanWipTest Row(int index, string code, string jobNo, string op, string vendor, decimal lead, decimal queue) =>
            new()
            {
                OrganizationId = organizationId,
                WipEntityId = 4800 + index,
                JobNo = jobNo,
                JobDt = jobDate,
                CustodianCode = code,
                ItemNo = $"{100 + index}",
                AlternateRoutingDesignator = "OSP",
                Opn1OperationSeq = 10,
                Opn1OperationDesc = op,
                Opn1VendorName = vendor,
                Opn1LeadTime = lead,
                Opn1QtyQueue = queue,
                Opn1ProcessStartDate = jobDate.AddDays(1),
                Opn2OperationSeq = 20,
                Opn2OperationDesc = "Secondary OSP",
                Opn2LeadTime = 2,
                Opn2ProcessStartDate = jobDate.AddDays(4),
                Opn3OperationSeq = 30,
                Opn3OperationDesc = "Finish OSP",
                Opn3LeadTime = 1,
                Opn3ProcessStartDate = jobDate.AddDays(7)
            };

        return
        [
            Row(1, "CG012", "JOB-0486-CG012", "Heat Treat", "Anandhi HT", 3, 12),
            Row(2, "CG013", "JOB-0486-CG013", "Plating", "Anandhi Plate", 2, 8),
            Row(3, "CG014", "JOB-0486-CG014", "Grinding", "Anandhi Grind", 4, 5),
            Row(4, "CG015", "JOB-0486-CG015", "Coating", "Anandhi Coat", 2, 3)
        ];
    }
}
