namespace JUSPlatform.Application.JobCard;

public interface IJobCardStatusService
{
    Task<JobCardScreenDto> GetScreenAsync(JobCardQuery query, CancellationToken cancellationToken = default);
    Task<JobCardRowDto> GetJobAsync(decimal wipEntityId, CancellationToken cancellationToken = default);
}
