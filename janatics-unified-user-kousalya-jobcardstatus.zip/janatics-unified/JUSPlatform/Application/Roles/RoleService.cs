using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Persistence;
using JUSPlatform.Infrastructure.Persistence.Seed;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Application.Roles;

public sealed class RoleService(AppDbContext db, ICurrentUser currentUser) : IRoleService
{
    public async Task<ApiPagedResponse<PermissionDto>> ListPermissionsAsync(
        PermissionListQuery query,
        CancellationToken cancellationToken)
    {
        var paging = query.Normalize();

        var q = db.Permissions.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(query.Module))
        {
            var module = query.Module.Trim();
            q = q.Where(x => x.Module == module);
        }

        if (!string.IsNullOrWhiteSpace(paging.Search))
        {
            var term = paging.Search.Trim();
            q = q.Where(x => x.Code.Contains(term) || x.Name.Contains(term) || x.Module.Contains(term));
        }

        q = ApplyPermissionSort(q, paging.Sort, paging.IsDescending());

        return await q
            .Select(x => new PermissionDto(x.Id, x.Code, x.Name, x.Module))
            .ToPagedResponseAsync(paging, cancellationToken);
    }

    public async Task<PermissionDto> CreatePermissionAsync(
        CreatePermissionRequest request,
        CancellationToken cancellationToken)
    {
        if (!currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Only the platform owner can create permission codes.");
        }

        var code = request.Code.Trim().ToLowerInvariant();
        if (await db.Permissions.AnyAsync(x => x.Code == code, cancellationToken))
        {
            throw new ConflictException($"Permission '{code}' already exists.");
        }

        var permission = new Permission
        {
            Code = code,
            Name = request.Name.Trim(),
            Module = request.Module.Trim()
        };
        db.Permissions.Add(permission);
        await db.SaveChangesAsync(cancellationToken);
        await SystemRoleSeeder.GrantPermissionToPlatformSuperAdminAsync(db, permission.Id, cancellationToken);

        return new PermissionDto(permission.Id, permission.Code, permission.Name, permission.Module);
    }

    public async Task<PermissionDto> UpdatePermissionAsync(
        Guid id,
        UpdatePermissionRequest request,
        CancellationToken cancellationToken)
    {
        if (!currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Only the platform owner can update permission codes.");
        }

        var permission = await db.Permissions.FirstOrDefaultAsync(x => x.Id == id, cancellationToken)
            ?? throw new NotFoundException(nameof(Permission), id);

        var code = request.Code.Trim().ToLowerInvariant();
        if (await db.Permissions.AnyAsync(x => x.Id != id && x.Code == code, cancellationToken))
        {
            throw new ConflictException($"Permission '{code}' already exists.");
        }

        permission.Code = code;
        permission.Name = request.Name.Trim();
        permission.Module = request.Module.Trim();
        await db.SaveChangesAsync(cancellationToken);

        return new PermissionDto(permission.Id, permission.Code, permission.Name, permission.Module);
    }

    public async Task<ApiPagedResponse<RoleDto>> ListAsync(
        RoleListQuery query,
        CancellationToken cancellationToken)
    {
        var paging = query.Normalize();

        var q = db.Roles
            .AsNoTracking()
            .Include(x => x.RolePermissions)
            .ThenInclude(x => x.Permission)
            .Include(x => x.RoleMenus)
            .ThenInclude(x => x.Menu)
            .AsQueryable();

        if (currentUser.IsSuperAdmin())
        {
            if (query.OrganizationId is { } organizationId)
            {
                q = q.Where(x => x.OrganizationId == organizationId);
            }
        }
        else
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == null || x.OrganizationId == organizationId);
        }

        if (query.IsSystem is { } isSystem)
        {
            q = q.Where(x => x.IsSystem == isSystem);
        }

        if (!string.IsNullOrWhiteSpace(paging.Search))
        {
            var term = paging.Search.Trim();
            q = q.Where(x => x.Name.Contains(term) || (x.Description != null && x.Description.Contains(term)));
        }

        q = ApplyRoleSort(q, paging.Sort, paging.IsDescending());

        var page = await q.ToPagedResponseAsync(paging, cancellationToken);
        return ApiPagedResponse<RoleDto>.Create(
            page.Items.Select(Map).ToList(),
            page.Page,
            page.PageSize,
            page.TotalItems);
    }

    public async Task<RoleDto?> GetAsync(Guid id, CancellationToken cancellationToken)
    {
        var q = db.Roles
            .AsNoTracking()
            .Include(x => x.RolePermissions)
            .ThenInclude(x => x.Permission)
            .Include(x => x.RoleMenus)
            .ThenInclude(x => x.Menu)
            .Where(x => x.Id == id);

        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == null || x.OrganizationId == organizationId);
        }

        var role = await q.FirstOrDefaultAsync(cancellationToken);
        return role is null ? null : Map(role);
    }

    public async Task<RoleDto> CreateAsync(CreateRoleRequest request, CancellationToken cancellationToken)
    {
        var organizationId = await ResolveOrganizationIdAsync(request.OrganizationId, cancellationToken);
        var name = request.Name.Trim();

        if (IsPrivilegedSystemRole(name))
        {
            throw new BusinessRuleException(
                "SuperAdmin and Admin are reserved system roles and cannot be created.");
        }

        if (SystemRoles.IsKnown(name))
        {
            throw new BusinessRuleException(
                $"System role '{name}' is provisioned automatically. Choose a different name for a custom role.");
        }

        if (await db.Roles.AnyAsync(x => x.OrganizationId == organizationId && x.Name == name, cancellationToken))
        {
            throw new ConflictException($"Role '{name}' already exists.");
        }

        var role = new Role
        {
            OrganizationId = organizationId,
            Name = name,
            Description = request.Description?.Trim(),
            IsSystem = false
        };

        await SetPermissionsAsync(role, request.PermissionCodes, cancellationToken);
        await SetMenusAsync(role, request.Menus, request.PermissionCodes, cancellationToken);
        db.Roles.Add(role);
        await db.SaveChangesAsync(cancellationToken);

        return (await GetAsync(role.Id, cancellationToken))!;
    }

    public async Task<RoleDto> UpdateAsync(Guid id, UpdateRoleRequest request, CancellationToken cancellationToken)
    {
        var role = await FindForWriteAsync(id, cancellationToken);

        if (IsPrivilegedSystemRole(role.Name))
        {
            throw new BusinessRuleException("SuperAdmin and Admin are reserved system roles and cannot be modified.");
        }

        var requestedName = request.Name.Trim();
        if (IsPrivilegedSystemRole(requestedName))
        {
            throw new BusinessRuleException("SuperAdmin and Admin are reserved system roles and cannot be assigned.");
        }

        if (!role.IsSystem)
        {
            if (SystemRoles.IsKnown(requestedName))
            {
                throw new BusinessRuleException(
                    $"System role name '{requestedName}' is reserved. Choose a different name.");
            }

            role.Name = requestedName;
        }

        role.Description = request.Description?.Trim();

        var existingPermissionLinks = await db.RolePermissions
            .Where(x => x.RoleId == role.Id)
            .ToListAsync(cancellationToken);
        db.RolePermissions.RemoveRange(existingPermissionLinks);

        var existingMenuLinks = await db.RoleMenus
            .Where(x => x.RoleId == role.Id)
            .ToListAsync(cancellationToken);
        db.RoleMenus.RemoveRange(existingMenuLinks);

        await SetPermissionsAsync(role, request.PermissionCodes, cancellationToken);
        await SetMenusAsync(role, request.Menus, request.PermissionCodes, cancellationToken);
        await db.SaveChangesAsync(cancellationToken);

        return (await GetAsync(role.Id, cancellationToken))!;
    }

    private async Task SetPermissionsAsync(Role role, IReadOnlyList<string>? codes, CancellationToken cancellationToken)
    {
        var normalized = (codes ?? [])
            .Select(c => c.Trim().ToLowerInvariant())
            .Where(c => c.Length > 0)
            .Distinct()
            .ToList();

        if (normalized.Count == 0)
        {
            return;
        }

        var permissions = await db.Permissions
            .Where(x => normalized.Contains(x.Code))
            .ToListAsync(cancellationToken);

        if (permissions.Count != normalized.Count)
        {
            var found = permissions.Select(p => p.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var missing = normalized.Where(c => !found.Contains(c)).ToList();
            throw new BusinessRuleException(
                $"Unknown permission code(s): {string.Join(", ", missing)}.");
        }

        foreach (var permission in permissions)
        {
            if (role.Id == Guid.Empty)
            {
                role.RolePermissions.Add(new RolePermission { PermissionId = permission.Id });
            }
            else
            {
                db.RolePermissions.Add(new RolePermission
                {
                    RoleId = role.Id,
                    PermissionId = permission.Id
                });
            }
        }
    }

    private async Task SetMenusAsync(
        Role role,
        IReadOnlyList<RoleMenuAccessDto>? menus,
        IReadOnlyList<string>? permissionCodes,
        CancellationToken cancellationToken)
    {
        IReadOnlyList<RoleMenuAccessDto> assigned;
        if (menus is not null)
        {
            assigned = DeduplicateMenus(menus);
        }
        else
        {
            assigned = await MenusMatchingPermissionsAsync(permissionCodes, cancellationToken);
        }

        if (assigned.Count == 0)
        {
            return;
        }

        var menuIds = assigned.Select(x => x.MenuId).ToList();
        var catalog = await db.AppMenus
            .Where(x => menuIds.Contains(x.Id))
            .Select(x => new { x.Id, x.ModuleId })
            .ToListAsync(cancellationToken);

        if (catalog.Count != menuIds.Count)
        {
            var missing = menuIds.Except(catalog.Select(x => x.Id)).ToList();
            throw new BusinessRuleException(
                $"Unknown menu id(s): {string.Join(", ", missing)}.");
        }

        var moduleByMenu = catalog.ToDictionary(x => x.Id, x => x.ModuleId);
        foreach (var menu in assigned)
        {
            var link = new RoleMenu
            {
                ModuleId = moduleByMenu[menu.MenuId],
                MenuId = menu.MenuId,
                CanCreate = menu.CanCreate,
                CanRead = menu.CanRead || menu.CanCreate || menu.CanUpdate || menu.CanDelete,
                CanUpdate = menu.CanUpdate,
                CanDelete = menu.CanDelete
            };

            if (role.Id == Guid.Empty)
            {
                role.RoleMenus.Add(link);
            }
            else
            {
                link.RoleId = role.Id;
                db.RoleMenus.Add(link);
            }
        }
    }

    private async Task<IReadOnlyList<RoleMenuAccessDto>> MenusMatchingPermissionsAsync(
        IReadOnlyList<string>? permissionCodes,
        CancellationToken cancellationToken)
    {
        var codes = (permissionCodes ?? [])
            .Select(c => c.Trim().ToLowerInvariant())
            .Where(c => c.Length > 0)
            .Distinct()
            .ToList();

        if (codes.Count == 0)
        {
            return [];
        }

        return await db.AppMenus
            .AsNoTracking()
            .Where(x => x.IsActive && x.PermissionCode != null && codes.Contains(x.PermissionCode))
            .Select(x => new RoleMenuAccessDto(x.Id, false, true, false, false))
            .ToListAsync(cancellationToken);
    }

    private static IReadOnlyList<RoleMenuAccessDto> DeduplicateMenus(IReadOnlyList<RoleMenuAccessDto> menus) =>
        menus
            .GroupBy(x => x.MenuId)
            .Select(g => g.Last())
            .ToList();

    private static IQueryable<Permission> ApplyPermissionSort(IQueryable<Permission> query, string? sort, bool descending) =>
        (sort?.Trim().ToLowerInvariant()) switch
        {
            "code" => descending ? query.OrderByDescending(x => x.Code) : query.OrderBy(x => x.Code),
            "name" => descending ? query.OrderByDescending(x => x.Name) : query.OrderBy(x => x.Name),
            _ => descending
                ? query.OrderByDescending(x => x.Module).ThenByDescending(x => x.Code)
                : query.OrderBy(x => x.Module).ThenBy(x => x.Code)
        };

    private static IQueryable<Role> ApplyRoleSort(IQueryable<Role> query, string? sort, bool descending) =>
        (sort?.Trim().ToLowerInvariant()) switch
        {
            "issystem" => descending ? query.OrderByDescending(x => x.IsSystem) : query.OrderBy(x => x.IsSystem),
            "description" => descending ? query.OrderByDescending(x => x.Description) : query.OrderBy(x => x.Description),
            _ => descending ? query.OrderByDescending(x => x.Name) : query.OrderBy(x => x.Name)
        };

    private static RoleDto Map(Role role) =>
        new(
            role.Id,
            role.OrganizationId,
            role.Name,
            role.Description,
            role.IsSystem,
            role.RolePermissions
                .Select(x => x.Permission?.Code ?? string.Empty)
                .Where(x => x.Length > 0)
                .OrderBy(x => x)
                .ToList(),
            role.RoleMenus
                .Select(x => new RoleMenuAccessDto(x.MenuId, x.CanCreate, x.CanRead, x.CanUpdate, x.CanDelete))
                .OrderBy(x => x.MenuId)
                .ToList());

    private static bool IsPrivilegedSystemRole(string name) =>
        string.Equals(name, SystemRoles.SuperAdmin, StringComparison.OrdinalIgnoreCase)
        || string.Equals(name, SystemRoles.Admin, StringComparison.OrdinalIgnoreCase);

    private async Task<Guid?> ResolveOrganizationIdAsync(Guid? requestedOrganizationId, CancellationToken cancellationToken)
    {
        if (!currentUser.IsSuperAdmin())
        {
            return currentUser.RequireOrganizationId();
        }

        if (requestedOrganizationId is not { } organizationId)
        {
            return null;
        }

        var exists = await db.Organizations.AnyAsync(x => x.Id == organizationId, cancellationToken);
        if (!exists)
        {
            throw new NotFoundException(nameof(Organization), organizationId);
        }

        return organizationId;
    }

    private async Task<Role> FindForWriteAsync(Guid id, CancellationToken cancellationToken)
    {
        var q = db.Roles.Where(x => x.Id == id);
        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        return await q.FirstOrDefaultAsync(cancellationToken)
            ?? throw new NotFoundException(nameof(Role), id);
    }
}
