namespace JUSPlatform.Application.Roles;

using FluentValidation;
using JUSPlatform.Application.Common;

public sealed class RoleListQueryValidator : AbstractValidator<RoleListQuery>
{
    public RoleListQueryValidator() => Include(new PagedListQueryValidator());
}

public sealed class PermissionListQueryValidator : AbstractValidator<PermissionListQuery>
{
    public PermissionListQueryValidator() => Include(new PagedListQueryValidator());
}
