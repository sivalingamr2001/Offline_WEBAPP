using JUSPlatform.Application.Common;

namespace JUSPlatform.Application.Roles;

public sealed record PermissionDto(Guid Id, string Code, string Name, string Module);

public sealed record CreatePermissionRequest(string Code, string Name, string Module);

public sealed record UpdatePermissionRequest(string Code, string Name, string Module);

public sealed record RoleMenuAccessDto(
    Guid MenuId,
    bool CanCreate,
    bool CanRead,
    bool CanUpdate,
    bool CanDelete);

public sealed record RoleDto(
    Guid Id,
    Guid? OrganizationId,
    string Name,
    string? Description,
    bool IsSystem,
    IReadOnlyList<string> Permissions,
    IReadOnlyList<RoleMenuAccessDto> Menus);

public sealed record CreateRoleRequest(
    string Name,
    string? Description,
    IReadOnlyList<string> PermissionCodes,
    IReadOnlyList<RoleMenuAccessDto>? Menus = null,
    Guid? OrganizationId = null);

public sealed record UpdateRoleRequest(
    string Name,
    string? Description,
    IReadOnlyList<string> PermissionCodes,
    IReadOnlyList<RoleMenuAccessDto>? Menus = null);

public interface IRoleService
{
    Task<ApiPagedResponse<PermissionDto>> ListPermissionsAsync(PermissionListQuery query, CancellationToken cancellationToken);
    Task<PermissionDto> CreatePermissionAsync(CreatePermissionRequest request, CancellationToken cancellationToken);
    Task<PermissionDto> UpdatePermissionAsync(Guid id, UpdatePermissionRequest request, CancellationToken cancellationToken);
    Task<ApiPagedResponse<RoleDto>> ListAsync(RoleListQuery query, CancellationToken cancellationToken);
    Task<RoleDto?> GetAsync(Guid id, CancellationToken cancellationToken);
    Task<RoleDto> CreateAsync(CreateRoleRequest request, CancellationToken cancellationToken);
    Task<RoleDto> UpdateAsync(Guid id, UpdateRoleRequest request, CancellationToken cancellationToken);
}
