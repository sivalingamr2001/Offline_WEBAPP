namespace JUSPlatform.Application.Roles;

using System.Text.Json.Serialization;
using JUSPlatform.Application.Common;
using Microsoft.AspNetCore.Mvc;

public sealed record RoleListQuery : PagedListQuery
{
    [FromQuery(Name = "isSystem")]
    [JsonPropertyName("isSystem")]
    public bool? IsSystem { get; init; }

    /// <summary>SuperAdmin only: list roles for an organization. Org users ignore this.</summary>
    [FromQuery(Name = "organizationId")]
    [JsonPropertyName("organizationId")]
    public Guid? OrganizationId { get; init; }
}

public sealed record PermissionListQuery : PagedListQuery
{
    [FromQuery(Name = "module")]
    [JsonPropertyName("module")]
    public string? Module { get; init; }
}
