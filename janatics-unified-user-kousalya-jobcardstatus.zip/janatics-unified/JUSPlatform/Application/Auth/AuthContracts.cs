namespace JUSPlatform.Application.Auth;

public sealed record RegisterRequest(
    string OrganizationName,
    string OrganizationCode,
    string Email,
    string DisplayName,
    string Password);

public sealed record ForgotPasswordRequest(string Email);

public sealed record ResetPasswordRequest(string Token, string Password);

public sealed record ChangePasswordRequest(string CurrentPassword, string NewPassword);

public sealed record MessageResponse(string Message);
