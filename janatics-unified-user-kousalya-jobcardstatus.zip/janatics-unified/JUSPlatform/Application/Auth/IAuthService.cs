using JUSPlatform.Application.Access;

namespace JUSPlatform.Application.Auth;

public sealed record LoginRequest(string Email, string Password);

/// <summary>
/// Org users carry tenant in the JWT (<c>org_id</c> claim). SuperAdmin has no org_id.
/// </summary>
public sealed record LoginResponse(
    string AccessToken,
    DateTimeOffset ExpiresAt,
    Guid UserId,
    string Email,
    string DisplayName,
    string? Designation,
    string? RoleName,
    IReadOnlyList<string> Permissions,
    IReadOnlyList<NavModuleDto> Modules);

public interface IAuthService
{
    Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken cancellationToken);
    Task<LoginResponse> RegisterAsync(RegisterRequest request, CancellationToken cancellationToken);
    Task<MessageResponse> ForgotPasswordAsync(ForgotPasswordRequest request, CancellationToken cancellationToken);
    Task<MessageResponse> ResetPasswordAsync(ResetPasswordRequest request, CancellationToken cancellationToken);
    Task<MessageResponse> ChangePasswordAsync(ChangePasswordRequest request, CancellationToken cancellationToken);
    Task LogoutAsync(string tokenJti, DateTimeOffset expiresAt, CancellationToken cancellationToken);
}
