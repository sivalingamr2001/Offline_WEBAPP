using JUSPlatform.Application.Access;
using JUSPlatform.Application.Common;
using JUSPlatform.Authorization;
using JUSPlatform.Domain.Entities;
using JUSPlatform.Domain.Exceptions;
using JUSPlatform.Infrastructure.Authentication;
using JUSPlatform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace JUSPlatform.Application.Users;

public sealed class UserService(
    AppDbContext db,
    PasswordHasher passwordHasher,
    ICurrentUser currentUser,
    IUserAvatarStorage avatarStorage) : IUserService
{
    public async Task<ApiPagedResponse<UserDto>> ListAsync(
        UserListQuery query,
        CancellationToken cancellationToken)
    {
        var paging = query.Normalize();
        var q = UsersWithRole();

        if (currentUser.IsSuperAdmin())
        {
            if (query.OrganizationId is { } organizationId)
            {
                q = q.Where(x => x.OrganizationId == organizationId);
            }
        }
        else
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        if (query.IsActive is { } isActive)
        {
            q = q.Where(x => x.IsActive == isActive);
        }

        if (query.RoleId is { } roleId)
        {
            q = q.Where(x => x.UserRoles.Any(ur => ur.RoleId == roleId));
        }

        if (!string.IsNullOrWhiteSpace(paging.Search))
        {
            var term = paging.Search.Trim();
            q = q.Where(x =>
                x.Email.Contains(term) ||
                x.DisplayName.Contains(term) ||
                (x.Designation != null && x.Designation.Contains(term)) ||
                (x.UserCode != null && x.UserCode.Contains(term)) ||
                (x.EmpId != null && x.EmpId.Contains(term)));
        }

        q = ApplySort(q, paging.Sort, paging.IsDescending());

        var page = await q.ToPagedResponseAsync(paging, cancellationToken);
        return ApiPagedResponse<UserDto>.Create(
            page.Items.Select(Map).ToList(),
            page.Page,
            page.PageSize,
            page.TotalItems);
    }

    public async Task<UserDto?> GetAsync(Guid id, CancellationToken cancellationToken)
    {
        var q = UsersWithRole().Where(x => x.Id == id);
        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        var user = await q.FirstOrDefaultAsync(cancellationToken);
        return user is null ? null : Map(user);
    }

    public async Task<UserDto> GetCurrentAsync(CancellationToken cancellationToken)
    {
        var userId = currentUser.UserId ?? throw new UnauthorizedAccessException();
        var user = await UsersWithRole().FirstOrDefaultAsync(x => x.Id == userId, cancellationToken);
        return user is null ? throw new NotFoundException(nameof(User), userId) : Map(user);
    }

    public async Task<UserDto> CreateAsync(CreateUserRequest request, CancellationToken cancellationToken)
    {
        var organizationId = await ResolveTargetOrganizationIdAsync(request.OrganizationId, cancellationToken);
        var email = request.Email.Trim().ToLowerInvariant();

        if (await db.Users.AnyAsync(x => x.Email == email, cancellationToken))
        {
            throw new ConflictException($"User '{email}' already exists.");
        }

        var userCode = NormalizeOptional(request.UserCode);
        var empId = NormalizeOptional(request.EmpId);
        await EnsureCodesAvailableAsync(organizationId, userCode, empId, excludeUserId: null, cancellationToken);

        var user = new User
        {
            OrganizationId = organizationId,
            Email = email,
            DisplayName = request.DisplayName.Trim(),
            PasswordHash = passwordHasher.Hash(request.Password),
            UserCode = userCode,
            EmpId = empId
        };

        if (request.RoleId is { } roleId)
        {
            await AssignRoleAsync(user, organizationId, roleId, cancellationToken);
        }

        db.Users.Add(user);
        await db.SaveChangesAsync(cancellationToken);

        return (await GetAsync(user.Id, cancellationToken))!;
    }

    public async Task<UserDto> UpdateAsync(Guid id, UpdateUserRequest request, CancellationToken cancellationToken)
    {
        var user = await FindForWriteAsync(id, cancellationToken);
        var currentRoleName = user.UserRoles.Select(x => x.Role?.Name).FirstOrDefault(n => !string.IsNullOrWhiteSpace(n));

        if (SystemRoles.IsSuperAdmin(currentRoleName))
        {
            throw new BusinessRuleException("SuperAdmin cannot be edited.");
        }

        if (SystemRoles.IsAdmin(currentRoleName) && !currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Admin users cannot be edited.");
        }

        var organizationId = user.OrganizationId;

        if (request.RoleId is { } roleId)
        {
            await EnsureRoleIsAssignableAsync(organizationId, roleId, cancellationToken);
        }

        var userCode = NormalizeOptional(request.UserCode);
        var empId = NormalizeOptional(request.EmpId);
        await EnsureCodesAvailableAsync(organizationId, userCode, empId, user.Id, cancellationToken);

        user.DisplayName = request.DisplayName.Trim();
        user.IsActive = request.IsActive;
        user.UserCode = userCode;
        user.EmpId = empId;

        if (request.RoleId is not null)
        {
            user.UserRoles.Clear();
            await AssignRoleAsync(user, organizationId, request.RoleId.Value, cancellationToken);
        }

        await db.SaveChangesAsync(cancellationToken);
        return (await GetAsync(user.Id, cancellationToken))!;
    }

    public async Task<UserDto> UpdateCurrentAsync(UpdateCurrentUserRequest request, CancellationToken cancellationToken)
    {
        var userId = currentUser.UserId ?? throw new UnauthorizedAccessException();
        var user = await db.Users.FirstOrDefaultAsync(x => x.Id == userId, cancellationToken)
            ?? throw new NotFoundException(nameof(User), userId);

        user.Designation = NormalizeOptional(request.Designation);
        await db.SaveChangesAsync(cancellationToken);
        return await GetCurrentAsync(cancellationToken);
    }

    public async Task<UserDto> UploadAvatarAsync(Stream content, CancellationToken cancellationToken)
    {
        var userId = currentUser.UserId ?? throw new UnauthorizedAccessException();
        var user = await db.Users.FirstOrDefaultAsync(x => x.Id == userId, cancellationToken)
            ?? throw new NotFoundException(nameof(User), userId);

        try
        {
            await avatarStorage.DeleteIfExistsAsync(user.AvatarPath, cancellationToken);
            user.AvatarPath = await avatarStorage.SaveAsync(user.OrganizationId, userId, content, cancellationToken);
            await db.SaveChangesAsync(cancellationToken);
        }
        catch (InvalidOperationException ex)
        {
            throw new BusinessRuleException(ex.Message);
        }

        return await GetCurrentAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<MenuAccessDto>> ListAccessRightsAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        await EnsureUserVisibleAsync(userId, cancellationToken);
        return [];
    }

    public async Task<IReadOnlyList<MenuAccessDto>> ReplaceAccessRightsAsync(
        Guid userId,
        IReadOnlyList<MenuAccessDto> rights,
        CancellationToken cancellationToken)
    {
        var user = await FindForWriteAsync(userId, cancellationToken);
        var currentRoleName = user.UserRoles.Select(x => x.Role?.Name).FirstOrDefault(n => !string.IsNullOrWhiteSpace(n));
        if (SystemRoles.IsSuperAdmin(currentRoleName))
        {
            throw new BusinessRuleException("SuperAdmin access rights cannot be changed.");
        }

        _ = rights;
        return [];
    }

    public async Task<IReadOnlyList<UserOrganizationDto>> ListOrganizationsAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        EnsurePlatformOwner();
        await EnsureUserVisibleAsync(userId, cancellationToken);

        return await db.UserAccessRights
            .AsNoTracking()
            .Include(x => x.Organization)
            .Where(x => x.UserId == userId)
            .OrderBy(x => x.Organization!.Name)
            .Select(x => new UserOrganizationDto(
                x.OrganizationId,
                x.Organization!.Name,
                x.Organization.Code,
                x.OperatingUnit,
                x.IsActive))
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<UserOrganizationDto>> ReplaceOrganizationsAsync(
        Guid userId,
        IReadOnlyList<UserOrganizationAssignment> assignments,
        CancellationToken cancellationToken)
    {
        EnsurePlatformOwner();
        var user = await FindForWriteAsync(userId, cancellationToken);
        var currentRoleName = user.UserRoles.Select(x => x.Role?.Name).FirstOrDefault(n => !string.IsNullOrWhiteSpace(n));
        if (SystemRoles.IsSuperAdmin(currentRoleName))
        {
            throw new BusinessRuleException("SuperAdmin does not use organization membership.");
        }

        var requested = assignments
            .GroupBy(x => x.OrganizationId)
            .Select(g => g.Last())
            .ToList();
        var requestedIds = requested.Select(x => x.OrganizationId).ToHashSet();

        var orgs = await db.Organizations
            .AsNoTracking()
            .Where(x => requestedIds.Contains(x.Id))
            .Select(x => x.Id)
            .ToListAsync(cancellationToken);
        if (orgs.Count != requestedIds.Count)
        {
            throw new NotFoundException(nameof(Organization), requestedIds.First(id => !orgs.Contains(id)));
        }

        var existing = await db.UserAccessRights
            .IgnoreQueryFilters()
            .Where(x => x.UserId == userId)
            .ToListAsync(cancellationToken);

        db.UserAccessRights.RemoveRange(existing.Where(x => !requestedIds.Contains(x.OrganizationId)));

        foreach (var item in requested)
        {
            var row = existing.FirstOrDefault(x => x.OrganizationId == item.OrganizationId);
            if (row is null)
            {
                db.UserAccessRights.Add(new UserAccessRight
                {
                    UserId = userId,
                    OrganizationId = item.OrganizationId,
                    OperatingUnit = item.OperatingUnit,
                    AccessChannel = "WEB",
                    IsActive = item.IsActive
                });
            }
            else
            {
                row.OperatingUnit = item.OperatingUnit;
                row.IsActive = item.IsActive;
                row.IsDeleted = false;
                row.DeletedAt = null;
                row.DeletedByUserId = null;
            }
        }

        var defaultOrgId = requested.FirstOrDefault(x => x.IsActive)?.OrganizationId
            ?? requested.FirstOrDefault()?.OrganizationId;
        if (user.OrganizationId is not { } currentDefault || !requestedIds.Contains(currentDefault))
        {
            user.OrganizationId = defaultOrgId;
        }

        await db.SaveChangesAsync(cancellationToken);
        return await ListOrganizationsAsync(userId, cancellationToken);
    }

    private void EnsurePlatformOwner()
    {
        if (!currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Only the platform owner can assign user organizations.");
        }
    }

    private async Task EnsureUserVisibleAsync(Guid userId, CancellationToken cancellationToken)
    {
        var q = db.Users.AsNoTracking().Where(x => x.Id == userId);
        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        if (!await q.AnyAsync(cancellationToken))
        {
            throw new NotFoundException(nameof(User), userId);
        }
    }

    private IQueryable<User> UsersWithRole() =>
        db.Users
            .AsNoTracking()
            .Include(x => x.Organization)
            .Include(x => x.UserRoles)
            .ThenInclude(x => x.Role)
            .Include(x => x.Role);

    private async Task<User> FindForWriteAsync(Guid id, CancellationToken cancellationToken)
    {
        var q = db.Users
            .Include(x => x.UserRoles)
            .ThenInclude(x => x.Role)
            .Include(x => x.Role)
            .Where(x => x.Id == id);

        if (!currentUser.IsSuperAdmin())
        {
            var organizationId = currentUser.RequireOrganizationId();
            q = q.Where(x => x.OrganizationId == organizationId);
        }

        return await q.FirstOrDefaultAsync(cancellationToken)
            ?? throw new NotFoundException(nameof(User), id);
    }

    private async Task<Guid?> ResolveTargetOrganizationIdAsync(
        Guid? requestedOrganizationId,
        CancellationToken cancellationToken)
    {
        if (currentUser.IsSuperAdmin())
        {
            if (requestedOrganizationId is not { } organizationId)
            {
                return null;
            }

            var exists = await db.Organizations.AnyAsync(x => x.Id == organizationId, cancellationToken);
            if (!exists)
            {
                throw new NotFoundException(nameof(Organization), organizationId);
            }

            return organizationId;
        }

        return currentUser.RequireOrganizationId();
    }

    private async Task AssignRoleAsync(
        User user,
        Guid? organizationId,
        Guid roleId,
        CancellationToken cancellationToken)
    {
        await EnsureRoleIsAssignableAsync(organizationId, roleId, cancellationToken);
        user.RoleId = roleId;
        user.UserRoles.Add(new UserRole { UserId = user.Id, RoleId = roleId });
    }

    private async Task EnsureRoleIsAssignableAsync(
        Guid? organizationId,
        Guid roleId,
        CancellationToken cancellationToken)
    {
        var role = await db.Roles
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == roleId, cancellationToken)
            ?? throw new BusinessRuleException("Role is invalid.");

        if (SystemRoles.IsSuperAdmin(role.Name))
        {
            throw new BusinessRuleException("SuperAdmin cannot be assigned.");
        }

        if (SystemRoles.IsAdmin(role.Name) && !currentUser.IsSuperAdmin())
        {
            throw new BusinessRuleException("Admin role cannot be assigned.");
        }

        if (role.OrganizationId is { } roleOrgId
            && !currentUser.IsSuperAdmin()
            && (organizationId is null || roleOrgId != organizationId))
        {
            throw new BusinessRuleException("Role is invalid for this user.");
        }
    }

    private static IQueryable<User> ApplySort(IQueryable<User> query, string? sort, bool descending) =>
        (sort?.Trim().ToLowerInvariant()) switch
        {
            "displayname" => descending ? query.OrderByDescending(x => x.DisplayName) : query.OrderBy(x => x.DisplayName),
            "isactive" => descending ? query.OrderByDescending(x => x.IsActive) : query.OrderBy(x => x.IsActive),
            "createdat" => descending ? query.OrderByDescending(x => x.CreatedAt) : query.OrderBy(x => x.CreatedAt),
            _ => descending ? query.OrderByDescending(x => x.Email) : query.OrderBy(x => x.Email)
        };

    private UserDto Map(User user) =>
        new(
            user.Id,
            user.OrganizationId,
            user.Organization?.Name,
            user.Email,
            user.DisplayName,
            user.Designation,
            user.IsActive,
            user.UserRoles.Select(x => x.Role?.Name).FirstOrDefault(n => !string.IsNullOrWhiteSpace(n))
                ?? user.Role?.Name,
            avatarStorage.GetReadUrl(user.AvatarPath),
            user.UserCode,
            user.EmpId);

    private async Task EnsureCodesAvailableAsync(
        Guid? organizationId,
        string? userCode,
        string? empId,
        Guid? excludeUserId,
        CancellationToken cancellationToken)
    {
        if (userCode is not null)
        {
            var taken = await db.Users.AnyAsync(
                x => x.OrganizationId == organizationId
                     && x.UserCode == userCode
                     && (excludeUserId == null || x.Id != excludeUserId),
                cancellationToken);
            if (taken)
            {
                throw new ConflictException(
                    organizationId is null
                        ? $"User code '{userCode}' already exists."
                        : $"User code '{userCode}' already exists in this organization.");
            }
        }

        if (empId is not null)
        {
            var taken = await db.Users.AnyAsync(
                x => x.OrganizationId == organizationId
                     && x.EmpId == empId
                     && (excludeUserId == null || x.Id != excludeUserId),
                cancellationToken);
            if (taken)
            {
                throw new ConflictException(
                    organizationId is null
                        ? $"Employee id '{empId}' already exists."
                        : $"Employee id '{empId}' already exists in this organization.");
            }
        }
    }

    private static string? NormalizeOptional(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
