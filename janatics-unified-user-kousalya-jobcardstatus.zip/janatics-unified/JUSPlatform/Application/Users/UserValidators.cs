using FluentValidation;

namespace JUSPlatform.Application.Users;

public sealed class CreateUserRequestValidator : AbstractValidator<CreateUserRequest>
{
    public CreateUserRequestValidator()
    {
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.DisplayName).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Password).NotEmpty().MinimumLength(8);
        RuleFor(x => x.RoleId).NotEmpty().WithMessage("Role is required.");
        RuleFor(x => x.UserCode).MaximumLength(10);
        RuleFor(x => x.EmpId).MaximumLength(10);
    }
}

public sealed class UpdateUserRequestValidator : AbstractValidator<UpdateUserRequest>
{
    public UpdateUserRequestValidator()
    {
        RuleFor(x => x.DisplayName).NotEmpty().MaximumLength(200);
        RuleFor(x => x.UserCode).MaximumLength(10);
        RuleFor(x => x.EmpId).MaximumLength(10);
    }
}

public sealed class UpdateCurrentUserRequestValidator : AbstractValidator<UpdateCurrentUserRequest>
{
    public UpdateCurrentUserRequestValidator()
    {
        RuleFor(x => x.Designation).MaximumLength(200);
    }
}

public sealed class UserOrganizationAssignmentValidator : AbstractValidator<UserOrganizationAssignment>
{
    public UserOrganizationAssignmentValidator()
    {
        RuleFor(x => x.OrganizationId).NotEmpty();
    }
}
