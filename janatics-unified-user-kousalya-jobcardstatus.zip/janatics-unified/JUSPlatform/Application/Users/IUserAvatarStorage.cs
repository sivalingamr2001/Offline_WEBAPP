namespace JUSPlatform.Application.Users;

public interface IUserAvatarStorage
{
    Task<string> SaveAsync(Guid? organizationId, Guid userId, Stream content, CancellationToken cancellationToken);
    Task DeleteIfExistsAsync(string? relativePath, CancellationToken cancellationToken);
    string? GetReadUrl(string? relativePath);
}

public static class UserAvatarRules
{
    public const int MaxBytes = 200 * 1024;
    public const string ContentType = "image/jpeg";
}
