namespace JUSPlatform.Application.Users;

using System.Text.Json.Serialization;
using JUSPlatform.Application.Common;
using Microsoft.AspNetCore.Mvc;

public sealed record UserListQuery : PagedListQuery
{
    [FromQuery(Name = "isActive")]
    [JsonPropertyName("isActive")]
    public bool? IsActive { get; init; }

    [FromQuery(Name = "roleId")]
    [JsonPropertyName("roleId")]
    public Guid? RoleId { get; init; }

    /// <summary>SuperAdmin only: filter users by organization. Org users ignore this.</summary>
    [FromQuery(Name = "organizationId")]
    [JsonPropertyName("organizationId")]
    public Guid? OrganizationId { get; init; }
}
