using JUSPlatform.Application.Access;
using JUSPlatform.Application.Common;

namespace JUSPlatform.Application.Users;

public sealed record UserDto(
    Guid Id,
    Guid? OrganizationId,
    string? OrganizationName,
    string Email,
    string DisplayName,
    string? Designation,
    bool IsActive,
    string? RoleName,
    string? AvatarUrl,
    string? UserCode,
    string? EmpId);

public sealed record CreateUserRequest(
    string Email,
    string DisplayName,
    string Password,
    Guid? RoleId,
    Guid? OrganizationId,
    string? UserCode = null,
    string? EmpId = null);

public sealed record UpdateUserRequest(
    string DisplayName,
    bool IsActive,
    Guid? RoleId,
    string? UserCode = null,
    string? EmpId = null);

public sealed record UpdateCurrentUserRequest(string? Designation);

public sealed record UserOrganizationDto(
    Guid OrganizationId,
    string OrganizationName,
    string OrganizationCode,
    int? OperatingUnit,
    bool IsActive);

public sealed class UserOrganizationAssignment
{
    public Guid OrganizationId { get; set; }
    public int? OperatingUnit { get; set; }
    public bool IsActive { get; set; } = true;
}

public interface IUserService
{
    Task<ApiPagedResponse<UserDto>> ListAsync(UserListQuery query, CancellationToken cancellationToken);
    Task<UserDto?> GetAsync(Guid id, CancellationToken cancellationToken);
    Task<UserDto> GetCurrentAsync(CancellationToken cancellationToken);
    Task<UserDto> CreateAsync(CreateUserRequest request, CancellationToken cancellationToken);
    Task<UserDto> UpdateAsync(Guid id, UpdateUserRequest request, CancellationToken cancellationToken);
    Task<UserDto> UpdateCurrentAsync(UpdateCurrentUserRequest request, CancellationToken cancellationToken);
    Task<UserDto> UploadAvatarAsync(Stream content, CancellationToken cancellationToken);
    Task<IReadOnlyList<MenuAccessDto>> ListAccessRightsAsync(Guid userId, CancellationToken cancellationToken);
    Task<IReadOnlyList<MenuAccessDto>> ReplaceAccessRightsAsync(
        Guid userId,
        IReadOnlyList<MenuAccessDto> rights,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<UserOrganizationDto>> ListOrganizationsAsync(Guid userId, CancellationToken cancellationToken);
    Task<IReadOnlyList<UserOrganizationDto>> ReplaceOrganizationsAsync(
        Guid userId,
        IReadOnlyList<UserOrganizationAssignment> assignments,
        CancellationToken cancellationToken);
}
