namespace JUSPlatform.Application.Users;

using FluentValidation;
using JUSPlatform.Application.Common;

public sealed class UserListQueryValidator : AbstractValidator<UserListQuery>
{
    public UserListQueryValidator()
    {
        Include(new PagedListQueryValidator());
    }
}
