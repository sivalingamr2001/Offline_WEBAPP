namespace JUSPlatform.Authorization;

/// <summary>
/// Fixed role names — one role per user; permissions are configured per role.
/// SuperAdmin is platform-only (layer 0). Other system roles are provisioned per organization.
/// </summary>
public static class SystemRoles
{
    public const string SuperAdmin = "SuperAdmin";
    public const string Admin = "Admin";
    public const string Manager = "Manager";
    public const string DataEntryOperator = "DataEntryOperator";

    public static IReadOnlyList<string> OrganizationRoles { get; } =
    [
        Admin,
        Manager,
        DataEntryOperator
    ];

    public static IReadOnlyList<string> All { get; } =
    [
        SuperAdmin,
        Admin,
        Manager,
        DataEntryOperator
    ];

    public static bool IsKnown(string name) =>
        All.Contains(name, StringComparer.OrdinalIgnoreCase);

    public static bool IsSuperAdmin(string? name) =>
        string.Equals(name, SuperAdmin, StringComparison.OrdinalIgnoreCase);

    public static bool IsAdmin(string? name) =>
        string.Equals(name, Admin, StringComparison.OrdinalIgnoreCase);
}
