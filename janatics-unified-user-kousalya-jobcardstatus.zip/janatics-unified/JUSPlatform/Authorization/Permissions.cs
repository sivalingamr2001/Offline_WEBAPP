namespace JUSPlatform.Authorization;

/// <summary>
/// Permission codes: <c>{resource}.{action}</c> — singular resource (org, user, role), not plural collection.
/// </summary>
public static class Permissions
{
    public const string OrgsRead = "org.read";
    public const string OrgsWrite = "org.write";

    public const string UsersRead = "user.read";
    public const string UsersWrite = "user.write";

    public const string RolesRead = "role.read";
    public const string RolesWrite = "role.write";

    public const string JobsRead = "job.read";
    public const string JobsWrite = "job.write";

    public const string ModulesRead = "module.read";
    public const string ModulesWrite = "module.write";

    public const string MenusRead = "menu.read";
    public const string MenusWrite = "menu.write";

    public const string PesView = "pes.view";
    public const string PesEdit = "pes.edit";
    public const string JobCardView = "jobcard.view";

    public static IReadOnlyList<(string Code, string Name, string Module)> Catalog { get; } =
    [
        (OrgsRead, "Read organization", "Organizations"),
        (OrgsWrite, "Write organization", "Organizations"),
        (UsersRead, "Read users", "Users"),
        (UsersWrite, "Write users", "Users"),
        (RolesRead, "Read roles", "Roles"),
        (RolesWrite, "Write roles", "Roles"),
        (JobsRead, "Read background jobs", "Jobs"),
        (JobsWrite, "Enqueue background jobs", "Jobs"),
        (ModulesRead, "Read app modules", "Modules"),
        (ModulesWrite, "Write app modules", "Modules"),
        (MenusRead, "Read app menus", "Menus"),
        (MenusWrite, "Write app menus", "Menus"),
        (PesView, "View PES", "PES"),
        (PesEdit, "Edit PES", "PES"),
        (JobCardView, "Read Job Card Status", "PES")
    ];

    /// <summary>Platform SuperAdmin is granted every catalog permission.</summary>
    public static IReadOnlyList<string> SuperAdminGrant { get; } =
        Catalog.Select(x => x.Code).ToArray();
}

public static class Policies
{
    public const string OrgsRead = "OrgsRead";
    public const string OrgsWrite = "OrgsWrite";
    public const string UsersRead = "UsersRead";
    public const string UsersWrite = "UsersWrite";
    public const string RolesRead = "RolesRead";
    public const string RolesWrite = "RolesWrite";
    public const string JobsRead = "JobsRead";
    public const string JobsWrite = "JobsWrite";
    public const string ModulesRead = "ModulesRead";
    public const string ModulesWrite = "ModulesWrite";
    public const string MenusRead = "MenusRead";
    public const string MenusWrite = "MenusWrite";
    public const string PesView = "PesView";
    public const string PesEdit = "PesEdit";
    public const string JobCardView = "JobCardView";
}

public static class ClaimTypesExt
{
    public const string OrganizationId = "org_id";
    public const string Permission = "permission";
    public const string RoleName = "role_name";
}
