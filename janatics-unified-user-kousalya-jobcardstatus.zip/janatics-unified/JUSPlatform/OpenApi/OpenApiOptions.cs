namespace JUSPlatform.OpenApi;

public sealed class OpenApiOptions
{
    public const string SectionName = "OpenApi";

    public string Title { get; set; } = "Janatics Unified Suite API";
    public string Summary { get; set; } = "Business operations for your organization";
    public string Description { get; set; } =
        "Create and manage organizations, people, roles, and background jobs in one place.";
    public string Version { get; set; } = "1.0.0";
    public string TermsOfService { get; set; } = "https://www.janatics.com/terms";
    public OpenApiContactOptions Contact { get; set; } = new();
    public OpenApiLicenseOptions License { get; set; } = new();
}

public sealed class OpenApiContactOptions
{
    public string Name { get; set; } = "Janatics India";
    public string Email { get; set; } = "developer@janatics.com";
    public string Url { get; set; } = "https://www.janatics.com";
}

public sealed class OpenApiLicenseOptions
{
    public string Name { get; set; } = "Proprietary";
    public string Url { get; set; } = "https://www.janatics.com";
}
