using Microsoft.AspNetCore.OpenApi;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi;

namespace JUSPlatform.OpenApi;

public static class OpenApiExtensions
{
    public const string DocumentName = "v1";
    public const string JsonRoute = "/openapi/v1.json";

    public static IServiceCollection AddJUSPlatformOpenApi(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<OpenApiOptions>(configuration.GetSection(OpenApiOptions.SectionName));
        services.AddOpenApi(DocumentName, options =>
        {
            options.AddDocumentTransformer<JusPlatformOpenApiDocumentTransformer>();
        });

        return services;
    }
}

internal sealed class JusPlatformOpenApiDocumentTransformer(IOptions<OpenApiOptions> options)
    : IOpenApiDocumentTransformer
{
    public Task TransformAsync(
        OpenApiDocument document,
        OpenApiDocumentTransformerContext context,
        CancellationToken cancellationToken)
    {
        OpenApiDocumentCustomizer.Apply(document, options.Value);
        return Task.CompletedTask;
    }
}

internal static class OpenApiDocumentCustomizer
{
    public static void Apply(OpenApiDocument document, OpenApiOptions options)
    {
        ApplyInfo(document, options);
        ApplyBearer(document);
    }

    public static void ApplyInfo(OpenApiDocument document, OpenApiOptions options)
    {
        var description = string.IsNullOrWhiteSpace(options.Summary)
            ? options.Description
            : $"{options.Summary}\n\n{options.Description}";

        document.Info = new OpenApiInfo
        {
            Title = options.Title,
            Description = description,
            Version = options.Version,
            TermsOfService = ParseOpenApiUri(options.TermsOfService),
            Contact = new OpenApiContact
            {
                Name = options.Contact.Name,
                Email = options.Contact.Email,
                Url = ParseOpenApiUri(options.Contact.Url)
            },
            License = new OpenApiLicense
            {
                Name = options.License.Name,
                Url = ParseOpenApiUri(options.License.Url)
            }
        };
    }

    public static void ApplyBearer(OpenApiDocument document)
    {
        document.Components ??= new OpenApiComponents();
        document.Components.SecuritySchemes ??= new Dictionary<string, IOpenApiSecurityScheme>(StringComparer.Ordinal);
        document.Components.SecuritySchemes["Bearer"] = new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "Access token from login."
        };

        document.Security ??= [];
        document.Security.Add(new OpenApiSecurityRequirement
        {
            [new OpenApiSecuritySchemeReference("Bearer", document)] = []
        });
    }

    private static Uri? ParseOpenApiUri(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) ? uri : null;
}
