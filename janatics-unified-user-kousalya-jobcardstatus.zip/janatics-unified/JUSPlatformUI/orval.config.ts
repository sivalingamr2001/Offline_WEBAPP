import { defineConfig } from 'orval'

const input =
  process.env.OPENAPI_URL ?? 'http://localhost:5201/openapi/v1.json'

export default defineConfig({
  jusplatform: {
    input,
    output: {
      mode: 'tags-split',
      target: './src/api/generated',
      schemas: './src/api/generated/models',
      client: 'axios',
      override: {
        mutator: {
          path: './src/api/mutator.ts',
          name: 'customInstance',
        },
      },
    },
  },
})
