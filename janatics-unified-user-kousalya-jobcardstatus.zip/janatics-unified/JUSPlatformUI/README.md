# JUSPlatformUI

React + TypeScript + Vite frontend for **Janatics Unified Suite** (publisher: **Janatics India**).

## Stack

- **pnpm** · **Vite** · **React 19** · **TypeScript**
- **Tailwind CSS 4** · **ShadCN-style** UI primitives
- **Orval** — OpenAPI → typed Axios client
- **TanStack Query** · **React Router 7**
- Fonts: **Geist** (sans) · **JetBrains Mono** (code)

## Project layout

```text
src/
├── api/              # Orval output + hand-written auth helpers
├── atoms/            # Smallest UI pieces (extend as needed)
├── components/       # Shared UI (data-table, ui/*)
├── constants/        # routes, design tokens, permissions
├── contexts/         # Auth, PageTitle
├── hooks/
├── layouts/          # Auth, Public, Dashboard
├── providers/
├── routers/          # Route map mirrors screens/
└── screens/          # One folder per route segment
    ├── Public/Login/index.tsx           → /login
    └── Dashboard/Invoices/InvoiceById/  → /dashboard/invoices/:id
```

## Quick start

**Windows (default)** — from repo root. Two terminals.

API:

```
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform\JUSPlatform.csproj
```

Frontend:

```
cd JUSPlatformUI
pnpm install
pnpm run dev
```

**Linux:**

```
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform/JUSPlatform.csproj
cd JUSPlatformUI && pnpm install && pnpm run dev
```

Mailpit (optional, needs Docker) for mock email: `docker compose -f docker/mailpit/docker-compose.yml up -d` — skip if Docker is not installed.

## Orval

With the API running:

```bash
pnpm api:generate   # reads OPENAPI_URL / localhost:5201/openapi/v1.json
```

Generated clients land in `src/api/generated/`. The Axios mutator in `src/api/mutator.ts` attaches JWT from `sessionStorage` and clears session on 401.

## Auth

| Flow | Route |
|------|-------|
| Login | `/login` |
| Create account (first user = **Admin**) | `/register` |
| Forgot password | `/forgot-password` |
| Reset password | `/reset-password?token=…` |

- JWT stored in **sessionStorage** (tab-scoped).
- **Logout** calls `POST /api/v1/auth/logout` to revoke the token server-side.

## Production build

Build output goes to `JUSPlatform/wwwroot/` (same origin as API):

```bash
pnpm build
```

## Team management

`/dashboard/team` — Admin/SuperAdmin only. Lists org users and invites members via `POST /api/v1/users`.

## Bugsink (application bugs)

The UI uses the **Sentry browser SDK** against a **Bugsink** DSN (same protocol as the API). This is for **frontend crashes**, not distributed traces.

| Concern | Where |
|---------|--------|
| React / router / unhandled errors | Bugsink via `@sentry/react` |
| API 500s | Already reported by the API |
| Traces & request logs | Grafana **Tempo** / **Loki** (API OpenTelemetry). Enable `Observability` on the API. |

Empty DSN = off (default). After `.\scripts\bugsink-up.ps1` (Linux: `./scripts/bugsink-up.sh`):

1. Open http://localhost:8000 (`admin@example.org` / `admin`)
2. Create a project (browser / JS is fine)
3. Copy the DSN into `JUSPlatformUI/.env`:

```bash
VITE_BUGSINK_DSN=http://YOUR_KEY@localhost:8000/PROJECT_ID
VITE_BUGSINK_ENVIRONMENT=development
```

Restart `pnpm run dev`. Events include `trace_id` and `response_id` from the last API response (`X-Trace-Id` / `X-Response-Id`) so you can search Tempo when observability is on.

The DSN is a **public ingest URL** (it ships in the bundle). It is not a JWT signing key. Do not put passwords in `VITE_*`. Production: set the vars at **build** time (`pnpm build`).

Do **not** turn on Sentry tracing, replay, or profiling here. If you need UI traces later, use the same OTel → Tempo/Loki path as the API.
