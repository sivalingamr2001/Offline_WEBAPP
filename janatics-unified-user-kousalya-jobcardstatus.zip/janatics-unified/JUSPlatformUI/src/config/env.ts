import { AXIOS_INSTANCE } from '@/api/axiosInstance'
import { initBugsink } from '@/observability/bugsink'

let apiBaseUrl = ''

export function configureEnv(): void {
  apiBaseUrl = import.meta.env.VITE_API_BASE_URL ?? ''
  AXIOS_INSTANCE.defaults.baseURL = apiBaseUrl
  initBugsink()
}

export function getApiBaseUrl(): string {
  return apiBaseUrl
}
