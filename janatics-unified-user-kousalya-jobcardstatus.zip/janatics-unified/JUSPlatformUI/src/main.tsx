import { StrictMode, Suspense } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider } from 'react-router-dom'
import { AppErrorBoundary } from '@/components/error/AppErrorBoundary'
import { configureEnv } from '@/config/env'
import { AppProviders } from '@/providers/AppProviders'
import { appRouter } from '@/routers/AppRouter'
import '@/index.css'
import { TooltipProvider } from './components/ui/tooltip'

configureEnv()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppErrorBoundary>
      <AppProviders>
        <TooltipProvider>
          <Suspense fallback={<div className="p-8 text-sm text-muted-foreground">Loading…</div>}>
            <RouterProvider router={appRouter} />
          </Suspense>
        </TooltipProvider>
      </AppProviders>
    </AppErrorBoundary>
  </StrictMode>,
)
