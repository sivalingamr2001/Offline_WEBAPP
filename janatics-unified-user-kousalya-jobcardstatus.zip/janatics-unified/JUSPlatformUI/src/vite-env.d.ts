/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Optional absolute API base (empty = same origin / Vite proxy). */
  readonly VITE_API_BASE_URL?: string
  /** Bugsink Sentry-compatible DSN (public ingest URL). Empty = off. */
  readonly VITE_BUGSINK_DSN?: string
  /** Environment tag on Bugsink events (defaults to Vite MODE). */
  readonly VITE_BUGSINK_ENVIRONMENT?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
