import { Loader2 } from 'lucide-react'
import { ContentPanel } from '@/components/layout/EmptyState'

type LoadingStateProps = {
  label?: string
}

export function LoadingState({ label = 'Loading…' }: LoadingStateProps) {
  return (
    <ContentPanel>
      <div className="flex min-h-[28rem] items-center justify-center gap-2 py-16 text-sm text-[var(--cf-text-muted)]">
        <Loader2 className="size-4 animate-spin" aria-hidden />
        {label}
      </div>
    </ContentPanel>
  )
}
