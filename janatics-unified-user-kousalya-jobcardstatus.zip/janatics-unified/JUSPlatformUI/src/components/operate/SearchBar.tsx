import { Search } from 'lucide-react'
import { cn } from '@/utils/cn'

type SearchBarProps = {
  value: string
  onChange: (value: string) => void
  onSubmit: () => void
  placeholder?: string
  className?: string
  fullWidth?: boolean
}

export function SearchBar({
  value,
  onChange,
  onSubmit,
  placeholder,
  className,
  fullWidth = true,
}: SearchBarProps) {
  return (
    <form
      className={cn(fullWidth ? 'relative mb-4 w-full' : 'relative mb-4 max-w-xl', className)}
      onSubmit={(e) => {
        e.preventDefault()
        onSubmit()
      }}
    >
      <Search
        className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-[var(--cf-text-muted)]"
        strokeWidth={1.75}
      />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-10 w-full rounded-lg border border-[var(--cf-border)] bg-white pl-10 pr-4 text-sm text-foreground shadow-sm placeholder:text-[var(--cf-text-muted)] focus:border-[var(--cf-blue)] focus:outline-none focus:ring-2 focus:ring-[var(--cf-blue)]/20"
      />
    </form>
  )
}
