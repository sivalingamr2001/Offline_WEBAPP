import { AlertTriangle, Home, Layers, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { brand } from '@/constants/brand'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'

export type ErrorFallbackProps = {
  title?: string
  message?: string
  details?: string
  onRetry?: () => void
  className?: string
}

export function ErrorFallback({
  title = 'Something went wrong',
  message = 'An unexpected error occurred. You can return to the dashboard and continue working.',
  details,
  onRetry,
  className,
}: ErrorFallbackProps) {
  return (
    <div
      className={cn(
        'flex min-h-screen flex-col bg-[var(--cf-page)] text-[var(--cf-text-primary)]',
        className,
      )}
      role="alert"
      aria-live="assertive"
    >
      <header className="border-b border-[var(--cf-border)] bg-[var(--cf-white)] px-4 py-3 lg:px-8">
        <a href={routes.dashboard} className="inline-flex min-w-0 items-center gap-2.5 rounded-md hover:opacity-90">
          <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-[var(--cf-blue)] text-white shadow-sm">
            <Layers className="size-4" aria-hidden />
          </div>
          <span className="truncate text-sm font-semibold tracking-tight">{brand.name}</span>
        </a>
      </header>

      <main className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="w-full max-w-lg rounded-xl border border-[var(--cf-border)] bg-[var(--cf-white)] p-8 shadow-sm">
          <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-red-50 text-red-600 ring-1 ring-inset ring-red-100">
            <AlertTriangle className="size-7" strokeWidth={1.75} aria-hidden />
          </div>

          <div className="mt-5 text-center">
            <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
            <p className="mt-2 text-sm leading-relaxed text-[var(--cf-text-secondary)]">{message}</p>
          </div>

          {details ? (
            <pre className="mt-5 max-h-40 overflow-auto rounded-lg border border-[var(--cf-border)] bg-[var(--cf-white-90)] px-3 py-2.5 text-left font-mono text-[11px] leading-relaxed text-[var(--cf-text-muted)]">
              {details}
            </pre>
          ) : null}

          <div className="mt-7 flex flex-col-reverse gap-2 sm:flex-row sm:justify-center">
            {onRetry ? (
              <Button type="button" variant="outline" className="gap-1.5" onClick={onRetry}>
                <RotateCcw className="size-3.5" aria-hidden />
                Try again
              </Button>
            ) : null}
            <Button asChild className="gap-1.5">
              {/* Plain anchor so recovery works even when router context is broken. */}
              <a href={routes.dashboard}>
                <Home className="size-3.5" aria-hidden />
                Back to dashboard
              </a>
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

export function describeError(error: unknown): { title: string; message: string; details?: string } {
  if (typeof error === 'object' && error !== null && 'status' in error) {
    const status = Number((error as { status?: number }).status)
    const statusText =
      'statusText' in error && typeof (error as { statusText?: string }).statusText === 'string'
        ? (error as { statusText: string }).statusText
        : undefined
    const data = 'data' in error ? (error as { data?: unknown }).data : undefined
    const dataMessage =
      typeof data === 'string'
        ? data
        : data && typeof data === 'object' && 'message' in data && typeof (data as { message: unknown }).message === 'string'
          ? (data as { message: string }).message
          : undefined

    if (status === 404) {
      return {
        title: 'Page not found',
        message: dataMessage || 'The page you requested does not exist or was moved.',
        details: import.meta.env.DEV ? `${status}${statusText ? ` ${statusText}` : ''}` : undefined,
      }
    }

    if (status === 401 || status === 403) {
      return {
        title: 'Access denied',
        message: dataMessage || 'You do not have permission to view this page.',
        details: import.meta.env.DEV ? `${status}${statusText ? ` ${statusText}` : ''}` : undefined,
      }
    }

    return {
      title: 'Request failed',
      message: dataMessage || 'The application hit an unexpected response. Return to the dashboard and try again.',
      details: import.meta.env.DEV
        ? `${status}${statusText ? ` ${statusText}` : ''}${dataMessage ? `\n${dataMessage}` : ''}`
        : undefined,
    }
  }

  if (error instanceof Error) {
    return {
      title: 'Something went wrong',
      message: 'An unexpected error stopped this page from loading. You can return to the dashboard and continue working.',
      details: import.meta.env.DEV ? `${error.name}: ${error.message}` : undefined,
    }
  }

  return {
    title: 'Something went wrong',
    message: 'An unexpected error occurred. You can return to the dashboard and continue working.',
    details: import.meta.env.DEV && error != null ? String(error) : undefined,
  }
}
