import { Component, type ErrorInfo, type ReactNode } from 'react'
import { ErrorFallback, describeError } from '@/components/error/ErrorFallback'
import { reportAppError } from '@/observability/bugsink'

type AppErrorBoundaryProps = {
  children: ReactNode
}

type AppErrorBoundaryState = {
  error: unknown
}

/** Catches render errors outside React Router route trees. */
export class AppErrorBoundary extends Component<AppErrorBoundaryProps, AppErrorBoundaryState> {
  state: AppErrorBoundaryState = { error: null }

  static getDerivedStateFromError(error: unknown): AppErrorBoundaryState {
    return { error }
  }

  componentDidCatch(error: unknown, info: ErrorInfo) {
    console.error('AppErrorBoundary caught an error', error, info.componentStack)
    reportAppError(error instanceof Error ? error : new Error(String(error)), {
      componentStack: info.componentStack,
    })
  }

  private handleRetry = () => {
    this.setState({ error: null })
  }

  render() {
    const { error } = this.state
    if (error == null) {
      return this.props.children
    }

    const described = describeError(error)
    return (
      <ErrorFallback
        title={described.title}
        message={described.message}
        details={described.details}
        onRetry={this.handleRetry}
      />
    )
  }
}
