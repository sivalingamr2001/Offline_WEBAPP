import type { LucideIcon } from 'lucide-react'
import { cn } from '@/utils/cn'

type EmptyStateProps = {
  icon: LucideIcon
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
}

export function ContentPanel({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        'overflow-hidden rounded-lg border border-[var(--cf-border)] bg-white shadow-sm',
        className,
      )}
    >
      {children}
    </div>
  )
}

export function EmptyState({ icon: Icon, title, description, action, className }: EmptyStateProps) {
  return (
    <ContentPanel className={className}>
      <div className="flex min-h-[28rem] flex-col items-center justify-center px-6 py-16 text-center">
        <Icon className="mb-5 size-14 text-[var(--cf-text-muted)]" strokeWidth={1.25} aria-hidden />
        <h3 className="text-lg font-semibold text-[var(--cf-text-primary)]">{title}</h3>
        {description ? (
          <p className="mt-2 max-w-md text-sm leading-relaxed text-[var(--cf-text-muted)]">{description}</p>
        ) : null}
        {action ? <div className="mt-6">{action}</div> : null}
      </div>
    </ContentPanel>
  )
}
