import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { StatusBadge } from '@/components/ui/status-badge'
import { routes } from '@/constants/routes'
import { usePermissions } from '@/hooks/usePermissions'
import { cn } from '@/utils/cn'

type TickerTone = 'danger' | 'warning' | 'info' | 'orange'

type TickerItem = {
  id: string
  tone: TickerTone
  source: string
  text: string
  to: string
}

const TICK_MS = 4200

const toneDot: Record<TickerTone, string> = {
  danger: 'bg-red-500',
  warning: 'bg-amber-500',
  info: 'bg-[var(--cf-blue)]',
  orange: 'bg-orange-500',
}

const headerNotifications: TickerItem[] = [
  {
    id: 'n1',
    tone: 'danger',
    source: 'Portfolio',
    text: 'Runner FG below OCQ threshold at AMS1',
    to: routes.portfolioAlerts,
  },
  {
    id: 'n2',
    tone: 'warning',
    source: 'Portfolio',
    text: 'Delivery slip on committed FG-3 this week',
    to: routes.portfolioPerformance,
  },
  {
    id: 'n3',
    tone: 'info',
    source: 'Portfolio',
    text: 'Quality watchlist updated for AMS1 products',
    to: routes.portfolioProducts,
  },
]

function slideClass(i: number, index: number, count: number) {
  const prev = (index - 1 + count) % count
  if (i === index) return 'translate-y-0'
  if (i === prev) return '-translate-y-full'
  return 'translate-y-full'
}

export function NotificationTicker({ className }: { className?: string }) {
  const { isSuperAdmin } = usePermissions()
  const items = headerNotifications
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)

  useEffect(() => {
    if (paused || items.length <= 1) return
    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % items.length)
    }, TICK_MS)
    return () => window.clearInterval(id)
  }, [items.length, paused])

  if (isSuperAdmin || items.length === 0) return null

  const prev = (index - 1 + items.length) % items.length

  return (
    <div
      className={cn('flex min-w-0 items-center gap-2.5', className)}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
    >
      <StatusBadge tone="info" className="h-5 shrink-0 px-1.5 font-mono text-[10px] font-semibold tracking-wider uppercase">
        Live
      </StatusBadge>
      <div
        className="relative h-8 min-w-0 flex-1 overflow-hidden"
        aria-live="polite"
        aria-atomic="true"
        role="region"
        aria-label="Live headlines"
      >
        {items.map((item, i) => {
          const active = i === index
          const leaving = i === prev
          return (
            <Link
              key={item.id}
              to={item.to}
              title={`${item.source}: ${item.text}`}
              tabIndex={active ? 0 : -1}
              aria-hidden={!active}
              className={cn(
                'absolute inset-0 flex items-center gap-2 text-[13px] text-[var(--cf-text-secondary)] hover:text-[var(--cf-text-primary)]',
                'motion-safe:duration-500 motion-safe:ease-out',
                active || leaving ? 'motion-safe:transition-transform' : 'transition-none',
                slideClass(i, index, items.length),
              )}
            >
              <span className={cn('size-1.5 shrink-0 rounded-full', toneDot[item.tone])} aria-hidden />
              <span className="min-w-0 truncate">
                <span className="font-medium text-[var(--cf-text-primary)]">{item.source}</span>
                <span className="text-[var(--cf-text-muted)]"> · </span>
                {item.text}
              </span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
