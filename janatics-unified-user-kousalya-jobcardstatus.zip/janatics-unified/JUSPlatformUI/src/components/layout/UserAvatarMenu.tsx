import { Home, LogOut, Settings } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'

function initialsFrom(name: string, email: string) {
  const source = name.trim() || email.split('@')[0] || 'U'
  const parts = source.split(/[\s._-]+/).filter(Boolean)
  if (parts.length >= 2) return `${parts[0]![0] ?? ''}${parts[1]![0] ?? ''}`.toUpperCase()
  return source.slice(0, 2).toUpperCase()
}

export function UserAvatarMenu() {
  const { session, logout } = useAuth()
  const navigate = useNavigate()
  const email = session?.email ?? ''
  const displayName = session?.displayName?.trim() || email.split('@')[0] || 'Account'
  const designation = session?.designation?.trim() || ''
  const roleLabel = session?.roleName?.trim() || ''
  const initials = initialsFrom(displayName, email)

  async function handleLogout() {
    await logout()
    navigate(routes.login)
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="ml-1 inline-flex items-center gap-2 rounded-lg border border-[var(--cf-border)] bg-white px-2 py-1 text-left text-sm outline-none hover:bg-[var(--cf-surface-hover)] focus-visible:ring-2 focus-visible:ring-[var(--cf-blue)]/20"
          aria-label="Account menu"
        >
          <span className="flex size-7 items-center justify-center rounded-full bg-[var(--cf-blue)] text-[10px] font-semibold text-white">
            {initials}
          </span>
          <span className="hidden min-w-0 sm:block">
            <span className="block max-w-[10rem] truncate text-xs font-medium text-[var(--cf-text-primary)]">
              {displayName}
            </span>
          </span>
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-72 p-0">
        <div className="flex items-start gap-3 px-3 py-3">
          <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[var(--cf-blue)] text-xs font-semibold text-white">
            {initials}
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-[var(--cf-text-primary)]">{displayName}</p>
            {designation ? (
              <p className="truncate text-xs text-[var(--cf-text-secondary)]">{designation}</p>
            ) : null}
            {roleLabel ? (
              <p className="truncate text-xs text-[var(--cf-text-secondary)]">{roleLabel}</p>
            ) : null}
            {email ? <p className="truncate text-xs text-[var(--cf-text-muted)]">{email}</p> : null}
          </div>
        </div>
        <DropdownMenuSeparator className="my-0" />
        <DropdownMenuGroup className="p-1">
          <DropdownMenuLabel>Workspace</DropdownMenuLabel>
          <DropdownMenuItem onSelect={() => navigate(routes.dashboard)}>
            <Home className="size-4" aria-hidden />
            Account home
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => navigate(routes.settings)}>
            <Settings className="size-4" aria-hidden />
            Settings
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator className="my-0" />
        <div className="p-1">
          <DropdownMenuItem
            className="text-red-600 focus:bg-red-50 focus:text-red-700"
            onSelect={() => {
              void handleLogout()
            }}
          >
            <LogOut className="size-4" aria-hidden />
            Sign out
          </DropdownMenuItem>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
