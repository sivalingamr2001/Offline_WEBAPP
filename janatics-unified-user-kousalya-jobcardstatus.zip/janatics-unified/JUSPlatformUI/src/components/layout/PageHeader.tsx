import type { LucideIcon } from 'lucide-react'
import { BookOpen } from 'lucide-react'
import { cn } from '@/utils/cn'
import { Button } from '@/components/ui/button'

type PageHeaderProps = {
  icon: LucideIcon
  title: string
  description?: string
  actions?: React.ReactNode
  className?: string
  showDocs?: boolean
}

export function PageHeader({ icon: Icon, title, description, actions, className, showDocs = true }: PageHeaderProps) {
  return (
    <div className={cn('mb-5', className)}>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex items-center gap-2.5">
            <Icon className="size-6 shrink-0 text-[var(--cf-text-primary)]" strokeWidth={1.75} aria-hidden />
            <h1 className="text-[1.75rem] font-semibold leading-tight tracking-tight text-[var(--cf-text-primary)]">
              {title}
            </h1>
          </div>
          {description ? (
            <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-[var(--cf-text-muted)]">{description}</p>
          ) : null}
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {showDocs ? (
            <Button variant="outline" size="icon" className="size-9" aria-label="Documentation">
              <BookOpen className="size-4" aria-hidden />
            </Button>
          ) : null}
          {actions}
        </div>
      </div>
    </div>
  )
}
