import { Layers } from 'lucide-react'
import { Link } from 'react-router-dom'
import { brand } from '@/constants/brand'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'

type AppBrandProps = {
  className?: string
  showName?: boolean
  showSubtitle?: boolean
}

export function AppBrand({ className, showName = true, showSubtitle = true }: AppBrandProps) {
  return (
    <Link
      to={routes.dashboard}
      className={cn('flex min-w-0 items-center gap-2 rounded-md transition-opacity hover:opacity-90', className)}
    >
      <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-[var(--cf-blue)] text-white shadow-sm">
        <Layers className="size-4" aria-hidden />
      </div>
      {showName ? (
        <span className="min-w-0 flex-1 overflow-hidden">
          <span className="block truncate text-[13px] font-semibold leading-tight tracking-tight text-[var(--cf-text-primary)]">
            {brand.name}
          </span>
          {showSubtitle ? (
            <span className="mt-0.5 block truncate text-[10px] leading-none text-[var(--cf-text-muted)]">
              {brand.subtitle}
            </span>
          ) : null}
        </span>
      ) : null}
    </Link>
  )
}
