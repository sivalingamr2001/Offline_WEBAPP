import { Shield } from 'lucide-react'
import { ActiveStatusBadge } from '@/components/ui/status-badge'
import { SelectWithIcon, SelectWithIconItem } from '@/components/ui/select-with-icon'

type UserStatusBadgeProps = {
  active: boolean
  className?: string
}

/** @deprecated Prefer ActiveStatusBadge from `@/components/ui/status-badge`. */
export function UserStatusBadge({ active, className }: UserStatusBadgeProps) {
  return <ActiveStatusBadge active={active} className={className} />
}

type RoleSelectProps = {
  roles: { id: string; name: string }[]
  value: string
  onChange: (roleId: string) => void
  disabled?: boolean
  className?: string
  placeholder?: string
}

export function RoleSelect({
  roles,
  value,
  onChange,
  disabled,
  className,
  placeholder = 'Select role',
}: RoleSelectProps) {
  return (
    <SelectWithIcon
      icon={Shield}
      value={value}
      onValueChange={onChange}
      disabled={disabled}
      placeholder={placeholder}
      className={className}
    >
      {roles.map((role) => (
        <SelectWithIconItem key={role.id} value={role.id}>
          {role.name}
        </SelectWithIconItem>
      ))}
    </SelectWithIcon>
  )
}

export function resolveRoleId(roles: { id: string; name: string }[], roleName: string | null | undefined): string {
  if (!roleName) return ''
  return roles.find((r) => r.name === roleName)?.id ?? ''
}
