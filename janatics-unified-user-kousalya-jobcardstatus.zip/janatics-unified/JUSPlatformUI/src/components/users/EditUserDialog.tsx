import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Hash, Mail, Pencil, ToggleLeft, User } from 'lucide-react'
import { type FormEvent, useEffect, useMemo, useState } from 'react'
import { getRoles } from '@/api/generated/roles/roles'
import { getUsers } from '@/api/generated/users/users'
import type { UserDto } from '@/api/generated/models/userDto'
import { resolveRoleId, RoleSelect } from '@/components/users/userFormParts'
import { filterAssignableRoles } from '@/constants/roles'
import { ActiveStatusBadge } from '@/components/ui/status-badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'

const { updateUser } = getUsers()
const { listRoles } = getRoles()

type EditUserDialogProps = {
  user: UserDto | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function EditUserDialog({ user, open, onOpenChange }: EditUserDialogProps) {
  const queryClient = useQueryClient()
  const { session } = useAuth()
  const { isSuperAdmin } = usePermissions()
  const [displayName, setDisplayName] = useState('')
  const [roleId, setRoleId] = useState('')
  const [userCode, setUserCode] = useState('')
  const [empId, setEmpId] = useState('')
  const [isActive, setIsActive] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const isSelf = user?.id === session?.userId

  const rolesQuery = useQuery({
    queryKey: ['roles', 'assignable'],
    queryFn: () => listRoles({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  const roles = useMemo(
    () =>
      filterAssignableRoles(
        (rolesQuery.data?.items ?? []).map((r) => ({ id: r.id, name: r.name })),
        { allowAdmin: isSuperAdmin },
      ),
    [isSuperAdmin, rolesQuery.data?.items],
  )

  useEffect(() => {
    if (user && open) {
      setDisplayName(user.displayName)
      setRoleId(resolveRoleId(roles, user.roleName))
      setUserCode(user.userCode ?? '')
      setEmpId(user.empId ?? '')
      setIsActive(user.isActive)
      setError(null)
    }
  }, [user, open, roles])

  const updateMutation = useMutation({
    mutationFn: async () => {
      await updateUser(user!.id, {
        displayName: displayName.trim(),
        isActive,
        roleId: roleId || null,
        userCode: userCode.trim() || null,
        empId: empId.trim() || null,
      })
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['users'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setError(null)
    updateMutation.mutate()
  }

  if (!user) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pencil className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Edit user
          </DialogTitle>
          <DialogDescription>
            Update profile and role for <strong>{user.email}</strong>. Organizations are assigned on User
            organizations.
          </DialogDescription>
        </DialogHeader>

        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label>Email</Label>
            <div className="relative">
              <Mail
                className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-[var(--cf-text-muted)]"
                strokeWidth={1.75}
                aria-hidden
              />
              <div className="flex h-9 w-full items-center rounded-md border border-[var(--cf-border)] bg-[var(--cf-surface-hover)] pl-9 pr-3 text-sm text-[var(--cf-text-secondary)]">
                {user.email}
              </div>
            </div>
            <p className="text-xs text-[var(--cf-text-muted)]">Email cannot be changed here.</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-displayName">Display name</Label>
            <InputWithIcon
              id="edit-displayName"
              icon={User}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-userCode">User code</Label>
            <InputWithIcon
              id="edit-userCode"
              icon={Hash}
              maxLength={10}
              value={userCode}
              onChange={(e) => setUserCode(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-empId">Employee id</Label>
            <InputWithIcon
              id="edit-empId"
              icon={Hash}
              maxLength={10}
              value={empId}
              onChange={(e) => setEmpId(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-role">Role</Label>
            <RoleSelect roles={roles} value={roleId} onChange={setRoleId} disabled={isSelf || rolesQuery.isLoading} />
            {isSelf ? (
              <p className="text-xs text-[var(--cf-text-muted)]">You cannot change your own role.</p>
            ) : rolesQuery.isLoading ? (
              <p className="text-xs text-[var(--cf-text-muted)]">Loading roles…</p>
            ) : rolesQuery.isError ? (
              <p className="text-xs text-destructive">Could not load roles.</p>
            ) : roles.length === 0 ? (
              <p className="text-xs text-[var(--cf-text-muted)]">No assignable roles. Create a catalog role first.</p>
            ) : null}
          </div>

          <div className="flex items-center justify-between rounded-lg border border-[var(--cf-border)] px-3 py-3">
            <div className="flex items-start gap-2.5">
              <ToggleLeft className="mt-0.5 size-4 text-[var(--cf-text-muted)]" aria-hidden />
              <div>
                <p className="text-sm font-medium">Account status</p>
                <p className="text-xs text-[var(--cf-text-muted)]">
                  {isSelf ? 'You cannot deactivate your own account.' : 'Inactive users cannot sign in.'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ActiveStatusBadge active={isActive} />
              <input
                type="checkbox"
                checked={isActive}
                disabled={isSelf}
                onChange={(e) => setIsActive(e.target.checked)}
                className="size-4 rounded border-input"
                aria-label="Active account"
              />
            </div>
          </div>

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={updateMutation.isPending}>
              {updateMutation.isPending ? 'Saving…' : 'Save changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
