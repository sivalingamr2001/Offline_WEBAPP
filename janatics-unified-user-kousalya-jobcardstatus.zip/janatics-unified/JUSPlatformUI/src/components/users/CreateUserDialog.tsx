import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Loader2, Mail, User, UserPlus, Hash } from 'lucide-react'
import { type FormEvent, useEffect, useState } from 'react'
import { getUsers } from '@/api/generated/users/users'
import { RoleSelect } from '@/components/users/userFormParts'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { PasswordInput } from '@/components/ui/password-input'
import { getApiErrorMessage } from '@/utils/apiError'

const { createUser } = getUsers()

type CreateUserDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  roles: { id: string; name: string }[]
  rolesLoading?: boolean
}

export function CreateUserDialog({
  open,
  onOpenChange,
  roles,
  rolesLoading = false,
}: CreateUserDialogProps) {
  const queryClient = useQueryClient()
  const [email, setEmail] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [password, setPassword] = useState('')
  const [roleId, setRoleId] = useState('')
  const [userCode, setUserCode] = useState('')
  const [empId, setEmpId] = useState('')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) {
      setEmail('')
      setDisplayName('')
      setPassword('')
      setRoleId('')
      setUserCode('')
      setEmpId('')
      setError(null)
    }
  }, [open])

  const createMutation = useMutation({
    mutationFn: createUser,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['users'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    createMutation.mutate({
      email: email.trim(),
      displayName: displayName.trim(),
      password,
      roleId: roleId || null,
      organizationId: null,
      userCode: userCode.trim() || null,
      empId: empId.trim() || null,
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Add user
          </DialogTitle>
          <DialogDescription>Add a person with a role. Organizations are assigned on User organizations.</DialogDescription>
        </DialogHeader>

        <form className="space-y-4" onSubmit={onSubmit}>
          {rolesLoading ? (
            <div className="flex items-center gap-2 rounded-md border border-[var(--cf-border)] bg-[var(--cf-surface-hover)] px-3 py-2 text-sm text-[var(--cf-text-muted)]">
              <Loader2 className="size-4 animate-spin" aria-hidden />
              Loading roles…
            </div>
          ) : null}
          <div className="space-y-2">
            <Label htmlFor="create-displayName">Name</Label>
            <InputWithIcon
              id="create-displayName"
              icon={User}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-email">Email</Label>
            <InputWithIcon
              id="create-email"
              icon={Mail}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-password">Temporary password</Label>
            <PasswordInput
              id="create-password"
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-userCode">User code</Label>
            <InputWithIcon
              id="create-userCode"
              icon={Hash}
              maxLength={10}
              value={userCode}
              onChange={(e) => setUserCode(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-empId">Employee id</Label>
            <InputWithIcon
              id="create-empId"
              icon={Hash}
              maxLength={10}
              value={empId}
              onChange={(e) => setEmpId(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-role">Role</Label>
            <RoleSelect roles={roles} value={roleId} onChange={setRoleId} disabled={rolesLoading} />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createMutation.isPending || rolesLoading || !roleId}>
              {createMutation.isPending ? 'Creating…' : 'Add user'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
