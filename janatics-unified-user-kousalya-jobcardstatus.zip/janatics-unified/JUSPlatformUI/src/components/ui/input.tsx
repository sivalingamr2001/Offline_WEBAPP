import * as React from 'react'
import { cn } from '@/utils/cn'

export function Input({ className, type, ...props }: React.ComponentProps<'input'>) {
  return (
    <input
      type={type}
      className={cn(
        'flex h-9 w-full rounded-md border border-[var(--cf-border)] bg-white px-3 py-2 text-sm text-foreground shadow-sm ring-offset-background placeholder:text-[var(--cf-text-muted)] focus-visible:border-[var(--cf-blue)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cf-blue)]/20 disabled:cursor-not-allowed disabled:opacity-50',
        className,
      )}
      {...props}
    />
  )
}
