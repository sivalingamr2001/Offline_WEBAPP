import type { LucideIcon } from 'lucide-react'
import { AlertTriangle, CheckCircle2, Info, XCircle } from 'lucide-react'
import type { ReactNode } from 'react'
import { type StatusBadgeTone, statusToneClass } from '@/components/ui/status-badge'
import { cn } from '@/utils/cn'

const defaultIcon: Record<StatusBadgeTone, LucideIcon> = {
  info: Info,
  success: CheckCircle2,
  warning: AlertTriangle,
  danger: XCircle,
  orange: AlertTriangle,
  neutral: Info,
}

type CalloutProps = {
  children: ReactNode
  tone?: StatusBadgeTone
  icon?: LucideIcon
  action?: ReactNode
  className?: string
}

/** Alert-style banner for footnotes, notices, and page footers. */
export function Callout({ children, tone = 'info', icon, action, className }: CalloutProps) {
  const Icon = icon ?? defaultIcon[tone]

  return (
    <div
      role="note"
      className={cn(
        'flex flex-col gap-2 rounded-lg border px-3.5 py-3 text-sm ring-1 ring-inset sm:flex-row sm:items-center sm:justify-between',
        statusToneClass[tone],
        className,
      )}
    >
      <div className="flex min-w-0 items-start gap-2.5">
        <Icon className="mt-0.5 size-4 shrink-0 opacity-90" aria-hidden />
        <div className="min-w-0 leading-relaxed">{children}</div>
      </div>
      {action ? <div className="flex shrink-0 items-center gap-2 sm:pl-2">{action}</div> : null}
    </div>
  )
}
