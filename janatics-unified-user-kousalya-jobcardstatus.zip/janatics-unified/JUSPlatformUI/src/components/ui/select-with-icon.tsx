import type { LucideIcon } from 'lucide-react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/utils/cn'

type SelectWithIconProps = {
  icon: LucideIcon
  value?: string
  onValueChange: (value: string) => void
  disabled?: boolean
  placeholder?: string
  className?: string
  children: React.ReactNode
}

export function SelectWithIcon({
  icon: Icon,
  value,
  onValueChange,
  disabled,
  placeholder,
  className,
  children,
}: SelectWithIconProps) {
  return (
    <Select value={value || undefined} onValueChange={onValueChange} disabled={disabled}>
      <div className="relative">
        <Icon
          className="pointer-events-none absolute top-1/2 left-3 z-10 size-4 -translate-y-1/2 text-[var(--cf-text-muted)]"
          strokeWidth={1.75}
          aria-hidden
        />
        <SelectTrigger className={cn('pl-9', className)}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
      </div>
      <SelectContent>{children}</SelectContent>
    </Select>
  )
}

export function SelectWithIconItem({
  value,
  children,
}: {
  value: string
  children: React.ReactNode
}) {
  return <SelectItem value={value}>{children}</SelectItem>
}
