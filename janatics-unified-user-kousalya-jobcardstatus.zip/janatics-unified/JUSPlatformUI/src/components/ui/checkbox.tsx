import * as React from 'react'
import { cn } from '@/utils/cn'

export function Checkbox({
  className,
  checked,
  onCheckedChange,
  id,
  disabled,
  ...props
}: Omit<React.ComponentProps<'input'>, 'type' | 'onChange'> & {
  checked?: boolean
  onCheckedChange?: (checked: boolean) => void
}) {
  return (
    <input
      id={id}
      type="checkbox"
      checked={checked}
      disabled={disabled}
      onChange={(e) => onCheckedChange?.(e.target.checked)}
      className={cn(
        'size-4 shrink-0 rounded border border-[var(--cf-border-strong)] text-[var(--cf-blue)] accent-[var(--cf-blue)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cf-blue)]/20 disabled:cursor-not-allowed disabled:opacity-50',
        className,
      )}
      {...props}
    />
  )
}
