import { CircleHelp } from 'lucide-react'
import type { ReactNode } from 'react'
import {
  Dialog,
  DialogCancelButton,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { cn } from '@/utils/cn'

type InfoHintProps = {
  title: string
  /** One-line preview shown on hover. */
  tooltip: string
  children: ReactNode
  className?: string
}

/** Info icon with a hover tooltip and a click dialog for the full explanation. */
export function InfoHint({ title, tooltip, children, className }: InfoHintProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <button
          type="button"
          className={cn(
            'group relative inline-flex size-4 shrink-0 items-center justify-center rounded-full text-[var(--cf-text-muted)] hover:text-[var(--cf-blue)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cf-blue)]/40',
            className,
          )}
          aria-label={`What ${title} means`}
        >
          <CircleHelp className="size-3.5" aria-hidden />
          <span
            role="tooltip"
            className="pointer-events-none absolute top-[calc(100%+6px)] right-0 z-30 hidden w-52 rounded-md border border-[var(--cf-border)] bg-white px-2.5 py-2 text-left text-[11px] leading-snug font-normal text-[var(--cf-text-secondary)] shadow-md group-hover:block group-focus-visible:block"
          >
            {tooltip}
            <span className="mt-1 block text-[10px] text-[var(--cf-text-muted)]">Click for details</span>
          </span>
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{tooltip}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 text-sm text-[var(--cf-text-secondary)]">{children}</div>
        <DialogFooter>
          <DialogCancelButton>Got it</DialogCancelButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function InfoHintSection({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <div>
      <p className="mb-1 text-xs font-semibold tracking-wide text-[var(--cf-text-primary)] uppercase">{heading}</p>
      <p>{children}</p>
    </div>
  )
}
