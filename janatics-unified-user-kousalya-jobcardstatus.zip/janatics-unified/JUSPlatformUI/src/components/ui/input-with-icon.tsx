import type { LucideIcon } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { cn } from '@/utils/cn'

type InputWithIconProps = React.ComponentProps<'input'> & {
  icon: LucideIcon
  wrapperClassName?: string
}

export function InputWithIcon({ icon: Icon, className, wrapperClassName, ...props }: InputWithIconProps) {
  return (
    <div className={cn('relative', wrapperClassName)}>
      <Icon
        className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-[var(--cf-text-muted)]"
        strokeWidth={1.75}
        aria-hidden
      />
      <Input className={cn('pl-9', className)} {...props} />
    </div>
  )
}
