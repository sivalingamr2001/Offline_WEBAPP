import type { ReactNode } from 'react'
import { cn } from '@/utils/cn'

export type StatusBadgeTone = 'success' | 'neutral' | 'info' | 'warning' | 'danger' | 'orange'

export const statusToneClass: Record<StatusBadgeTone, string> = {
  success: 'bg-emerald-50 text-emerald-700 ring-emerald-200 border-emerald-200',
  neutral: 'bg-muted text-muted-foreground ring-border border-border',
  info: 'bg-blue-50 text-blue-800 ring-blue-200 border-blue-200',
  warning: 'bg-amber-50 text-amber-900 ring-amber-200 border-amber-200',
  danger: 'bg-red-50 text-red-700 ring-red-200 border-red-200',
  orange: 'bg-orange-50 text-orange-800 ring-orange-200 border-orange-200',
}

type StatusBadgeProps = {
  children: ReactNode
  tone?: StatusBadgeTone
  className?: string
}

/** Shared pill badge used for Active/Inactive and other status chips. */
export function StatusBadge({ children, tone = 'neutral', className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset capitalize',
        statusToneClass[tone],
        className,
      )}
    >
      {children}
    </span>
  )
}

type ActiveStatusBadgeProps = {
  active: boolean
  className?: string
  activeLabel?: string
  inactiveLabel?: string
}

export function ActiveStatusBadge({
  active,
  className,
  activeLabel = 'Active',
  inactiveLabel = 'Inactive',
}: ActiveStatusBadgeProps) {
  return (
    <StatusBadge tone={active ? 'success' : 'warning'} className={cn('normal-case', className)}>
      {active ? activeLabel : inactiveLabel}
    </StatusBadge>
  )
}
