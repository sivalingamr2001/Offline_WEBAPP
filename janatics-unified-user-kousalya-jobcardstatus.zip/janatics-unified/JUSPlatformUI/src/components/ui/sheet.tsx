import type { ComponentProps } from 'react'
import * as DialogPrimitive from '@radix-ui/react-dialog'
import { cn } from '@/utils/cn'

export const Sheet = DialogPrimitive.Root
export const SheetTrigger = DialogPrimitive.Trigger
export const SheetClose = DialogPrimitive.Close
export const SheetPortal = DialogPrimitive.Portal
export const SheetTitle = DialogPrimitive.Title
export const SheetDescription = DialogPrimitive.Description

export function SheetContent({ className, children, ...props }: ComponentProps<typeof DialogPrimitive.Content>) {
  return (
    <SheetPortal>
      <DialogPrimitive.Content
        onInteractOutside={(event) => event.preventDefault()}
        className={cn(
          'fixed top-12 right-0 bottom-0 z-20 flex w-full max-w-[26.5rem] flex-col outline-none',
          'border-l border-[var(--cf-border)] bg-[var(--cf-page)] shadow-[-8px_0_24px_rgba(17,24,39,0.06)]',
          'transition-transform duration-300 ease-out data-[state=closed]:translate-x-full data-[state=open]:translate-x-0',
          className,
        )}
        {...props}
      >
        {children}
      </DialogPrimitive.Content>
    </SheetPortal>
  )
}
