import { Eye, EyeOff, KeyRound } from 'lucide-react'
import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { cn } from '@/utils/cn'

type PasswordInputProps = Omit<React.ComponentProps<'input'>, 'type'>

export function PasswordInput({ className, ...props }: PasswordInputProps) {
  const [visible, setVisible] = useState(false)

  return (
    <div className="relative">
      <KeyRound
        className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-[var(--cf-text-muted)]"
        strokeWidth={1.75}
        aria-hidden
      />
      <Input
        type={visible ? 'text' : 'password'}
        className={cn('pr-10 pl-9', className)}
        {...props}
      />
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="absolute top-0 right-0 size-9 text-[var(--cf-text-muted)] hover:text-foreground"
        onClick={() => setVisible((v) => !v)}
        aria-label={visible ? 'Hide password' : 'Show password'}
      >
        {visible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
      </Button>
    </div>
  )
}
