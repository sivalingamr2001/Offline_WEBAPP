import { useQuery } from '@tanstack/react-query'
import { Check, Lock, X } from 'lucide-react'
import { useMemo, useState } from 'react'
import { getCurrentOrganization } from '@/api/organizations'
import { AskAiChat } from '@/components/ai/AskAiChat'
import { Button } from '@/components/ui/button'
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetTitle } from '@/components/ui/sheet'
import { brand } from '@/constants/brand'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'
import { cn } from '@/utils/cn'

const CONNECTED_KEY = 'jusplatform.askai.connected'

type Step = 'connect' | 'permissions' | 'ready'

type WorkspaceChoice = {
  id: string
  name: string
  detail: string
  current: boolean
}

const modelPermissions = [
  {
    id: 'read',
    label: 'Read operational data',
    detail: 'Organizations, users, roles, jobs, and Portfolio alerts',
    granted: true,
    locked: true,
  },
  {
    id: 'summarize',
    label: 'Summarize and recommend',
    detail: 'Draft insights from Portfolio and Account home',
    granted: true,
    locked: false,
  },
  {
    id: 'write',
    label: 'Change records',
    detail: 'Create or update users, roles, and organization records',
    granted: false,
    locked: true,
  },
] as const

function loadConnected() {
  try {
    return sessionStorage.getItem(CONNECTED_KEY) === '1'
  } catch {
    return false
  }
}

function persistConnected(value: boolean) {
  try {
    if (value) sessionStorage.setItem(CONNECTED_KEY, '1')
    else sessionStorage.removeItem(CONNECTED_KEY)
  } catch {
    /* ignore quota / private mode */
  }
}

function CloudMark() {
  return (
    <div className="relative mx-auto h-24 w-40" aria-hidden>
      <span className="absolute top-6 left-3 size-14 rounded-full bg-blue-200/90" />
      <span className="absolute top-3 left-[2.75rem] size-[4.5rem] rounded-full bg-[var(--cf-blue)]/80" />
      <span className="absolute top-8 left-6 size-12 rounded-full bg-indigo-300/80" />
      <span className="absolute top-4 right-2 size-12 rounded-full bg-[var(--brand-cover-deep)]/70" />
      <span className="absolute top-12 right-8 size-9 rounded-full bg-violet-300/90" />
    </div>
  )
}

function Toggle({
  checked,
  onCheckedChange,
  labelledBy,
}: {
  checked: boolean
  onCheckedChange: (next: boolean) => void
  labelledBy: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-labelledby={labelledBy}
      onClick={() => onCheckedChange(!checked)}
      className={cn(
        'relative h-6 w-11 shrink-0 rounded-full transition-colors',
        checked ? 'bg-[var(--cf-blue)]' : 'bg-[var(--cf-border-strong)]',
      )}
    >
      <span
        className={cn(
          'absolute top-0.5 left-0.5 size-5 rounded-full bg-white shadow-sm transition-transform',
          checked && 'translate-x-5',
        )}
      />
    </button>
  )
}

export function AskAiSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const { session } = useAuth()
  const { isSuperAdmin } = usePermissions()
  const [step, setStep] = useState<Step>(() => (loadConnected() ? 'ready' : 'connect'))
  const [grantAll, setGrantAll] = useState(false)
  const [pickedIds, setPickedIds] = useState<string[] | null>(null)

  const { data: org } = useQuery({
    queryKey: ['organization', 'me'],
    queryFn: getCurrentOrganization,
    enabled: open && !isSuperAdmin,
  })

  const workspaces = useMemo<WorkspaceChoice[]>(() => {
    const current: WorkspaceChoice = {
      id: org?.id ?? 'workspace-current',
      name: org?.name ?? (session?.email ? `${session.email}'s workspace` : 'Current workspace'),
      detail: org ? `${org.code} · ${org.id}` : 'Active organization for this session',
      current: true,
    }
    return [
      current,
      {
        id: 'workspace-sandbox',
        name: 'Sandbox',
        detail: 'demo-sandbox · read-only sample data',
        current: false,
      },
    ]
  }, [org, session?.email])

  const selected = useMemo(() => {
    const ids = workspaces.map((w) => w.id)
    const current = workspaces.find((w) => w.current)?.id ?? ids[0]!
    if (grantAll) return ids
    if (pickedIds == null) return [current]
    const mapped = pickedIds
      .map((id) => (id === 'workspace-current' ? current : id))
      .filter((id) => ids.includes(id))
    const unique = [...new Set(mapped)]
    return unique.length > 0 ? unique : [current]
  }, [grantAll, pickedIds, workspaces])

  function toggleWorkspace(id: string) {
    if (grantAll) return
    setPickedIds((prev) => {
      const base = prev ?? selected
      if (base.includes(id)) {
        if (base.length === 1) return base
        return base.filter((item) => item !== id)
      }
      return [...base, id]
    })
  }

  function approveConnection() {
    persistConnected(true)
    setStep('ready')
  }

  function disconnect() {
    persistConnected(false)
    setStep('connect')
    setGrantAll(false)
    setPickedIds(null)
  }

  const selectedCount = selected.length

  return (
    <Sheet open={open} onOpenChange={onOpenChange} modal={false}>
      <SheetContent aria-describedby="ask-ai-desc">
        <div className="relative flex h-full min-h-0 flex-col">
          <SheetClose
            className="absolute top-3 right-3 z-10 rounded-md p-1.5 text-[var(--cf-text-muted)] hover:bg-[var(--cf-surface-hover)] hover:text-[var(--cf-text-primary)]"
            aria-label="Close"
          >
            <X className="size-5" strokeWidth={1.75} />
          </SheetClose>

          {step === 'ready' ? (
            <AskAiChat onDisconnect={disconnect} />
          ) : (
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 py-8 lg:px-5">
              <div className="my-auto w-full overflow-hidden rounded-lg border border-[var(--cf-border)] bg-white p-6 shadow-sm">
                <CloudMark />

                {step === 'connect' ? (
                  <>
                    <SheetTitle className="mt-1 text-center text-lg font-semibold tracking-tight text-[var(--cf-text-primary)]">
                      Enable {brand.aiName} access
                    </SheetTitle>
                    <SheetDescription
                      id="ask-ai-desc"
                      className="mt-2 text-center text-sm leading-relaxed text-[var(--cf-text-muted)]"
                    >
                      A model connection will be created so {brand.aiName} can work with data in your selected
                      workspace.
                    </SheetDescription>

                    <div className="mt-6 flex items-center justify-between gap-4 rounded-md border border-[var(--cf-border)] px-4 py-3">
                      <div>
                        <p id="grant-all-label" className="text-sm font-medium text-[var(--cf-text-primary)]">
                          Grant access to all workspaces
                        </p>
                        <p className="mt-0.5 text-xs text-[var(--cf-text-muted)]">
                          Includes any workspaces added in the future.
                        </p>
                      </div>
                      <Toggle checked={grantAll} onCheckedChange={setGrantAll} labelledBy="grant-all-label" />
                    </div>

                    <div className="mt-5 flex items-center justify-between text-sm">
                      <span className="font-medium text-[var(--cf-text-primary)]">Select workspace(s)</span>
                      <span className="text-[var(--cf-text-muted)]">{selectedCount} selected</span>
                    </div>

                    <ul className="mt-2 space-y-2">
                      {workspaces.map((workspace) => {
                        const checked = selected.includes(workspace.id)
                        return (
                          <li key={workspace.id}>
                            <button
                              type="button"
                              onClick={() => toggleWorkspace(workspace.id)}
                              className={cn(
                                'flex w-full items-start gap-3 rounded-md border px-3 py-3 text-left transition-colors',
                                checked
                                  ? 'border-[var(--cf-blue)] bg-blue-50/70'
                                  : 'border-[var(--cf-border)] bg-white hover:bg-[var(--cf-surface-hover)]',
                              )}
                            >
                              <span
                                className={cn(
                                  'mt-0.5 flex size-4 shrink-0 items-center justify-center rounded border',
                                  checked
                                    ? 'border-[var(--cf-blue)] bg-[var(--cf-blue)] text-white'
                                    : 'border-[var(--cf-border-strong)] bg-white',
                                )}
                              >
                                {checked ? <Check className="size-3" strokeWidth={3} /> : null}
                              </span>
                              <span className="min-w-0 flex-1">
                                <span className="flex items-center gap-2">
                                  <span className="truncate text-sm font-medium text-[var(--cf-text-primary)]">
                                    {workspace.name}
                                  </span>
                                  {workspace.current ? (
                                    <span className="rounded-full bg-[var(--cf-surface-hover)] px-2 py-0.5 text-[10px] font-medium text-[var(--cf-text-secondary)]">
                                      Current
                                    </span>
                                  ) : null}
                                </span>
                                <span className="mt-0.5 block truncate font-mono text-[11px] text-[var(--cf-text-muted)]">
                                  {workspace.detail}
                                </span>
                              </span>
                            </button>
                          </li>
                        )
                      })}
                    </ul>

                    <p className="mt-3 text-xs text-[var(--cf-text-muted)]">At least one workspace must be selected.</p>

                    <Button
                      type="button"
                      className="mt-5 h-10 w-full"
                      disabled={selectedCount === 0}
                      onClick={() => setStep('permissions')}
                    >
                      Review permissions
                    </Button>
                  </>
                ) : null}

                {step === 'permissions' ? (
                  <>
                    <SheetTitle className="mt-1 text-center text-lg font-semibold tracking-tight text-[var(--cf-text-primary)]">
                      Review permissions
                    </SheetTitle>
                    <SheetDescription
                      id="ask-ai-desc"
                      className="mt-2 text-center text-sm leading-relaxed text-[var(--cf-text-muted)]"
                    >
                      Approve what {brand.aiName} may do in {selectedCount} workspace
                      {selectedCount === 1 ? '' : 's'}. This preview does not create a live token.
                    </SheetDescription>

                    <ul className="mt-6 divide-y divide-[var(--cf-border)] rounded-md border border-[var(--cf-border)]">
                      {modelPermissions.map((item) => (
                        <li key={item.id} className="flex gap-3 px-4 py-3">
                          <span
                            className={cn(
                              'mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full',
                              item.granted
                                ? 'bg-blue-50 text-[var(--cf-blue)]'
                                : 'bg-[var(--cf-surface-hover)] text-[var(--cf-text-muted)]',
                            )}
                          >
                            {item.granted ? (
                              <Check className="size-3" strokeWidth={2.5} />
                            ) : (
                              <Lock className="size-3" />
                            )}
                          </span>
                          <span>
                            <span className="flex items-center gap-2 text-sm font-medium text-[var(--cf-text-primary)]">
                              {item.label}
                              {item.locked ? (
                                <span className="text-[10px] font-normal uppercase tracking-wide text-[var(--cf-text-muted)]">
                                  {item.granted ? 'Required' : 'Denied'}
                                </span>
                              ) : null}
                            </span>
                            <span className="mt-0.5 block text-xs leading-relaxed text-[var(--cf-text-muted)]">
                              {item.detail}
                            </span>
                          </span>
                        </li>
                      ))}
                    </ul>

                    <div className="mt-5 grid grid-cols-2 gap-2">
                      <Button type="button" variant="outline" className="h-10" onClick={() => setStep('connect')}>
                        Back
                      </Button>
                      <Button type="button" className="h-10" onClick={approveConnection}>
                        Approve access
                      </Button>
                    </div>
                  </>
                ) : null}
              </div>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}
