import { ArrowUp, ExternalLink, FileText, Sparkles } from 'lucide-react'
import { type FormEvent, type KeyboardEvent, useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { SheetDescription, SheetTitle } from '@/components/ui/sheet'
import { brand } from '@/constants/brand'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'

type Citation = {
  id: string
  n: number
  label: string
  source: string
  to: string
}

type MessageStatus = 'thinking' | 'streaming' | 'done'

type ChatMessage = {
  id: string
  role: 'user' | 'assistant'
  text: string
  citations?: Citation[]
  link?: { label: string; to: string }
  status?: MessageStatus
}

type BotReply = {
  text: string
  citations?: Citation[]
  link?: { label: string; to: string }
  thinkMs?: number
}

const starters = [
  'What is on the Portfolio watchlist?',
  'Who can manage users in this org?',
  'Show organization settings',
] as const

const thinkingLabels = ['Thinking', 'Searching records', 'Reading workspace'] as const

const starterReplies: Record<string, BotReply> = {
  'What is on the Portfolio watchlist?': {
    text: 'Runner FG is below the OCQ threshold at AMS1 [1]. Delivery for FG-3 slipped this week [2]. Open Portfolio alerts for the full list.',
    citations: [
      { id: 'c1', n: 1, label: 'OCQ threshold', source: 'Portfolio', to: routes.portfolioAlerts },
      { id: 'c2', n: 2, label: 'FG-3 delivery', source: 'Portfolio', to: routes.portfolioPerformance },
    ],
  },
  'Who can manage users in this org?': {
    text: 'Organization Admins can create and update users [1]. Role assignments are managed under Roles [2].',
    citations: [
      { id: 'c3', n: 1, label: 'Users', source: 'Users', to: routes.users },
      { id: 'c4', n: 2, label: 'Roles', source: 'Roles', to: routes.roles },
    ],
  },
  'Show organization settings': {
    text: 'Account and workspace preferences live in Settings [1]. Portfolio settings are in the Portfolio module [2].',
    citations: [
      { id: 'c5', n: 1, label: 'Settings', source: 'Settings', to: routes.settings },
      { id: 'c6', n: 2, label: 'Portfolio settings', source: 'Portfolio', to: routes.portfolioSettings },
    ],
  },
}

const fallbackReply: BotReply = {
  text: 'I can help with Portfolio, users, roles, and organization settings. Try a starter below.',
}

function pick<T>(items: readonly T[]): T {
  return items[Math.floor(Math.random() * items.length)]!
}

function normalize(text: string) {
  return text.trim().toLowerCase().replace(/[.!?]+$/g, '').replace(/\s+/g, ' ')
}

function isAffirmative(q: string) {
  return /^(ok|okay|k|yes|yep|yeah|sure|got it|alright|all right|cool|thanks|thank you|thx|ok thanks)$/i.test(q)
}

function isGoodbye(q: string) {
  return /^(bye|goodbye|good bye|see you|see ya|cya|later|take care|that'?s all|ok bye|okay bye|bye bye)$/i.test(q)
}

function isLooksGood(q: string) {
  return /looks good( to me)?|lgtm|looks great|sounds good|that works|all good|perfect|great job/i.test(q)
}

function isGibberish(q: string) {
  const tokens = q.split(/[\s,./]+/).filter(Boolean)
  const mash =
    /^(abcd+|qwerty|asdf+|zxcvbnm?|qwe+|asd+|hjkl|aeiou|lorem|ipsum|blah|foo|bar|baz|xxx+|yyy+|zzz+|test|testing|123+|aaa+|abc)$/i
  if (tokens.length > 0 && tokens.every((t) => mash.test(t))) return true
  return tokens.length <= 2 && tokens.every((w) => w.length >= 4 && !/[aeiou]/i.test(w) && /[a-z]/i.test(w))
}

function replyFor(raw: string): BotReply {
  const starterKey = Object.keys(starterReplies).find((key) => normalize(key) === normalize(raw))
  if (starterKey) return starterReplies[starterKey]!

  const q = normalize(raw)

  if (isGibberish(q)) {
    return {
      thinkMs: 700,
      text: "Sorry, I'm not able to understand that. Try a workspace question — Portfolio alerts, users, or roles.",
    }
  }
  if (isGoodbye(q)) {
    return {
      thinkMs: 650,
      text: pick([
        "Thanks for stopping by. I'll be here when you need the workspace again — take care, and come back anytime.",
        "Appreciate the time. Come back whenever you want a read on Portfolio or users. Goodbye for now.",
        "Thank you. I'll be right here in JUSPlatform when you return. See you soon.",
      ]),
    }
  }
  if (isLooksGood(q)) {
    return {
      thinkMs: 700,
      text: pick([
        "Glad that landed well. Let's try another question — Portfolio, users, or roles whenever you're ready.",
        "Perfect. Ask something new and I'll look it up in the workspace.",
        "Great — that checks out. When you're ready, try another question and I'll pull the records.",
      ]),
    }
  }
  if (isAffirmative(q)) {
    return {
      thinkMs: 550,
      text: pick([
        "Okay — I'm with you. What should we look at next?",
        "Got it. Happy to keep going. Ask me about Portfolio, users, or roles whenever you're ready.",
        "Yes, noted. Tell me what you'd like to check in the workspace.",
      ]),
    }
  }

  return fallbackReply
}

function nextChunk(full: string, index: number) {
  const ch = full[index]
  if (!ch) return { end: index, delay: 0 }
  if (/[.!?]/.test(ch)) return { end: index + 1, delay: 150 }
  if (/[,;:]/.test(ch)) return { end: index + 1, delay: 80 }
  if (ch === ' ') return { end: index + 1, delay: 20 }
  let end = index + 1
  while (end < full.length && end - index < 3 && /[A-Za-z0-9]/.test(full[end]!)) end += 1
  return { end, delay: 14 + Math.random() * 16 }
}

function renderTextWithCitations(text: string) {
  const parts = text.split(/(\[\d+\])/g)
  return parts.map((part, index) => {
    const cite = part.match(/^\[(\d+)\]$/)
    if (!cite) return <span key={index}>{part}</span>
    return (
      <sup
        key={index}
        className="ml-0.5 inline-flex size-4 translate-y-[-1px] items-center justify-center rounded-sm bg-blue-50 align-middle text-[10px] font-semibold text-[var(--cf-blue)]"
      >
        {cite[1]}
      </sup>
    )
  })
}

function ThinkingDots() {
  return (
    <span className="inline-flex items-center gap-1" aria-hidden>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="size-1.5 rounded-full bg-[var(--cf-text-muted)]"
          style={{ animation: 'ask-ai-dot 1s ease-in-out infinite', animationDelay: `${i * 160}ms` }}
        />
      ))}
    </span>
  )
}

function ThinkingBubble() {
  const [labelIndex, setLabelIndex] = useState(0)

  useEffect(() => {
    const timer = window.setInterval(() => {
      setLabelIndex((i) => (i + 1) % thinkingLabels.length)
    }, 850)
    return () => window.clearInterval(timer)
  }, [])

  return (
    <div className="flex justify-start">
      <div className="rounded-2xl rounded-bl-md border border-[var(--cf-border)] bg-white px-3.5 py-2.5 shadow-sm">
        <div className="flex items-center gap-2 text-[13px] text-[var(--cf-text-muted)]">
          <ThinkingDots />
          <span className="font-medium">{thinkingLabels[labelIndex]}</span>
        </div>
      </div>
    </div>
  )
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user'
  const streaming = message.status === 'streaming'

  return (
    <div className={cn('flex', isUser ? 'justify-end' : 'justify-start')}>
      <div className={cn('max-w-[92%] space-y-1.5', isUser ? 'items-end' : 'items-start')}>
        <div
          className={cn(
            'rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed',
            isUser
              ? 'rounded-br-md bg-[var(--cf-blue)] text-white'
              : 'rounded-bl-md border border-[var(--cf-border)] bg-white text-[var(--cf-text-primary)] shadow-sm',
          )}
        >
          {isUser ? (
            message.text
          ) : (
            <>
              {renderTextWithCitations(message.text)}
              {streaming ? (
                <span
                  className="ml-0.5 inline-block h-[13px] w-[2px] translate-y-0.5 bg-[var(--cf-blue)] align-text-bottom"
                  style={{ animation: 'ask-ai-caret 0.9s steps(1) infinite' }}
                  aria-hidden
                />
              ) : null}
            </>
          )}
        </div>
        {message.status === 'done' && message.citations && message.citations.length > 0 ? (
          <div className="flex flex-wrap gap-1.5 px-0.5">
            {message.citations.map((citation) => (
              <Link
                key={citation.id}
                to={citation.to}
                className="inline-flex max-w-full items-center gap-1 rounded-md border border-[var(--cf-border)] bg-white px-1.5 py-1 text-[11px] text-[var(--cf-text-secondary)] shadow-sm hover:border-[var(--cf-blue)] hover:text-[var(--cf-blue)]"
              >
                <span className="flex size-4 shrink-0 items-center justify-center rounded-sm bg-blue-50 font-mono text-[10px] font-semibold text-[var(--cf-blue)]">
                  {citation.n}
                </span>
                <FileText className="size-3 shrink-0 opacity-70" aria-hidden />
                <span className="truncate font-medium">{citation.label}</span>
                <span className="truncate text-[var(--cf-text-muted)]">{citation.source}</span>
              </Link>
            ))}
          </div>
        ) : null}
        {message.status === 'done' && message.link ? (
          <Link
            to={message.link.to}
            className="inline-flex items-center gap-1 px-0.5 text-[12px] font-medium text-[var(--cf-blue)] hover:underline"
          >
            {message.link.label}
            <ExternalLink className="size-3" aria-hidden />
          </Link>
        ) : null}
      </div>
    </div>
  )
}

function StarterPrompts({ disabled, onPick }: { disabled: boolean; onPick: (text: string) => void }) {
  return (
    <div className="flex h-full flex-col justify-end gap-3">
      <div>
        <p className="text-sm font-medium text-[var(--cf-text-primary)]">Start a conversation</p>
        <p className="mt-1 text-xs leading-relaxed text-[var(--cf-text-muted)]">
          Pick a suggestion, or type your own message below.
        </p>
      </div>
      <div className="flex flex-col gap-2">
        {starters.map((prompt) => (
          <button
            key={prompt}
            type="button"
            disabled={disabled}
            onClick={() => onPick(prompt)}
            className="rounded-lg border border-[var(--cf-border)] bg-white px-3 py-2.5 text-left text-[13px] text-[var(--cf-text-primary)] shadow-sm hover:border-[var(--cf-blue)] hover:bg-blue-50/50 disabled:opacity-50"
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  )
}

export function AskAiChat({ onDisconnect }: { onDisconnect: () => void }) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [draft, setDraft] = useState('')
  const [busy, setBusy] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)
  const timersRef = useRef<number[]>([])

  function clearTimers() {
    timersRef.current.forEach((id) => window.clearTimeout(id))
    timersRef.current = []
  }

  function later(ms: number, fn: () => void) {
    const id = window.setTimeout(fn, ms)
    timersRef.current.push(id)
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' })
    })
  }

  useEffect(() => () => clearTimers(), [])

  function send(text: string) {
    const q = text.trim()
    if (!q || busy) return

    const canned = replyFor(q)
    const userId = `u-${Date.now()}`
    const assistantId = `a-${Date.now()}`
    const thinkMs = canned.thinkMs ?? 1100 + Math.random() * 700

    setBusy(true)
    setDraft('')
    clearTimers()
    setMessages((prev) => [
      ...prev,
      { id: userId, role: 'user', text: q },
      { id: assistantId, role: 'assistant', text: '', status: 'thinking' },
    ])
    scrollToBottom()

    later(thinkMs, () => {
      setMessages((prev) =>
        prev.map((message) =>
          message.id === assistantId ? { ...message, status: 'streaming' } : message,
        ),
      )
      scrollToBottom()

      const stream = (index: number) => {
        if (index >= canned.text.length) {
          later(180, () => {
            setMessages((prev) =>
              prev.map((message) =>
                message.id === assistantId
                  ? { ...message, text: canned.text, status: 'done', citations: canned.citations, link: canned.link }
                  : message,
              ),
            )
            setBusy(false)
            scrollToBottom()
          })
          return
        }
        const { end, delay } = nextChunk(canned.text, index)
        setMessages((prev) =>
          prev.map((message) =>
            message.id === assistantId ? { ...message, text: canned.text.slice(0, end) } : message,
          ),
        )
        scrollToBottom()
        later(delay, () => stream(end))
      }

      stream(0)
    })
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    send(draft)
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send(draft)
    }
  }

  const last = messages[messages.length - 1]
  const showThinking = last?.role === 'assistant' && last.status === 'thinking'
  const visibleMessages = showThinking ? messages.slice(0, -1) : messages

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex shrink-0 items-start gap-3 border-b border-[var(--cf-border)] bg-white px-4 py-3 pr-12">
        <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-[var(--cf-blue)] text-white shadow-sm">
          <Sparkles className="size-4" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <SheetTitle className="text-sm font-semibold tracking-tight text-[var(--cf-text-primary)]">
            {brand.aiName} is connected
          </SheetTitle>
          <SheetDescription id="ask-ai-desc" className="mt-0.5 text-xs text-[var(--cf-text-muted)]">
            Ask about this workspace · sources attach when I reply
          </SheetDescription>
        </div>
        <button
          type="button"
          onClick={onDisconnect}
          className="shrink-0 text-xs text-[var(--cf-text-muted)] hover:text-[var(--cf-text-secondary)]"
        >
          Disconnect
        </button>
      </header>

      <div ref={listRef} className="min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-4">
        {messages.length === 0 ? (
          <StarterPrompts disabled={busy} onPick={send} />
        ) : (
          <>
            {visibleMessages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            {showThinking ? <ThinkingBubble /> : null}
          </>
        )}
      </div>

      <form onSubmit={onSubmit} className="shrink-0 border-t border-[var(--cf-border)] bg-white p-3">
        <label className="sr-only" htmlFor="ask-ai-draft">
          Ask {brand.aiName}
        </label>
        <div className="flex items-end gap-2 rounded-lg border border-[var(--cf-border)] bg-[var(--cf-page)] p-2 focus-within:border-[var(--cf-blue)] focus-within:ring-2 focus-within:ring-[var(--cf-blue)]/20">
          <textarea
            id="ask-ai-draft"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            rows={2}
            disabled={busy}
            placeholder={busy ? 'Waiting for a reply…' : 'Ask about Portfolio, users, or roles…'}
            className="min-h-[2.5rem] flex-1 resize-none bg-transparent px-1 py-1.5 text-sm outline-none placeholder:text-[var(--cf-text-muted)] disabled:opacity-70"
          />
          <Button type="submit" size="icon" className="size-8 shrink-0" disabled={busy || !draft.trim()} aria-label="Send">
            <ArrowUp className="size-4" />
          </Button>
        </div>
        <p className="mt-1.5 px-0.5 text-[11px] text-[var(--cf-text-muted)]">Enter to send · Shift+Enter for a new line</p>
      </form>
    </div>
  )
}
