import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { FileText, Loader2, Pencil, Shield } from 'lucide-react'
import { type FormEvent, useEffect, useState } from 'react'
import { listAppMenus } from '@/api/appCatalog'
import { getRoles } from '@/api/generated/roles/roles'
import type { RoleDto } from '@/api/generated/models/roleDto'
import { MenuAccessPicker, type MenuAccessValue } from '@/components/roles/MenuAccessPicker'
import { PermissionPicker } from '@/components/roles/PermissionPicker'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { roleTypeLabel } from '@/constants/roles'
import { getApiErrorMessage } from '@/utils/apiError'

const { updateRole, listPermissions } = getRoles()

type EditRoleDialogProps = {
  role: RoleDto | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function EditRoleDialog({ role, open, onOpenChange }: EditRoleDialogProps) {
  const queryClient = useQueryClient()
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [permissionCodes, setPermissionCodes] = useState<string[]>([])
  const [menus, setMenus] = useState<MenuAccessValue[]>([])
  const [error, setError] = useState<string | null>(null)

  const permissionsQuery = useQuery({
    queryKey: ['permissions'],
    queryFn: () => listPermissions({ page: 1, pageSize: 200 }),
    enabled: open,
  })

  const menusQuery = useQuery({
    queryKey: ['app-menus', 'role-picker'],
    queryFn: () => listAppMenus({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  useEffect(() => {
    if (role && open) {
      setName(role.name)
      setDescription(role.description ?? '')
      setPermissionCodes(role.permissions)
      setMenus(role.menus ?? [])
      setError(null)
    }
  }, [role, open])

  const updateMutation = useMutation({
    mutationFn: () =>
      updateRole(role!.id, {
        name: name.trim(),
        description: description.trim() || null,
        permissionCodes,
        menus,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['roles'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!role) return
    setError(null)
    updateMutation.mutate()
  }

  if (!role) return null

  const permissions = permissionsQuery.data?.items ?? []
  const nameLocked = role.isSystem

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pencil className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Edit role
          </DialogTitle>
          <DialogDescription>
            Update permissions and menus for the <strong>{roleTypeLabel(role.isSystem)}</strong> role{' '}
            <strong>{role.name}</strong>.
          </DialogDescription>
        </DialogHeader>

        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="edit-role-name">Role name</Label>
            <InputWithIcon
              id="edit-role-name"
              icon={Shield}
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={nameLocked}
              required
            />
            {nameLocked ? (
              <p className="text-xs text-[var(--cf-text-muted)]">System role names cannot be changed.</p>
            ) : null}
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-role-description">Description</Label>
            <InputWithIcon
              id="edit-role-description"
              icon={FileText}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional summary"
            />
          </div>
          <div className="space-y-2">
            <Label>Permissions</Label>
            {permissionsQuery.isLoading ? (
              <div className="flex items-center gap-2 text-sm text-[var(--cf-text-muted)]">
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Loading permissions…
              </div>
            ) : (
              <PermissionPicker
                permissions={permissions}
                selected={permissionCodes}
                onChange={setPermissionCodes}
              />
            )}
          </div>
          <div className="space-y-2">
            <Label>Menus</Label>
            {menusQuery.isLoading ? (
              <div className="flex items-center gap-2 text-sm text-[var(--cf-text-muted)]">
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Loading menus…
              </div>
            ) : (
              <MenuAccessPicker menus={menusQuery.data?.items ?? []} selected={menus} onChange={setMenus} />
            )}
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={updateMutation.isPending || permissionsQuery.isLoading}>
              {updateMutation.isPending ? 'Saving…' : 'Save role'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
