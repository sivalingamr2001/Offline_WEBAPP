import type { AppMenuDto } from '@/api/appCatalog'
import { cn } from '@/utils/cn'

export type MenuAccessValue = {
  menuId: string
  canCreate: boolean
  canRead: boolean
  canUpdate: boolean
  canDelete: boolean
}

type MenuAccessPickerProps = {
  menus: AppMenuDto[]
  selected: MenuAccessValue[]
  onChange: (next: MenuAccessValue[]) => void
  disabled?: boolean
}

function upsert(selected: MenuAccessValue[], menuId: string, patch: Partial<MenuAccessValue>): MenuAccessValue[] {
  const current = selected.find((item) => item.menuId === menuId)
  const next: MenuAccessValue = {
    menuId,
    canCreate: false,
    canRead: true,
    canUpdate: false,
    canDelete: false,
    ...current,
    ...patch,
  }
  const visible = next.canCreate || next.canRead || next.canUpdate || next.canDelete
  const without = selected.filter((item) => item.menuId !== menuId)
  return visible ? [...without, next] : without
}

export function MenuAccessPicker({ menus, selected, onChange, disabled }: MenuAccessPickerProps) {
  const grouped = new Map<string, AppMenuDto[]>()
  for (const menu of menus) {
    const list = grouped.get(menu.moduleName) ?? []
    list.push(menu)
    grouped.set(menu.moduleName, list)
  }

  if (menus.length === 0) {
    return <p className="text-sm text-[var(--cf-text-muted)]">No menus available.</p>
  }

  return (
    <div className="max-h-72 space-y-3 overflow-y-auto rounded-md border border-[var(--cf-border)] p-3">
      {[...grouped.entries()].map(([module, items]) => (
        <div key={module}>
          <p className="mb-2 text-xs font-semibold tracking-wide text-[var(--cf-text-muted)] uppercase">{module}</p>
          <div className="space-y-2">
            {items.map((menu) => {
              const access = selected.find((item) => item.menuId === menu.id)
              const checked = Boolean(access)
              return (
                <div key={menu.id} className="rounded-md px-2 py-1.5 hover:bg-[var(--cf-surface-hover)]">
                  <label className={cn('flex items-start gap-2 text-sm', disabled && 'cursor-not-allowed opacity-60')}>
                    <input
                      type="checkbox"
                      className="mt-0.5 size-4 rounded border-[var(--cf-border)]"
                      checked={checked}
                      disabled={disabled}
                      onChange={() =>
                        onChange(
                          upsert(selected, menu.id, {
                            canRead: !checked,
                            canCreate: false,
                            canUpdate: false,
                            canDelete: false,
                          }),
                        )
                      }
                    />
                    <span>
                      <span className="font-medium text-[var(--cf-text-primary)]">{menu.name}</span>
                      <span className="mt-0.5 block font-mono text-xs text-[var(--cf-text-muted)]">
                        {menu.path ?? menu.code}
                      </span>
                    </span>
                  </label>
                  {checked ? (
                    <div className="mt-1 ml-6 flex flex-wrap gap-3 text-xs text-[var(--cf-text-secondary)]">
                      {(
                        [
                          ['canRead', 'Read'],
                          ['canCreate', 'Create'],
                          ['canUpdate', 'Update'],
                          ['canDelete', 'Delete'],
                        ] as const
                      ).map(([key, label]) => (
                        <label key={key} className="flex items-center gap-1">
                          <input
                            type="checkbox"
                            className="size-3.5 rounded border-[var(--cf-border)]"
                            checked={Boolean(access?.[key])}
                            disabled={disabled}
                            onChange={() => onChange(upsert(selected, menu.id, { [key]: !access?.[key] }))}
                          />
                          {label}
                        </label>
                      ))}
                    </div>
                  ) : null}
                </div>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}
