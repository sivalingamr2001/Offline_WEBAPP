import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { FileText, Loader2, ShieldPlus } from 'lucide-react'
import { type FormEvent, useEffect, useState } from 'react'
import { listAppMenus } from '@/api/appCatalog'
import { getRoles } from '@/api/generated/roles/roles'
import { MenuAccessPicker, type MenuAccessValue } from '@/components/roles/MenuAccessPicker'
import { PermissionPicker } from '@/components/roles/PermissionPicker'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { getApiErrorMessage } from '@/utils/apiError'

const { createRole, listPermissions } = getRoles()

type CreateRoleDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CreateRoleDialog({ open, onOpenChange }: CreateRoleDialogProps) {
  const queryClient = useQueryClient()
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [permissionCodes, setPermissionCodes] = useState<string[]>([])
  const [menus, setMenus] = useState<MenuAccessValue[]>([])
  const [error, setError] = useState<string | null>(null)

  const permissionsQuery = useQuery({
    queryKey: ['permissions'],
    queryFn: () => listPermissions({ page: 1, pageSize: 200 }),
    enabled: open,
  })

  const menusQuery = useQuery({
    queryKey: ['app-menus', 'role-picker'],
    queryFn: () => listAppMenus({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  useEffect(() => {
    if (!open) {
      setName('')
      setDescription('')
      setPermissionCodes([])
      setMenus([])
      setError(null)
    }
  }, [open])

  const createMutation = useMutation({
    mutationFn: createRole,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['roles'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    createMutation.mutate({
      name: name.trim(),
      description: description.trim() || null,
      permissionCodes,
      ...(menus.length > 0 ? { menus } : {}),
    })
  }

  const permissions = permissionsQuery.data?.items ?? []

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldPlus className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Create role
          </DialogTitle>
          <DialogDescription>
            Define a custom role, then assign permissions and the modules/menus that role can open.
          </DialogDescription>
        </DialogHeader>

        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="create-role-name">Role name</Label>
            <InputWithIcon
              id="create-role-name"
              icon={ShieldPlus}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Warehouse Clerk"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-role-description">Description</Label>
            <InputWithIcon
              id="create-role-description"
              icon={FileText}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional summary"
            />
          </div>
          <div className="space-y-2">
            <Label>Permissions</Label>
            {permissionsQuery.isLoading ? (
              <div className="flex items-center gap-2 text-sm text-[var(--cf-text-muted)]">
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Loading permissions…
              </div>
            ) : (
              <PermissionPicker
                permissions={permissions}
                selected={permissionCodes}
                onChange={setPermissionCodes}
              />
            )}
          </div>
          <div className="space-y-2">
            <Label>Menus</Label>
            {menusQuery.isLoading ? (
              <div className="flex items-center gap-2 text-sm text-[var(--cf-text-muted)]">
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Loading menus…
              </div>
            ) : (
              <MenuAccessPicker
                menus={menusQuery.data?.items ?? []}
                selected={menus}
                onChange={(next) => {
                  setMenus(next)
                  const catalog = menusQuery.data?.items ?? []
                  const extra = catalog
                    .filter((menu) => next.some((item) => item.menuId === menu.id) && menu.permissionCode)
                    .map((menu) => menu.permissionCode!)
                  setPermissionCodes([...new Set([...permissionCodes, ...extra])])
                }}
              />
            )}
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending || permissionsQuery.isLoading || permissionCodes.length === 0}
            >
              {createMutation.isPending ? 'Creating…' : 'Create role'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
