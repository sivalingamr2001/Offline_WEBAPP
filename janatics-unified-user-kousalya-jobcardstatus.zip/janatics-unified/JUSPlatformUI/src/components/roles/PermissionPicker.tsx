import { useMemo } from 'react'
import type { PermissionDto } from '@/api/generated/models/permissionDto'
import { cn } from '@/utils/cn'

type PermissionPickerProps = {
  permissions: PermissionDto[]
  selected: string[]
  onChange: (codes: string[]) => void
  disabled?: boolean
  className?: string
}

export function PermissionPicker({ permissions, selected, onChange, disabled, className }: PermissionPickerProps) {
  const grouped = useMemo(() => {
    const map = new Map<string, PermissionDto[]>()
    for (const permission of permissions) {
      const list = map.get(permission.module) ?? []
      list.push(permission)
      map.set(permission.module, list)
    }
    return [...map.entries()].sort(([a], [b]) => a.localeCompare(b))
  }, [permissions])

  function toggle(code: string) {
    if (disabled) return
    if (selected.includes(code)) {
      onChange(selected.filter((c) => c !== code))
    } else {
      onChange([...selected, code])
    }
  }

  if (permissions.length === 0) {
    return <p className="text-sm text-[var(--cf-text-muted)]">No permissions available.</p>
  }

  return (
    <div className={cn('max-h-64 space-y-4 overflow-y-auto rounded-md border border-[var(--cf-border)] p-3', className)}>
      {grouped.map(([module, items]) => (
        <div key={module}>
          <p className="mb-2 text-xs font-semibold tracking-wide text-[var(--cf-text-muted)] uppercase">{module}</p>
          <div className="space-y-2">
            {items.map((permission) => {
              const checked = selected.includes(permission.code)
              return (
                <label
                  key={permission.id}
                  className={cn(
                    'flex cursor-pointer items-start gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-[var(--cf-surface-hover)]',
                    disabled && 'cursor-not-allowed opacity-60',
                  )}
                >
                  <input
                    type="checkbox"
                    className="mt-0.5 size-4 rounded border-[var(--cf-border)]"
                    checked={checked}
                    disabled={disabled}
                    onChange={() => toggle(permission.code)}
                  />
                  <span>
                    <span className="font-medium text-[var(--cf-text-primary)]">{permission.name}</span>
                    <span className="mt-0.5 block font-mono text-xs text-[var(--cf-text-muted)]">{permission.code}</span>
                  </span>
                </label>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}
