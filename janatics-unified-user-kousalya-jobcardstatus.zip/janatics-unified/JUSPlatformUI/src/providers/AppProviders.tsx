import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { type ReactNode, useState } from 'react'
import { AuthProvider } from '@/contexts/AuthContext'
import { PageTitleProvider } from '@/contexts/PageTitleContext'

export function AppProviders({ children }: { children: ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 30_000, retry: 1 },
        },
      }),
  )

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <PageTitleProvider>{children}</PageTitleProvider>
      </AuthProvider>
    </QueryClientProvider>
  )
}
