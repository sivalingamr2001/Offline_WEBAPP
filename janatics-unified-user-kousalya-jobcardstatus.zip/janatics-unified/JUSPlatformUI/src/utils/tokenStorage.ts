const STORAGE_KEY = 'jusplatform.auth.session'

export type AuthSession = {
  accessToken: string
  expiresAt: string
  userId: string
  email: string
  displayName: string
  designation?: string | null
  roleName?: string | null
  permissions: string[]
  modules: import('@/constants/navigation').SessionNavModule[]
}

export function loadSession(): AuthSession | null {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const session = JSON.parse(raw) as AuthSession
    if (!session.accessToken || !session.expiresAt) return null
    if (new Date(session.expiresAt).getTime() <= Date.now()) {
      clearSession()
      return null
    }
    return { ...session, permissions: session.permissions ?? [], modules: session.modules ?? [] }
  } catch {
    clearSession()
    return null
  }
}

export function saveSession(session: AuthSession) {
  sessionStorage.setItem(STORAGE_KEY, JSON.stringify(session))
}

export function clearSession() {
  sessionStorage.removeItem(STORAGE_KEY)
}

export function getAccessToken() {
  return loadSession()?.accessToken ?? null
}
