export type ApiErrorBody = {
  success: false
  detail?: string | null
  errors?: Record<string, string[]> | null
}

export function getApiErrorMessage(error: unknown, fallback = 'Something went wrong.') {
  if (typeof error === 'object' && error !== null && 'response' in error) {
    const data = (error as { response?: { data?: ApiErrorBody } }).response?.data
    if (data?.detail) return data.detail
    if (data?.errors) {
      const first = Object.values(data.errors)[0]?.[0]
      if (first) return first
    }
  }
  if (error instanceof Error && error.message) return error.message
  return fallback
}
