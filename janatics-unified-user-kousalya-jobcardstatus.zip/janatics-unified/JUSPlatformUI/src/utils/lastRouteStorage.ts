import { routes } from '@/constants/routes'

const LAST_ROUTE_KEY = 'jusplatform.nav.lastRoute'

const allowedPrefixes = ['/dashboard'] as const
const removedPrefixes = [
  '/dashboard/invoices',
  '/dashboard/inventory',
  '/dashboard/sales',
  '/dashboard/purchase-orders',
  '/dashboard/customers',
  '/dashboard/control-tower',
] as const

export function saveLastRoute(pathname: string) {
  if (!allowedPrefixes.some((prefix) => pathname.startsWith(prefix))) {
    return
  }

  if (removedPrefixes.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`))) {
    return
  }

  if (pathname === routes.home) {
    return
  }

  localStorage.setItem(LAST_ROUTE_KEY, pathname)
}

export function getLastRoute(): string | null {
  try {
    const path = localStorage.getItem(LAST_ROUTE_KEY)
    if (!path || !allowedPrefixes.some((prefix) => path.startsWith(prefix))) {
      return null
    }

    if (removedPrefixes.some((prefix) => path === prefix || path.startsWith(`${prefix}/`))) {
      return null
    }

    return path
  } catch {
    return null
  }
}

export function clearLastRoute() {
  localStorage.removeItem(LAST_ROUTE_KEY)
}

export function resolvePostLoginRoute() {
  return getLastRoute() ?? routes.dashboard
}
