import { type FormEvent, useState } from 'react'
import { LogIn, Mail } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { brand } from '@/constants/brand'
import { useAuth } from '@/hooks/useAuth'
import { usePageTitle } from '@/hooks/usePageTitle'
import { getApiErrorMessage } from '@/utils/apiError'
import { resolvePostLoginRoute } from '@/utils/lastRouteStorage'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { PasswordInput } from '@/components/ui/password-input'
import { Separator } from '@/components/ui/separator'

export default function LoginScreen() {
  usePageTitle('Sign in')
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await login({ email, password })
      navigate(resolvePostLoginRoute())
    } catch (err) {
      setError(getApiErrorMessage(err, 'Invalid email or password.'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Welcome to {brand.shortName}</CardTitle>
        <CardDescription>Use your organization account.</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={onSubmit}>
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <InputWithIcon
            id="email"
            icon={Mail}
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <PasswordInput
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={loading}>
          <LogIn className="size-4" aria-hidden />
          {loading ? 'Signing in…' : 'Sign in'}
        </Button>
      </form>
      </CardContent>

      <Separator />

      <div className="space-y-2 px-6 py-6 text-center text-sm text-muted-foreground">
        <Link to={routes.forgotPassword} className="inline-flex items-center gap-1 text-primary hover:underline">
          Forgot password?
        </Link>
        <p>
          New company?{' '}
          <Link to={routes.register} className="font-medium text-primary hover:underline">
            Create account
          </Link>
        </p>
      </div>
    </Card>
  )
}
