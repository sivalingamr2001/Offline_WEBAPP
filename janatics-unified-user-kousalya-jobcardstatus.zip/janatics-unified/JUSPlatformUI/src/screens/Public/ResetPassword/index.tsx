import { type FormEvent, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePageTitle } from '@/hooks/usePageTitle'
import { getApiErrorMessage } from '@/utils/apiError'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'

export default function ResetPasswordScreen() {
  usePageTitle('Reset password')
  const { resetPassword } = useAuth()
  const [params] = useSearchParams()
  const token = params.get('token') ?? ''
  const [password, setPassword] = useState('')
  const [done, setDone] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await resetPassword({ token, password })
      setDone(true)
    } catch (err) {
      setError(getApiErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  if (!token) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Invalid link</CardTitle>
          <CardDescription>Request a new password reset email.</CardDescription>
        </CardHeader>

        <Separator />

        <p className="px-6 py-6 text-center text-sm text-muted-foreground">
          <Link to={routes.forgotPassword} className="font-medium text-primary hover:underline">
            Forgot password
          </Link>
        </p>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Reset password</CardTitle>
        <CardDescription>Choose a new password for your account.</CardDescription>
      </CardHeader>
      <CardContent>
        {done ? (
          <p className="text-sm text-muted-foreground">Password updated.</p>
        ) : (
          <form className="space-y-4" onSubmit={onSubmit}>
            <div className="space-y-2">
              <Label htmlFor="password">New password</Label>
              <Input id="password" type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Saving…' : 'Update password'}
            </Button>
          </form>
        )}
      </CardContent>

      <Separator />

      <p className="px-6 py-6 text-center text-sm text-muted-foreground">
        <Link to={routes.login} className="font-medium text-primary hover:underline">
          {done ? 'Sign in' : 'Back to sign in'}
        </Link>
      </p>
    </Card>
  )
}
