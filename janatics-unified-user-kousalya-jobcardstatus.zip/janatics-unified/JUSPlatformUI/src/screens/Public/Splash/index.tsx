import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { pingApi } from '@/api/health'
import { brand } from '@/constants/brand'
import { routes } from '@/constants/routes'
import { Button } from '@/components/ui/button'
import { loadSession } from '@/utils/tokenStorage'
import { resolvePostLoginRoute } from '@/utils/lastRouteStorage'

type SplashState = 'checking' | 'offline'

export default function SplashScreen() {
  const navigate = useNavigate()
  const [state, setState] = useState<SplashState>('checking')
  const [detail, setDetail] = useState<string | null>(null)

  const runBootCheck = useCallback(async () => {
    setState('checking')
    setDetail(null)

    const controller = new AbortController()
    const timeout = window.setTimeout(() => controller.abort(), 8_000)

    try {
      await pingApi(controller.signal)
      const session = loadSession()
      navigate(session ? resolvePostLoginRoute() : routes.login, { replace: true })
    } catch (error) {
      setState('offline')
      setDetail(error instanceof Error ? error.message : 'Could not reach the API.')
    } finally {
      window.clearTimeout(timeout)
    }
  }, [navigate])

  useEffect(() => {
    void runBootCheck()
  }, [runBootCheck])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-blue-50/80 via-background to-background px-6">
      <div className="w-full max-w-sm text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{brand.name}</p>
        <p className="mt-1.5 text-sm text-muted-foreground">{brand.subtitle}</p>
        <h1 className="mt-3 text-2xl font-semibold tracking-tight">
          {state === 'checking' ? 'Starting…' : 'API unavailable'}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {state === 'checking'
            ? 'Checking API and your session.'
            : (detail ?? 'Start the JUSPlatform API and try again.')}
        </p>
        {state === 'checking' ? (
          <div className="mx-auto mt-8 size-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        ) : (
          <Button className="mt-8" onClick={() => void runBootCheck()}>
            Retry
          </Button>
        )}
      </div>
    </div>
  )
}
