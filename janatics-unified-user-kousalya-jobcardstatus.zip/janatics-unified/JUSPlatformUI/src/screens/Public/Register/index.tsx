import { type FormEvent, useState } from 'react'
import { Building2, Hash, Mail, UserPlus } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePageTitle } from '@/hooks/usePageTitle'
import { getApiErrorMessage } from '@/utils/apiError'
import { resolvePostLoginRoute } from '@/utils/lastRouteStorage'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { PasswordInput } from '@/components/ui/password-input'
import { Separator } from '@/components/ui/separator'

export default function RegisterScreen() {
  usePageTitle('Create account')
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({
    organizationName: '',
    organizationCode: '',
    displayName: '',
    email: '',
    password: '',
  })
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await register(form)
      navigate(resolvePostLoginRoute())
    } catch (err) {
      setError(getApiErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create your account</CardTitle>
        <CardDescription>Register your company. The first user becomes Admin.</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={onSubmit}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="organizationName">Company name</Label>
            <InputWithIcon
              id="organizationName"
              icon={Building2}
              value={form.organizationName}
              onChange={(e) => setForm({ ...form, organizationName: e.target.value })}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="organizationCode">Company code</Label>
            <InputWithIcon
              id="organizationCode"
              icon={Hash}
              value={form.organizationCode}
              onChange={(e) => setForm({ ...form, organizationCode: e.target.value.toUpperCase() })}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="displayName">Your name</Label>
            <InputWithIcon
              id="displayName"
              icon={UserPlus}
              value={form.displayName}
              onChange={(e) => setForm({ ...form, displayName: e.target.value })}
              required
            />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="email">Work email</Label>
            <InputWithIcon
              id="email"
              icon={Mail}
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="password">Password</Label>
            <PasswordInput
              id="password"
              minLength={8}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>
        </div>
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={loading}>
          <UserPlus className="size-4" aria-hidden />
          {loading ? 'Creating…' : 'Create account'}
        </Button>
      </form>
      </CardContent>

      <Separator />

      <p className="px-6 py-6 text-center text-sm text-muted-foreground">
        Already have an account?{' '}
        <Link to={routes.login} className="font-medium text-primary hover:underline">
          Sign in
        </Link>
      </p>
    </Card>
  )
}
