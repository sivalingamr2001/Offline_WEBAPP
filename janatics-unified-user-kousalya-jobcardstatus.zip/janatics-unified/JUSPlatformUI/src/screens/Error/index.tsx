import { isRouteErrorResponse, useRouteError } from 'react-router-dom'
import { useEffect } from 'react'
import { ErrorFallback, describeError } from '@/components/error/ErrorFallback'
import { routes } from '@/constants/routes'
import { reportAppError } from '@/observability/bugsink'

/** React Router `errorElement` — full-page fallback with dashboard recovery. */
export default function RouteErrorPage() {
  const error = useRouteError()
  const described = describeError(isRouteErrorResponse(error) ? error : error)

  useEffect(() => {
    if (isRouteErrorResponse(error)) {
      if (error.status >= 500) {
        reportAppError(new Error(`Route error ${error.status}`), { status: error.status })
      }
      return
    }
    reportAppError(error instanceof Error ? error : new Error(String(error)))
  }, [error])

  return (
    <ErrorFallback
      title={described.title}
      message={described.message}
      details={described.details}
      onRetry={() => {
        window.location.assign(routes.dashboard)
      }}
    />
  )
}
