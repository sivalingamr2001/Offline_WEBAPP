import { useQuery } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { Pencil, Shield, ShieldPlus } from 'lucide-react'
import { useMemo, useState } from 'react'
import { getRoles } from '@/api/generated/roles/roles'
import type { RoleDto } from '@/api/generated/models/roleDto'
import { CreateRoleDialog } from '@/components/roles/CreateRoleDialog'
import { EditRoleDialog } from '@/components/roles/EditRoleDialog'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { DataTable } from '@/components/data-table/DataTable'
import { Button } from '@/components/ui/button'
import { filterManagedRoles, roleTypeLabel } from '@/constants/roles'
import { permissions } from '@/constants/permissions'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'

const { listRoles } = getRoles()

export default function RolesScreen() {
  usePageTitle('Roles')
  const { hasPermission, isAdmin, isSuperAdmin } = usePermissions()
  const canWrite = isSuperAdmin || isAdmin || hasPermission(permissions.rolesWrite)

  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editRole, setEditRole] = useState<RoleDto | null>(null)

  const rolesQuery = useQuery({
    queryKey: ['roles', debouncedSearch],
    queryFn: () =>
      listRoles({
        page: 1,
        pageSize: 50,
        search: debouncedSearch || undefined,
      }),
  })

  const items = useMemo(
    () => filterManagedRoles(rolesQuery.data?.items ?? []),
    [rolesQuery.data?.items],
  )

  const columns = useMemo<ColumnDef<RoleDto>[]>(
    () => [
      { accessorKey: 'name', header: 'Role' },
      {
        id: 'type',
        header: 'Type',
        cell: ({ row }) => roleTypeLabel(row.original.isSystem),
      },
      {
        id: 'permissions',
        header: 'Permissions',
        cell: ({ row }) => row.original.permissions.length,
      },
      {
        id: 'menus',
        header: 'Menus',
        cell: ({ row }) => row.original.menus?.length ?? 0,
      },
      {
        accessorKey: 'description',
        header: 'Description',
        cell: ({ row }) => row.original.description ?? '—',
      },
      {
        id: 'actions',
        header: '',
        cell: ({ row }) =>
          canWrite ? (
            <Button variant="ghost" size="sm" className="gap-1" onClick={() => setEditRole(row.original)}>
              <Pencil className="size-3.5" aria-hidden />
              Edit
            </Button>
          ) : null,
      },
    ],
    [canWrite],
  )

  const isLoading = rolesQuery.isLoading
  const isEmpty = !isLoading && items.length === 0 && !debouncedSearch

  return (
    <div className="space-y-0">
      <PageHeader
        icon={Shield}
        title="Roles"
        description="Create catalog roles with permissions and menus. Users get organizations separately."
        actions={
          canWrite ? (
            <>
              <Button size="sm" variant="outline" disabled>
                Import
              </Button>
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <ShieldPlus className="size-4" aria-hidden />
                Create role
              </Button>
            </>
          ) : undefined
        }
      />

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search by role name or description…"
      />

      {isLoading ? (
        <LoadingState label="Loading roles…" />
      ) : isEmpty ? (
        <EmptyState
          icon={Shield}
          title="No data available"
          description="Create a catalog role, then assign it to users. Organizations are assigned on User organizations."
          action={
            canWrite ? (
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <ShieldPlus className="size-4" aria-hidden />
                Create role
              </Button>
            ) : undefined
          }
        />
      ) : (
        <DataTable columns={columns} data={items} emptyMessage="No roles match your search." />
      )}

      {canWrite ? (
        <>
          <CreateRoleDialog open={createOpen} onOpenChange={setCreateOpen} />
          <EditRoleDialog
            role={editRole}
            open={editRole !== null}
            onOpenChange={(open) => {
              if (!open) setEditRole(null)
            }}
          />
        </>
      ) : null}
    </div>
  )
}
