import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Building2 } from 'lucide-react'
import { type FormEvent, useEffect, useMemo, useState } from 'react'
import { listUserOrganizations, replaceUserOrganizations } from '@/api/auth'
import { getUsers } from '@/api/generated/users/users'
import { listOrganizations } from '@/api/organizations'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { usePageTitle } from '@/hooks/usePageTitle'
import { getApiErrorMessage } from '@/utils/apiError'

const { listUsers } = getUsers()

export default function UserOrganizationsScreen() {
  usePageTitle('User organizations')
  const queryClient = useQueryClient()
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [userId, setUserId] = useState('')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [error, setError] = useState<string | null>(null)

  const usersQuery = useQuery({
    queryKey: ['users', debouncedSearch],
    queryFn: () =>
      listUsers({
        page: 1,
        pageSize: 100,
        search: debouncedSearch || undefined,
      }),
  })

  const orgsQuery = useQuery({
    queryKey: ['organizations'],
    queryFn: () => listOrganizations({ page: 1, pageSize: 100 }),
  })

  const membershipQuery = useQuery({
    queryKey: ['user-organizations', userId],
    queryFn: () => listUserOrganizations(userId),
    enabled: Boolean(userId),
  })

  const users = useMemo(
    () => (usersQuery.data?.items ?? []).filter((user) => user.roleName?.toLowerCase() !== 'superadmin'),
    [usersQuery.data?.items],
  )
  const orgs = orgsQuery.data?.items ?? []

  useEffect(() => {
    if (!userId) {
      setSelected(new Set())
      setError(null)
      return
    }
    if (membershipQuery.isError) {
      setError(getApiErrorMessage(membershipQuery.error, 'Could not load this user\'s organizations.'))
      return
    }
    if (!membershipQuery.data) {
      return
    }
    setSelected(new Set(membershipQuery.data.filter((row) => row.isActive).map((row) => row.organizationId)))
    setError(null)
  }, [membershipQuery.data, membershipQuery.error, membershipQuery.isError, userId])

  const saveMutation = useMutation({
    mutationFn: () =>
      replaceUserOrganizations(
        userId,
        [...selected].map((organizationId) => ({ organizationId, isActive: true })),
      ),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['user-organizations', userId] })
      await queryClient.invalidateQueries({ queryKey: ['users'] })
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!userId) return
    setError(null)
    saveMutation.mutate()
  }

  function toggleOrg(id: string) {
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const isLoading = usersQuery.isLoading || orgsQuery.isLoading

  return (
    <div className="space-y-0">
      <PageHeader
        icon={Building2}
        title="User organizations"
        description="Choose which organizations a user may work in. A user with no organizations cannot enter tenant data."
      />

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search users…"
      />

      {isLoading ? (
        <LoadingState label="Loading users and organizations…" />
      ) : users.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No users"
          description="Create a user first, then assign organizations here."
        />
      ) : (
        <form className="space-y-4 p-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="membership-user">User</Label>
            <select
              id="membership-user"
              className="flex h-9 w-full max-w-xl rounded-md border border-[var(--cf-border)] bg-white px-3 text-sm"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
            >
              <option value="">Select a user</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.displayName} ({user.email})
                </option>
              ))}
            </select>
          </div>

          {!userId ? (
            <p className="text-sm text-[var(--cf-text-muted)]">Select a user to assign organizations.</p>
          ) : membershipQuery.isLoading ? (
            <p className="text-sm text-[var(--cf-text-muted)]">Loading membership…</p>
          ) : membershipQuery.isError ? (
            <p className="text-sm text-destructive">{getApiErrorMessage(membershipQuery.error)}</p>
          ) : orgs.length === 0 ? (
            <p className="text-sm text-[var(--cf-text-muted)]">No organizations exist yet.</p>
          ) : (
            <div className="max-h-[28rem] space-y-1 overflow-y-auto rounded-md border border-[var(--cf-border)] bg-white p-3">
              {orgs.map((org) => (
                <label
                  key={org.id}
                  className="flex cursor-pointer items-start gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-[var(--cf-surface-hover)]"
                >
                  <input
                    type="checkbox"
                    className="mt-0.5 size-4 rounded border-input"
                    checked={selected.has(org.id)}
                    onChange={() => toggleOrg(org.id)}
                  />
                  <span>
                    <span className="font-medium text-[var(--cf-text-primary)]">{org.name}</span>
                    <span className="mt-0.5 block font-mono text-xs text-[var(--cf-text-muted)]">{org.code}</span>
                  </span>
                </label>
              ))}
            </div>
          )}

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <Button type="submit" disabled={!userId || saveMutation.isPending || membershipQuery.isLoading}>
            {saveMutation.isPending ? 'Saving…' : 'Save organizations'}
          </Button>
        </form>
      )}
    </div>
  )
}
