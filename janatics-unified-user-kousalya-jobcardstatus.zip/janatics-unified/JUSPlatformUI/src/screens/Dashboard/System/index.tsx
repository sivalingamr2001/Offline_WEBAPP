import { Cpu } from 'lucide-react'
import { ContentPanel } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { usePageTitle } from '@/hooks/usePageTitle'

export default function SystemScreen() {
  usePageTitle('System')
  return (
    <div className="space-y-0">
      <PageHeader
        icon={Cpu}
        title="System"
        description="Platform health and runtime settings for this environment."
        showDocs={false}
      />
      <ContentPanel>
        <div className="bg-white p-6 text-sm text-[var(--cf-text-muted)]">
          System diagnostics will appear here. The menu is available from the administration catalog.
        </div>
      </ContentPanel>
    </div>
  )
}
