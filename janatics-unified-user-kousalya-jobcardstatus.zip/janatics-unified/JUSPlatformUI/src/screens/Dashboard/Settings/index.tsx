import { useMutation, useQuery } from '@tanstack/react-query'
import { Briefcase, Building2, Camera, Hash, KeyRound, Lock, Settings, User } from 'lucide-react'
import { useEffect, useRef, useState, type FormEvent } from 'react'
import { getCurrentOrganization } from '@/api/organizations'
import { changePassword, getCurrentUser, updateCurrentUser, uploadAvatar } from '@/api/profile'
import { ContentPanel } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { Button } from '@/components/ui/button'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { PasswordInput } from '@/components/ui/password-input'
import { useAuth } from '@/hooks/useAuth'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'

const maxAvatarBytes = 200 * 1024

export default function SettingsScreen() {
  usePageTitle('Settings')
  const fileRef = useRef<HTMLInputElement>(null)
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [designation, setDesignation] = useState('')
  const [accountError, setAccountError] = useState<string | null>(null)
  const [accountMessage, setAccountMessage] = useState<string | null>(null)

  const { isSuperAdmin } = usePermissions()
  const { syncSession } = useAuth()

  const { data: org, isLoading: orgLoading } = useQuery({
    queryKey: ['organization', 'me'],
    queryFn: getCurrentOrganization,
    enabled: !isSuperAdmin,
  })

  const profileQuery = useQuery({
    queryKey: ['profile', 'me'],
    queryFn: getCurrentUser,
  })

  useEffect(() => {
    if (!profileQuery.isSuccess) return
    setDesignation(profileQuery.data.designation ?? '')
    syncSession({ designation: profileQuery.data.designation ?? null })
  }, [profileQuery.isSuccess, profileQuery.data?.designation, syncSession])

  const changePasswordMutation = useMutation({
    mutationFn: () => changePassword({ currentPassword, newPassword }),
    onSuccess: (res) => {
      setAccountMessage(res.message)
      setAccountError(null)
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    },
    onError: (err) => setAccountError(getApiErrorMessage(err)),
  })

  const avatarMutation = useMutation({
    mutationFn: (file: File) => uploadAvatar(file),
    onSuccess: async () => {
      setAccountMessage('Avatar updated.')
      setAccountError(null)
      await profileQuery.refetch()
    },
    onError: (err) => setAccountError(getApiErrorMessage(err)),
  })

  const designationMutation = useMutation({
    mutationFn: () => updateCurrentUser({ designation: designation.trim() || null }),
    onSuccess: async (updated) => {
      setAccountMessage('Designation updated.')
      setAccountError(null)
      syncSession({ designation: updated.designation ?? null })
      await profileQuery.refetch()
    },
    onError: (err) => setAccountError(getApiErrorMessage(err)),
  })

  function onSaveDesignation(e: FormEvent) {
    e.preventDefault()
    setAccountMessage(null)
    setAccountError(null)
    designationMutation.mutate()
  }

  function onChangePassword(e: FormEvent) {
    e.preventDefault()
    setAccountMessage(null)
    if (newPassword !== confirmPassword) {
      setAccountError('New passwords do not match.')
      return
    }
    changePasswordMutation.mutate()
  }

  function onAvatarSelected(file: File | undefined) {
    setAccountMessage(null)
    setAccountError(null)
    if (!file) return
    if (file.type !== 'image/jpeg') {
      setAccountError('Avatar must be a JPEG image.')
      return
    }
    if (file.size > maxAvatarBytes) {
      setAccountError('Avatar must be 200 KB or smaller.')
      return
    }
    avatarMutation.mutate(file)
  }

  const profile = profileQuery.data

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Settings}
        title="Settings"
        description={isSuperAdmin ? 'Your platform owner account.' : 'Organization profile and your account preferences.'}
      />

      <ContentPanel className="max-w-2xl">
        <div className="border-b border-[var(--cf-border)] px-6 py-4">
          <div className="flex items-center gap-2.5">
            <User className="size-5 text-[var(--cf-text-muted)]" strokeWidth={1.75} aria-hidden />
            <h2 className="font-medium text-[var(--cf-text-primary)]">Your account</h2>
          </div>
        </div>
        <div className="space-y-6 px-6 py-5">
          <div className="flex items-center gap-4">
            <div className="flex size-16 items-center justify-center overflow-hidden rounded-full border border-[var(--cf-border)] bg-[var(--cf-surface-hover)]">
              {profile?.avatarUrl ? (
                <img src={profile.avatarUrl} alt="" className="size-full object-cover" />
              ) : (
                <User className="size-7 text-[var(--cf-text-muted)]" aria-hidden />
              )}
            </div>
            <div>
              <p className="font-medium text-[var(--cf-text-primary)]">{profile?.displayName ?? '—'}</p>
              {profile?.designation ? (
                <p className="text-sm text-[var(--cf-text-secondary)]">{profile.designation}</p>
              ) : null}
              <p className="text-sm text-[var(--cf-text-muted)]">{profile?.email ?? '—'}</p>
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="mt-2 gap-2"
                disabled={avatarMutation.isPending}
                onClick={() => fileRef.current?.click()}
              >
                <Camera className="size-4" aria-hidden />
                {avatarMutation.isPending ? 'Uploading…' : 'Upload avatar'}
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,.jpg,.jpeg"
                className="hidden"
                onChange={(e) => onAvatarSelected(e.target.files?.[0])}
              />
              <p className="mt-1 text-xs text-[var(--cf-text-muted)]">JPEG only, max 200 KB.</p>
            </div>
          </div>

          <form className="space-y-4 border-t border-[var(--cf-border)] pt-5" onSubmit={onSaveDesignation}>
            <div className="flex items-center gap-2.5">
              <Briefcase className="size-5 text-[var(--cf-text-muted)]" strokeWidth={1.75} aria-hidden />
              <h3 className="font-medium text-[var(--cf-text-primary)]">Designation</h3>
            </div>
            <div className="space-y-2">
              <Label htmlFor="designation">Job title</Label>
              <InputWithIcon
                id="designation"
                icon={Briefcase}
                maxLength={200}
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                placeholder="e.g. Sales Manager"
              />
            </div>
            <Button type="submit" disabled={designationMutation.isPending}>
              {designationMutation.isPending ? 'Saving…' : 'Save designation'}
            </Button>
            {accountError ? <p className="text-sm text-destructive">{accountError}</p> : null}
            {accountMessage ? <p className="text-sm text-emerald-700">{accountMessage}</p> : null}
          </form>

          <form className="space-y-4 border-t border-[var(--cf-border)] pt-5" onSubmit={onChangePassword}>
            <div className="flex items-center gap-2.5">
              <Lock className="size-5 text-[var(--cf-text-muted)]" strokeWidth={1.75} aria-hidden />
              <h3 className="font-medium text-[var(--cf-text-primary)]">Change password</h3>
            </div>
            <div className="space-y-2">
              <Label htmlFor="current-password">Current password</Label>
              <PasswordInput id="current-password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">New password</Label>
              <PasswordInput id="new-password" minLength={8} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm new password</Label>
              <InputWithIcon id="confirm-password" icon={KeyRound} type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
            </div>
            {accountError ? <p className="text-sm text-destructive">{accountError}</p> : null}
            {accountMessage ? <p className="text-sm text-emerald-700">{accountMessage}</p> : null}
            <Button type="submit" disabled={changePasswordMutation.isPending}>
              {changePasswordMutation.isPending ? 'Updating…' : 'Update password'}
            </Button>
          </form>
        </div>
      </ContentPanel>

      {isSuperAdmin ? null : (
        <ContentPanel className="max-w-2xl">
        <div className="border-b border-[var(--cf-border)] px-6 py-4">
          <div className="flex items-center gap-2.5">
            <Building2 className="size-5 text-[var(--cf-text-muted)]" strokeWidth={1.75} aria-hidden />
            <h2 className="font-medium text-[var(--cf-text-primary)]">Organization</h2>
          </div>
        </div>
        <div className="space-y-3 px-6 py-5 text-sm">
          {orgLoading ? (
            <p className="text-[var(--cf-text-muted)]">Loading…</p>
          ) : org ? (
            <>
              <p className="flex items-center gap-2">
                <Building2 className="size-4 text-[var(--cf-text-muted)]" aria-hidden />
                <span className="text-[var(--cf-text-muted)]">Name:</span>
                <span className="font-medium text-[var(--cf-text-primary)]">{org.name}</span>
              </p>
              <p className="flex items-center gap-2">
                <Hash className="size-4 text-[var(--cf-text-muted)]" aria-hidden />
                <span className="text-[var(--cf-text-muted)]">Code:</span>
                <code className="font-mono font-medium text-[var(--cf-text-primary)]">{org.code}</code>
              </p>
            </>
          ) : null}
        </div>
      </ContentPanel>
      )}
    </div>
  )
}
