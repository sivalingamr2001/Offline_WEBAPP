import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { Hash, Menu, Pencil, Plus } from 'lucide-react'
import { type FormEvent, useEffect, useMemo, useState } from 'react'
import {
  createAppMenu,
  listAppMenus,
  listAppModules,
  updateAppMenu,
  type AppMenuDto,
} from '@/api/appCatalog'
import { DataTable } from '@/components/data-table/DataTable'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { ActiveStatusBadge } from '@/components/ui/status-badge'
import { permissions } from '@/constants/permissions'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'

export default function MenusScreen() {
  usePageTitle('Menus')
  const { hasPermission, isAdmin, isSuperAdmin } = usePermissions()
  const canWrite = isAdmin || isSuperAdmin || hasPermission(permissions.menusWrite)
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [moduleId, setModuleId] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editMenu, setEditMenu] = useState<AppMenuDto | null>(null)

  const modulesQuery = useQuery({
    queryKey: ['app-modules'],
    queryFn: () => listAppModules({ page: 1, pageSize: 100 }),
  })

  const query = useQuery({
    queryKey: ['app-menus', debouncedSearch, moduleId],
    queryFn: () =>
      listAppMenus({
        page: 1,
        pageSize: 100,
        sort: 'code',
        search: debouncedSearch || undefined,
        moduleId: moduleId || undefined,
      }),
  })

  const columns = useMemo<ColumnDef<AppMenuDto>[]>(
    () => [
      {
        accessorKey: 'sortOrder',
        header: 'Seq',
        cell: ({ row }) => row.original.sortOrder,
      },
      {
        accessorKey: 'code',
        header: 'Code',
        cell: ({ row }) => <code className="font-mono text-sm">{row.original.code}</code>,
      },
      { accessorKey: 'name', header: 'Name' },
      { accessorKey: 'moduleName', header: 'Module' },
      {
        accessorKey: 'path',
        header: 'Path',
        cell: ({ row }) =>
          row.original.path ? <code className="font-mono text-sm">{row.original.path}</code> : '—',
      },
      {
        accessorKey: 'permissionCode',
        header: 'Permission',
        cell: ({ row }) => row.original.permissionCode ?? '—',
      },
      {
        accessorKey: 'isActive',
        header: 'Status',
        cell: ({ row }) => <ActiveStatusBadge active={row.original.isActive} />,
      },
      {
        id: 'actions',
        header: '',
        cell: ({ row }) =>
          canWrite ? (
            <Button variant="ghost" size="sm" className="gap-1" onClick={() => setEditMenu(row.original)}>
              <Pencil className="size-3.5" aria-hidden />
              Edit
            </Button>
          ) : null,
      },
    ],
    [canWrite],
  )

  const items = query.data?.items ?? []
  const isLoading = query.isLoading
  const isError = query.isError
  const isEmpty = !isLoading && !isError && items.length === 0 && !debouncedSearch && !moduleId

  return (
    <div className="space-y-0">
      <PageHeader
        icon={Menu}
        title="Menus"
        description="Catalog menus from public.app_menus."
        actions={
          canWrite ? (
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add menu
            </Button>
          ) : undefined
        }
      />

      <div className="border-b border-[var(--cf-border)] bg-white px-4 py-3">
        <label className="flex items-center gap-2 text-sm text-[var(--cf-text-secondary)]">
          Module
          <select
            className="h-9 rounded-md border border-[var(--cf-border)] bg-white px-2 text-sm"
            value={moduleId}
            onChange={(e) => setModuleId(e.target.value)}
          >
            <option value="">All modules</option>
            {(modulesQuery.data?.items ?? []).map((module) => (
              <option key={module.id} value={module.id}>
                {module.name} ({module.code})
              </option>
            ))}
          </select>
        </label>
      </div>

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search by name, code, or path…"
      />

      {isLoading ? (
        <LoadingState label="Loading menus…" />
      ) : isError ? (
        <EmptyState
          icon={Menu}
          title="Menus could not be loaded"
          description={getApiErrorMessage(query.error, 'You do not have permission to list menus.')}
        />
      ) : isEmpty ? (
        <EmptyState
          icon={Menu}
          title="No menus yet"
          description="Add a menu item under an app module."
          action={
            canWrite ? (
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="size-4" aria-hidden />
                Add menu
              </Button>
            ) : undefined
          }
        />
      ) : (
        <DataTable columns={columns} data={items} emptyMessage="No menus match your search." />
      )}

      {canWrite ? (
        <>
          <CreateMenuDialog
            open={createOpen}
            onOpenChange={setCreateOpen}
            defaultModuleId={moduleId}
          />
          <EditMenuDialog menu={editMenu} open={editMenu !== null} onOpenChange={(open) => !open && setEditMenu(null)} />
        </>
      ) : null}
    </div>
  )
}

function CreateMenuDialog({
  open,
  onOpenChange,
  defaultModuleId,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  defaultModuleId: string
}) {
  const queryClient = useQueryClient()
  const [moduleId, setModuleId] = useState('')
  const [code, setCode] = useState('')
  const [name, setName] = useState('')
  const [path, setPath] = useState('')
  const [permissionCode, setPermissionCode] = useState('')
  const [error, setError] = useState<string | null>(null)

  const modulesQuery = useQuery({
    queryKey: ['app-modules'],
    queryFn: () => listAppModules({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  useEffect(() => {
    if (!open) {
      setModuleId(defaultModuleId)
      setCode('')
      setName('')
      setPath('')
      setPermissionCode('')
      setError(null)
    } else {
      setModuleId(defaultModuleId)
    }
  }, [open, defaultModuleId])

  const mutation = useMutation({
    mutationFn: createAppMenu,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['app-menus'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    if (!moduleId) {
      setError('Select a module.')
      return
    }
    mutation.mutate({
      moduleId,
      code: code.trim() ? code.trim().toUpperCase() : undefined,
      name: name.trim(),
      path: path.trim() || null,
      permissionCode: permissionCode.trim() || null,
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Menu className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Add menu
          </DialogTitle>
          <DialogDescription>Creates a row in public.app_menus.</DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="menu-module">Module</Label>
            <select
              id="menu-module"
              className="flex h-9 w-full rounded-md border border-[var(--cf-border)] bg-white px-3 text-sm"
              value={moduleId}
              onChange={(e) => setModuleId(e.target.value)}
              required
            >
              <option value="">Select a module</option>
              {(modulesQuery.data?.items ?? []).map((module) => (
                <option key={module.id} value={module.id}>
                  {module.name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="menu-name">Name</Label>
            <InputWithIcon id="menu-name" icon={Menu} value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="menu-code">Code</Label>
            <InputWithIcon
              id="menu-code"
              icon={Hash}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="MNU001 (auto)"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="menu-path">Path</Label>
            <Input id="menu-path" value={path} onChange={(e) => setPath(e.target.value)} placeholder="/modules/pes/on-time-delivery" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="menu-permission">Permission code</Label>
            <Input
              id="menu-permission"
              value={permissionCode}
              onChange={(e) => setPermissionCode(e.target.value)}
              placeholder="org.read"
            />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? 'Creating…' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function EditMenuDialog({
  menu,
  open,
  onOpenChange,
}: {
  menu: AppMenuDto | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [moduleId, setModuleId] = useState('')
  const [name, setName] = useState('')
  const [path, setPath] = useState('')
  const [permissionCode, setPermissionCode] = useState('')
  const [isActive, setIsActive] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const modulesQuery = useQuery({
    queryKey: ['app-modules'],
    queryFn: () => listAppModules({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  useEffect(() => {
    if (menu && open) {
      setModuleId(menu.moduleId)
      setName(menu.name)
      setPath(menu.path ?? '')
      setPermissionCode(menu.permissionCode ?? '')
      setIsActive(menu.isActive)
      setError(null)
    }
  }, [menu, open])

  const mutation = useMutation({
    mutationFn: () =>
      updateAppMenu(menu!.id, {
        moduleId,
        name: name.trim(),
        path: path.trim() || null,
        permissionCode: permissionCode.trim() || null,
        isActive,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['app-menus'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!menu) return
    setError(null)
    if (!moduleId) {
      setError('Select a module.')
      return
    }
    mutation.mutate()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pencil className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Edit menu
          </DialogTitle>
          <DialogDescription>
            Update path and permission so this item can appear in the sidebar. Code {menu?.code} stays the same.
          </DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="edit-menu-module">Module</Label>
            <select
              id="edit-menu-module"
              className="flex h-9 w-full rounded-md border border-[var(--cf-border)] bg-white px-3 text-sm"
              value={moduleId}
              onChange={(e) => setModuleId(e.target.value)}
              required
            >
              <option value="">Select a module</option>
              {(modulesQuery.data?.items ?? []).map((module) => (
                <option key={module.id} value={module.id}>
                  {module.name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-menu-name">Name</Label>
            <InputWithIcon id="edit-menu-name" icon={Menu} value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-menu-code">Code</Label>
            <InputWithIcon id="edit-menu-code" icon={Hash} value={menu?.code ?? ''} disabled />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-menu-path">Path</Label>
            <Input
              id="edit-menu-path"
              value={path}
              onChange={(e) => setPath(e.target.value)}
              placeholder="/modules/pes/on-time-delivery"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-menu-permission">Permission code</Label>
            <Input
              id="edit-menu-permission"
              value={permissionCode}
              onChange={(e) => setPermissionCode(e.target.value)}
              placeholder="pes.view"
            />
          </div>
          <label className="flex items-center gap-2 text-sm text-[var(--cf-text-secondary)]">
            <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} />
            Active
          </label>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending || !menu}>
              {mutation.isPending ? 'Saving…' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
