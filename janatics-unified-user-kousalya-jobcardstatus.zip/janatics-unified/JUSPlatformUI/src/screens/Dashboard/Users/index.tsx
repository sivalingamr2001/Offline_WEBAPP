import { useQuery } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { Pencil, UserCog, UserPlus } from 'lucide-react'
import { useMemo, useState } from 'react'
import { getRoles } from '@/api/generated/roles/roles'
import { getUsers } from '@/api/generated/users/users'
import type { UserDto } from '@/api/generated/models/userDto'
import { CreateUserDialog } from '@/components/users/CreateUserDialog'
import { EditUserDialog } from '@/components/users/EditUserDialog'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { DataTable } from '@/components/data-table/DataTable'
import { Button } from '@/components/ui/button'
import { ActiveStatusBadge } from '@/components/ui/status-badge'
import { filterAssignableRoles, isPrivilegedRole } from '@/constants/roles'
import { permissions } from '@/constants/permissions'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'

const { listUsers } = getUsers()
const { listRoles } = getRoles()

export default function UsersScreen() {
  usePageTitle('Users')
  const { isSuperAdmin, isAdmin, hasPermission } = usePermissions()
  const canWrite = isSuperAdmin || isAdmin || hasPermission(permissions.usersWrite)
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editUser, setEditUser] = useState<UserDto | null>(null)

  const usersQuery = useQuery({
    queryKey: ['users', debouncedSearch],
    queryFn: () =>
      listUsers({
        page: 1,
        pageSize: 50,
        search: debouncedSearch || undefined,
      }),
  })

  const rolesQuery = useQuery({
    queryKey: ['roles', 'assignable'],
    queryFn: () => listRoles({ page: 1, pageSize: 100 }),
  })

  const roles = useMemo(
    () =>
      filterAssignableRoles(
        (rolesQuery.data?.items ?? []).map((r) => ({ id: r.id, name: r.name })),
        { allowAdmin: isSuperAdmin },
      ),
    [isSuperAdmin, rolesQuery.data?.items],
  )

  const columns = useMemo<ColumnDef<UserDto>[]>(
    () => [
      { accessorKey: 'displayName', header: 'Name' },
      {
        accessorKey: 'userCode',
        header: 'User code',
        cell: ({ row }) => row.original.userCode?.trim() || '—',
      },
      {
        accessorKey: 'empId',
        header: 'Emp id',
        cell: ({ row }) => row.original.empId?.trim() || '—',
      },
      {
        accessorKey: 'designation',
        header: 'Designation',
        cell: ({ row }) => row.original.designation?.trim() || '—',
      },
      { accessorKey: 'email', header: 'Email' },
      ...(isSuperAdmin
        ? [
            {
              accessorKey: 'organizationName',
              header: 'Default org',
              cell: ({ row }: { row: { original: UserDto } }) => row.original.organizationName ?? '—',
            } satisfies ColumnDef<UserDto>,
          ]
        : []),
      {
        accessorKey: 'roleName',
        header: 'Role',
        cell: ({ row }) => row.original.roleName ?? '—',
      },
      {
        accessorKey: 'isActive',
        header: 'Status',
        cell: ({ row }) => <ActiveStatusBadge active={row.original.isActive} />,
      },
      {
        id: 'actions',
        header: '',
        cell: ({ row }) => {
          const privileged = isPrivilegedRole(row.original.roleName ?? '')
          if (privileged && !isSuperAdmin) {
            return <span className="text-xs text-muted-foreground">Protected</span>
          }
          if (row.original.roleName?.toLowerCase() === 'superadmin') {
            return <span className="text-xs text-muted-foreground">Protected</span>
          }
          if (!canWrite) return null
          return (
            <Button variant="ghost" size="sm" className="gap-1" onClick={() => setEditUser(row.original)}>
              <Pencil className="size-3.5" aria-hidden />
              Edit
            </Button>
          )
        },
      },
    ],
    [canWrite, isSuperAdmin],
  )

  const items = usersQuery.data?.items ?? []
  const isLoading = usersQuery.isLoading
  const isEmpty = !isLoading && items.length === 0 && !debouncedSearch

  return (
    <div className="space-y-0">
      <PageHeader
        icon={UserCog}
        title="Users"
        description={
          isSuperAdmin
            ? 'Create people here. Assign which organizations they can work in on User organizations.'
            : 'Invite members, assign roles, and control account access.'
        }
        actions={
          canWrite ? (
            <>
              <Button size="sm" variant="outline" disabled>
                Import
              </Button>
              <Button size="sm" onClick={() => setCreateOpen(true)} disabled={rolesQuery.isLoading}>
                <UserPlus className="size-4" aria-hidden />
                Add user
              </Button>
            </>
          ) : undefined
        }
      />

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search by name or email…"
      />

      {isLoading ? (
        <LoadingState label="Loading users…" />
      ) : isEmpty ? (
        <EmptyState
          icon={UserCog}
          title="No data available"
          description={
            isSuperAdmin
              ? 'Add a user, then assign organizations on the User organizations page.'
              : 'Invite members, assign roles, and control account access for your organization.'
          }
          action={
            canWrite ? (
              <Button size="sm" onClick={() => setCreateOpen(true)} disabled={rolesQuery.isLoading}>
                <UserPlus className="size-4" aria-hidden />
                Add user
              </Button>
            ) : undefined
          }
        />
      ) : (
        <DataTable columns={columns} data={items} emptyMessage="No users match your search." />
      )}

      <CreateUserDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        roles={roles}
        rolesLoading={rolesQuery.isLoading}
      />
      <EditUserDialog
        user={editUser}
        open={editUser !== null}
        onOpenChange={(open) => {
          if (!open) setEditUser(null)
        }}
      />
    </div>
  )
}
