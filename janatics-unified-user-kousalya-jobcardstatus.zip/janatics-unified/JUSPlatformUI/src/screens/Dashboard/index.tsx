import { useQuery } from '@tanstack/react-query'
import { Building2, Home } from 'lucide-react'
import { Link } from 'react-router-dom'
import { getCurrentOrganization } from '@/api/organizations'
import { ContentPanel } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { resolveNavIcon } from '@/constants/navigation'
import { cn } from '@/utils/cn'

export default function DashboardHomeScreen() {
  usePageTitle('Account home')
  const { isSuperAdmin, modules } = usePermissions()
  const { data: org } = useQuery({
    queryKey: ['organization', 'me'],
    queryFn: getCurrentOrganization,
    enabled: !isSuperAdmin,
  })

  const quickLinks = modules.flatMap((module) =>
    module.menus
      .filter((menu) => menu.path && menu.path !== '/dashboard')
      .map((menu) => ({
        to: menu.path!,
        label: menu.name,
        icon: resolveNavIcon(menu.icon),
        description: module.name,
      })),
  )

  return (
    <div className="space-y-0">
      <PageHeader
        icon={Home}
        title="Account home"
        description={
          isSuperAdmin
            ? 'Platform owner. Create organizations, operating units, users, roles, permissions, menus, and modules.'
            : org
              ? `Signed in to ${org.name} (${org.code}).`
              : 'Your organization workspace at a glance.'
        }
        showDocs={false}
      />

      <ContentPanel>
        <div className="grid gap-px bg-[var(--cf-border)] md:grid-cols-3">
          {quickLinks.length === 0 ? (
            <div className="bg-white p-6 text-sm text-[var(--cf-text-muted)] md:col-span-3">
              No module menus are assigned to your role yet.
            </div>
          ) : (
            quickLinks.map(({ to, label, icon: Icon, description }) => (
              <Link
                key={`${to}-${label}`}
                to={to}
                className="group flex flex-col bg-white p-6 transition hover:bg-[var(--cf-surface-hover)]"
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="size-5 text-[var(--cf-text-primary)]" strokeWidth={1.75} aria-hidden />
                  <span className="font-medium text-[var(--cf-text-primary)]">{label}</span>
                </div>
                <p className="mt-2 text-sm text-[var(--cf-text-muted)] group-hover:text-[var(--cf-text-secondary)]">
                  {description}
                </p>
              </Link>
            ))
          )}
        </div>

        {org ? (
          <div className={cn('border-t border-[var(--cf-border)] bg-white p-6')}>
            <div className="flex items-center gap-2.5">
              <Building2 className="size-5 text-[var(--cf-text-muted)]" strokeWidth={1.75} aria-hidden />
              <h2 className="font-medium text-[var(--cf-text-primary)]">Organization</h2>
            </div>
            <p className="mt-2 text-sm text-[var(--cf-text-muted)]">
              You are working in <strong className="text-[var(--cf-text-primary)]">{org.name}</strong>.
            </p>
          </div>
        ) : null}
      </ContentPanel>
    </div>
  )
}
