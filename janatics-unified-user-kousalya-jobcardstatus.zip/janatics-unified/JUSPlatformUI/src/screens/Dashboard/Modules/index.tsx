import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { AppWindow, Hash, Plus } from 'lucide-react'
import { type FormEvent, useEffect, useMemo, useState } from 'react'
import { createAppModule, listAppModules, type AppModuleDto } from '@/api/appCatalog'
import { DataTable } from '@/components/data-table/DataTable'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { ActiveStatusBadge } from '@/components/ui/status-badge'
import { permissions } from '@/constants/permissions'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'

export default function ModulesScreen() {
  usePageTitle('Modules')
  const { hasPermission, isAdmin, isSuperAdmin } = usePermissions()
  const canWrite = isAdmin || isSuperAdmin || hasPermission(permissions.modulesWrite)
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [createOpen, setCreateOpen] = useState(false)

  const query = useQuery({
    queryKey: ['app-modules', debouncedSearch],
    queryFn: () => listAppModules({ page: 1, pageSize: 100, search: debouncedSearch || undefined }),
  })

  const columns = useMemo<ColumnDef<AppModuleDto>[]>(
    () => [
      { accessorKey: 'name', header: 'Name' },
      {
        accessorKey: 'code',
        header: 'Code',
        cell: ({ row }) => <code className="font-mono text-sm">{row.original.code}</code>,
      },
      {
        accessorKey: 'description',
        header: 'Description',
        cell: ({ row }) => row.original.description ?? '—',
      },
      { accessorKey: 'sortOrder', header: 'Order' },
      {
        accessorKey: 'isActive',
        header: 'Status',
        cell: ({ row }) => <ActiveStatusBadge active={row.original.isActive} />,
      },
    ],
    [],
  )

  const items = query.data?.items ?? []
  const isLoading = query.isLoading
  const isEmpty = !isLoading && items.length === 0 && !debouncedSearch

  return (
    <div className="space-y-0">
      <PageHeader
        icon={AppWindow}
        title="Modules"
        description="Catalog modules from public.app_modules."
        actions={
          canWrite ? (
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add module
            </Button>
          ) : undefined
        }
      />

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search by name or code…"
      />

      {isLoading ? (
        <LoadingState label="Loading modules…" />
      ) : isEmpty ? (
        <EmptyState
          icon={AppWindow}
          title="No modules yet"
          description="Add a catalog module to group menus."
          action={
            canWrite ? (
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="size-4" aria-hidden />
                Add module
              </Button>
            ) : undefined
          }
        />
      ) : (
        <DataTable columns={columns} data={items} emptyMessage="No modules match your search." />
      )}

      {canWrite ? <CreateModuleDialog open={createOpen} onOpenChange={setCreateOpen} /> : null}
    </div>
  )
}

function CreateModuleDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [code, setCode] = useState('')
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [sortOrder, setSortOrder] = useState('0')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) {
      setCode('')
      setName('')
      setDescription('')
      setSortOrder('0')
      setError(null)
    }
  }, [open])

  const mutation = useMutation({
    mutationFn: createAppModule,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['app-modules'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    mutation.mutate({
      code: code.trim().toUpperCase(),
      name: name.trim(),
      description: description.trim() || null,
      sortOrder: Number(sortOrder) || 0,
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AppWindow className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Add module
          </DialogTitle>
          <DialogDescription>Creates a row in public.app_modules.</DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="module-name">Name</Label>
            <InputWithIcon
              id="module-name"
              icon={AppWindow}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="module-code">Code</Label>
            <InputWithIcon id="module-code" icon={Hash} value={code} onChange={(e) => setCode(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="module-description">Description</Label>
            <Input
              id="module-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="module-order">Sort order</Label>
            <Input
              id="module-order"
              type="number"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? 'Creating…' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
