import { useLocation } from 'react-router-dom'
import { ContentPanel } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { resolveNavIcon } from '@/constants/navigation'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import CustomerComplaintsScreen from '@/screens/Dashboard/Pes/CustomerComplaints'
import JobCardStatusScreen from '@/screens/Dashboard/Pes/JobCardStatus'
import JobCardByIdScreen from '@/screens/Dashboard/Pes/JobCardStatus/JobCardById'

function titleFromPath(pathname: string) {
  const slug = pathname.split('/').filter(Boolean).at(-1) ?? 'pes'
  return slug
    .split('-')
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ')
}

export default function PesModuleScreen() {
  const location = useLocation()
  const { modules } = usePermissions()
  const menu = modules
    .flatMap((module) => module.menus.map((item) => ({ moduleName: module.name, ...item })))
    .find((item) => item.path && (location.pathname === item.path || location.pathname.startsWith(`${item.path}/`)))

  const title = menu?.name ?? titleFromPath(location.pathname)
  const Icon = resolveNavIcon(menu?.icon)
  usePageTitle(title)

  if (/customer-complaint|control-complaint/i.test(location.pathname)) {
    return <CustomerComplaintsScreen />
  }

  if (/job-card-status\/[^/]+/i.test(location.pathname)) {
    return <JobCardByIdScreen />
  }

  if (/job-card-status/i.test(location.pathname)) {
    return <JobCardStatusScreen />
  }

  return (
    <div className="space-y-0">
      <PageHeader
        icon={Icon}
        title={title}
        description={menu ? `${menu.moduleName} workspace.` : 'PES workspace.'}
        showDocs={false}
      />
      <ContentPanel>
        <div className="bg-white p-6 text-sm text-[var(--cf-text-muted)]">
          This PES screen is available at <code className="font-mono">{location.pathname}</code>.
        </div>
      </ContentPanel>
    </div>
  )
}
