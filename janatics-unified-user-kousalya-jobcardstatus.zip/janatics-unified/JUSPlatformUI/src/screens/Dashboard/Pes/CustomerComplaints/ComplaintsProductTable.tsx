import type {
  ComplaintsProductRowDto,
  ComplaintsProductSlaCountsDto,
  ComplaintsProductTotalDto,
} from '@/api/customerComplaints'
import { formatUnits, toNum } from '@/api/customerComplaints'
import { InfoHint, InfoHintSection } from '@/components/ui/info-hint'
import { Button } from '@/components/ui/button'

export function ComplaintsProductTable({
  rows,
  totals,
  page,
  pageSize,
  totalPages,
  onPageChange,
}: {
  rows: ComplaintsProductRowDto[]
  totals: ComplaintsProductTotalDto
  page: number | string
  pageSize: number | string
  totalPages: number
  onPageChange: (page: number) => void
}) {
  const currentPage = toNum(page)
  const size = toNum(pageSize)
  return (
    <div className="overflow-hidden rounded-lg border border-[var(--cf-border)] bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-[var(--cf-border)] px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-[var(--cf-text-primary)]">
          Product-wise Complaint Summary (WTD)
        </h2>
        <InfoHint title="Product-wise Complaint Summary" tooltip="Orders delivered and SLA split by product code.">
          <InfoHintSection heading="How it is calculated">
            Complaints group by item number. Orders delivered group by ordered item. Complaint rate is complaints
            divided by invoiced quantity, times 100.
          </InfoHintSection>
        </InfoHint>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[56rem] text-left text-sm">
          <thead className="bg-[var(--cf-surface-hover)] text-xs font-medium text-[var(--cf-text-muted)]">
            <tr>
              <th className="px-3 py-2" rowSpan={2}>
                #
              </th>
              <th className="px-3 py-2" rowSpan={2}>
                Product Code
              </th>
              <th className="px-3 py-2" rowSpan={2}>
                Product Description
              </th>
              <th className="px-3 py-2" rowSpan={2}>
                Orders Delivered (WTD)
              </th>
              <th className="px-3 py-2" rowSpan={2}>
                Total Complaints (WTD)
              </th>
              <th className="px-3 py-2 text-center" colSpan={2}>
                Solved Within SLA
              </th>
              <th className="px-3 py-2 text-center" colSpan={2}>
                Open Within SLA
              </th>
              <th className="px-3 py-2 text-center" colSpan={2}>
                Open / Breached SLA
              </th>
              <th className="px-3 py-2" rowSpan={2}>
                Complaint Rate (%)
              </th>
            </tr>
            <tr>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">%</th>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">%</th>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">%</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--cf-border)]">
            {rows.length === 0 ? (
              <tr>
                <td colSpan={12} className="px-3 py-8 text-center text-[var(--cf-text-muted)]">
                  No complaints or deliveries for this week.
                </td>
              </tr>
            ) : (
              rows.map((row) => (
                <tr key={`${row.rank}-${row.productCode}`} className="hover:bg-[var(--cf-surface-hover)]/70">
                  <td className="px-3 py-2 tabular-nums text-[var(--cf-text-muted)]">{row.rank}</td>
                  <td className="px-3 py-2 font-medium text-[var(--cf-text-primary)]">{row.productCode || '—'}</td>
                  <td className="px-3 py-2 text-[var(--cf-text-secondary)]">{row.productDescription}</td>
                  <td className="px-3 py-2 tabular-nums">{formatUnits(row.ordersDelivered)}</td>
                  <td className="px-3 py-2 tabular-nums">{toNum(row.totalComplaints)}</td>
                  <SlaCells counts={row.solvedWithinSla} />
                  <SlaCells counts={row.openWithinSla} />
                  <SlaCells counts={row.openBreachedSla} />
                  <td className="px-3 py-2 tabular-nums">{toNum(row.complaintRatePct).toFixed(2)}%</td>
                </tr>
              ))
            )}
          </tbody>
          <tfoot className="border-t border-[var(--cf-border)] bg-slate-50 font-semibold">
            <tr>
              <td className="px-3 py-2" colSpan={3}>
                Total
              </td>
              <td className="px-3 py-2 tabular-nums">{formatUnits(totals.ordersDelivered)}</td>
              <td className="px-3 py-2 tabular-nums">{toNum(totals.totalComplaints)}</td>
              <SlaCells counts={totals.solvedWithinSla} />
              <SlaCells counts={totals.openWithinSla} />
              <SlaCells counts={totals.openBreachedSla} />
              <td className="px-3 py-2 tabular-nums">{toNum(totals.complaintRatePct).toFixed(2)}%</td>
            </tr>
          </tfoot>
        </table>
      </div>
      <div className="flex items-center justify-end gap-2 border-t border-[var(--cf-border)] px-4 py-2.5 text-xs text-[var(--cf-text-muted)]">
        <Button type="button" variant="outline" size="sm" disabled={currentPage <= 1} onClick={() => onPageChange(currentPage - 1)}>
          ‹
        </Button>
        <span className="inline-flex size-7 items-center justify-center rounded bg-[var(--cf-blue)] text-white">
          {currentPage}
        </span>
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={currentPage >= totalPages}
          onClick={() => onPageChange(currentPage + 1)}
        >
          ›
        </Button>
        <span>{size} / page</span>
      </div>
    </div>
  )
}

function SlaCells({ counts }: { counts: ComplaintsProductSlaCountsDto }) {
  return (
    <>
      <td className="px-3 py-2 tabular-nums">{toNum(counts.count)}</td>
      <td className="px-3 py-2 tabular-nums">{toNum(counts.pct).toFixed(1)}%</td>
    </>
  )
}
