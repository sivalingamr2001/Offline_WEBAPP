import type { ComplaintsSlaGaugeDto } from '@/api/customerComplaints'
import { toNum } from '@/api/customerComplaints'
import { InfoHint, InfoHintSection } from '@/components/ui/info-hint'
import { cn } from '@/utils/cn'

const CX = 140
const CY = 128
const RADIUS = 96
const STROKE = 18

export function ComplaintsSlaGauge({ sla }: { sla: ComplaintsSlaGaugeDto }) {
  const pct = clampPct(toNum(sla.withinSlaPct))
  const previous = toNum(sla.previousWithinSlaPct)
  const delta = toNum(sla.deltaPct)
  const target = toNum(sla.targetPct)
  const needleInner = polar(RADIUS - STROKE * 0.9, pct)
  const needleOuter = polar(RADIUS + STROKE * 0.4, pct)

  return (
    <div className="rounded-none border border-[var(--cf-border)] bg-white shadow-sm">
      <div className="flex items-center gap-1.5 px-4 pt-4">
        <h2 className="text-[11px] font-semibold tracking-[0.08em] text-[var(--cf-text-primary)] uppercase">
          SLA Performance (WTD)
        </h2>
        <InfoHint title="SLA Performance" tooltip="Share of complaints solved within SLA versus a 90% target.">
          <InfoHintSection heading="How it is calculated">
            Solved within SLA divided by total complaints this week, times 100. Target is {target}%.
          </InfoHintSection>
        </InfoHint>
      </div>
      <div className="flex flex-col items-center px-4 pt-1 pb-5">
        <svg
          viewBox="0 0 280 168"
          className="h-[11.5rem] w-full max-w-[18rem]"
          role="img"
          aria-label={`${pct.toFixed(1)} percent within SLA`}
        >
          <path d={arc(0, 78)} fill="none" stroke="#22c55e" strokeWidth={STROKE} />
          <path d={arc(78, 89)} fill="none" stroke="#f59e0b" strokeWidth={STROKE} />
          <path d={arc(89, 100)} fill="none" stroke="#ef4444" strokeWidth={STROKE} />
          <line
            x1={needleInner.x}
            y1={needleInner.y}
            x2={needleOuter.x}
            y2={needleOuter.y}
            stroke="#0f172a"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <text x={CX} y={CY - 42} textAnchor="middle" fill="#0f172a" fontSize="28" fontWeight="700">
            {pct.toFixed(1)}%
          </text>
          <text x={CX} y={CY - 20} textAnchor="middle" fill="#64748b" fontSize="12">
            Within SLA
          </text>
          <text x={CX - RADIUS} y={CY + 20} textAnchor="middle" fill="#94a3b8" fontSize="11">
            0%
          </text>
          <text x={CX + RADIUS} y={CY + 20} textAnchor="middle" fill="#94a3b8" fontSize="11">
            100%
          </text>
        </svg>
        <p className="mt-1 text-xs text-[var(--cf-text-muted)]">
          vs Last WTD: {previous.toFixed(1)}%{' '}
          <span className={cn('font-semibold', delta >= 0 ? 'text-emerald-600' : 'text-red-600')}>
            {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(1)}%
          </span>
        </p>
        <p className="mt-1 inline-flex items-center gap-1 text-xs text-[var(--cf-text-muted)]">
          SLA Target: ≥ {target}%{' '}
          <InfoHint
            title="SLA Target"
            tooltip="At least 90% of complaints should be solved within the promised completion date."
          >
            <InfoHintSection heading="Target">
              At least 90% of complaints should be closed on or before the target completion date.
            </InfoHintSection>
          </InfoHint>
        </p>
      </div>
    </div>
  )
}

function clampPct(value: number) {
  if (Number.isNaN(value)) return 0
  return Math.min(Math.max(value, 0), 100)
}

function polar(radius: number, pct = 0) {
  const theta = Math.PI * (1 - clampPct(pct) / 100)
  return { x: CX + Math.cos(theta) * radius, y: CY - Math.sin(theta) * radius }
}

function arc(fromPct: number, toPct: number) {
  const start = polar(RADIUS, fromPct)
  const end = polar(RADIUS, toPct)
  return `M ${start.x} ${start.y} A ${RADIUS} ${RADIUS} 0 0 1 ${end.x} ${end.y}`
}
