import type { ComplaintsTrendPointDto } from '@/api/customerComplaints'
import { toNum } from '@/api/customerComplaints'
import { InfoHint, InfoHintSection } from '@/components/ui/info-hint'

export function ComplaintsTrendChart({ points }: { points: ComplaintsTrendPointDto[] }) {
  const maxCount = Math.max(
    ...points.map(
      (point) => toNum(point.solvedWithinSla) + toNum(point.openWithinSla) + toNum(point.openBreachedSla),
    ),
    1,
  )
  const maxRate = Math.max(...points.map((point) => toNum(point.complaintRatePct)), 0.25)
  const width = 560
  const height = 220
  const pad = { left: 36, right: 40, top: 16, bottom: 36 }
  const innerW = width - pad.left - pad.right
  const innerH = height - pad.top - pad.bottom
  const barSlot = innerW / Math.max(points.length, 1)
  const linePoints = points.map((point, index) => {
    const x = pad.left + barSlot * index + barSlot / 2
    const y = pad.top + innerH - (toNum(point.complaintRatePct) / maxRate) * innerH
    return `${x},${y}`
  })

  return (
    <div className="rounded-lg border border-[var(--cf-border)] bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-[var(--cf-border)] px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-[var(--cf-text-primary)]">Complaints Trend (WTD)</h2>
        <InfoHint title="Complaints Trend" tooltip="Daily stacked complaint counts and complaint rate for the week.">
          <InfoHintSection heading="What it shows">
            Solved, open, and breached complaints by day, with complaint rate overlay.
          </InfoHintSection>
        </InfoHint>
      </div>
      <div className="px-4 pt-3 text-[11px] text-[var(--cf-text-muted)]">
        <span className="mr-3">
          <i className="mr-1 inline-block size-2 rounded-sm bg-emerald-500" /> Solved Within SLA
        </span>
        <span className="mr-3">
          <i className="mr-1 inline-block size-2 rounded-sm bg-orange-400" /> Open Within SLA
        </span>
        <span className="mr-3">
          <i className="mr-1 inline-block size-2 rounded-sm bg-red-500" /> Open / Breached SLA
        </span>
        <span>
          <i className="mr-1 inline-block size-2 rounded-full bg-violet-600" /> Complaint Rate (%)
        </span>
      </div>
      <div className="overflow-x-auto p-4 pt-2">
        <svg viewBox={`0 0 ${width} ${height}`} className="h-56 min-w-[32rem] w-full">
          {[0, 0.5, 1].map((tick) => {
            const y = pad.top + innerH * (1 - tick)
            return (
              <g key={tick}>
                <line x1={pad.left} x2={width - pad.right} y1={y} y2={y} stroke="#e5e7eb" />
                <text x={pad.left - 8} y={y + 3} textAnchor="end" className="fill-slate-400" fontSize="10">
                  {Math.round(maxCount * tick)}
                </text>
                <text x={width - pad.right + 8} y={y + 3} className="fill-slate-400" fontSize="10">
                  {(maxRate * tick).toFixed(2)}%
                </text>
              </g>
            )
          })}
          {points.map((point, index) => {
            const solved = toNum(point.solvedWithinSla)
            const open = toNum(point.openWithinSla)
            const breached = toNum(point.openBreachedSla)
            const x = pad.left + barSlot * index + barSlot * 0.28
            const barW = barSlot * 0.44
            const hSolved = (solved / maxCount) * innerH
            const hOpen = (open / maxCount) * innerH
            const hBreach = (breached / maxCount) * innerH
            const yBreach = pad.top + innerH - hBreach
            const yOpen = yBreach - hOpen
            const ySolved = yOpen - hSolved
            return (
              <g key={point.date}>
                <rect x={x} y={yBreach} width={barW} height={hBreach} fill="#ef4444" rx="2" />
                <rect x={x} y={yOpen} width={barW} height={hOpen} fill="#fb923c" rx="2" />
                <rect x={x} y={ySolved} width={barW} height={hSolved} fill="#10b981" rx="2" />
                <text x={x + barW / 2} y={height - 8} textAnchor="middle" className="fill-slate-500" fontSize="9">
                  {point.label}
                </text>
              </g>
            )
          })}
          <polyline fill="none" stroke="#7c3aed" strokeWidth="2" points={linePoints.join(' ')} />
          {points.map((point, index) => {
            const [x, y] = linePoints[index].split(',').map(Number)
            return (
              <g key={`${point.date}-dot`}>
                <circle cx={x} cy={y} r="3" fill="#7c3aed" />
                <text x={x} y={y - 8} textAnchor="middle" className="fill-violet-700" fontSize="9">
                  {toNum(point.complaintRatePct).toFixed(2)}%
                </text>
              </g>
            )
          })}
        </svg>
      </div>
    </div>
  )
}
