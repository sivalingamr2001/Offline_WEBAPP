import type { ReactNode } from 'react'
import type { ComplaintsOverviewKpisDto } from '@/api/customerComplaints'
import { toNum } from '@/api/customerComplaints'
import { InfoHint, InfoHintSection } from '@/components/ui/info-hint'
import { cn } from '@/utils/cn'

function formatChange(value: number | string | null | undefined, suffix = '%') {
  if (value == null || Number.isNaN(Number(value))) return '—'
  const n = toNum(value)
  const abs = Math.abs(n).toFixed(1)
  const sign = n > 0 ? '+' : n < 0 ? '−' : ''
  return `${sign}${abs}${suffix}`
}

function Delta({
  previous,
  changePct,
  invert,
}: {
  previous: number | string
  changePct: number | string | null | undefined
  invert?: boolean
}) {
  const n = changePct == null ? null : toNum(changePct)
  const upIsBad = !invert
  const tone =
    n == null || n === 0
      ? 'text-[var(--cf-text-muted)]'
      : n > 0 === upIsBad
        ? 'text-red-600'
        : 'text-emerald-600'
  return (
    <p className="mt-2 text-[11px] text-[var(--cf-text-muted)]">
      vs Last WTD: {toNum(previous).toLocaleString('en-US')}{' '}
      <span className={cn('font-semibold tabular-nums', tone)}>{formatChange(n)}</span>
    </p>
  )
}

export function ComplaintsKpiStrip({ kpis }: { kpis: ComplaintsOverviewKpisDto }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
      <KpiCard
        label="Total Complaints (WTD)"
        value={String(toNum(kpis.totalComplaints.current))}
        valueClass="text-[var(--cf-text-primary)]"
        hint={`${toNum(kpis.totalComplaints.pctOfTotal).toFixed(1)}% of Total`}
        hideHint
        what="How many customer complaint records were logged this week."
        how="Counts complaint extract rows whose complaint date falls in the selected Monday–Sunday week."
      >
        <Delta previous={toNum(kpis.totalComplaints.previous)} changePct={kpis.totalComplaints.changePct} />
      </KpiCard>
      <KpiCard
        label="Solved Within SLA"
        value={String(toNum(kpis.solvedWithinSla.current))}
        valueClass="text-emerald-600"
        hint={`${toNum(kpis.solvedWithinSla.pctOfTotal).toFixed(1)}% of Total`}
        what="Complaints closed on or before the target completion date."
        how="Closed date is set and is on or before the target date (or the target is blank)."
      >
        <Delta previous={toNum(kpis.solvedWithinSla.previous)} changePct={kpis.solvedWithinSla.changePct} invert />
      </KpiCard>
      <KpiCard
        label="Open Within SLA"
        value={String(toNum(kpis.openWithinSla.current))}
        valueClass="text-orange-500"
        hint={`${toNum(kpis.openWithinSla.pctOfTotal).toFixed(1)}% of Total`}
        what="Open complaints that have not yet passed the SLA target."
        how="Close date is blank and today (week end) is on or before the target date."
      >
        <Delta previous={toNum(kpis.openWithinSla.previous)} changePct={kpis.openWithinSla.changePct} />
      </KpiCard>
      <KpiCard
        label="Open / Breached SLA"
        value={String(toNum(kpis.openBreachedSla.current))}
        valueClass="text-red-600"
        hint={`${toNum(kpis.openBreachedSla.pctOfTotal).toFixed(1)}% of Total`}
        what="Open complaints past target, or closed after the target date."
        how="Still open after the target, or closed later than the target completion date."
      >
        <Delta previous={toNum(kpis.openBreachedSla.previous)} changePct={kpis.openBreachedSla.changePct} />
      </KpiCard>
      <KpiCard
        label="Complaint Rate (WTD)"
        value={`${toNum(kpis.complaintRate.ratePct).toFixed(2)}%`}
        valueClass="text-violet-700"
        hint="Complaints / Orders Delivered"
        what="Share of delivered orders that resulted in a complaint this week."
        how="Total complaints divided by invoiced quantity in the same week, times 100."
      >
        <p className="mt-2 text-[11px] text-[var(--cf-text-muted)]">
          vs Last WTD: {toNum(kpis.complaintRate.previousRatePct).toFixed(2)}%{' '}
          <span
            className={cn(
              'font-semibold tabular-nums',
              toNum(kpis.complaintRate.deltaPp) > 0
                ? 'text-red-600'
                : toNum(kpis.complaintRate.deltaPp) < 0
                  ? 'text-emerald-600'
                  : 'text-[var(--cf-text-muted)]',
            )}
          >
            {formatChange(kpis.complaintRate.deltaPp, ' pp')}
          </span>
        </p>
      </KpiCard>
    </div>
  )
}

function KpiCard({
  label,
  value,
  valueClass,
  hint,
  hideHint,
  what,
  how,
  children,
}: {
  label: string
  value: string
  valueClass: string
  hint: string
  hideHint?: boolean
  what: string
  how: string
  children: ReactNode
}) {
  return (
    <div className="relative rounded-lg border border-[var(--cf-border)] bg-white p-4 pr-8 shadow-sm">
      <InfoHint title={label} tooltip={what} className="absolute top-2 right-2">
        <InfoHintSection heading="What it shows">{what}</InfoHintSection>
        <InfoHintSection heading="How it is calculated">{how}</InfoHintSection>
      </InfoHint>
      <p className="text-[11px] font-medium tracking-wide text-[var(--cf-text-muted)] uppercase">{label}</p>
      <p className={cn('mt-1 text-3xl font-semibold tabular-nums', valueClass)}>{value}</p>
      {hideHint ? null : <p className="mt-1 text-[11px] text-[var(--cf-text-muted)]">{hint}</p>}
      {children}
    </div>
  )
}
