import { useQuery } from '@tanstack/react-query'
import { Download, Funnel, RefreshCw } from 'lucide-react'
import { useEffect, useState } from 'react'
import { customerComplaintApi, formatLastUpdated, toNum } from '@/api/customerComplaints'
import { listOrganizations } from '@/api/organizations'
import { LoadingState } from '@/components/operate/LoadingState'
import { Button } from '@/components/ui/button'
import { Callout } from '@/components/ui/callout'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { InfoHint, InfoHintSection } from '@/components/ui/info-hint'
import { ComplaintsKpiStrip } from '@/screens/Dashboard/Pes/CustomerComplaints/ComplaintsKpiStrip'
import { ComplaintsProductTable } from '@/screens/Dashboard/Pes/CustomerComplaints/ComplaintsProductTable'
import { ComplaintsSlaGauge } from '@/screens/Dashboard/Pes/CustomerComplaints/ComplaintsSlaGauge'
import { ComplaintsTrendChart } from '@/screens/Dashboard/Pes/CustomerComplaints/ComplaintsTrendChart'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'

export default function CustomerComplaintsScreen() {
  usePageTitle('Customer Complaints')
  const filters = useCustomerComplaintFilters()
  const [weekStart, setWeekStart] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10

  const weeksQuery = useQuery({
    queryKey: ['customer-complaints', 'weeks', filters.organizationId, filters.refreshKey],
    queryFn: () => customerComplaintApi.listCustomerComplaintWeeks({ organizationId: filters.organizationId }),
    enabled: filters.orgReady,
  })

  const weeks = (weeksQuery.data ?? []).map((week) => ({
    ...week,
    weekStart: String(week.weekStart).slice(0, 10),
  }))

  useEffect(() => {
    if (!weeks.length) {
      setWeekStart('')
      return
    }
    if (!weeks.some((week) => week.weekStart === weekStart)) {
      setWeekStart(weeks[0].weekStart)
      setPage(1)
    }
  }, [weeks, weekStart])

  const query = useQuery({
    queryKey: ['customer-complaints', 'overview', weekStart, page, pageSize, filters.organizationId, filters.refreshKey],
    queryFn: () =>
      customerComplaintApi.getCustomerComplaintsOverview({
        weekStart,
        page,
        pageSize,
        organizationId: filters.organizationId,
      }),
    enabled: filters.orgReady && Boolean(weekStart),
  })

  if (!filters.orgReady || weeksQuery.isPending || (Boolean(weekStart) && query.isPending)) {
    return <LoadingState label="Loading customer complaints…" />
  }

  if (weeksQuery.isError) {
    return <Callout tone="danger">{getApiErrorMessage(weeksQuery.error) || 'Failed to load complaint weeks.'}</Callout>
  }

  if (weeks.length === 0) {
    return <Callout tone="warning">No complaint weeks are available for your assigned organizations and custodian.</Callout>
  }

  if (query.isError || !query.data) {
    return <Callout tone="danger">{getApiErrorMessage(query.error) || 'Failed to load complaints overview.'}</Callout>
  }

  const data = query.data
  const totalPages = Math.max(1, Math.ceil(toNum(data.totalProducts) / pageSize))

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold tracking-tight text-[var(--cf-text-primary)]">{data.title}</h2>
            <InfoHint
              title="Customer Complaints Overview"
              tooltip="Week-to-date complaint counts, SLA, and complaint rate versus orders delivered."
            >
              <InfoHintSection heading="What it shows">
                Product-wise customer complaints for the selected week, compared with the previous week.
              </InfoHintSection>
              <InfoHintSection heading="How it is calculated">
                Complaints are counted from leftover complaint dates. Orders delivered are invoiced quantity in the same
                week. Complaint rate is total complaints divided by quantity invoiced, times 100.
              </InfoHintSection>
            </InfoHint>
          </div>
          <p className="mt-1 text-sm text-[var(--cf-text-muted)]">{data.subtitle}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {filters.isSuperAdmin ? (
            <Select
              value={filters.organizationId ?? ''}
              onValueChange={(value) => {
                filters.setOrganizationId(value)
                setPage(1)
              }}
            >
              <SelectTrigger className="h-9 w-[14rem] bg-white shadow-sm">
                <SelectValue placeholder="Organization" />
              </SelectTrigger>
              <SelectContent align="end">
                {filters.organizations.map((org) => (
                  <SelectItem key={org.id} value={org.id}>
                    {org.code}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : null}
          <Select
            value={weekStart}
            onValueChange={(value) => {
              setWeekStart(value)
              setPage(1)
            }}
          >
            <SelectTrigger className="h-9 w-[18rem] bg-white shadow-sm">
              <SelectValue placeholder="Select week" />
            </SelectTrigger>
            <SelectContent align="end">
              {weeks.map((week) => (
                <SelectItem key={week.weekStart} value={week.weekStart}>
                  {week.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="button" variant="outline" size="sm" className="h-9 gap-1.5 bg-white">
            <Funnel className="size-3.5" aria-hidden />
            Filter
          </Button>
          <Button type="button" variant="outline" size="sm" className="h-9 gap-1.5 bg-white">
            <Download className="size-3.5" aria-hidden />
            Download
          </Button>
        </div>
      </div>

      <div className="flex justify-end text-xs text-[var(--cf-text-muted)]">
        <span>Data as on: {formatLastUpdated(data.asOf)}</span>
        <button
          type="button"
          className="ml-2 rounded p-0.5 hover:bg-blue-100/80"
          aria-label="Refresh complaints"
          onClick={() => {
            filters.bumpRefresh()
            void weeksQuery.refetch()
            void query.refetch()
          }}
        >
          <RefreshCw className="size-3.5" />
        </button>
      </div>

      <ComplaintsKpiStrip kpis={data.kpis} />

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.4fr)_minmax(16rem,0.8fr)]">
        <ComplaintsTrendChart points={data.trend} />
        <ComplaintsSlaGauge sla={data.sla} />
      </div>

      <ComplaintsProductTable
        rows={data.products}
        totals={data.totals}
        page={data.page}
        pageSize={data.pageSize}
        totalPages={totalPages}
        onPageChange={setPage}
      />

      <p className="text-xs text-[var(--cf-text-muted)]">{data.footnote}</p>
    </div>
  )
}

function useCustomerComplaintFilters() {
  const { isSuperAdmin } = usePermissions()
  const [organizationId, setOrganizationId] = useState('')
  const [refreshKey, setRefreshKey] = useState(0)

  const orgsQuery = useQuery({
    queryKey: ['organizations'],
    queryFn: () => listOrganizations({ page: 1, pageSize: 100 }),
    enabled: isSuperAdmin,
  })

  useEffect(() => {
    if (!isSuperAdmin || organizationId || !orgsQuery.data?.items?.length) return
    const preferred =
      orgsQuery.data.items.find((org) => org.code.toUpperCase() === 'JIPL') ?? orgsQuery.data.items[0]
    if (preferred) setOrganizationId(preferred.id)
  }, [isSuperAdmin, organizationId, orgsQuery.data])

  return {
    isSuperAdmin,
    organizationId: isSuperAdmin ? organizationId : undefined,
    setOrganizationId,
    organizations: orgsQuery.data?.items ?? [],
    orgReady: !isSuperAdmin || Boolean(organizationId),
    refreshKey,
    bumpRefresh: () => setRefreshKey((key) => key + 1),
  }
}
