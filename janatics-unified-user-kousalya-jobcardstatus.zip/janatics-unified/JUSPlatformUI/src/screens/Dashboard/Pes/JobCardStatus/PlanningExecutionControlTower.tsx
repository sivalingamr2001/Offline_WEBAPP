import { useMemo, useState, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import {
  AlertTriangle,
  CheckCircle2,
  CircleAlert,
  CircleCheckBig,
  ChevronRight,
  Info,
  LayoutGrid,
  RefreshCw,
  Route,
  Truck,
  X,
} from 'lucide-react'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'
import type { JourneyItem, StageBlock, StageStatus } from '@/screens/Dashboard/Pes/JobCardStatus/adaptJobCards'

function statusBadge(status: string) {
  switch (status) {
    case 'On Track':
      return 'bg-green-100 text-green-700'
    case 'At Risk':
      return 'bg-amber-100 text-amber-700'
    case 'Delayed':
      return 'bg-red-100 text-red-600'
    default:
      return 'bg-gray-100 text-gray-600'
  }
}

function stageCarClass(status: StageStatus) {
  switch (status) {
    case 'on-track':
      return 'border-green-400 bg-green-50/80'
    case 'at-risk':
      return 'border-amber-400 bg-amber-50/80'
    case 'delayed':
      return 'border-red-400 bg-red-50/80'
    default:
      return 'border-dashed border-slate-300 bg-white'
  }
}

function trackLineClass(status: StageStatus) {
  switch (status) {
    case 'on-track':
      return 'bg-green-400'
    case 'at-risk':
      return 'bg-amber-400'
    case 'delayed':
      return 'bg-red-400'
    default:
      return 'bg-slate-200'
  }
}

function TrainArrow() {
  return (
    <div className="flex shrink-0 items-center px-0.5" aria-hidden>
      <span className="h-[2px] w-3 bg-blue-500 sm:w-4" />
      <ChevronRight className="-ml-1.5 h-4 w-4 text-blue-500" />
    </div>
  )
}

function FinishFlag() {
  return (
    <div className="ml-1 flex shrink-0 items-end gap-0.5" aria-label="Finish">
      <span className="mb-0.5 h-6 w-px bg-slate-400" />
      <span
        className="mb-3 h-4 w-5 rounded-[2px] border border-slate-400 shadow-sm"
        style={{
          backgroundImage:
            'linear-gradient(45deg,#1e293b 25%,transparent 25%,transparent 75%,#1e293b 75%),linear-gradient(45deg,#1e293b 25%,#fff 25%,#fff 75%,#1e293b 75%)',
          backgroundPosition: '0 0, 4px 4px',
          backgroundSize: '8px 8px',
        }}
      />
    </div>
  )
}

function formatDisplayDate(value?: string) {
  if (!value) return undefined
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).format(date)
}

function StageTrain({ stages, compact }: { stages: StageBlock[]; compact?: boolean }) {
  const finished = stages.length > 0 && stages.every((stage) => stage.status === 'on-track')

  return (
    <div className="flex min-w-max items-center py-2">
      <Truck className="mr-0.5 h-5 w-5 shrink-0 text-blue-600" />
      {stages.map((stage, idx) => {
        const isEmpty = stage.status === 'not-started'
        const showWarning = stage.status === 'delayed' || stage.status === 'at-risk' || Boolean(stage.warning && !isEmpty)
        return (
          <div key={`${stage.name}-${idx}`} className="flex items-center">
            <TrainArrow />
            <div className="flex shrink-0 flex-col items-center">
              <div
                className={cn(
                  'relative min-w-[148px] rounded-xl border-2 px-2 pt-2.5 pb-3.5 shadow-[0_1px_2px_rgba(15,23,42,0.06)]',
                  stageCarClass(stage.status),
                )}
              >
                <div className="relative flex items-start justify-between gap-1">
                  <span className={cn('absolute top-[7px] right-6 left-6 h-[2px]', trackLineClass(stage.status))} />
                  {(['queue', 'toMove', 'scrap'] as const).map((part) => {
                    const value = part === 'queue' ? stage.queue : part === 'toMove' ? stage.toMove : stage.scrap
                    return (
                      <div key={part} className="relative z-[1] flex min-w-[40px] flex-col items-center">
                        {isEmpty ? (
                          <span className="mt-0.5 h-2.5 w-2.5 rounded-full border-2 border-slate-300 bg-white" />
                        ) : (
                          <CircleCheckBig className="h-4 w-4 rounded-full bg-white text-green-600" />
                        )}
                        <span className="mt-1 text-[8px] leading-none font-semibold tracking-wide text-slate-500 uppercase">
                          {part === 'toMove' ? 'TO MOVE' : part}
                        </span>
                        <span
                          className={cn(
                            'mt-0.5 font-mono text-[10px] leading-none font-semibold',
                            isEmpty ? 'text-slate-400' : 'text-slate-700',
                          )}
                        >
                          {value ?? '-'}
                        </span>
                      </div>
                    )
                  })}
                </div>
                <div className="absolute -bottom-2 left-1/2 flex -translate-x-1/2 justify-center">
                  {showWarning ? (
                    <span
                      className={cn(
                        'inline-flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold text-white shadow',
                        stage.status === 'delayed' ? 'bg-red-500' : 'bg-amber-500',
                      )}
                    >
                      !
                    </span>
                  ) : isEmpty ? (
                    <span className="h-2.5 w-2.5 rounded-full border border-slate-300 bg-white" />
                  ) : (
                    <CircleCheckBig className="h-4 w-4 rounded-full bg-white text-green-600" />
                  )}
                </div>
              </div>
              <p className="mt-2.5 max-w-[148px] truncate text-center text-[9px] text-slate-400" title={stage.name}>
                {stage.name}
              </p>
              {compact ? null : (
                <p className="max-w-[148px] truncate text-center text-[9px] text-slate-400" title={stage.vendorName}>
                  {stage.vendorName}
                </p>
              )}
            </div>
          </div>
        )
      })}
      {finished ? (
        <TrainArrow />
      ) : (
        <div className="mx-2 h-px min-w-16 flex-1 border-t-2 border-dashed border-slate-300" />
      )}
      <FinishFlag />
    </div>
  )
}

export function PlanningExecutionControlTower({
  rows,
  isLoading,
  error,
  onRetry,
  toolbar,
}: {
  rows: JourneyItem[]
  isLoading?: boolean
  error?: string | null
  onRetry?: () => void
  toolbar?: ReactNode
}) {
  const [expandedRow, setExpandedRow] = useState<number | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  const filteredJourneyData = useMemo(() => {
    if (!searchQuery.trim()) return rows
    const q = searchQuery.toLowerCase()
    return rows.filter(
      (row) =>
        row.item?.toLowerCase().includes(q) ||
        row.location?.toLowerCase().includes(q) ||
        row.jobId?.toLowerCase().includes(q) ||
        row.status?.toLowerCase().includes(q) ||
        row.jobCards?.some((card) => card.jobId?.toLowerCase().includes(q)) ||
        row.stages?.some(
          (stage) => stage.name?.toLowerCase().includes(q) || stage.vendorName?.toLowerCase().includes(q),
        ),
    )
  }, [rows, searchQuery])

  const totalJobs = filteredJourneyData.reduce((total, row) => total + (row.jobs ?? 1), 0)
  const onTrack = filteredJourneyData
    .filter((row) => row.status === 'On Track')
    .reduce((total, row) => total + (row.jobs ?? 1), 0)
  const atRisk = filteredJourneyData
    .filter((row) => row.status === 'At Risk')
    .reduce((total, row) => total + (row.jobs ?? 1), 0)
  const delayed = filteredJourneyData
    .filter((row) => row.status === 'Delayed')
    .reduce((total, row) => total + (row.jobs ?? 1), 0)
  const percentage = (value: number) => (totalJobs === 0 ? '0%' : `${Math.round((value / totalJobs) * 100)}%`)
  const statusData = [
    { name: 'On Track', value: onTrack, color: '#16a34a' },
    { name: 'At Risk', value: atRisk, color: '#d97706' },
    { name: 'Delayed', value: delayed, color: '#dc2626' },
  ]
  const gradient = statusData
    .filter((item) => item.value > 0)
    .map((item, index, list) => {
      const start = list.slice(0, index).reduce((sum, entry) => sum + (entry.value / totalJobs) * 100, 0)
      const end = start + (item.value / Math.max(totalJobs, 1)) * 100
      return `${item.color} ${start}% ${end}%`
    })
    .join(', ')
  const delayedOSPs = filteredJourneyData
    .flatMap((row) =>
      row.stages
        .filter((stage) => stage.status === 'delayed' || stage.status === 'at-risk')
        .map((stage) => ({ name: `${row.item} · ${stage.name}`, value: Math.abs(row.variance) })),
    )
    .sort((left, right) => right.value - left.value)
    .slice(0, 5)
  const maxDelay = Math.max(1, ...delayedOSPs.map((item) => item.value))
  const varianceBars = [
    {
      stage: 'Queue',
      value: averageQty(filteredJourneyData, 'queue'),
      color: 'bg-red-300',
    },
    {
      stage: 'To Move',
      value: averageQty(filteredJourneyData, 'toMove'),
      color: 'bg-red-500',
    },
    {
      stage: 'Scrap',
      value: averageQty(filteredJourneyData, 'scrap'),
      color: 'bg-emerald-400',
    },
  ]
  const maxVar = Math.max(1, ...varianceBars.map((item) => item.value))

  return (
    <div className="flex min-h-0 min-w-0 flex-col overflow-hidden rounded-xl border border-gray-200 bg-slate-100 font-sans text-sm">
      <header className="flex shrink-0 flex-col gap-3 bg-blue-600 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-[13px] leading-tight font-bold tracking-wide text-white uppercase">
            Planning & Execution Control Tower
          </h1>
          <p className="mt-0.5 text-[11px] text-blue-300/70">Jobs Card Train Journey</p>
        </div>
        <div className="flex min-w-0 flex-1 flex-col items-stretch gap-2 sm:max-w-xl sm:items-end">
          <div className="relative w-full">
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search items, status, location..."
              className="w-full rounded-lg border border-slate-700/80 bg-white py-1.5 pr-8 pl-3 text-xs text-black placeholder-slate-400 transition-all focus:ring-1 focus:ring-blue-400 focus:outline-none"
            />
            {searchQuery ? (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute top-1/2 right-2.5 -translate-y-1/2 text-[10px] text-slate-400 hover:text-white"
              >
                ✕
              </button>
            ) : null}
          </div>
        </div>
      </header>

      {toolbar ? <div className="border-b border-gray-200 bg-white px-3 py-2 sm:px-4">{toolbar}</div> : null}

      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-3 sm:p-4">
        {isLoading ? (
          <div className="rounded-lg border border-blue-100 bg-blue-50 px-4 py-3 text-sm text-blue-700">
            Loading control tower data...
          </div>
        ) : null}
        {error ? (
          <div className="flex items-center justify-between gap-3 rounded-lg border border-red-100 bg-red-50 px-4 py-3 text-sm text-red-700">
            <span>{error}</span>
            {onRetry ? (
              <button
                type="button"
                className="inline-flex items-center gap-1.5 font-semibold hover:text-red-900"
                onClick={onRetry}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Retry
              </button>
            ) : null}
          </div>
        ) : null}
        {!isLoading && !error && rows.length === 0 ? (
          <div className="rounded-lg border border-gray-200 bg-white px-4 py-8 text-center text-sm text-gray-500">
            No control tower records were returned.
          </div>
        ) : null}

        <div className="flex flex-wrap gap-2">
          <KpiCard
            label="Total Job Card"
            value={totalJobs}
            sub="Across all stages"
            icon={<LayoutGrid className="h-4 w-4 text-blue-600" />}
            iconBg="bg-blue-50"
          />
          <KpiCard
            label="On Track"
            value={onTrack}
            sub={percentage(onTrack)}
            icon={<CheckCircle2 className="h-4 w-4 text-green-600" />}
            iconBg="bg-green-50"
            subClass="text-green-600"
          />
          <KpiCard
            label="At Risk"
            value={atRisk}
            sub={percentage(atRisk)}
            icon={<AlertTriangle className="h-4 w-4 text-amber-600" />}
            iconBg="bg-amber-50"
            subClass="text-amber-600"
          />
          <KpiCard
            label="Delayed"
            value={delayed}
            sub={percentage(delayed)}
            icon={<CircleAlert className="h-4 w-4 text-red-600" />}
            iconBg="bg-red-50"
            subClass="text-red-600"
          />
          <KpiCard
            label="On-time Completion"
            value={percentage(onTrack)}
            sub="Current query"
            icon={<CheckCircle2 className="h-4 w-4 text-green-600" />}
            iconBg="bg-green-50"
            subClass="text-green-600"
          />
        </div>

        <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 px-4 py-2.5">
            <div className="flex items-center gap-1.5">
              <span className="text-[12px] font-bold tracking-wide text-gray-800 uppercase">
                Job Card Train Journey – All Items
              </span>
              <Info className="h-3.5 w-3.5 text-gray-400" />
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-3 text-[10px] text-gray-500">
                <LegendDot color="bg-green-500" label="On Track" />
                <LegendDot color="bg-amber-500" label="At Risk" />
                <LegendDot color="bg-red-500" label="Delayed" />
                <LegendDot color="bg-gray-300" label="Not Started" />
              </div>
              <div className="flex items-center gap-1 rounded border border-purple-200 bg-purple-50 px-2 py-0.5 text-[10px] text-purple-600">
                <Route className="h-3 w-3" />
                <span className="font-semibold">Alt. Route Available</span>
              </div>
            </div>
          </div>

          <div className="hidden items-center bg-gray-50 px-2 text-[10px] font-semibold tracking-wide text-gray-500 uppercase md:flex">
            <div className="w-6 shrink-0" />
            <div className="w-30 shrink-0 px-2 py-2">Item</div>
            <div className="w-14 shrink-0 py-2 text-center">No Of JOBS</div>
            <div className="w-14 shrink-0 py-2 text-center">St Dlyd Pend</div>
            <div className="w-24 shrink-0 py-2 text-center">Status</div>
            <div className="flex flex-1 justify-center px-2 py-2">Operation Work Station</div>
          </div>

          {filteredJourneyData.map((row) => (
            <div key={row.id} className="border-b border-gray-100 last:border-b-0">
              <div
                className={cn(
                  'flex cursor-pointer flex-col gap-2 px-2 py-2.5 transition-colors hover:bg-slate-50 md:flex-row md:items-center',
                  expandedRow === row.id ? 'bg-blue-50/30' : '',
                )}
                onClick={() => setExpandedRow((prev) => (prev === row.id ? null : row.id))}
              >
                <div className="flex items-center gap-2 md:contents">
                  <div className="flex w-6 shrink-0 justify-center text-gray-400 hover:text-blue-500">
                    <ChevronRight className={cn('h-3.5 w-3.5 transition-transform', expandedRow === row.id ? 'rotate-90' : '')} />
                  </div>
                  <div className="min-w-0 flex-1 px-2 md:w-30 md:flex-none">
                    <span className="text-[11px] leading-tight font-bold text-gray-800">{row.item}</span>
                    {row.Description ? (
                      <span className="block text-[9px] leading-tight text-gray-500">{row.Description}</span>
                    ) : null}
                    {row.location ? <span className="block text-[9px] text-gray-400">{row.location}</span> : null}
                  </div>
                  <div className="w-16 text-center font-mono text-[12px] font-semibold text-gray-700 md:w-10">
                    {row.jobs}
                  </div>
                  <div className="w-16 text-center font-mono text-[12px] font-semibold text-gray-700 md:w-14">
                    <span className={cn('rounded px-2 py-0.5 text-[12px] font-semibold', row.qtyToStore === 0 ? '' : 'bg-green-100 text-green-700')}>
                      {row.qtyToStore === 0 ? '' : row.qtyToStore}
                    </span>
                  </div>
                  <div className="flex w-24 shrink-0 items-center justify-center gap-1">
                    <span className={cn('rounded px-2 py-0.5 text-[10px] font-semibold', statusBadge(row.status))}>
                      {row.status}
                    </span>
                    {row.status === 'Delayed' ? <CircleAlert className="h-3.5 w-3.5 text-red-500" /> : null}
                  </div>
                </div>
                <div className="min-w-0 flex-1 overflow-x-auto">
                  <StageTrain stages={row.stages} />
                </div>
              </div>

              {expandedRow === row.id ? (
                <div className="border-t border-blue-100">
                  {(row.jobCards ?? [row]).map((jobCard) => (
                    <div
                      key={jobCard.wipId ?? jobCard.jobId ?? jobCard.id}
                      className="flex flex-col gap-2 border-t border-dashed border-gray-200 bg-slate-50 py-1.5 pr-2 pl-6 transition-colors hover:bg-blue-50/40 md:flex-row md:items-center md:pl-10"
                    >
                      <div className="w-36 shrink-0 px-2">
                        {jobCard.wipId ? (
                          <Link
                            to={routes.pesJobCardById(jobCard.wipId)}
                            className="text-[11px] font-semibold text-blue-600 hover:underline"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {jobCard.jobId ?? `Item ${jobCard.id}`}
                          </Link>
                        ) : (
                          <p className="text-[11px] font-semibold text-blue-600">{jobCard.jobId ?? `Item ${jobCard.id}`}</p>
                        )}
                        {jobCard.jobDate ? (
                          <p className="text-[9px] text-gray-500">{formatDisplayDate(jobCard.jobDate)}</p>
                        ) : null}
                      </div>
                      <div className="hidden w-14 shrink-0 text-center font-mono text-[11px] text-gray-600 md:block">
                        {jobCard.totalOSPs}
                      </div>
                      <div className="flex w-24 shrink-0 justify-center">
                        <span className={cn('rounded px-2 py-0.5 text-[10px] font-semibold', statusBadge(jobCard.status))}>
                          {jobCard.status}
                        </span>
                      </div>
                      <div className="min-w-0 flex-1 overflow-x-auto">
                        <StageTrain stages={jobCard.stages} />
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
          <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
            <h3 className="mb-3 text-[11px] font-bold tracking-wide text-gray-700 uppercase">Variance by Stage</h3>
            <div className="space-y-2">
              {varianceBars.map((item) => (
                <div key={item.stage}>
                  <div className="mb-1 flex justify-between text-[10px] text-gray-600">
                    <span>{item.stage}</span>
                    <span className="font-mono">{item.value.toFixed(1)}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded bg-gray-100">
                    <div className={cn('h-full', item.color)} style={{ width: `${Math.min(100, (item.value / maxVar) * 100)}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
            <h3 className="mb-3 text-[11px] font-bold tracking-wide text-gray-700 uppercase">
              Top Delayed Job Card (by Avg Variance)
            </h3>
            <div className="space-y-2.5">
              {delayedOSPs.length === 0 ? (
                <p className="text-sm text-gray-500">No delayed OSPs.</p>
              ) : (
                delayedOSPs.map((item, idx) => (
                  <div key={`${item.name}-${idx}`} className="flex items-center gap-2">
                    <span className="w-36 shrink-0 truncate text-[10px] text-gray-600">{item.name}</span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-100">
                      <div
                        className="h-2 rounded-full bg-red-500"
                        style={{ width: `${Math.min(100, (item.value / maxDelay) * 100)}%` }}
                      />
                    </div>
                    <span className="w-14 text-right font-mono text-[10px] font-semibold text-red-600">
                      +{item.value} Days
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
          <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
            <h3 className="mb-2 text-[11px] font-bold tracking-wide text-gray-700 uppercase">Jobs by Overall Status</h3>
            <div className="flex flex-col items-center gap-3 min-[420px]:flex-row">
              <div className="relative">
                <div
                  className="size-[120px] rounded-full"
                  style={{ background: `conic-gradient(${gradient || '#e2e8f0 0% 100%'})` }}
                  aria-label={`${totalJobs} jobs`}
                />
                <div className="absolute inset-0 m-5 rounded-full bg-white" />
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                  <span className="font-mono text-xl leading-none font-bold text-gray-900">{totalJobs}</span>
                  <span className="mt-0.5 text-[9px] text-gray-400">Total Jobs</span>
                </div>
              </div>
              <div className="space-y-2">
                {statusData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <span className="inline-block h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: item.color }} />
                    <div>
                      <p className="text-[10px] text-gray-600">{item.name}</p>
                      <p className="font-mono text-[11px] font-semibold text-gray-800">
                        {item.value}{' '}
                        <span className="font-normal text-gray-400">({totalJobs === 0 ? 0 : Math.round((item.value / totalJobs) * 100)}%)</span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function averageQty(rows: JourneyItem[], key: keyof Pick<StageBlock, 'queue' | 'toMove' | 'scrap'>) {
  if (rows.length === 0) return 0
  const total = rows.reduce(
    (sum, row) => sum + row.stages.reduce((inner, stage) => inner + Number.parseFloat(stage[key] ?? '0'), 0),
    0,
  )
  return total / rows.length
}

function KpiCard({
  label,
  value,
  sub,
  icon,
  iconBg,
  subClass = 'text-gray-400',
}: {
  label: string
  value: string | number
  sub: string
  icon: ReactNode
  iconBg: string
  subClass?: string
}) {
  return (
    <div className="flex min-w-[180px] flex-1 items-start gap-3 rounded-lg border border-gray-100 bg-white px-3 py-2.5 shadow-sm">
      <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${iconBg}`}>{icon}</div>
      <div className="min-w-0">
        <p className="mb-1 text-[10px] leading-none whitespace-nowrap text-gray-500">{label}</p>
        <p className="font-mono text-xl leading-none font-bold text-gray-900">{value}</p>
        <p className={`mt-0.5 text-[11px] font-semibold ${subClass}`}>{sub}</p>
      </div>
    </div>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1">
      <span className={`inline-block h-2 w-2 rounded-full ${color}`} />
      <span>{label}</span>
    </div>
  )
}

export function FilterBarActions({
  onRefresh,
  onClear,
  canClear,
}: {
  onRefresh: () => void
  onClear: () => void
  canClear: boolean
}) {
  return (
    <div className="flex gap-2">
      <button
        type="button"
        onClick={onRefresh}
        className="inline-flex items-center gap-1 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
      >
        <RefreshCw className="h-3.5 w-3.5" />
        Refresh
      </button>
      <button
        type="button"
        onClick={onClear}
        disabled={!canClear}
        className="inline-flex items-center gap-1 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
      >
        <X className="h-3.5 w-3.5" />
        Clear
      </button>
    </div>
  )
}
