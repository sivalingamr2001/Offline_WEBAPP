import type { StatusBadgeTone } from '@/components/ui/status-badge'

export const jobCardStatusLabel: Record<string, string> = {
  onTrack: 'On Track',
  atRisk: 'At Risk',
  delayed: 'Delayed',
  completed: 'Completed',
  notStarted: 'Not Started',
}

export const jobCardStatusTone: Record<string, StatusBadgeTone> = {
  onTrack: 'success',
  atRisk: 'orange',
  delayed: 'danger',
  completed: 'info',
  notStarted: 'neutral',
}

export function formatJobCardDays(value: number) {
  return `${value % 1 === 0 ? value : value.toFixed(1)}d`
}

export function formatJobCardSignedDays(value: number) {
  if (value === 0) return '0'
  const abs = Math.abs(value)
  const body = abs % 1 === 0 ? String(abs) : abs.toFixed(1)
  return `${value > 0 ? '+' : '−'}${body}`
}

export function formatJobCardDate(value?: string | null) {
  if (!value) return null
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return null
  return date.toLocaleDateString(undefined, { day: '2-digit', month: 'short' })
}
