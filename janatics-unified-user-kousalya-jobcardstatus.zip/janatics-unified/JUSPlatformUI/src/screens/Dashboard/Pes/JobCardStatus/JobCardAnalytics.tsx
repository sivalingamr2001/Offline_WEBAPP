import type { JobCardScreenDto } from '@/api/jobCardStatus'
import { toNum } from '@/api/jobCardStatus'
import { jobCardStatusLabel } from '@/screens/Dashboard/Pes/JobCardStatus/status'
import { cn } from '@/utils/cn'

const statusColor: Record<string, string> = {
  onTrack: '#10b981',
  atRisk: '#f97316',
  delayed: '#ef4444',
  completed: '#0ea5e9',
}

export function JobCardAnalytics({
  varianceByStage,
  topDelayedOsps,
  jobsByStatus,
  totalJobs,
}: Pick<JobCardScreenDto, 'varianceByStage' | 'topDelayedOsps' | 'jobsByStatus'> & { totalJobs: number }) {
  const maxVar = Math.max(1, ...varianceByStage.map((x) => Math.abs(toNum(x.avgVarianceDays))))
  const maxDelay = Math.max(1, ...topDelayedOsps.map((x) => toNum(x.avgVarianceDays)))
  const slices = jobsByStatus.filter((x) => toNum(x.count) > 0)
  const gradient = slices.length
    ? slices
        .map((slice, index) => {
          const start = slices.slice(0, index).reduce((sum, item) => sum + toNum(item.pct), 0)
          const end = start + toNum(slice.pct)
          return `${statusColor[slice.status] ?? '#94a3b8'} ${start}% ${end}%`
        })
        .join(', ')
    : '#e2e8f0 0% 100%'

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
      <section className="rounded-xl border border-[var(--cf-border)] bg-white p-4 shadow-sm">
        <h3 className="text-xs font-semibold tracking-wide text-[var(--cf-text-muted)] uppercase">
          Variance by stage (avg days)
        </h3>
        <div className="mt-3 space-y-2">
          {varianceByStage.map((row) => {
            const n = toNum(row.avgVarianceDays)
            return (
              <div key={row.stage}>
                <div className="mb-1 flex justify-between text-xs">
                  <span>{row.stage}</span>
                  <span className={n > 0 ? 'text-red-600' : n < 0 ? 'text-emerald-600' : undefined}>
                    {n > 0 ? '+' : ''}
                    {n.toFixed(1)}
                  </span>
                </div>
                <div className="h-2 overflow-hidden rounded bg-slate-100">
                  <div
                    className={cn('h-full', n >= 0 ? 'bg-red-400' : 'bg-emerald-400')}
                    style={{ width: `${Math.min(100, (Math.abs(n) / maxVar) * 100)}%` }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </section>
      <section className="rounded-xl border border-[var(--cf-border)] bg-white p-4 shadow-sm">
        <h3 className="text-xs font-semibold tracking-wide text-[var(--cf-text-muted)] uppercase">
          Top delayed OSPs (by avg variance)
        </h3>
        <div className="mt-3 space-y-2">
          {topDelayedOsps.length === 0 ? (
            <p className="text-sm text-[var(--cf-text-muted)]">No delayed OSPs.</p>
          ) : (
            topDelayedOsps.map((row) => (
              <div key={row.label}>
                <div className="mb-1 flex justify-between gap-2 text-xs">
                  <span className="truncate">{row.label}</span>
                  <span className="shrink-0 text-red-600">+{toNum(row.avgVarianceDays).toFixed(1)} days</span>
                </div>
                <div className="h-2 overflow-hidden rounded bg-slate-100">
                  <div
                    className="h-full bg-red-400"
                    style={{ width: `${Math.min(100, (toNum(row.avgVarianceDays) / maxDelay) * 100)}%` }}
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </section>
      <section className="rounded-xl border border-[var(--cf-border)] bg-white p-4 shadow-sm">
        <h3 className="text-xs font-semibold tracking-wide text-[var(--cf-text-muted)] uppercase">Jobs by overall status</h3>
        <div className="mt-4 flex flex-col items-center gap-4 min-[420px]:flex-row min-[420px]:items-center">
          <div
            className="size-24 shrink-0 rounded-full sm:size-28"
            style={{ background: `conic-gradient(${gradient})` }}
            aria-label={`${totalJobs} jobs`}
          />
          <ul className="w-full space-y-1 text-xs">
            {jobsByStatus.map((slice) => (
              <li key={slice.status} className="flex items-center gap-2">
                <span
                  className="size-2 rounded-full"
                  style={{ background: statusColor[slice.status] ?? '#94a3b8' }}
                />
                {jobCardStatusLabel[slice.status] ?? slice.status} {toNum(slice.count)} ({toNum(slice.pct).toFixed(0)}%)
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  )
}
