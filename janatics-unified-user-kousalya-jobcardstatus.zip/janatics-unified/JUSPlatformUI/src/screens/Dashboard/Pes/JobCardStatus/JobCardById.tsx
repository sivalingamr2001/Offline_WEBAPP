import { useQuery } from '@tanstack/react-query'
import { Link, useParams } from 'react-router-dom'
import { jobCardStatusApi, toNum } from '@/api/jobCardStatus'
import { LoadingState } from '@/components/operate/LoadingState'
import { Callout } from '@/components/ui/callout'
import { StatusBadge } from '@/components/ui/status-badge'
import { routes } from '@/constants/routes'
import { usePageTitle } from '@/hooks/usePageTitle'
import { getApiErrorMessage } from '@/utils/apiError'
import { Journey } from '@/screens/Dashboard/Pes/JobCardStatus/JobCardTrainTable'
import {
  formatJobCardDays,
  formatJobCardSignedDays,
  jobCardStatusLabel,
  jobCardStatusTone,
} from '@/screens/Dashboard/Pes/JobCardStatus/status'

export default function JobCardByIdScreen() {
  const { id } = useParams<{ id: string }>()
  const query = useQuery({
    queryKey: ['job-card-status', id],
    queryFn: () => jobCardStatusApi.getJobCardStatusJob(id!),
    enabled: Boolean(id),
  })

  const job = query.data
  usePageTitle(job ? job.jobNo : 'OSP Job')

  if (query.isLoading) {
    return <LoadingState label="Loading OSP job…" />
  }

  if (query.isError || !job) {
    return (
      <div className="space-y-3">
        <Link to={routes.pesJobCardStatus} className="text-sm text-[var(--cf-blue)]">
          Back to OSP jobs
        </Link>
        <Callout tone="danger">{getApiErrorMessage(query.error) || 'OSP job not found.'}</Callout>
      </div>
    )
  }

  const variance = toNum(job.varianceDays)

  return (
    <div className="min-w-0 space-y-4 sm:space-y-5">
      <Link to={routes.pesJobCardStatus} className="text-sm text-[var(--cf-blue)]">
        Back to OSP jobs
      </Link>
      <div className="flex min-w-0 flex-wrap items-center gap-3">
        <h2 className="text-lg font-semibold break-all sm:text-xl">{job.jobNo}</h2>
        <StatusBadge tone={jobCardStatusTone[job.overallStatus]} className="normal-case">
          {jobCardStatusLabel[job.overallStatus]}
        </StatusBadge>
      </div>
      <p className="text-sm text-[var(--cf-text-muted)]">
        {job.description} · {job.plant}
      </p>
      <div className="grid grid-cols-1 gap-3 min-[420px]:grid-cols-3">
        <Field label="Plan TAT" value={formatJobCardDays(toNum(job.planTatDays))} />
        <Field label="Actual TAT" value={formatJobCardDays(toNum(job.actualTatDays))} />
        <Field
          label="Variance"
          value={formatJobCardSignedDays(variance)}
          valueClass={variance > 0 ? 'text-red-600' : variance < 0 ? 'text-emerald-600' : undefined}
        />
      </div>
      <Journey operations={job.operations} />
      <div className="-mx-1 overflow-x-auto rounded-xl border border-[var(--cf-border)] bg-white">
        <table className="min-w-[36rem] w-full text-left text-sm">
          <thead className="bg-slate-50 text-[11px] font-semibold uppercase text-[var(--cf-text-muted)]">
            <tr>
              <th className="px-3 py-2">OSP</th>
              <th className="px-3 py-2">Vendor</th>
              <th className="px-3 py-2">Q / M / S / C</th>
              <th className="px-3 py-2">Lead</th>
              <th className="px-3 py-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {job.operations.map((op) => (
              <tr key={op.index} className="border-t border-[var(--cf-border)]">
                <td className="px-3 py-2">
                  {op.index} {op.name}
                </td>
                <td className="px-3 py-2">{op.vendor ?? '—'}</td>
                <td className="px-3 py-2 tabular-nums">
                  {toNum(op.qtyQueue)} / {toNum(op.qtyMove)} / {toNum(op.qtyScrap)} / {toNum(op.qtyComp)}
                </td>
                <td className="px-3 py-2">{formatJobCardDays(toNum(op.leadTimeDays))}</td>
                <td className="px-3 py-2">
                  <StatusBadge tone={jobCardStatusTone[op.status]} className="normal-case">
                    {jobCardStatusLabel[op.status]}
                  </StatusBadge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function Field({ label, value, valueClass }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="rounded-xl border border-[var(--cf-border)] bg-white px-3 py-2">
      <p className="text-[11px] text-[var(--cf-text-muted)]">{label}</p>
      <p className={`text-sm font-semibold tabular-nums ${valueClass ?? ''}`}>{value}</p>
    </div>
  )
}
