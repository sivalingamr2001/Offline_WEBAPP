import { useQuery } from '@tanstack/react-query'
import { useEffect, useMemo, useState } from 'react'
import { listOrganizations } from '@/api/organizations'
import { jobCardStatusApi } from '@/api/jobCardStatus'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'
import { adaptJobCards } from '@/screens/Dashboard/Pes/JobCardStatus/adaptJobCards'
import {
  FilterBarActions,
  PlanningExecutionControlTower,
} from '@/screens/Dashboard/Pes/JobCardStatus/PlanningExecutionControlTower'

const dateRangeOptions = [
  { value: 'last30', label: 'Last 30 Days' },
  { value: 'last90', label: 'Last 90 Days' },
  { value: 'ytd', label: 'Year to date' },
  { value: 'all', label: 'All' },
]

const ALL = '__all__'

export default function JobCardStatusScreen() {
  usePageTitle('Job Card Status')
  const filters = useJobCardFilters()
  const [dateRange, setDateRange] = useState('all')
  const [jobType, setJobType] = useState('')
  const [product, setProduct] = useState('')
  const [plant, setPlant] = useState('')

  const query = useQuery({
    queryKey: [
      'job-card-status',
      dateRange,
      jobType,
      product,
      plant,
      filters.organizationId,
      filters.refreshKey,
    ],
    queryFn: () =>
      jobCardStatusApi.getJobCardStatus({
        dateRange,
        jobType: jobType || undefined,
        product: product || undefined,
        plant: plant || undefined,
        organizationId: filters.organizationId,
      }),
    enabled: filters.orgReady,
  })

  const rows = useMemo(() => adaptJobCards(query.data?.jobs ?? []), [query.data?.jobs])
  const canClear =
    dateRange !== 'all' || Boolean(jobType || product || plant) || filters.organizationChanged

  function clearFilters() {
    setDateRange('all')
    setJobType('')
    setProduct('')
    setPlant('')
    filters.resetOrganization()
  }

  const filterOptions = {
    jobTypes: query.data?.jobTypes ?? [],
    products: query.data?.products ?? [],
    plants: query.data?.plants ?? [],
  }

  return (
    <PlanningExecutionControlTower
      rows={rows}
      isLoading={!filters.orgReady || query.isPending}
      error={query.isError ? getApiErrorMessage(query.error) || 'Failed to load OSP jobs.' : null}
      onRetry={() => void query.refetch()}
      toolbar={
        <div className="flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
          <div className="grid min-w-0 flex-1 grid-cols-1 gap-2 min-[480px]:grid-cols-2 xl:grid-cols-5">
            {filters.isSuperAdmin ? (
              <Filter
                label="Organization"
                value={filters.organizationId ?? ''}
                onChange={filters.setOrganizationId}
                options={filters.organizations.map((org) => ({ value: org.id, label: org.code }))}
                allowAll={false}
              />
            ) : null}
            <Filter
              label="Date Range"
              value={dateRange}
              onChange={setDateRange}
              options={dateRangeOptions}
              allowAll={false}
            />
            <Filter
              label="Job Type"
              value={jobType}
              onChange={setJobType}
              options={filterOptions.jobTypes.map((value) => ({ value, label: value }))}
            />
            <Filter
              label="Product"
              value={product}
              onChange={setProduct}
              options={filterOptions.products.map((value) => ({ value, label: value }))}
            />
            <Filter
              label="Plant"
              value={plant}
              onChange={setPlant}
              options={filterOptions.plants.map((value) => ({ value, label: value }))}
            />
          </div>
          <FilterBarActions onRefresh={filters.bumpRefresh} onClear={clearFilters} canClear={canClear} />
        </div>
      }
    />
  )
}

function Filter({
  label,
  value,
  onChange,
  options,
  allowAll = true,
}: {
  label: string
  value: string
  onChange: (value: string) => void
  options: { value: string; label: string }[]
  allowAll?: boolean
}) {
  const selectValue = value || ALL
  return (
    <label className="grid gap-1 text-[11px] font-medium text-gray-500">
      {label}
      <Select value={selectValue} onValueChange={(next) => onChange(next === ALL ? '' : next)}>
        <SelectTrigger className="h-8 w-full bg-white">
          <SelectValue placeholder={label} />
        </SelectTrigger>
        <SelectContent>
          {allowAll ? <SelectItem value={ALL}>All</SelectItem> : null}
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  )
}

function useJobCardFilters() {
  const { isSuperAdmin } = usePermissions()
  const [organizationId, setOrganizationId] = useState('')
  const [refreshKey, setRefreshKey] = useState(0)

  const orgsQuery = useQuery({
    queryKey: ['organizations'],
    queryFn: () => listOrganizations({ page: 1, pageSize: 100 }),
    enabled: isSuperAdmin,
  })

  const preferredOrgId =
    orgsQuery.data?.items.find((org) => org.code.toUpperCase() === 'JIPL')?.id ??
    orgsQuery.data?.items[0]?.id ??
    ''

  useEffect(() => {
    if (!isSuperAdmin || organizationId || !preferredOrgId) return
    setOrganizationId(preferredOrgId)
  }, [isSuperAdmin, organizationId, preferredOrgId])

  return {
    isSuperAdmin,
    organizationId: isSuperAdmin ? organizationId : undefined,
    setOrganizationId,
    organizations: orgsQuery.data?.items ?? [],
    orgReady: !isSuperAdmin || Boolean(organizationId),
    organizationChanged: isSuperAdmin && Boolean(preferredOrgId) && organizationId !== preferredOrgId,
    refreshKey,
    bumpRefresh: () => setRefreshKey((key) => key + 1),
    resetOrganization: () => {
      if (preferredOrgId) setOrganizationId(preferredOrgId)
    },
  }
}
