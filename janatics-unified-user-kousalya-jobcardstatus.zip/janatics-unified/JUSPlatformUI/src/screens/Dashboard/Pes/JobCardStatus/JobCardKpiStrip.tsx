import type { JobCardKpisDto } from '@/api/jobCardStatus'
import { toNum } from '@/api/jobCardStatus'
import { InfoHint, InfoHintSection } from '@/components/ui/info-hint'
import { cn } from '@/utils/cn'
import { formatJobCardSignedDays } from '@/screens/Dashboard/Pes/JobCardStatus/status'

export function JobCardKpiStrip({ kpis }: { kpis: JobCardKpisDto }) {
  const variance = toNum(kpis.avgVarianceDays)
  return (
    <div className="grid grid-cols-2 gap-2 sm:gap-3 md:grid-cols-4 xl:grid-cols-8">
      <Card label="Total OSP Jobs" value={String(toNum(kpis.totalJobs))} hint="Across all stages" />
      <Card
        label="On Track"
        value={String(toNum(kpis.onTrack))}
        valueClass="text-emerald-600"
        hint={`${toNum(kpis.onTrackPct).toFixed(0)}%`}
      />
      <Card
        label="At Risk"
        value={String(toNum(kpis.atRisk))}
        valueClass="text-orange-600"
        hint={`${toNum(kpis.atRiskPct).toFixed(0)}%`}
      />
      <Card
        label="Delayed"
        value={String(toNum(kpis.delayed))}
        valueClass="text-red-600"
        hint={`${toNum(kpis.delayedPct).toFixed(0)}%`}
      />
      <Card label="Avg Plan TAT" value={`${toNum(kpis.avgPlanTatDays).toFixed(1)} Days`} />
      <Card label="Avg Actual TAT" value={`${toNum(kpis.avgActualTatDays).toFixed(1)} Days`} />
      <Card
        label="Avg Variance"
        value={formatJobCardSignedDays(variance)}
        valueClass={variance > 0 ? 'text-red-600' : variance < 0 ? 'text-emerald-600' : undefined}
      />
      <Card
        label="On-time Completion"
        value={`${toNum(kpis.onTimeCompletionPct).toFixed(0)}%`}
        hint={`${formatJobCardSignedDays(toNum(kpis.onTimeCompletionDeltaPct))}% vs prior period`}
      />
    </div>
  )
}

function Card({
  label,
  value,
  hint,
  valueClass,
}: {
  label: string
  value: string
  hint?: string
  valueClass?: string
}) {
  return (
    <div className="min-w-0 rounded-xl border border-[var(--cf-border)] bg-white px-2.5 py-2.5 shadow-sm sm:px-3 sm:py-3">
      <div className="flex items-center gap-1">
        <p className="truncate text-[10px] font-medium text-[var(--cf-text-muted)] sm:text-[11px]">{label}</p>
        <InfoHint title={label} tooltip={label}>
          <InfoHintSection heading="Source">JAN_WIP_TEST job rows in the current filters.</InfoHintSection>
        </InfoHint>
      </div>
      <p className={cn('mt-1 text-base font-semibold tabular-nums text-[var(--cf-text-primary)] sm:text-xl', valueClass)}>{value}</p>
      {hint ? <p className="mt-1 line-clamp-2 text-[10px] text-[var(--cf-text-muted)] sm:text-[11px]">{hint}</p> : null}
    </div>
  )
}
