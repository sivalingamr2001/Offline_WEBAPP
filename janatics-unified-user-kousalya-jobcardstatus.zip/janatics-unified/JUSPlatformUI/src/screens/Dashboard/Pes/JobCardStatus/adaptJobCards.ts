import type { JobCardOperationDto, JobCardRowDto } from '@/api/jobCardStatus'
import { toNum } from '@/api/jobCardStatus'

export type StageStatus = 'on-track' | 'at-risk' | 'delayed' | 'not-started'

export type StageBlock = {
  name: string
  queue?: string
  toMove?: string
  scrap?: string
  status: StageStatus
  warning?: boolean
  vendorName: string
}

export type JourneyItem = {
  id: number
  item: string
  location: string
  totalOSPs: number
  planTAT: number
  actualTAT: number
  variance: number
  status: 'On Track' | 'At Risk' | 'Delayed'
  altRoute?: boolean
  jobs?: number
  delayedJobs?: number
  stages: StageBlock[]
  jobId?: string
  wipId?: string
  jobVariance?: number
  jobCards?: JourneyItem[]
  jobDate?: string
  Description?: string
  qtyToStore: number
}

function mapStageStatus(status: string): StageStatus {
  const value = status.toLowerCase()
  if (value.includes('delay')) return 'delayed'
  if (value.includes('risk')) return 'at-risk'
  if (value.includes('not') || value.includes('start')) return 'not-started'
  return 'on-track'
}

function mapJobStatus(status: string): JourneyItem['status'] {
  const value = status.toLowerCase()
  if (value.includes('delay')) return 'Delayed'
  if (value.includes('risk')) return 'At Risk'
  return 'On Track'
}

function itemLabel(job: JobCardRowDto) {
  return job.description.replace(/^item\s+/i, '').trim() || job.jobNo
}

function toStage(op: JobCardOperationDto): StageBlock {
  const qtyComp = toNum(op.qtyComp)
  return {
    name: op.name,
    queue: String(toNum(op.qtyQueue)),
    toMove: String(toNum(op.qtyMove)),
    scrap: String(toNum(op.qtyScrap)),
    status: mapStageStatus(op.status),
    warning: Boolean(op.processStartDate) && qtyComp <= 0,
    vendorName: op.vendor?.trim() || 'In House',
  }
}

function toJobCard(job: JobCardRowDto, index: number): JourneyItem {
  const stages = job.operations.map(toStage)
  const status = mapJobStatus(job.overallStatus)
  const qtyToStore = job.operations.reduce((sum, op) => sum + toNum(op.qtyComp), 0)
  return {
    id: Number.parseInt(job.id, 10) || index + 1,
    item: itemLabel(job),
    location: job.plant,
    totalOSPs: toNum(job.ospCount) || stages.length,
    planTAT: toNum(job.planTatDays),
    actualTAT: toNum(job.actualTatDays),
    variance: toNum(job.varianceDays),
    status,
    altRoute: Boolean(job.jobType),
    jobs: 1,
    delayedJobs: status === 'Delayed' ? 1 : 0,
    stages,
    jobId: job.jobNo,
    wipId: job.id,
    jobVariance: toNum(job.varianceDays),
    Description: job.description,
    qtyToStore,
  }
}

function sumStageValue(
  jobCards: JourneyItem[],
  stageIndex: number,
  key: keyof Pick<StageBlock, 'queue' | 'toMove' | 'scrap'>,
): string | undefined {
  const values = jobCards
    .map((jobCard) => jobCard.stages[stageIndex]?.[key])
    .filter((value): value is string => value != null && value.trim() !== '')
  if (values.length === 0) return undefined
  const total = values.reduce((sum, value) => sum + (Number.isFinite(Number(value)) ? Number(value) : 0), 0)
  return String(total)
}

function aggregateStages(jobCards: JourneyItem[]): StageBlock[] {
  const stageCount = Math.max(0, ...jobCards.map((jobCard) => jobCard.stages.length))
  return Array.from({ length: stageCount }, (_, stageIndex) => {
    const stages = jobCards
      .map((jobCard) => jobCard.stages[stageIndex])
      .filter((stage): stage is StageBlock => stage != null)
    const status: StageStatus = stages.some((stage) => stage.status === 'delayed')
      ? 'delayed'
      : stages.some((stage) => stage.status === 'at-risk')
        ? 'at-risk'
        : stages.every((stage) => stage.status === 'not-started')
          ? 'not-started'
          : 'on-track'
    return {
      name: stages[0]?.name ?? `OSP ${stageIndex + 1}`,
      queue: sumStageValue(jobCards, stageIndex, 'queue'),
      toMove: sumStageValue(jobCards, stageIndex, 'toMove'),
      scrap: sumStageValue(jobCards, stageIndex, 'scrap'),
      status,
      warning: stages.some((stage) => stage.warning),
      vendorName: stages[0]?.vendorName ?? 'In House',
    }
  })
}

export function adaptJobCards(jobs: JobCardRowDto[]): JourneyItem[] {
  const jobRows = jobs.map(toJobCard)
  const grouped = new Map<string, JourneyItem[]>()
  for (const job of jobRows) {
    const key = `${job.item}|${job.location}`
    const existing = grouped.get(key) ?? []
    existing.push(job)
    grouped.set(key, existing)
  }

  return Array.from(grouped.values())
    .map((jobCards, index) => {
      const firstJob = jobCards[0]
      const status = jobCards.some((job) => job.status === 'Delayed')
        ? 'Delayed'
        : jobCards.some((job) => job.status === 'At Risk')
          ? 'At Risk'
          : 'On Track'
      return {
        ...firstJob,
        id: index + 1,
        stages: aggregateStages(jobCards),
        status,
        totalOSPs: Math.max(...jobCards.map((job) => job.totalOSPs)),
        planTAT: Math.max(...jobCards.map((job) => job.planTAT)),
        actualTAT: Math.max(...jobCards.map((job) => job.actualTAT)),
        variance: Math.max(...jobCards.map((job) => job.variance)),
        jobs: jobCards.length,
        delayedJobs: jobCards.filter((job) => job.status === 'Delayed').length,
        jobId: undefined,
        wipId: undefined,
        jobVariance: undefined,
        qtyToStore: jobCards.reduce((sum, job) => sum + job.qtyToStore, 0),
        jobCards,
      } satisfies JourneyItem
    })
    .sort((a, b) => a.item.localeCompare(b.item))
}
