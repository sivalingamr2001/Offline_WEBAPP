import { Link } from 'react-router-dom'
import type { JobCardOperationDto, JobCardRowDto } from '@/api/jobCardStatus'
import { toNum } from '@/api/jobCardStatus'
import { StatusBadge } from '@/components/ui/status-badge'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'
import {
  formatJobCardDate,
  formatJobCardDays,
  formatJobCardSignedDays,
  jobCardStatusLabel,
  jobCardStatusTone,
} from '@/screens/Dashboard/Pes/JobCardStatus/status'

const phaseTone: Record<string, string> = {
  onTrack: 'bg-emerald-500',
  atRisk: 'bg-orange-400',
  delayed: 'bg-red-500',
  completed: 'bg-sky-500',
  notStarted: 'bg-slate-300',
}

export function JobCardTrainTable({
  jobs,
  expanded,
  onToggleExpand,
}: {
  jobs: JobCardRowDto[]
  expanded: boolean
  onToggleExpand: () => void
}) {
  return (
    <div className="overflow-hidden rounded-xl border border-[var(--cf-border)] bg-white shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--cf-border)] px-3 py-3 sm:px-4">
        <h2 className="text-xs font-semibold tracking-wide text-[var(--cf-text-primary)] uppercase sm:text-sm">
          Multi-OSP train journey — all jobs
        </h2>
        <button type="button" className="shrink-0 text-xs font-medium text-[var(--cf-blue)]" onClick={onToggleExpand}>
          {expanded ? 'Collapse all' : 'Expand all'}
        </button>
      </div>
      {jobs.length === 0 ? (
        <p className="px-4 py-10 text-sm text-[var(--cf-text-muted)]">No OSP jobs for the current filters.</p>
      ) : (
        <>
          <div className="divide-y divide-[var(--cf-border)] md:hidden">
            {jobs.map((job) => (
              <JobCardMobileRow key={job.id} job={job} expanded={expanded} />
            ))}
          </div>
          <div className="hidden overflow-x-auto md:block">
            <table className="min-w-[64rem] w-full text-left text-sm">
              <thead className="bg-slate-50 text-[11px] font-semibold tracking-wide text-[var(--cf-text-muted)] uppercase">
                <tr>
                  <th className="sticky left-0 bg-slate-50 px-3 py-2">Job info</th>
                  <th className="px-3 py-2">OSPs</th>
                  <th className="px-3 py-2">Plan TAT</th>
                  <th className="px-3 py-2">Actual TAT</th>
                  <th className="px-3 py-2">Variance</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2">Journey</th>
                </tr>
              </thead>
              <tbody>
                {jobs.map((job) => {
                  const variance = toNum(job.varianceDays)
                  return (
                    <tr key={job.id} className="border-t border-[var(--cf-border)] align-top">
                      <td className="sticky left-0 bg-white px-3 py-3">
                        <Link
                          to={routes.pesJobCardById(job.id)}
                          className="font-semibold break-all text-[var(--cf-blue)] hover:underline"
                        >
                          {job.jobNo}
                        </Link>
                        <p className="text-[var(--cf-text-secondary)]">{job.description}</p>
                        <p className="text-xs text-[var(--cf-text-muted)]">{job.plant}</p>
                      </td>
                      <td className="px-3 py-3 tabular-nums">{toNum(job.ospCount)}</td>
                      <td className="px-3 py-3 tabular-nums">{formatJobCardDays(toNum(job.planTatDays))}</td>
                      <td className="px-3 py-3 tabular-nums">{formatJobCardDays(toNum(job.actualTatDays))}</td>
                      <td
                        className={cn(
                          'px-3 py-3 tabular-nums',
                          variance > 0 ? 'text-red-600' : variance < 0 ? 'text-emerald-600' : undefined,
                        )}
                      >
                        {formatJobCardSignedDays(variance)}
                      </td>
                      <td className="px-3 py-3">
                        <StatusBadge tone={jobCardStatusTone[job.overallStatus] ?? 'neutral'} className="normal-case">
                          {jobCardStatusLabel[job.overallStatus] ?? job.overallStatus}
                        </StatusBadge>
                      </td>
                      <td className="px-3 py-3">
                        <Journey operations={job.operations} />
                        {expanded ? <QuantityLines operations={job.operations} /> : null}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}

export function Journey({ operations }: { operations: JobCardOperationDto[] }) {
  return (
    <div className="flex min-w-0 flex-wrap items-center gap-2">
      {operations.map((op) => {
        const started = formatJobCardDate(op.processStartDate)
        return (
          <div key={op.index} className="min-w-[6.5rem] flex-1 rounded-lg border border-[var(--cf-border)] px-2 py-1.5 sm:min-w-[7.5rem] sm:flex-none">
            <p className="text-[10px] font-semibold break-words text-[var(--cf-text-primary)]">
              OSP {op.index} {op.name}
            </p>
            <p className="text-[9px] text-[var(--cf-text-muted)]">
              {started ? `Proc ${started}` : 'Proc not started'}
            </p>
            <div className="mt-1 flex items-center justify-between gap-1">
              {op.phases.map((phase) => (
                <div key={phase.kind} className="flex flex-col items-center">
                  <span className={cn('size-2.5 rounded-full', phaseTone[phase.status] ?? 'bg-slate-300')} />
                  <span className="text-[9px] text-[var(--cf-text-muted)] uppercase">{phase.kind}</span>
                </div>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

function QuantityLines({ operations }: { operations: JobCardOperationDto[] }) {
  return (
    <>
      {operations.map((op) => (
        <p key={op.index} className="mt-1 text-[11px] break-words text-[var(--cf-text-muted)]">
          OSP {op.index} {op.name}: Q {toNum(op.qtyQueue)} · M {toNum(op.qtyMove)} · S {toNum(op.qtyScrap)} · C{' '}
          {toNum(op.qtyComp)}
          {formatJobCardDate(op.processStartDate) ? ` · start ${formatJobCardDate(op.processStartDate)}` : ''}
          {op.vendor ? ` · ${op.vendor}` : ''}
        </p>
      ))}
    </>
  )
}

function JobCardMobileRow({ job, expanded }: { job: JobCardRowDto; expanded: boolean }) {
  const variance = toNum(job.varianceDays)
  return (
    <article className="space-y-3 px-3 py-3">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <Link
            to={routes.pesJobCardById(job.id)}
            className="font-semibold break-all text-[var(--cf-blue)] hover:underline"
          >
            {job.jobNo}
          </Link>
          <p className="text-sm text-[var(--cf-text-secondary)]">{job.description}</p>
          <p className="text-xs text-[var(--cf-text-muted)]">{job.plant}</p>
        </div>
        <StatusBadge tone={jobCardStatusTone[job.overallStatus] ?? 'neutral'} className="shrink-0 normal-case">
          {jobCardStatusLabel[job.overallStatus] ?? job.overallStatus}
        </StatusBadge>
      </div>
      <dl className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
        <div>
          <dt className="text-[var(--cf-text-muted)]">OSPs</dt>
          <dd className="font-medium tabular-nums">{toNum(job.ospCount)}</dd>
        </div>
        <div>
          <dt className="text-[var(--cf-text-muted)]">Plan TAT</dt>
          <dd className="font-medium tabular-nums">{formatJobCardDays(toNum(job.planTatDays))}</dd>
        </div>
        <div>
          <dt className="text-[var(--cf-text-muted)]">Actual TAT</dt>
          <dd className="font-medium tabular-nums">{formatJobCardDays(toNum(job.actualTatDays))}</dd>
        </div>
        <div>
          <dt className="text-[var(--cf-text-muted)]">Variance</dt>
          <dd
            className={cn(
              'font-medium tabular-nums',
              variance > 0 ? 'text-red-600' : variance < 0 ? 'text-emerald-600' : undefined,
            )}
          >
            {formatJobCardSignedDays(variance)}
          </dd>
        </div>
      </dl>
      <Journey operations={job.operations} />
      {expanded ? <QuantityLines operations={job.operations} /> : null}
    </article>
  )
}
