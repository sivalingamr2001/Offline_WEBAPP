import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { Hash, KeyRound, Pencil, Plus } from 'lucide-react'
import { type FormEvent, useEffect, useMemo, useState } from 'react'
import { listAppModules } from '@/api/appCatalog'
import { customInstance } from '@/api/mutator'
import { getRoles } from '@/api/generated/roles/roles'
import type { PermissionDto } from '@/api/generated/models/permissionDto'
import { DataTable } from '@/components/data-table/DataTable'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { Label } from '@/components/ui/label'
import { SelectWithIcon, SelectWithIconItem } from '@/components/ui/select-with-icon'
import { usePageTitle } from '@/hooks/usePageTitle'
import { usePermissions } from '@/hooks/usePermissions'
import { getApiErrorMessage } from '@/utils/apiError'

const { listPermissions } = getRoles()

function createPermission(body: { code: string; name: string; module: string }) {
  return customInstance<PermissionDto>({
    url: '/api/v1/roles/permissions',
    method: 'POST',
    data: body,
  })
}

function updatePermission(id: string, body: { code: string; name: string; module: string }) {
  return customInstance<PermissionDto>({
    url: `/api/v1/roles/permissions/${id}`,
    method: 'PUT',
    data: body,
  })
}

export default function PermissionsScreen() {
  usePageTitle('Permissions')
  const { isSuperAdmin } = usePermissions()
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [module, setModule] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editPermission, setEditPermission] = useState<PermissionDto | null>(null)

  const catalogQuery = useQuery({
    queryKey: ['permissions', 'catalog'],
    queryFn: () => listPermissions({ page: 1, pageSize: 100 }),
  })

  const query = useQuery({
    queryKey: ['permissions', debouncedSearch, module],
    queryFn: () =>
      listPermissions({
        page: 1,
        pageSize: 100,
        search: debouncedSearch || undefined,
        module: module || undefined,
      }),
  })

  const columns = useMemo<ColumnDef<PermissionDto>[]>(
    () => [
      { accessorKey: 'name', header: 'Name' },
      {
        accessorKey: 'code',
        header: 'Code',
        cell: ({ row }) => <code className="font-mono text-sm">{row.original.code}</code>,
      },
      { accessorKey: 'module', header: 'Module' },
      {
        id: 'actions',
        header: '',
        cell: ({ row }) =>
          isSuperAdmin ? (
            <Button
              variant="ghost"
              size="sm"
              className="gap-1"
              onClick={() => setEditPermission(row.original)}
            >
              <Pencil className="size-3.5" aria-hidden />
              Edit
            </Button>
          ) : null,
      },
    ],
    [isSuperAdmin],
  )

  const items = query.data?.items ?? []
  const modules = useMemo(
    () => [...new Set((catalogQuery.data?.items ?? []).map((item) => item.module).filter(Boolean))].sort(),
    [catalogQuery.data?.items],
  )
  const isLoading = query.isLoading
  const isEmpty = !isLoading && items.length === 0 && !debouncedSearch && !module

  return (
    <div className="space-y-0">
      <PageHeader
        icon={KeyRound}
        title="Permissions"
        description="Assignable permission codes. Map them onto a role under Roles → Edit → Permissions."
        actions={
          isSuperAdmin ? (
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add permission
            </Button>
          ) : undefined
        }
      />

      <div className="border-b border-[var(--cf-border)] bg-white px-4 py-3">
        <label className="flex items-center gap-2 text-sm text-[var(--cf-text-secondary)]">
          Module
          <select
            className="h-9 rounded-md border border-[var(--cf-border)] bg-white px-2 text-sm"
            value={module}
            onChange={(e) => setModule(e.target.value)}
          >
            <option value="">All modules</option>
            {modules.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </label>
      </div>

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search by code, name, or module…"
      />

      {isLoading ? (
        <LoadingState label="Loading permissions…" />
      ) : isEmpty ? (
        <EmptyState
          icon={KeyRound}
          title="No permissions"
          description="Permission codes are seeded with the platform catalog."
          action={
            isSuperAdmin ? (
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="size-4" aria-hidden />
                Add permission
              </Button>
            ) : undefined
          }
        />
      ) : (
        <DataTable columns={columns} data={items} emptyMessage="No permissions match your search." />
      )}

      {isSuperAdmin ? <CreatePermissionDialog open={createOpen} onOpenChange={setCreateOpen} /> : null}
      {isSuperAdmin ? (
        <EditPermissionDialog
          permission={editPermission}
          open={editPermission !== null}
          onOpenChange={(open) => {
            if (!open) setEditPermission(null)
          }}
        />
      ) : null}
    </div>
  )
}

function CreatePermissionDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [code, setCode] = useState('')
  const [name, setName] = useState('')
  const [module, setModule] = useState('')
  const [error, setError] = useState<string | null>(null)

  const modulesQuery = useQuery({
    queryKey: ['app-modules'],
    queryFn: () => listAppModules({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  const moduleOptions = useMemo(() => {
    const names = (modulesQuery.data?.items ?? [])
      .filter((item) => item.isActive)
      .map((item) => item.name.trim())
      .filter(Boolean)
    return [...new Set(names)].sort((a, b) => a.localeCompare(b))
  }, [modulesQuery.data?.items])

  useEffect(() => {
    if (!open) {
      setCode('')
      setName('')
      setModule('')
      setError(null)
    }
  }, [open])

  const mutation = useMutation({
    mutationFn: createPermission,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['permissions'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    if (!module) {
      setError('Select a module.')
      return
    }
    mutation.mutate({
      code: code.trim(),
      name: name.trim(),
      module,
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Add permission
          </DialogTitle>
          <DialogDescription>
            Creates a catalog code such as jobcard.view. Then open Roles, Edit the role, and tick the
            permission under PES.
          </DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="perm-name">Name</Label>
            <InputWithIcon
              id="perm-name"
              icon={KeyRound}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="perm-code">Code</Label>
            <InputWithIcon
              id="perm-code"
              icon={Hash}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="customer.view"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="perm-module">Module</Label>
            <SelectWithIcon
              icon={Hash}
              value={module}
              onValueChange={setModule}
              disabled={modulesQuery.isLoading || moduleOptions.length === 0}
              placeholder={modulesQuery.isLoading ? 'Loading modules…' : 'Select a module'}
            >
              {moduleOptions.map((name) => (
                <SelectWithIconItem key={name} value={name}>
                  {name}
                </SelectWithIconItem>
              ))}
            </SelectWithIcon>
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending || !module || moduleOptions.length === 0}>
              {mutation.isPending ? 'Creating…' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function EditPermissionDialog({
  permission,
  open,
  onOpenChange,
}: {
  permission: PermissionDto | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [code, setCode] = useState('')
  const [name, setName] = useState('')
  const [module, setModule] = useState('')
  const [error, setError] = useState<string | null>(null)

  const modulesQuery = useQuery({
    queryKey: ['app-modules'],
    queryFn: () => listAppModules({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  const moduleOptions = useMemo(() => {
    const names = (modulesQuery.data?.items ?? [])
      .filter((item) => item.isActive)
      .map((item) => item.name.trim())
      .filter(Boolean)
    return [...new Set(names)].sort((a, b) => a.localeCompare(b))
  }, [modulesQuery.data?.items])

  useEffect(() => {
    if (permission && open) {
      setCode(permission.code)
      setName(permission.name)
      setModule(permission.module)
      setError(null)
    }
  }, [permission, open])

  const mutation = useMutation({
    mutationFn: () =>
      updatePermission(permission!.id, {
        code: code.trim(),
        name: name.trim(),
        module,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['permissions'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!permission) return
    setError(null)
    if (!module) {
      setError('Select a module.')
      return
    }
    mutation.mutate()
  }

  if (!permission) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pencil className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Edit permission
          </DialogTitle>
          <DialogDescription>
            Updates the catalog entry. Roles keep this code until you save them again.
          </DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="edit-perm-name">Name</Label>
            <InputWithIcon
              id="edit-perm-name"
              icon={KeyRound}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-perm-code">Code</Label>
            <InputWithIcon
              id="edit-perm-code"
              icon={Hash}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-perm-module">Module</Label>
            <SelectWithIcon
              icon={Hash}
              value={module}
              onValueChange={setModule}
              disabled={modulesQuery.isLoading || moduleOptions.length === 0}
              placeholder={modulesQuery.isLoading ? 'Loading modules…' : 'Select a module'}
            >
              {moduleOptions.map((item) => (
                <SelectWithIconItem key={item} value={item}>
                  {item}
                </SelectWithIconItem>
              ))}
            </SelectWithIcon>
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending || !module || moduleOptions.length === 0}>
              {mutation.isPending ? 'Saving…' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
