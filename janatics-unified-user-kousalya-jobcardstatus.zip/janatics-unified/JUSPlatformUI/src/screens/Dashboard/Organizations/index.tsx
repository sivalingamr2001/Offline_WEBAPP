import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { type ColumnDef } from '@tanstack/react-table'
import { Building2, Hash, Plus } from 'lucide-react'
import { type FormEvent, useEffect, useMemo, useState } from 'react'
import { createOrganization, createOperatingUnit, listOperatingUnits, listOrganizations, type OperatingUnitDto, type OrganizationDto } from '@/api/organizations'
import { DataTable } from '@/components/data-table/DataTable'
import { EmptyState } from '@/components/layout/EmptyState'
import { PageHeader } from '@/components/layout/PageHeader'
import { LoadingState } from '@/components/operate/LoadingState'
import { SearchBar } from '@/components/operate/SearchBar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InputWithIcon } from '@/components/ui/input-with-icon'
import { ActiveStatusBadge } from '@/components/ui/status-badge'
import { Label } from '@/components/ui/label'
import { usePageTitle } from '@/hooks/usePageTitle'
import { getApiErrorMessage } from '@/utils/apiError'

export default function OrganizationsScreen() {
  usePageTitle('Organizations')
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [createUnitOpen, setCreateUnitOpen] = useState(false)

  const query = useQuery({
    queryKey: ['organizations', debouncedSearch],
    queryFn: () => listOrganizations({ page: 1, pageSize: 50, search: debouncedSearch || undefined }),
  })

  const unitsQuery = useQuery({
    queryKey: ['operating-units'],
    queryFn: () => listOperatingUnits({ page: 1, pageSize: 100 }),
  })

  const columns = useMemo<ColumnDef<OrganizationDto>[]>(
    () => [
      { accessorKey: 'name', header: 'Name' },
      {
        accessorKey: 'code',
        header: 'Code',
        cell: ({ row }) => <code className="font-mono text-sm">{row.original.code}</code>,
      },
      {
        accessorKey: 'operatingUnitName',
        header: 'Operating unit',
        cell: ({ row }) => row.original.operatingUnitName ?? '—',
      },
      {
        accessorKey: 'unitName',
        header: 'Unit',
        cell: ({ row }) => row.original.unitName ?? '—',
      },
      {
        accessorKey: 'isActive',
        header: 'Status',
        cell: ({ row }) => <ActiveStatusBadge active={row.original.isActive} />,
      },
    ],
    [],
  )

  const unitColumns = useMemo<ColumnDef<OperatingUnitDto>[]>(
    () => [
      { accessorKey: 'name', header: 'Name' },
      {
        accessorKey: 'orgId',
        header: 'Oracle org id',
        cell: ({ row }) => <code className="font-mono text-sm">{row.original.orgId}</code>,
      },
      {
        accessorKey: 'isActive',
        header: 'Status',
        cell: ({ row }) => <ActiveStatusBadge active={row.original.isActive} />,
      },
    ],
    [],
  )

  const items = query.data?.items ?? []
  const units = unitsQuery.data?.items ?? []
  const isLoading = query.isLoading
  const isEmpty = !isLoading && items.length === 0 && !debouncedSearch

  return (
    <div className="space-y-0">
      <PageHeader
        icon={Building2}
        title="Organizations"
        description="Create operating units, then provision tenant organizations. Each org has its own Admin."
        actions={
          <>
            <Button size="sm" variant="outline" onClick={() => setCreateUnitOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add operating unit
            </Button>
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add organization
            </Button>
          </>
        }
      />

      <SearchBar
        value={search}
        onChange={setSearch}
        onSubmit={() => setDebouncedSearch(search.trim())}
        placeholder="Search by name or code…"
      />

      {isLoading ? (
        <LoadingState label="Loading organizations…" />
      ) : isEmpty ? (
        <EmptyState
          icon={Building2}
          title="No organizations yet"
          description="Provision a company. Then add an Admin user for that organization."
          action={
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add organization
            </Button>
          }
        />
      ) : (
        <DataTable columns={columns} data={items} emptyMessage="No organizations match your search." />
      )}

      <div className="border-t border-[var(--cf-border)] bg-[var(--cf-surface-hover)] px-4 py-3 text-sm font-medium text-[var(--cf-text-secondary)]">
        Operating units
      </div>
      {unitsQuery.isLoading ? (
        <LoadingState label="Loading operating units…" />
      ) : units.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No operating units yet"
          description="Create an operating unit, then link it when you add an organization."
          action={
            <Button size="sm" onClick={() => setCreateUnitOpen(true)}>
              <Plus className="size-4" aria-hidden />
              Add operating unit
            </Button>
          }
        />
      ) : (
        <DataTable columns={unitColumns} data={units} emptyMessage="No operating units." />
      )}

      <CreateOrganizationDialog open={createOpen} onOpenChange={setCreateOpen} />
      <CreateOperatingUnitDialog open={createUnitOpen} onOpenChange={setCreateUnitOpen} />
    </div>
  )
}

function CreateOrganizationDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [name, setName] = useState('')
  const [code, setCode] = useState('')
  const [operatingUnitId, setOperatingUnitId] = useState('')
  const [oracleOrgId, setOracleOrgId] = useState('')
  const [unitName, setUnitName] = useState('')
  const [error, setError] = useState<string | null>(null)

  const unitsQuery = useQuery({
    queryKey: ['operating-units'],
    queryFn: () => listOperatingUnits({ page: 1, pageSize: 100 }),
    enabled: open,
  })

  useEffect(() => {
    if (!open) {
      setName('')
      setCode('')
      setOperatingUnitId('')
      setOracleOrgId('')
      setUnitName('')
      setError(null)
    }
  }, [open])

  const mutation = useMutation({
    mutationFn: createOrganization,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['organizations'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    const parsedOracle = oracleOrgId.trim() ? Number(oracleOrgId.trim()) : null
    mutation.mutate({
      name: name.trim(),
      code: code.trim().toUpperCase(),
      operatingUnitId: operatingUnitId || null,
      oracleOrgId: parsedOracle && Number.isFinite(parsedOracle) ? parsedOracle : null,
      unitName: unitName.trim() || null,
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Add organization
          </DialogTitle>
          <DialogDescription>Creates a tenant with Admin, Manager, and DataEntryOperator roles.</DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="org-name">Name</Label>
            <InputWithIcon id="org-name" icon={Building2} value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="org-code">Code</Label>
            <InputWithIcon id="org-code" icon={Hash} value={code} onChange={(e) => setCode(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="org-ou">Operating unit</Label>
            <select
              id="org-ou"
              className="h-9 w-full rounded-md border border-[var(--cf-border)] bg-white px-2 text-sm"
              value={operatingUnitId}
              onChange={(e) => setOperatingUnitId(e.target.value)}
            >
              <option value="">None</option>
              {(unitsQuery.data?.items ?? []).map((unit) => (
                <option key={unit.id} value={unit.id}>
                  {unit.name} ({unit.orgId})
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="org-oracle">Oracle org id</Label>
            <InputWithIcon
              id="org-oracle"
              icon={Hash}
              inputMode="numeric"
              value={oracleOrgId}
              onChange={(e) => setOracleOrgId(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="org-unit">Unit name</Label>
            <InputWithIcon id="org-unit" icon={Building2} value={unitName} onChange={(e) => setUnitName(e.target.value)} />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? 'Creating…' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function CreateOperatingUnitDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [name, setName] = useState('')
  const [orgId, setOrgId] = useState('')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) {
      setName('')
      setOrgId('')
      setError(null)
    }
  }, [open])

  const mutation = useMutation({
    mutationFn: createOperatingUnit,
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['operating-units'] })
      onOpenChange(false)
    },
    onError: (err) => setError(getApiErrorMessage(err)),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    const parsed = Number(orgId.trim())
    if (!Number.isInteger(parsed) || parsed <= 0) {
      setError('Oracle org id must be a positive integer.')
      return
    }
    mutation.mutate({ orgId: parsed, name: name.trim(), isActive: true })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="size-5 text-[var(--cf-blue)]" aria-hidden />
            Add operating unit
          </DialogTitle>
          <DialogDescription>Stores the existing integer org_id mapping used for tenant scope.</DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="ou-name">Name</Label>
            <InputWithIcon id="ou-name" icon={Building2} value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ou-org-id">Oracle org id</Label>
            <InputWithIcon
              id="ou-org-id"
              icon={Hash}
              inputMode="numeric"
              value={orgId}
              onChange={(e) => setOrgId(e.target.value)}
              required
            />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? 'Creating…' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
