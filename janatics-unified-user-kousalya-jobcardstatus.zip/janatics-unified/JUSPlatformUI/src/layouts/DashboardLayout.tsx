import {
  Bell,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Home,
  LogOut,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
  Sparkles,
} from 'lucide-react'
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { AskAiSheet } from '@/components/ai/AskAiSheet'
import { AppBrand } from '@/components/layout/AppBrand'
import { NotificationTicker } from '@/components/layout/NotificationTicker'
import { UserAvatarMenu } from '@/components/layout/UserAvatarMenu'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import {
  isNavItemActive,
  isNavItemVisible,
  modulesToNavGroups,
  type NavGroup,
  type NavItem,
} from '@/constants/navigation'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'
import { useLastRouteTracker } from '@/hooks/useLastRouteTracker'
import { Button } from '@/components/ui/button'
import { cn } from '@/utils/cn'

const SIDEBAR_COLLAPSED_KEY = 'jus-sidebar-collapsed'

function SidebarTip({
  label,
  children,
  side = 'right',
  className,
}: {
  label: string
  children: ReactNode
  side?: 'top' | 'right' | 'bottom' | 'left'
  className?: string
}) {
  return (
    <div className={cn('flex justify-center', className)}>
      <Tooltip>
        <TooltipTrigger asChild>{children}</TooltipTrigger>
        <TooltipContent side={side} sideOffset={8}>
          {label}
        </TooltipContent>
      </Tooltip>
    </div>
  )
}

function NavItemLink({
  item,
  onNavigate,
  nested = false,
  collapsed = false,
}: {
  item: NavItem
  onNavigate: () => void
  nested?: boolean
  collapsed?: boolean
}) {
  const Icon = item.icon
  const link = (
    <NavLink
      to={item.to}
      end={item.end}
      aria-label={collapsed ? item.label : undefined}
      onClick={onNavigate}
      className={({ isActive }) =>
        cn(
          'flex items-center rounded-md text-[13px] font-medium transition-colors',
          collapsed
            ? 'size-9 shrink-0 justify-center p-0'
            : nested
              ? 'gap-2.5 py-2 pr-3 pl-9'
              : 'gap-2.5 px-3 py-2',
          isActive
            ? 'bg-[var(--cf-surface-hover)] text-[var(--cf-text-primary)]'
            : 'text-[var(--cf-text-secondary)] hover:bg-[var(--cf-surface-hover)]/70 hover:text-[var(--cf-text-primary)]',
        )
      }
    >
      <Icon className="size-4 shrink-0 opacity-80" strokeWidth={1.75} aria-hidden />
      {collapsed ? null : <span className="min-w-0 flex-1 truncate">{item.label}</span>}
      {!collapsed && item.badge ? (
        <span className="rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] font-semibold leading-none text-white">
          {item.badge}
        </span>
      ) : null}
    </NavLink>
  )
  return collapsed ? <SidebarTip className="w-full" label={item.label}>{link}</SidebarTip> : link
}

function NestedNavItem({
  item,
  onNavigate,
  defaultOpen,
  collapsed = false,
}: {
  item: NavItem
  onNavigate: () => void
  defaultOpen: boolean
  collapsed?: boolean
}) {
  const location = useLocation()
  const children = item.children ?? []
  const [open, setOpen] = useState(defaultOpen)
  const parentActive = isNavItemActive(item, location.pathname)

  useEffect(() => {
    if (parentActive) setOpen(true)
  }, [parentActive])

  if (collapsed) {
    return (
      <div className="flex w-full flex-col items-center space-y-0.5">
        <NavItemLink item={{ ...item, children: undefined }} onNavigate={onNavigate} collapsed />
        {children.map((child) => (
          <NavItemLink key={`${child.to}-${child.label}`} item={child} onNavigate={onNavigate} collapsed />
        ))}
      </div>
    )
  }

  const Icon = item.icon

  return (
    <div>
      <div className="flex items-center gap-0.5">
        <NavLink
          to={item.to}
          end={item.end}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn(
              'flex min-w-0 flex-1 items-center gap-2.5 rounded-md py-2 pr-2 pl-3 text-[13px] font-medium transition-colors',
              isActive || parentActive
                ? 'bg-[var(--cf-surface-hover)] text-[var(--cf-text-primary)]'
                : 'text-[var(--cf-text-secondary)] hover:bg-[var(--cf-surface-hover)]/70 hover:text-[var(--cf-text-primary)]',
            )
          }
        >
          <Icon className="size-4 shrink-0 opacity-80" strokeWidth={1.75} aria-hidden />
          <span className="truncate">{item.label}</span>
        </NavLink>
        <button
          type="button"
          aria-label={open ? `Collapse ${item.label}` : `Expand ${item.label}`}
          className="mr-1 rounded-md p-1.5 text-[var(--cf-text-muted)] hover:bg-[var(--cf-surface-hover)] hover:text-[var(--cf-text-secondary)]"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
        </button>
      </div>
      {open ? (
        <div className="mt-0.5 space-y-0.5 border-l border-[var(--cf-border)] ml-[1.35rem] pl-1">
          {children.map((child) => (
            <NavItemLink key={`${child.to}-${child.label}`} item={child} onNavigate={onNavigate} />
          ))}
        </div>
      ) : null}
    </div>
  )
}

function NavSection({
  group,
  isAdmin,
  isSuperAdmin,
  hasPermission,
  onNavigate,
  defaultOpen,
  collapsed = false,
}: {
  group: NavGroup
  isAdmin: boolean
  isSuperAdmin: boolean
  hasPermission: (code: string) => boolean
  onNavigate: () => void
  defaultOpen: boolean
  collapsed?: boolean
}) {
  const location = useLocation()
  const items = group.items.filter((item) => isNavItemVisible(item, { isAdmin, isSuperAdmin, hasPermission }))
  const [open, setOpen] = useState(defaultOpen)
  if (items.length === 0) return null

  const links = items.map((item) => {
    const visibleChildren = (item.children ?? []).filter((child) =>
      isNavItemVisible(child, { isAdmin, isSuperAdmin, hasPermission }),
    )
    if (visibleChildren.length > 0) {
      return (
        <NestedNavItem
          key={item.to}
          item={{ ...item, children: visibleChildren }}
          onNavigate={onNavigate}
          defaultOpen={isNavItemActive(item, location.pathname)}
          collapsed={collapsed}
        />
      )
    }
    return <NavItemLink key={item.to} item={item} onNavigate={onNavigate} nested={!collapsed} collapsed={collapsed} />
  })

  if (collapsed) {
    return (
      <div className="flex w-full flex-col items-center space-y-0.5 py-1">
        <div className="mx-auto my-1 w-8 border-t border-[var(--cf-border)]" />
        {links}
      </div>
    )
  }

  return (
    <div className="py-1">
      <button
        type="button"
        className="flex w-full items-center gap-1 px-3 py-1.5 text-left text-xs font-medium text-[var(--cf-text-muted)] hover:text-[var(--cf-text-secondary)]"
        onClick={() => setOpen((v) => !v)}
      >
        {open ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
        {group.label}
      </button>
      {open ? (
        <div className="mt-0.5 space-y-0.5">
          {links}
        </div>
      ) : null}
    </div>
  )
}

export function DashboardLayout() {
  useLastRouteTracker()
  const location = useLocation()
  const { logout, session } = useAuth()
  const { isAdmin, isSuperAdmin, hasPermission } = usePermissions()
  const navigate = useNavigate()
  const mainRef = useRef<HTMLElement>(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [askAiOpen, setAskAiOpen] = useState(false)
  const [navQuery, setNavQuery] = useState('')
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === '1'
    } catch {
      return false
    }
  })

  function toggleCollapsed() {
    setCollapsed((current) => {
      const next = !current
      try {
        localStorage.setItem(SIDEBAR_COLLAPSED_KEY, next ? '1' : '0')
      } catch {
        /* ignore */
      }
      return next
    })
  }

  const scrollMainToTop = () => {
    mainRef.current?.scrollTo({ top: 0, left: 0, behavior: 'auto' })
  }

  const handleNavigate = () => {
    setMobileOpen(false)
    scrollMainToTop()
  }

  useEffect(() => {
    scrollMainToTop()
  }, [location.pathname])

  const navGroups = useMemo(
    () => modulesToNavGroups(session?.modules ?? []),
    [session?.modules],
  )

  const filteredGroups = useMemo(() => {
    const q = navQuery.trim().toLowerCase()
    const source = navGroups
    if (!q) return source
    return source
      .map((group) => ({
        ...group,
        items: group.items
          .map((item) => {
            const selfMatch =
              item.label.toLowerCase().includes(q) || group.label.toLowerCase().includes(q)
            const matchedChildren = (item.children ?? []).filter(
              (child) =>
                isNavItemVisible(child, { isAdmin, isSuperAdmin, hasPermission }) &&
                (selfMatch || child.label.toLowerCase().includes(q)),
            )
            if (!isNavItemVisible(item, { isAdmin, isSuperAdmin, hasPermission })) return null
            if (selfMatch) return item
            if (matchedChildren.length > 0) return { ...item, children: matchedChildren }
            return null
          })
          .filter((item): item is NavItem => item != null),
      }))
      .filter((group) => group.items.length > 0)
  }, [hasPermission, isAdmin, isSuperAdmin, navGroups, navQuery])

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        if (collapsed) {
          setCollapsed(false)
          try {
            localStorage.setItem(SIDEBAR_COLLAPSED_KEY, '0')
          } catch {
            /* ignore */
          }
          window.setTimeout(() => document.getElementById('sidebar-quick-search')?.focus(), 0)
          return
        }
        document.getElementById('sidebar-quick-search')?.focus()
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [collapsed])

  async function handleLogout() {
    await logout()
    navigate(routes.login)
  }

  const sidebar = (iconOnly: boolean) => (
    <div className="flex h-full min-h-0 flex-col overflow-visible bg-[var(--cf-sidebar)]">
      {iconOnly ? (
        <div className="flex shrink-0 justify-center px-2 pt-3 pb-2">
          <SidebarTip className="w-full" label="Quick search">
            <button
              type="button"
              className="flex size-9 items-center justify-center rounded-md border border-[var(--cf-border)] bg-white text-[var(--cf-text-muted)]"
              aria-label="Expand sidebar to search"
              onClick={toggleCollapsed}
            >
              <Search className="size-4" strokeWidth={1.75} />
            </button>
          </SidebarTip>
        </div>
      ) : (
        <div className="shrink-0 px-3 pt-3 pb-2">
          <div className="relative">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-[var(--cf-text-muted)]"
              strokeWidth={1.75}
            />
            <input
              id="sidebar-quick-search"
              value={navQuery}
              onChange={(e) => setNavQuery(e.target.value)}
              placeholder="Quick search…"
              className="h-9 w-full rounded-md border border-[var(--cf-border)] bg-white pr-14 pl-9 text-[13px] shadow-sm placeholder:text-[var(--cf-text-muted)] focus:border-[var(--cf-blue)] focus:ring-2 focus:ring-[var(--cf-blue)]/20 focus:outline-none"
            />
            <kbd className="pointer-events-none absolute top-1/2 right-2 -translate-y-1/2 rounded border border-[var(--cf-border)] bg-[#fafafa] px-1.5 py-0.5 text-[10px] font-medium text-[var(--cf-text-muted)]">
              Ctrl K
            </kbd>
          </div>
        </div>
      )}

      <nav className={cn('min-h-0 flex-1 overflow-y-auto pb-4', iconOnly ? 'overflow-x-visible px-1' : 'px-2')}>
        {iconOnly ? (
          <SidebarTip className="w-full" label="Account home">
            <NavLink
              to={routes.dashboard}
              end
              aria-label="Account home"
              onClick={handleNavigate}
              className={({ isActive }) =>
                cn(
                  'flex px-2.5 py-3 size-9 shrink-0 items-center justify-center rounded-md text-[13px] font-medium transition-colors',
                  isActive
                    ? 'bg-[var(--cf-surface-hover)] text-[var(--cf-text-primary)]'
                    : 'text-[var(--cf-text-secondary)] hover:bg-[var(--cf-surface-hover)]/70 hover:text-[var(--cf-text-primary)]',
                )
              }
            >
              <Home className="size-4 shrink-0" strokeWidth={1.75} aria-hidden />
            </NavLink>
          </SidebarTip>
        ) : (
          <NavLink
            to={routes.dashboard}
            end
            onClick={handleNavigate}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-2.5 rounded-md px-3 py-2 text-[13px] font-medium transition-colors',
                isActive
                  ? 'bg-[var(--cf-surface-hover)] text-[var(--cf-text-primary)]'
                  : 'text-[var(--cf-text-secondary)] hover:bg-[var(--cf-surface-hover)]/70 hover:text-[var(--cf-text-primary)]',
              )
            }
          >
            <Home className="size-4 shrink-0" strokeWidth={1.75} aria-hidden />
            Account home
          </NavLink>
        )}

        {filteredGroups.map((group) => {
          const activeInGroup = group.items.some(
            (item) =>
              isNavItemVisible(item, { isAdmin, isSuperAdmin, hasPermission }) &&
              isNavItemActive(item, location.pathname),
          )
          return (
            <NavSection
              key={group.label}
              group={group}
              isAdmin={isAdmin}
              isSuperAdmin={isSuperAdmin}
              hasPermission={hasPermission}
              onNavigate={handleNavigate}
              defaultOpen={activeInGroup}
              collapsed={iconOnly}
            />
          )
        })}
      </nav>

      <div className={cn('shrink-0 border-t border-[var(--cf-border)] bg-[var(--cf-sidebar)]', iconOnly ? 'p-2' : 'p-3')}>
        {iconOnly ? (
          <SidebarTip className="w-full" label="Sign out">
            <Button
              variant="ghost"
              size="icon"
              className="mx-auto text-[var(--cf-text-secondary)]"
              aria-label="Sign out"
              onClick={handleLogout}
            >
              <LogOut className="size-4" aria-hidden />
            </Button>
          </SidebarTip>
        ) : (
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-[var(--cf-text-secondary)]"
            onClick={handleLogout}
          >
            <LogOut className="size-4" aria-hidden />
            Sign out
          </Button>
        )}
      </div>
    </div>
  )

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-[var(--cf-page)]">
      <header className="z-30 flex h-12 shrink-0 border-b border-[var(--cf-border)] bg-white">
        <div
          className={cn(
            'flex h-full min-w-0 items-center lg:shrink-0 lg:border-r lg:border-[var(--cf-border)]',
            collapsed ? 'lg:w-16 lg:justify-center lg:px-0' : 'gap-1 px-2 lg:w-[280px]',
          )}
        >
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)}>
            <Menu className="size-5" />
          </Button>
          <SidebarTip
            className="shrink-0"
            label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            side="bottom"
          >
            <Button
              variant="ghost"
              size="icon"
              className="hidden size-9 shrink-0 lg:inline-flex"
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              onClick={toggleCollapsed}
            >
              {collapsed ? <PanelLeftOpen className="size-5" /> : <PanelLeftClose className="size-5" />}
            </Button>
          </SidebarTip>
          <AppBrand
            showName={!collapsed}
            showSubtitle={!collapsed}
            className={cn('min-w-0 flex-1 overflow-hidden', collapsed && 'lg:hidden')}
          />
        </div>

        <div className="flex min-w-0 flex-1 items-center gap-3 px-3 lg:px-4">
          <NotificationTicker className="hidden min-w-0 flex-1 md:flex" />
          <div className="ml-auto flex shrink-0 items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 text-[var(--cf-text-secondary)]"
              aria-expanded={askAiOpen}
              onClick={() => setAskAiOpen(true)}
            >
              <Sparkles className="size-4" aria-hidden />
              <span className="hidden sm:inline">Ask AI</span>
            </Button>
            <Button variant="ghost" size="sm" className="hidden gap-2 text-[var(--cf-text-secondary)] sm:inline-flex">
              <CircleHelp className="size-4" aria-hidden />
              Support
            </Button>
            <Button variant="ghost" size="icon" className="relative text-[var(--cf-text-secondary)]" aria-label="Notifications">
              <Bell className="size-4" />
              <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-red-500" />
            </Button>
            <UserAvatarMenu />
          </div>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside
          className={cn(
            'hidden h-full shrink-0 overflow-visible border-r border-[var(--cf-border)] bg-[var(--cf-sidebar)] lg:block',
            collapsed ? 'w-16' : 'w-[280px]',
          )}
        >
          {sidebar(collapsed)}
        </aside>

        {mobileOpen ? (
          <div className="fixed inset-0 z-40 lg:hidden">
            <button
              className="absolute inset-0 bg-black/40"
              aria-label="Close menu"
              onClick={() => setMobileOpen(false)}
            />
            <aside className="relative z-50 flex h-full w-[260px] flex-col border-r border-[var(--cf-border)] bg-white shadow-xl">
              {sidebar(false)}
            </aside>
          </div>
        ) : null}

        <main ref={mainRef} className="min-h-0 min-w-0 flex-1 overflow-y-auto">
          <div className="min-w-0 px-3 py-4 sm:px-4 lg:px-8 lg:py-6">
            <Outlet />
          </div>
        </main>
      </div>

      <AskAiSheet open={askAiOpen} onOpenChange={setAskAiOpen} />
    </div>
  )
}
