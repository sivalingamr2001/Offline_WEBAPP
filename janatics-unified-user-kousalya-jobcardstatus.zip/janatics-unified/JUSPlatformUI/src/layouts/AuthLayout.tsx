import { Layers } from 'lucide-react'
import { Outlet } from 'react-router-dom'
import { brand } from '@/constants/brand'

export function AuthLayout() {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col bg-background">
        <header className="px-6 py-6 lg:px-10">
          <div className="flex items-center gap-3">
            <div className="flex size-11 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Layers className="size-6" aria-hidden />
            </div>
            <div>
              <p className="text-xl font-semibold tracking-tight">{brand.name}</p>
              <p className="text-sm text-muted-foreground">{brand.subtitle}</p>
            </div>
          </div>
        </header>

        <div className="flex flex-1 items-center px-6 pb-10 lg:px-10">
          <div className="w-full max-w-md">
            <Outlet />
          </div>
        </div>

        <p className="px-6 pb-6 text-sm text-muted-foreground lg:px-10">
          © {new Date().getFullYear()} {brand.copyright}
        </p>
      </div>

      <aside className="relative hidden overflow-hidden bg-gradient-to-br from-brand-cover via-brand-cover to-brand-cover-deep lg:flex lg:items-center lg:justify-center">
        <div
          className="pointer-events-none absolute inset-0 opacity-25"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)',
            backgroundSize: '24px 24px',
          }}
        />
        <div className="relative w-full max-w-lg px-10 text-center">
          <h1 className="text-4xl font-semibold tracking-tight text-white">{brand.tagline}</h1>
          <p className="mt-4 text-base text-white/85">
            Organizations, people, and roles — scoped to your workspace with role-based access.
          </p>
        </div>
      </aside>
    </div>
  )
}
