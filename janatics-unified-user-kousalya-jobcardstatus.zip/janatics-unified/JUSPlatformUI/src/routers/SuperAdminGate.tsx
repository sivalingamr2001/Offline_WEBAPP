import { type ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'

export function SuperAdminGate({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth()
  const { isSuperAdmin } = usePermissions()
  if (!isAuthenticated) return <Navigate to={routes.login} replace />
  if (!isSuperAdmin) return <Navigate to={routes.dashboard} replace />
  return children
}
