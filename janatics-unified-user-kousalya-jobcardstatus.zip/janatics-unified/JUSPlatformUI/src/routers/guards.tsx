import { Navigate, Outlet } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'
import { resolvePostLoginRoute } from '@/utils/lastRouteStorage'

export function RequireAuth() {
  const { isAuthenticated } = useAuth()
  if (!isAuthenticated) return <Navigate to={routes.login} replace />
  return <Outlet />
}

export function RequireGuest() {
  const { isAuthenticated } = useAuth()
  if (isAuthenticated) return <Navigate to={resolvePostLoginRoute()} replace />
  return <Outlet />
}

export function RequireAdmin() {
  const { isAuthenticated } = useAuth()
  const { isPrivileged } = usePermissions()
  if (!isAuthenticated) return <Navigate to={routes.login} replace />
  if (!isPrivileged) return <Navigate to={routes.dashboard} replace />
  return <Outlet />
}
