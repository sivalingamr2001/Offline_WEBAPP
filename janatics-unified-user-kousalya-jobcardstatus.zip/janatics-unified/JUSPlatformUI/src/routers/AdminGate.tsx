import { type ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'

export function AdminGate({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth()
  const { isPrivileged } = usePermissions()
  if (!isAuthenticated) return <Navigate to={routes.login} replace />
  if (!isPrivileged) return <Navigate to={routes.dashboard} replace />
  return children
}
