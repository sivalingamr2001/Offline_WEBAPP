import { lazy } from 'react'
import { createBrowserRouter, Navigate, Outlet, useParams } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { permissions } from '@/constants/permissions'
import { AuthLayout } from '@/layouts/AuthLayout'
import { DashboardLayout } from '@/layouts/DashboardLayout'
import { PortfolioLayout } from '@/modules/portfolio/layouts/PortfolioLayout'
import { SuperAdminGate } from '@/routers/SuperAdminGate'
import { MenuGate, PermissionGate } from '@/routers/PermissionGate'
import { RequireAuth, RequireGuest } from '@/routers/guards'
import RouteErrorPage from '@/screens/Error'

const SplashScreen = lazy(() => import('@/screens/Public/Splash'))
const LoginScreen = lazy(() => import('@/screens/Public/Login'))
const RegisterScreen = lazy(() => import('@/screens/Public/Register'))
const ForgotPasswordScreen = lazy(() => import('@/screens/Public/ForgotPassword'))
const ResetPasswordScreen = lazy(() => import('@/screens/Public/ResetPassword'))
const DashboardHomeScreen = lazy(() => import('@/screens/Dashboard'))
const SettingsScreen = lazy(() => import('@/screens/Dashboard/Settings'))
const UsersScreen = lazy(() => import('@/screens/Dashboard/Users'))
const UserOrganizationsScreen = lazy(() => import('@/screens/Dashboard/UserOrganizations'))
const OrganizationsScreen = lazy(() => import('@/screens/Dashboard/Organizations'))
const RolesScreen = lazy(() => import('@/screens/Dashboard/Roles'))
const PermissionsScreen = lazy(() => import('@/screens/Dashboard/Permissions'))
const ModulesScreen = lazy(() => import('@/screens/Dashboard/Modules'))
const MenusScreen = lazy(() => import('@/screens/Dashboard/Menus'))
const SystemScreen = lazy(() => import('@/screens/Dashboard/System'))
// const LogsScreen = lazy(() => import('@/screens/Dashboard/Logs'))
const CustomerComplaintsScreen = lazy(() => import('@/screens/Dashboard/Pes/CustomerComplaints'))
const PesModuleScreen = lazy(() => import('@/screens/Dashboard/Pes/Overview'))
const PortfolioOverviewScreen = lazy(() => import('@/modules/portfolio/screens/Overview'))
const PortfolioAlertsScreen = lazy(() => import('@/modules/portfolio/screens/Alerts'))
const PortfolioProductsScreen = lazy(() => import('@/modules/portfolio/screens/Products'))
const PortfolioPerformanceScreen = lazy(() => import('@/modules/portfolio/screens/Performance'))
const PortfolioReportsScreen = lazy(() => import('@/modules/portfolio/screens/Reports'))
const PortfolioSettingsScreen = lazy(() => import('@/modules/portfolio/screens/Settings'))

export const appRouter = createBrowserRouter([
  {
    element: <Outlet />,
    errorElement: <RouteErrorPage />,
    children: [
      { path: routes.home, element: <SplashScreen /> },
      {
        element: <RequireGuest />,
        children: [
          {
            element: <AuthLayout />,
            children: [
              { path: routes.login, element: <LoginScreen /> },
              { path: routes.register, element: <RegisterScreen /> },
              { path: routes.forgotPassword, element: <ForgotPasswordScreen /> },
              { path: routes.resetPassword, element: <ResetPasswordScreen /> },
            ],
          },
        ],
      },
      {
        element: <RequireAuth />,
        children: [
          {
            element: <DashboardLayout />,
            children: [
              { path: routes.dashboard, element: <DashboardHomeScreen /> },
              { path: routes.settings, element: (
                <MenuGate>
                  <SettingsScreen />
                </MenuGate>
              ) },
              {
                path: routes.organizations,
                element: (
                  <SuperAdminGate>
                    <OrganizationsScreen />
                  </SuperAdminGate>
                ),
              },
              {
                path: routes.users,
                element: (
                  <PermissionGate permission={permissions.usersRead}>
                    <UsersScreen />
                  </PermissionGate>
                ),
              },
              {
                path: routes.userOrganizations,
                element: (
                  <SuperAdminGate>
                    <UserOrganizationsScreen />
                  </SuperAdminGate>
                ),
              },
              {
                path: routes.roles,
                element: (
                  <PermissionGate permission={permissions.rolesRead}>
                    <RolesScreen />
                  </PermissionGate>
                ),
              },
              {
                path: routes.permissions,
                element: (
                  <PermissionGate permission={permissions.rolesRead}>
                    <PermissionsScreen />
                  </PermissionGate>
                ),
              },
              {
                path: routes.modules,
                element: (
                  <PermissionGate permission={permissions.modulesRead}>
                    <ModulesScreen />
                  </PermissionGate>
                ),
              },
              {
                path: routes.apps,
                element: (
                  <PermissionGate permission={permissions.modulesRead}>
                    <ModulesScreen />
                  </PermissionGate>
                ),
              },
              {
                path: routes.menus,
                element: (
                  <PermissionGate permission={permissions.menusRead}>
                    <MenusScreen />
                  </PermissionGate>
                ),
              },
              {
                path: routes.system,
                element: (
                  <MenuGate>
                    <SystemScreen />
                  </MenuGate>
                ),
              },
              // {
              //   path: routes.logs,
              //   element: (
              //     <MenuGate>
              //       <LogsScreen />
              //     </MenuGate>
              //   ),
              // },
              {
                path: '/modules/pes/control-complaints',
                element: (
                  <MenuGate>
                    <CustomerComplaintsScreen />
                  </MenuGate>
                ),
              },
              {
                path: '/modules/pes/customer-complaints',
                element: (
                  <MenuGate>
                    <CustomerComplaintsScreen />
                  </MenuGate>
                ),
              },
              {
                path: '/modules/pes/customer-complaint',
                element: (
                  <MenuGate>
                    <CustomerComplaintsScreen />
                  </MenuGate>
                ),
              },
              {
                path: '/modules/pes',
                element: (
                  <MenuGate>
                    <PesModuleScreen />
                  </MenuGate>
                ),
              },
              {
                path: '/modules/pes/*',
                element: (
                  <MenuGate>
                    <PesModuleScreen />
                  </MenuGate>
                ),
              },
              { path: '/dashboard/pes', element: <Navigate to={routes.pes} replace /> },
              { path: '/dashboard/pes/*', element: <RedirectDashboardPes /> },
              { path: routes.team, element: <Navigate to={routes.users} replace /> },
              {
                element: (
                  <MenuGate>
                    <PortfolioLayout />
                  </MenuGate>
                ),
                children: [
                  { path: routes.portfolio, element: <PortfolioOverviewScreen /> },
                  { path: routes.portfolioAlerts, element: <PortfolioAlertsScreen /> },
                  { path: routes.portfolioProducts, element: <PortfolioProductsScreen /> },
                  { path: routes.portfolioPerformance, element: <PortfolioPerformanceScreen /> },
                  { path: routes.portfolioReports, element: <PortfolioReportsScreen /> },
                  { path: routes.portfolioSettings, element: <PortfolioSettingsScreen /> },
                ],
              },
              { path: '*', element: <Navigate to={routes.dashboard} replace /> },
            ],
          },
        ],
      },
      { path: '*', element: <Navigate to={routes.home} replace /> },
    ],
  },
])

function RedirectDashboardPes() {
  const rest = useParams()['*']
  return <Navigate to={rest ? `${routes.pes}/${rest}` : routes.pes} replace />
}
