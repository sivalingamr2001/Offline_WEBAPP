import { type ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { routes } from '@/constants/routes'
import { useAuth } from '@/hooks/useAuth'
import { usePermissions } from '@/hooks/usePermissions'

type PermissionGateProps = {
  permission: string
  children: ReactNode
}

export function PermissionGate({ permission, children }: PermissionGateProps) {
  const location = useLocation()
  const { isAuthenticated, canAccessPath } = useAuth()
  const { isAdmin, isSuperAdmin, hasPermission } = usePermissions()

  if (!isAuthenticated) return <Navigate to={routes.login} replace />
  if (!isAdmin && !isSuperAdmin && !hasPermission(permission)) return <Navigate to={routes.dashboard} replace />
  if (!isAdmin && !isSuperAdmin && !canAccessPath(location.pathname)) {
    return <Navigate to={routes.dashboard} replace />
  }
  return children
}

export function MenuGate({ children }: { children: ReactNode }) {
  const location = useLocation()
  const { isAuthenticated, canAccessPath } = useAuth()

  if (!isAuthenticated) return <Navigate to={routes.login} replace />
  if (!canAccessPath(location.pathname)) return <Navigate to={routes.dashboard} replace />
  return children
}
