import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import {
  forgotPassword,
  login,
  logout as apiLogout,
  register,
  resetPassword,
  toSession,
  type ForgotPasswordRequest,
  type LoginRequest,
  type RegisterRequest,
  type ResetPasswordRequest,
} from '@/api/auth'
import {
  clearSession,
  loadSession,
  saveSession,
  type AuthSession,
} from '@/utils/tokenStorage'
import { clearLastRoute } from '@/utils/lastRouteStorage'
import { hasNavPath } from '@/constants/navigation'
import { isSuperAdminRole } from '@/constants/permissions'
import { routes } from '@/constants/routes'
import { setBugsinkUser } from '@/observability/bugsink'

type AuthContextValue = {
  session: AuthSession | null
  isAuthenticated: boolean
  login: (request: LoginRequest) => Promise<void>
  register: (request: RegisterRequest) => Promise<void>
  forgotPassword: (request: ForgotPasswordRequest) => Promise<void>
  resetPassword: (request: ResetPasswordRequest) => Promise<void>
  logout: () => Promise<void>
  hasPermission: (code: string) => boolean
  canAccessPath: (pathname: string) => boolean
  syncSession: (patch: Partial<Pick<AuthSession, 'displayName' | 'designation'>>) => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(() => loadSession())

  const applySession = useCallback((next: AuthSession | null) => {
    if (next) saveSession(next)
    else clearSession()
    setSession(next)
  }, [])

  useEffect(() => {
    setBugsinkUser(session ? { id: session.userId, roleName: session.roleName } : null)
  }, [session])

  const syncSession = useCallback((patch: Partial<Pick<AuthSession, 'displayName' | 'designation'>>) => {
    setSession((prev) => {
      if (!prev) return prev
      const next = { ...prev, ...patch }
      saveSession(next)
      return next
    })
  }, [])

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      isAuthenticated: session !== null,
      login: async (request) => {
        const response = await login(request)
        applySession(toSession(response))
      },
      register: async (request) => {
        const response = await register(request)
        applySession(toSession(response))
      },
      forgotPassword: (request) => forgotPassword(request).then(() => undefined),
      resetPassword: (request) => resetPassword(request).then(() => undefined),
      logout: async () => {
        try {
          if (session) await apiLogout()
        } finally {
          clearLastRoute()
          applySession(null)
        }
      },
      hasPermission: (code) =>
        session?.permissions.some((p) => p.toLowerCase() === code.toLowerCase()) ?? false,
      canAccessPath: (pathname) => {
        if (!session) return false
        if (pathname === routes.dashboard) return true
        if (isSuperAdminRole(session.roleName)) return true
        return hasNavPath(session.modules ?? [], pathname)
      },
      syncSession,
    }),
    [applySession, session, syncSession],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuthContext() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuthContext must be used within AuthProvider')
  return ctx
}
