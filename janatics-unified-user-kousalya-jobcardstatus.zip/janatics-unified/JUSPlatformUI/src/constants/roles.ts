import { isOrgAdminRole, isSuperAdminRole } from '@/constants/permissions'

export type RoleOption = {
  id: string
  name: string
}

export function isPrivilegedRole(name: string) {
  return isSuperAdminRole(name) || isOrgAdminRole(name)
}

/** Roles that can be assigned when inviting or editing users. SuperAdmin may assign Admin. */
export function filterAssignableRoles<T extends RoleOption>(
  roles: T[],
  options?: { allowAdmin?: boolean },
): T[] {
  return roles.filter((role) => {
    if (isSuperAdminRole(role.name)) return false
    if (isOrgAdminRole(role.name)) return options?.allowAdmin === true
    return true
  })
}

/** Roles shown on the role management screen. */
export function filterManagedRoles<T extends { name: string }>(roles: T[]): T[] {
  return roles.filter((role) => !isPrivilegedRole(role.name))
}

export function roleTypeLabel(isSystem: boolean) {
  return isSystem ? 'System' : 'Custom'
}
