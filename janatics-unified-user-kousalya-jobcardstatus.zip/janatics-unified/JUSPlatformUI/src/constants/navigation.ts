import {
  Bell,
  Briefcase,
  AppWindow,
  Building2,
  ClipboardList,
  Cpu,
  KeyRound,
  LayoutDashboard,
  LayoutGrid,
  Menu,
  Package,
  ScrollText,
  Settings,
  Shield,
  SlidersHorizontal,
  TrendingUp,
  UserCog,
  type LucideIcon,
} from 'lucide-react'
import { routes } from '@/constants/routes'

export type NavItem = {
  to: string
  label: string
  icon: LucideIcon
  adminOnly?: boolean
  platformOnly?: boolean
  hideForSuperAdmin?: boolean
  permission?: string
  end?: boolean
  badge?: number
  children?: NavItem[]
}

export type NavGroup = {
  label: string
  items: NavItem[]
}

/** @deprecated Sidebar is built from login `session.modules` only. */
export const portfolioNavChildren: NavItem[] = []

/** @deprecated Sidebar is built from login `session.modules` only. */
export const dashboardNavGroups: NavGroup[] = []

export const homeNavItem = {
  to: routes.dashboard,
  label: 'Account home',
  icon: LayoutDashboard,
} as const

export function isNavItemVisible(
  item: NavItem,
  opts: { isSuperAdmin: boolean; isAdmin: boolean; hasPermission: (code: string) => boolean },
) {
  if (item.hideForSuperAdmin && opts.isSuperAdmin) return false
  if (item.platformOnly && !opts.isSuperAdmin) return false
  if (item.adminOnly && !opts.isAdmin && !opts.isSuperAdmin) return false
  if (item.permission && !opts.isAdmin && !opts.isSuperAdmin && !opts.hasPermission(item.permission)) return false
  return true
}

export function isNavItemActive(item: NavItem, pathname: string): boolean {
  if (item.end) return pathname === item.to
  if (item.children?.length) {
    return item.children.some((child) => isNavItemActive(child, pathname)) || pathname.startsWith(item.to)
  }
  return pathname === item.to || pathname.startsWith(`${item.to}/`)
}

export type SessionNavMenu = {
  id: string
  parentId?: string | null
  code: string
  name: string
  path?: string | null
  icon?: string | null
  sortOrder: number
  permissionCode?: string | null
}

export type SessionNavModule = {
  id: string
  code: string
  name: string
  icon?: string | null
  sortOrder: number
  menus: SessionNavMenu[]
}

const iconByName: Record<string, LucideIcon> = {
  Bell,
  Briefcase,
  AppWindow,
  Building2,
  ClipboardList,
  Cpu,
  KeyRound,
  LayoutDashboard,
  LayoutGrid,
  Menu,
  Package,
  ScrollText,
  Settings,
  Shield,
  SlidersHorizontal,
  TrendingUp,
  UserCog,
}

export function resolveNavIcon(name?: string | null): LucideIcon {
  if (!name) return LayoutDashboard
  return iconByName[name] ?? LayoutDashboard
}

export function modulesToNavGroups(modules: SessionNavModule[]): NavGroup[] {
  return [...modules]
    .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name))
    .map((module) => ({
      label: module.name,
      items: toNavItems(module.menus),
    }))
    .filter((group) => group.items.length > 0)
}

function toNavItems(menus: SessionNavMenu[]): NavItem[] {
  const usable = menus.filter((menu) => menu.path && menu.path !== '/dashboard')
  const byParent = new Map<string | null, SessionNavMenu[]>()
  for (const menu of usable) {
    const key = menu.parentId ?? null
    const list = byParent.get(key) ?? []
    list.push(menu)
    byParent.set(key, list)
  }

  const seenPaths = new Set<string>()
  const roots = (byParent.get(null) ?? [])
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .filter((menu) => {
      const path = menu.path!
      if (seenPaths.has(path)) return false
      seenPaths.add(path)
      return true
    })
  return roots.map((menu) => {
    const children = (byParent.get(menu.id) ?? [])
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((child) => toNavItem(child))
    return toNavItem(menu, children.length > 0 ? children : undefined)
  })
}

function toNavItem(menu: SessionNavMenu, children?: NavItem[]): NavItem {
  return {
    to: menu.path!,
    label: menu.name,
    icon: resolveNavIcon(menu.icon),
    permission: menu.permissionCode ?? undefined,
    children,
  }
}

export function hasNavPath(modules: SessionNavModule[] | undefined, pathname: string) {
  if (!modules?.length) return false
  return modules.some((module) =>
    module.menus.some((menu) => {
      if (!menu.path) return false
      return pathname === menu.path || pathname.startsWith(`${menu.path}/`)
    }),
  )
}
