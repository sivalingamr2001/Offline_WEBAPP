export const brand = {
  name: 'Janatics Unified Suite',
  shortName: 'JUSPlatform',
  aiName: 'JUSPlatform AI',
  copyright: 'Janatics India',
  subtitle: 'Intelligent operations platform',
  description: 'Intelligent operations platform',
  tagline: 'Where your operations team connects.',
} as const
