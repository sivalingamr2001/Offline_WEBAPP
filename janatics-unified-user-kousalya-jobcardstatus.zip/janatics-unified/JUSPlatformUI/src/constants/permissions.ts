/** Mirrors JUSPlatform permission codes used for UI gating. */
export const permissions = {
  usersRead: 'user.read',
  usersWrite: 'user.write',
  rolesRead: 'role.read',
  rolesWrite: 'role.write',
  orgsRead: 'org.read',
  orgsWrite: 'org.write',
  jobsRead: 'job.read',
  jobsWrite: 'job.write',
  modulesRead: 'module.read',
  modulesWrite: 'module.write',
  menusRead: 'menu.read',
  menusWrite: 'menu.write',
  pesView: 'pes.view',
  pesEdit: 'pes.edit',
  jobCardView: 'jobcard.view',
} as const

export function isSuperAdminRole(roleName?: string | null) {
  return roleName?.toLowerCase() === 'superadmin'
}

export function isOrgAdminRole(roleName?: string | null) {
  return roleName?.toLowerCase() === 'admin'
}

export function isPrivilegedRoleName(roleName?: string | null) {
  return isSuperAdminRole(roleName) || isOrgAdminRole(roleName)
}
