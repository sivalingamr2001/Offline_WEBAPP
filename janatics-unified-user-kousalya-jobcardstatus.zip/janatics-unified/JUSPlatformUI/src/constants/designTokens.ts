export const designTokens = {
  brand: {
    name: 'Janatics Unified Suite',
    coverFrom: 'var(--brand-cover)',
    coverTo: 'var(--brand-cover-deep)',
  },
  fontFamily: {
    sans: "'Geist Sans', ui-sans-serif, system-ui, sans-serif",
    mono: 'JetBrains Mono, ui-monospace, monospace',
  },
  radius: {
    sm: '0.375rem',
    md: '0.5rem',
    lg: '0.625rem',
    xl: '0.875rem',
  },
  layout: {
    sidebarWidth: '16rem',
    headerHeight: '3.5rem',
    contentMaxWidth: '80rem',
  },
} as const
