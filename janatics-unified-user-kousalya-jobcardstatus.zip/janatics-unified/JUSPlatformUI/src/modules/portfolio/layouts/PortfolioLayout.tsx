import { Outlet } from 'react-router-dom'
import { FiltersBar } from '@/modules/portfolio/components/FiltersBar'
import { ModuleSubheader } from '@/modules/portfolio/components/ModuleSubheader'
import { PortfolioFiltersProvider } from '@/modules/portfolio/components/PortfolioFiltersContext'
import { usePageTitle } from '@/hooks/usePageTitle'

/** Content shell only — module nav lives in the shared sidebar (2-level). */
export function PortfolioLayout() {
  usePageTitle('Portfolio')

  return (
    <PortfolioFiltersProvider>
      <div className="portfolio-module -mx-4 -mt-5 space-y-0 lg:-mx-8 lg:-mt-6">
        <ModuleSubheader />
        <FiltersBar />
        <div className="px-4 py-5 lg:px-8 lg:py-6">
          <Outlet />
        </div>
      </div>
    </PortfolioFiltersProvider>
  )
}
