/** @deprecated Prefer portfolioNavChildren from `@/constants/navigation`. */
export { portfolioNavChildren as portfolioNavItems } from '@/constants/navigation'
