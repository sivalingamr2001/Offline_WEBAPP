export type ProductCategory = 'Runner' | 'Repeater' | 'Stranger'
export type AlertSeverity = 'Critical' | 'High' | 'Medium' | 'Low'
export type AlertStatus = 'New' | 'In Progress' | 'Resolved'
export type DeliveryStatus = 'On Track' | 'At Risk' | 'Behind'

export type PlantPortfolio = {
  id: string
  name: string
  theme: 'blue' | 'amber'
  categories: { name: ProductCategory; count: number; color: string }[]
  sampleProducts: { sku: string; name: string }[]
}

export type PortfolioAlert = {
  id: string
  title: string
  severity: AlertSeverity
  ageing: string
  status: AlertStatus
  plant: string
}

export type DeliveryMetric = {
  id: string
  metric: string
  plan: number
  actual: number
  completionPct: number
  varianceEa: number
  variancePct: number
  status: DeliveryStatus
}

export type QualityMetric = {
  label: string
  targetPpm: number
  actualPpm: number
  variancePpm: number
  betterThanTarget: boolean
  note: string
}

export type PortfolioProduct = {
  sku: string
  name: string
  plant: string
  category: ProductCategory
  ocq: number
  stock: number
}

export type PortfolioReport = {
  id: string
  title: string
  description: string
  period: string
}

export const portfolioLastUpdated = 'May 24, 2026 09:00 AM'

export const portfolioPlants: PlantPortfolio[] = [
  {
    id: 'AMS1',
    name: 'AMS1',
    theme: 'blue',
    categories: [
      { name: 'Runner', count: 12, color: '#2563eb' },
      { name: 'Repeater', count: 8, color: '#16a34a' },
      { name: 'Stranger', count: 5, color: '#7c3aed' },
    ],
    sampleProducts: [
      { sku: 'FG-1001', name: 'Hydraulic Cylinder' },
      { sku: 'FG-1008', name: 'Valve Block Assembly' },
      { sku: 'FG-1014', name: 'Pressure Sensor Kit' },
    ],
  },
  {
    id: 'AMS2',
    name: 'AMS2',
    theme: 'amber',
    categories: [
      { name: 'Runner', count: 9, color: '#2563eb' },
      { name: 'Repeater', count: 11, color: '#16a34a' },
      { name: 'Stranger', count: 4, color: '#7c3aed' },
    ],
    sampleProducts: [
      { sku: 'FG-2003', name: 'Gear Housing' },
      { sku: 'FG-2011', name: 'Seal Ring Set' },
      { sku: 'FG-2020', name: 'Drive Shaft' },
    ],
  },
]

export const portfolioAlerts: PortfolioAlert[] = [
  {
    id: 'PC-AL-001',
    title: 'Runner FG below OCQ threshold',
    severity: 'Critical',
    ageing: '2h 15m',
    status: 'New',
    plant: 'AMS1',
  },
  {
    id: 'PC-AL-002',
    title: 'Buffer replenishment lag on AMS2',
    severity: 'High',
    ageing: '5h 40m',
    status: 'In Progress',
    plant: 'AMS2',
  },
  {
    id: 'PC-AL-003',
    title: 'Stranger SKU demand spike',
    severity: 'Medium',
    ageing: '1d 2h',
    status: 'New',
    plant: 'AMS1',
  },
  {
    id: 'PC-AL-004',
    title: 'OCQ plan vs actual gap > 10%',
    severity: 'High',
    ageing: '3h 05m',
    status: 'In Progress',
    plant: 'AMS1',
  },
  {
    id: 'PC-AL-005',
    title: 'Quality lot hold pending disposition',
    severity: 'Medium',
    ageing: '8h 20m',
    status: 'New',
    plant: 'AMS2',
  },
]

export const deliveryMetrics: DeliveryMetric[] = [
  {
    id: 'd1',
    metric: 'AMS1 – Fixed Plan (OCQ)',
    plan: 1000,
    actual: 920,
    completionPct: 92,
    varianceEa: -80,
    variancePct: -8,
    status: 'On Track',
  },
  {
    id: 'd2',
    metric: 'AMS1 – Buffer Replenishment Plan',
    plan: 250,
    actual: 238,
    completionPct: 95,
    varianceEa: -12,
    variancePct: -4.8,
    status: 'On Track',
  },
  {
    id: 'd3',
    metric: 'AMS2 – OCQ (Plan)',
    plan: 800,
    actual: 760,
    completionPct: 95,
    varianceEa: -40,
    variancePct: -5,
    status: 'On Track',
  },
  {
    id: 'd4',
    metric: 'M2O – Plan',
    plan: 120,
    actual: 112,
    completionPct: 93,
    varianceEa: -8,
    variancePct: -6.7,
    status: 'On Track',
  },
]

export const qualityMetric: QualityMetric = {
  label: 'Customer Rejection PPM',
  targetPpm: 500,
  actualPpm: 320,
  variancePpm: -180,
  betterThanTarget: true,
  note: 'Lower than target is good. Keep up the good work!',
}

export const portfolioProducts: PortfolioProduct[] = [
  { sku: 'FG-1001', name: 'Hydraulic Cylinder', plant: 'AMS1', category: 'Runner', ocq: 120, stock: 98 },
  { sku: 'FG-1008', name: 'Valve Block Assembly', plant: 'AMS1', category: 'Runner', ocq: 80, stock: 76 },
  { sku: 'FG-1014', name: 'Pressure Sensor Kit', plant: 'AMS1', category: 'Repeater', ocq: 40, stock: 42 },
  { sku: 'FG-1022', name: 'Manifold Cover', plant: 'AMS1', category: 'Stranger', ocq: 15, stock: 11 },
  { sku: 'FG-2003', name: 'Gear Housing', plant: 'AMS2', category: 'Runner', ocq: 90, stock: 88 },
  { sku: 'FG-2011', name: 'Seal Ring Set', plant: 'AMS2', category: 'Repeater', ocq: 60, stock: 55 },
  { sku: 'FG-2020', name: 'Drive Shaft', plant: 'AMS2', category: 'Runner', ocq: 70, stock: 64 },
  { sku: 'FG-2035', name: 'Coupling Flange', plant: 'AMS2', category: 'Stranger', ocq: 12, stock: 9 },
]

export const portfolioReports: PortfolioReport[] = [
  {
    id: 'r1',
    title: 'MTD Delivery Summary',
    description: 'Plan vs actual completion by plant and plan type.',
    period: 'May 1 – May 24, 2026',
  },
  {
    id: 'r2',
    title: 'Active Alerts Digest',
    description: 'Open alerts requiring Product Custodian action.',
    period: 'Last 7 days',
  },
  {
    id: 'r3',
    title: 'Quality PPM Trend',
    description: 'Customer rejection PPM vs target for the month.',
    period: 'MTD May 2026',
  },
  {
    id: 'r4',
    title: 'Portfolio Mix Snapshot',
    description: 'Runner / Repeater / Stranger counts by plant.',
    period: 'As of May 24, 2026',
  },
]

export const aboutItems = [
  {
    title: 'Time range',
    body: 'MTD covers the current month from day 1 through the last refresh.',
  },
  {
    title: 'OCQ Completion %',
    body: 'Actual ÷ Plan × 100 for the selected plant and plan type.',
  },
  {
    title: 'Customer Rejection PPM',
    body: '(Rejected units ÷ Shipped units) × 1,000,000. Lower than target is better.',
  },
  {
    title: 'Alerts',
    body: 'Click an alert row to open details and update status (mock UI).',
  },
] as const
