import { useState } from 'react'
import { Callout } from '@/components/ui/callout'
import { usePageTitle } from '@/hooks/usePageTitle'
import { cn } from '@/utils/cn'

export default function PortfolioSettingsScreen() {
  usePageTitle('Portfolio Settings')
  const [defaultPlant, setDefaultPlant] = useState('All Plants')
  const [emailDigest, setEmailDigest] = useState(true)
  const [criticalOnly, setCriticalOnly] = useState(false)
  const [autoRefresh, setAutoRefresh] = useState(true)

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="text-sm font-semibold tracking-tight text-slate-800">Defaults</h2>
        <label className="mt-4 block text-sm text-slate-600">
          Default plant filter
          <select
            value={defaultPlant}
            onChange={(e) => setDefaultPlant(e.target.value)}
            className="mt-1.5 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
          >
            <option>All Plants</option>
            <option>AMS1</option>
            <option>AMS2</option>
          </select>
        </label>
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="text-sm font-semibold tracking-tight text-slate-800">Notifications</h2>
        <div className="mt-4 space-y-3">
          <ToggleRow
            label="Daily email digest"
            description="Summary of open alerts and delivery variance."
            checked={emailDigest}
            onChange={setEmailDigest}
          />
          <ToggleRow
            label="Critical alerts only"
            description="Push notifications for Critical severity."
            checked={criticalOnly}
            onChange={setCriticalOnly}
          />
          <ToggleRow
            label="Auto-refresh overview"
            description="Refresh mock dashboard timestamps every few minutes."
            checked={autoRefresh}
            onChange={setAutoRefresh}
          />
        </div>
      </section>

      <Callout tone="warning">Settings are local mock state — not persisted yet.</Callout>
    </div>
  )
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string
  description: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-md border border-slate-100 px-3 py-3">
      <div>
        <p className="text-sm font-medium text-slate-800">{label}</p>
        <p className="mt-0.5 text-sm text-slate-500">{description}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative h-6 w-11 shrink-0 rounded-full transition-colors',
          checked ? 'bg-blue-600' : 'bg-slate-300',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 left-0.5 size-5 rounded-full bg-white shadow transition-transform',
            checked && 'translate-x-5',
          )}
        />
      </button>
    </div>
  )
}
