import { useMemo } from 'react'
import { AboutPanel } from '@/modules/portfolio/components/AboutPanel'
import { AlertsTable } from '@/modules/portfolio/components/AlertsTable'
import { DeliveryTable } from '@/modules/portfolio/components/DeliveryTable'
import { PortfolioCard } from '@/modules/portfolio/components/PortfolioCard'
import { usePortfolioFilters } from '@/modules/portfolio/components/PortfolioFiltersContext'
import { QualityPanel } from '@/modules/portfolio/components/QualityPanel'
import {
  deliveryMetrics,
  portfolioAlerts,
  portfolioPlants,
  qualityMetric,
} from '@/modules/portfolio/mock/data'
import { usePageTitle } from '@/hooks/usePageTitle'

export default function PortfolioOverviewScreen() {
  usePageTitle('Portfolio Overview')
  const { isPlantSelected, selectedPlants } = usePortfolioFilters()

  const plants = useMemo(
    () => portfolioPlants.filter((p) => isPlantSelected(p.name)),
    [isPlantSelected, selectedPlants],
  )

  const alerts = useMemo(() => {
    const open = portfolioAlerts.filter((a) => a.status !== 'Resolved' && isPlantSelected(a.plant))
    return open.slice(0, 3)
  }, [isPlantSelected, selectedPlants])

  const delivery = useMemo(() => {
    return deliveryMetrics.filter(
      (m) => m.metric.startsWith('M2O') || selectedPlants.some((plant) => m.metric.includes(plant)),
    )
  }, [selectedPlants])

  return (
    <div className="space-y-4">
      <div className="grid min-w-0 gap-4 xl:grid-cols-2">
        <section className="min-w-0 overflow-hidden rounded-lg border border-[var(--cf-border)] bg-white shadow-sm">
          <div className="border-b border-[var(--cf-border)] px-4 py-3">
            <h2 className="text-sm font-semibold tracking-tight text-[var(--cf-text-primary)]">
              My Product Portfolio
            </h2>
          </div>
          <div className="grid gap-3 p-4 sm:grid-cols-2">
            {plants.map((p) => (
              <PortfolioCard key={p.id} plant={p} />
            ))}
          </div>
        </section>

        <AlertsTable alerts={alerts} showViewAll compact className="min-w-0" />
      </div>

      <DeliveryTable metrics={delivery} />

      <div className="grid gap-4 xl:grid-cols-2">
        <QualityPanel metric={qualityMetric} />
        <AboutPanel />
      </div>
    </div>
  )
}
