import { Download, FileSpreadsheet } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { portfolioReports } from '@/modules/portfolio/mock/data'
import { usePageTitle } from '@/hooks/usePageTitle'

export default function PortfolioReportsScreen() {
  usePageTitle('Portfolio Reports')

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {portfolioReports.map((report) => (
        <div key={report.id} className="flex flex-col rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-start gap-3">
            <div className="flex size-10 items-center justify-center rounded-md bg-blue-50 text-blue-700">
              <FileSpreadsheet className="size-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-slate-900">{report.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{report.description}</p>
              <p className="mt-2 text-xs font-medium tracking-tight text-slate-400">{report.period}</p>
            </div>
          </div>
          <div className="mt-4">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-2"
              onClick={() => {
                /* mock download — no API yet */
              }}
            >
              <Download className="size-4" aria-hidden />
              Download
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}
