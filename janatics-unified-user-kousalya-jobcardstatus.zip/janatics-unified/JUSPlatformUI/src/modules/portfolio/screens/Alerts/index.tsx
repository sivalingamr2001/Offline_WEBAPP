import { useMemo, useState } from 'react'
import { AlertsTable } from '@/modules/portfolio/components/AlertsTable'
import { usePortfolioFilters } from '@/modules/portfolio/components/PortfolioFiltersContext'
import { portfolioAlerts, type AlertSeverity } from '@/modules/portfolio/mock/data'
import { usePageTitle } from '@/hooks/usePageTitle'
import { cn } from '@/utils/cn'

const severities: Array<AlertSeverity | 'All'> = ['All', 'Critical', 'High', 'Medium', 'Low']

export default function PortfolioAlertsScreen() {
  usePageTitle('Portfolio Alerts')
  const { isPlantSelected } = usePortfolioFilters()
  const [severity, setSeverity] = useState<AlertSeverity | 'All'>('All')

  const alerts = useMemo(() => {
    return portfolioAlerts.filter((a) => {
      if (!isPlantSelected(a.plant)) return false
      if (severity !== 'All' && a.severity !== severity) return false
      return true
    })
  }, [isPlantSelected, severity])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {severities.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSeverity(s)}
            className={cn(
              'rounded-full px-3 py-1.5 text-xs font-medium ring-1 ring-inset transition',
              severity === s
                ? 'bg-slate-900 text-white ring-slate-900'
                : 'bg-white text-slate-600 ring-slate-200 hover:bg-slate-50',
            )}
          >
            {s}
          </button>
        ))}
      </div>
      <AlertsTable alerts={alerts} className="min-w-0" />
    </div>
  )
}
