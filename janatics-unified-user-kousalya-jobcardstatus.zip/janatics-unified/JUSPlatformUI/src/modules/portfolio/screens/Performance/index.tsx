import { useMemo } from 'react'
import { DeliveryTable } from '@/modules/portfolio/components/DeliveryTable'
import { usePortfolioFilters } from '@/modules/portfolio/components/PortfolioFiltersContext'
import { QualityPanel } from '@/modules/portfolio/components/QualityPanel'
import { deliveryMetrics, qualityMetric } from '@/modules/portfolio/mock/data'
import { usePageTitle } from '@/hooks/usePageTitle'

export default function PortfolioPerformanceScreen() {
  usePageTitle('Portfolio Performance')
  const { selectedPlants } = usePortfolioFilters()

  const delivery = useMemo(() => {
    return deliveryMetrics.filter(
      (m) => m.metric.startsWith('M2O') || selectedPlants.some((plant) => m.metric.includes(plant)),
    )
  }, [selectedPlants])

  return (
    <div className="space-y-4">
      <DeliveryTable metrics={delivery} />
      <div className="max-w-2xl">
        <QualityPanel metric={qualityMetric} />
      </div>
    </div>
  )
}
