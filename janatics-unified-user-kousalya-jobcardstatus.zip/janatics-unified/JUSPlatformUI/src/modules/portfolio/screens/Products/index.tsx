import { useMemo } from 'react'
import { CategoryDot } from '@/modules/portfolio/components/StatusBadge'
import { usePortfolioFilters } from '@/modules/portfolio/components/PortfolioFiltersContext'
import { portfolioProducts } from '@/modules/portfolio/mock/data'
import { usePageTitle } from '@/hooks/usePageTitle'

export default function PortfolioProductsScreen() {
  usePageTitle('Portfolio Products')
  const { isPlantSelected, selectedPlants } = usePortfolioFilters()

  const products = useMemo(
    () => portfolioProducts.filter((p) => isPlantSelected(p.plant)),
    [isPlantSelected, selectedPlants],
  )

  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-slate-800">Product Portfolio</h2>
        <p className="mt-1 text-sm text-slate-500">{products.length} SKUs in scope</p>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs font-medium tracking-tight text-slate-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">SKU</th>
              <th className="px-4 py-2.5 font-medium">Name</th>
              <th className="px-4 py-2.5 font-medium">Plant</th>
              <th className="px-4 py-2.5 font-medium">Category</th>
              <th className="px-4 py-2.5 font-medium">OCQ</th>
              <th className="px-4 py-2.5 font-medium">Stock</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {products.map((p) => (
              <tr key={p.sku} className="hover:bg-slate-50/80">
                <td className="px-4 py-3 font-mono text-xs font-medium text-blue-700">{p.sku}</td>
                <td className="px-4 py-3 text-slate-800">{p.name}</td>
                <td className="px-4 py-3 text-slate-600">{p.plant}</td>
                <td className="px-4 py-3">
                  <span className="inline-flex items-center gap-1.5 text-slate-700">
                    <CategoryDot category={p.category} />
                    {p.category}
                  </span>
                </td>
                <td className="px-4 py-3 tabular-nums text-slate-700">{p.ocq}</td>
                <td className="px-4 py-3 tabular-nums text-slate-700">{p.stock}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
