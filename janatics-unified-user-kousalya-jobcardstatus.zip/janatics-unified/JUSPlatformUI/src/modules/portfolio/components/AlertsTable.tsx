import { ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { AlertStatusBadge, SeverityBadge } from '@/modules/portfolio/components/StatusBadge'
import type { PortfolioAlert } from '@/modules/portfolio/mock/data'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'

type AlertsTableProps = {
  alerts: PortfolioAlert[]
  showViewAll?: boolean
  compact?: boolean
  className?: string
}

export function AlertsTable({ alerts, showViewAll = false, compact = false, className }: AlertsTableProps) {
  return (
    <div
      className={cn(
        'flex min-w-0 flex-col overflow-hidden rounded-lg border border-[var(--cf-border)] bg-white shadow-sm',
        className,
      )}
    >
      <div className="flex shrink-0 items-center justify-between gap-3 border-b border-[var(--cf-border)] px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-[var(--cf-text-primary)]">
          Active Alerts {compact ? '' : '(Requiring Action)'}
        </h2>
        {showViewAll ? (
          <Link
            to={routes.portfolioAlerts}
            className="inline-flex shrink-0 items-center gap-1 text-sm font-medium text-[var(--cf-blue)] hover:underline"
          >
            View All Alerts
            <ArrowRight className="size-3.5" aria-hidden />
          </Link>
        ) : null}
      </div>

      <div className="min-w-0 w-full overflow-x-auto">
        <table className="w-full min-w-[36rem] table-fixed text-left text-sm">
          <colgroup>
            <col className="w-[7.5rem]" />
            <col />
            <col className="w-[6.5rem]" />
            <col className="w-[5.5rem]" />
            <col className="w-[7rem]" />
          </colgroup>
          <thead className="bg-[var(--cf-surface-hover)] text-xs font-medium tracking-tight text-[var(--cf-text-muted)]">
            <tr>
              <th className="px-4 py-2.5 font-medium">Alert ID</th>
              <th className="px-4 py-2.5 font-medium">Alert Title</th>
              <th className="px-4 py-2.5 font-medium">Severity</th>
              <th className="px-4 py-2.5 font-medium">Ageing</th>
              <th className="px-4 py-2.5 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--cf-border)]">
            {alerts.map((alert) => (
              <tr key={alert.id} className="hover:bg-[var(--cf-surface-hover)]/70">
                <td className="truncate px-4 py-3 font-mono text-xs text-[var(--cf-text-secondary)]">{alert.id}</td>
                <td className="truncate px-4 py-3 text-[var(--cf-text-primary)]" title={alert.title}>
                  {alert.title}
                </td>
                <td className="px-4 py-3">
                  <SeverityBadge value={alert.severity} />
                </td>
                <td className="px-4 py-3 tabular-nums text-[var(--cf-text-secondary)]">{alert.ageing}</td>
                <td className="px-4 py-3">
                  <AlertStatusBadge value={alert.status} />
                </td>
              </tr>
            ))}
            {alerts.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-[var(--cf-text-muted)]">
                  No alerts for this filter.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  )
}
