import { ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { CategoryDot } from '@/modules/portfolio/components/StatusBadge'
import type { PlantPortfolio } from '@/modules/portfolio/mock/data'
import { routes } from '@/constants/routes'
import { cn } from '@/utils/cn'

export function PortfolioCard({ plant }: { plant: PlantPortfolio }) {
  const theme =
    plant.theme === 'blue'
      ? {
          border: 'border-blue-200',
          header: 'bg-blue-50 text-blue-900',
          accent: 'text-blue-700',
        }
      : {
          border: 'border-amber-200',
          header: 'bg-amber-50 text-amber-950',
          accent: 'text-amber-800',
        }

  return (
    <div className={cn('flex flex-col overflow-hidden rounded-lg border bg-white shadow-sm', theme.border)}>
      <div className={cn('px-4 py-2.5 text-sm font-semibold', theme.header)}>{plant.name}</div>
      <div className="flex flex-1 flex-col gap-4 p-4">
        <div className="flex flex-wrap gap-3">
          {plant.categories.map((c) => (
            <div key={c.name} className="inline-flex items-center gap-1.5 text-xs text-slate-600">
              <CategoryDot category={c.name} />
              <span>
                {c.name} <strong className="text-slate-900">{c.count}</strong>
              </span>
            </div>
          ))}
        </div>
        <div>
          <p className="text-xs font-medium tracking-tight text-slate-400">Sample products</p>
          <ul className="mt-2 space-y-1.5">
            {plant.sampleProducts.map((p) => (
              <li key={p.sku} className="text-sm text-slate-700">
                <span className={cn('font-medium', theme.accent)}>{p.sku}</span> {p.name}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-100 px-4 py-3">
        <Link
          to={routes.portfolioProducts}
          className="inline-flex items-center gap-1 text-sm font-medium text-blue-600 hover:underline"
        >
          View Complete Portfolio
          <ArrowRight className="size-3.5" aria-hidden />
        </Link>
      </div>
    </div>
  )
}
