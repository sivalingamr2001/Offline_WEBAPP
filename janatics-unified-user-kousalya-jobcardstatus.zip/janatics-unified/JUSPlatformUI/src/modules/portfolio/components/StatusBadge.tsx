import { StatusBadge, type StatusBadgeTone } from '@/components/ui/status-badge'
import { cn } from '@/utils/cn'
import type { AlertSeverity, AlertStatus, DeliveryStatus, ProductCategory } from '@/modules/portfolio/mock/data'

const severityTone: Record<AlertSeverity, StatusBadgeTone> = {
  Critical: 'danger',
  High: 'orange',
  Medium: 'warning',
  Low: 'neutral',
}

const alertStatusTone: Record<AlertStatus, StatusBadgeTone> = {
  New: 'danger',
  'In Progress': 'info',
  Resolved: 'success',
}

const deliveryStatusTone: Record<DeliveryStatus, StatusBadgeTone> = {
  'On Track': 'success',
  'At Risk': 'warning',
  Behind: 'danger',
}

const categoryDot: Record<ProductCategory, string> = {
  Runner: 'bg-blue-600',
  Repeater: 'bg-green-600',
  Stranger: 'bg-violet-600',
}

export function SeverityBadge({ value }: { value: AlertSeverity }) {
  return (
    <StatusBadge tone={severityTone[value]} className="normal-case">
      {value}
    </StatusBadge>
  )
}

export function AlertStatusBadge({ value }: { value: AlertStatus }) {
  return (
    <StatusBadge tone={alertStatusTone[value]} className="normal-case">
      {value}
    </StatusBadge>
  )
}

export function DeliveryStatusBadge({ value }: { value: DeliveryStatus }) {
  return (
    <StatusBadge tone={deliveryStatusTone[value]} className="normal-case">
      {value}
    </StatusBadge>
  )
}

export function CategoryDot({ category }: { category: ProductCategory }) {
  return <span className={cn('inline-block size-2 rounded-full', categoryDot[category])} aria-hidden />
}
