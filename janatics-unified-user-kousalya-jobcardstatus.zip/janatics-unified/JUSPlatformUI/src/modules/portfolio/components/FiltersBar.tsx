import { CalendarDays, ChevronDown, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  PORTFOLIO_PERIOD_OPTIONS,
  PORTFOLIO_PLANT_OPTIONS,
  usePortfolioFilters,
  type PortfolioPeriod,
} from '@/modules/portfolio/components/PortfolioFiltersContext'

export function FiltersBar() {
  const {
    period,
    setPeriod,
    selectedPlants,
    togglePlant,
    selectAllPlants,
    plantFilterLabel,
  } = usePortfolioFilters()

  const allSelected = selectedPlants.length === PORTFOLIO_PLANT_OPTIONS.length

  return (
    <div className="flex flex-wrap items-center justify-end gap-3 border-b border-[var(--cf-border)] bg-[var(--cf-page)] px-4 py-3 lg:px-6">
      <Select value={period} onValueChange={(value) => setPeriod(value as PortfolioPeriod)}>
        <SelectTrigger className="h-9 w-auto min-w-[14rem] gap-2 bg-white shadow-sm">
          <CalendarDays className="size-4 shrink-0 text-[var(--cf-text-muted)]" aria-hidden />
          <SelectValue placeholder="Select period" />
        </SelectTrigger>
        <SelectContent align="end">
          {PORTFOLIO_PERIOD_OPTIONS.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-9 min-w-[10rem] justify-between gap-2 bg-white px-3 font-normal shadow-sm"
          >
            <span className="inline-flex items-center gap-2">
              <Filter className="size-4 text-[var(--cf-text-muted)]" aria-hidden />
              {plantFilterLabel}
            </span>
            <ChevronDown className="size-4 opacity-50" aria-hidden />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel>Plants</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuCheckboxItem
            checked={allSelected}
            onCheckedChange={(checked) => {
              if (checked) selectAllPlants()
            }}
            onSelect={(e) => e.preventDefault()}
          >
            All Plants
          </DropdownMenuCheckboxItem>
          <DropdownMenuSeparator />
          {PORTFOLIO_PLANT_OPTIONS.map((plant) => (
            <DropdownMenuCheckboxItem
              key={plant}
              checked={selectedPlants.includes(plant)}
              onCheckedChange={() => togglePlant(plant)}
              onSelect={(e) => e.preventDefault()}
            >
              {plant}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
