import { RefreshCw } from 'lucide-react'
import { usePortfolioFilters } from '@/modules/portfolio/components/PortfolioFiltersContext'
import { Button } from '@/components/ui/button'

type ModuleSubheaderProps = {
  title?: string
  description?: string
}

export function ModuleSubheader({
  title = 'Portfolio Dashboard – Product Custodian',
  description = 'Real-time view of portfolio, alerts and performance.',
}: ModuleSubheaderProps) {
  const { refreshedAt, refresh } = usePortfolioFilters()

  return (
    <div className="flex flex-col gap-3 border-b border-[var(--cf-border)] bg-white px-4 py-4 sm:flex-row sm:items-start sm:justify-between lg:px-6">
      <div className="min-w-0">
        <h1 className="text-lg font-semibold tracking-tight text-[var(--cf-text-primary)] lg:text-xl">{title}</h1>
        <p className="mt-1 text-sm text-[var(--cf-text-muted)]">{description}</p>
      </div>
      <div className="flex shrink-0 justify-end sm:pt-1">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={refresh}
          className="gap-1.5 text-[var(--cf-text-muted)]"
        >
          <RefreshCw className="size-3.5" aria-hidden />
          Last updated: {refreshedAt}
        </Button>
      </div>
    </div>
  )
}
