import { CircleCheck } from 'lucide-react'
import type { QualityMetric } from '@/modules/portfolio/mock/data'

export function QualityPanel({ metric }: { metric: QualityMetric }) {
  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-slate-800">Quality Performance (MTD)</h2>
      </div>
      <div className="p-5">
        <p className="text-sm font-medium text-slate-600">{metric.label}</p>
        <div className="mt-5 grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="text-xs tracking-tight text-slate-400">Target (PPM)</p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-slate-800">{metric.targetPpm}</p>
          </div>
          <div>
            <p className="text-xs tracking-tight text-slate-400">Actual (PPM)</p>
            <p className="mt-1 text-3xl font-bold tabular-nums text-blue-600">{metric.actualPpm}</p>
          </div>
          <div>
            <p className="text-xs tracking-tight text-slate-400">Variance (PPM)</p>
            <p className="mt-1 text-3xl font-bold tabular-nums text-emerald-600">{metric.variancePpm}</p>
          </div>
        </div>
        {metric.betterThanTarget ? (
          <div className="mt-5 flex items-center justify-center gap-2 text-emerald-700">
            <CircleCheck className="size-6" aria-hidden />
            <span className="text-sm font-semibold">Better than Target</span>
          </div>
        ) : null}
        <div className="mt-5 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-sm text-emerald-800">
          {metric.note}
        </div>
      </div>
    </div>
  )
}
