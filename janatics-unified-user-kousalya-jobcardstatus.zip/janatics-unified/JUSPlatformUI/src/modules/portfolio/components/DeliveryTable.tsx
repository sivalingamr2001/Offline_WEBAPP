import { Package } from 'lucide-react'
import { ProgressBar } from '@/modules/portfolio/components/ProgressBar'
import { DeliveryStatusBadge } from '@/modules/portfolio/components/StatusBadge'
import type { DeliveryMetric } from '@/modules/portfolio/mock/data'

function formatNum(n: number) {
  return n.toLocaleString('en-US')
}

export function DeliveryTable({ metrics }: { metrics: DeliveryMetric[] }) {
  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-slate-800">Delivery Performance (MTD)</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs font-medium tracking-tight text-slate-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">Metric</th>
              <th className="px-4 py-2.5 font-medium">Plan (EA)</th>
              <th className="px-4 py-2.5 font-medium">Actual (EA)</th>
              <th className="px-4 py-2.5 font-medium">Completion (%)</th>
              <th className="px-4 py-2.5 font-medium">Variance (EA)</th>
              <th className="px-4 py-2.5 font-medium">Variance (%)</th>
              <th className="px-4 py-2.5 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {metrics.map((row) => (
              <tr key={row.id} className="hover:bg-slate-50/80">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2 text-slate-800">
                    <Package className="size-4 shrink-0 text-slate-400" aria-hidden />
                    {row.metric}
                  </div>
                </td>
                <td className="px-4 py-3 tabular-nums text-slate-700">{formatNum(row.plan)}</td>
                <td className="px-4 py-3 tabular-nums text-slate-700">{formatNum(row.actual)}</td>
                <td className="px-4 py-3">
                  <ProgressBar value={row.completionPct} />
                </td>
                <td className="px-4 py-3 tabular-nums font-medium text-emerald-600">{row.varianceEa}</td>
                <td className="px-4 py-3 tabular-nums font-medium text-emerald-600">{row.variancePct}%</td>
                <td className="px-4 py-3">
                  <DeliveryStatusBadge value={row.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
