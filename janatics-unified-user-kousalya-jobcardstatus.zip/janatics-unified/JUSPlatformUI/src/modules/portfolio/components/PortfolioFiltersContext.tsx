import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'

export const PORTFOLIO_PLANT_OPTIONS = ['AMS1', 'AMS2'] as const
export type PortfolioPlantId = (typeof PORTFOLIO_PLANT_OPTIONS)[number]

export const PORTFOLIO_PERIOD_OPTIONS = [
  { value: 'mtd', label: 'MTD (May 1 – May 24, 2026)' },
  { value: 'qtd', label: 'QTD (Apr 1 – May 24, 2026)' },
  { value: 'ytd', label: 'YTD (Jan 1 – May 24, 2026)' },
] as const

export type PortfolioPeriod = (typeof PORTFOLIO_PERIOD_OPTIONS)[number]['value']

export type PortfolioFilters = {
  period: PortfolioPeriod
  periodLabel: string
  setPeriod: (period: PortfolioPeriod) => void
  selectedPlants: PortfolioPlantId[]
  togglePlant: (plant: PortfolioPlantId) => void
  selectAllPlants: () => void
  clearPlants: () => void
  isPlantSelected: (plant: string) => boolean
  plantFilterLabel: string
  refreshedAt: string
  refresh: () => void
}

const PortfolioFiltersContext = createContext<PortfolioFilters | null>(null)

export function PortfolioFiltersProvider({ children }: { children: ReactNode }) {
  const [period, setPeriod] = useState<PortfolioPeriod>('mtd')
  const [selectedPlants, setSelectedPlants] = useState<PortfolioPlantId[]>([...PORTFOLIO_PLANT_OPTIONS])
  const [refreshedAt, setRefreshedAt] = useState('May 24, 2026 09:00 AM')

  const togglePlant = useCallback((plant: PortfolioPlantId) => {
    setSelectedPlants((prev) => {
      if (prev.includes(plant)) {
        const next = prev.filter((p) => p !== plant)
        return next.length === 0 ? prev : next
      }
      return [...prev, plant]
    })
  }, [])

  const selectAllPlants = useCallback(() => {
    setSelectedPlants([...PORTFOLIO_PLANT_OPTIONS])
  }, [])

  const clearPlants = useCallback(() => {
    setSelectedPlants([...PORTFOLIO_PLANT_OPTIONS])
  }, [])

  const isPlantSelected = useCallback(
    (plant: string) => {
      if (selectedPlants.length === PORTFOLIO_PLANT_OPTIONS.length) return true
      return selectedPlants.includes(plant as PortfolioPlantId)
    },
    [selectedPlants],
  )

  const periodLabel = PORTFOLIO_PERIOD_OPTIONS.find((p) => p.value === period)?.label ?? period

  const plantFilterLabel =
    selectedPlants.length === PORTFOLIO_PLANT_OPTIONS.length
      ? 'All Plants'
      : selectedPlants.length === 1
        ? selectedPlants[0]
        : `${selectedPlants.length} plants`

  const value = useMemo<PortfolioFilters>(
    () => ({
      period,
      periodLabel,
      setPeriod,
      selectedPlants,
      togglePlant,
      selectAllPlants,
      clearPlants,
      isPlantSelected,
      plantFilterLabel,
      refreshedAt,
      refresh: () => {
        const now = new Date()
        setRefreshedAt(
          now.toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          }),
        )
      },
    }),
    [
      period,
      periodLabel,
      selectedPlants,
      togglePlant,
      selectAllPlants,
      clearPlants,
      isPlantSelected,
      plantFilterLabel,
      refreshedAt,
    ],
  )

  return <PortfolioFiltersContext.Provider value={value}>{children}</PortfolioFiltersContext.Provider>
}

export function usePortfolioFilters() {
  const ctx = useContext(PortfolioFiltersContext)
  if (!ctx) throw new Error('usePortfolioFilters must be used within PortfolioFiltersProvider')
  return ctx
}
