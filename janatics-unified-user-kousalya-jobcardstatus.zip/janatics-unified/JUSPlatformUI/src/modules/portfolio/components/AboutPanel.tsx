import { Bell, Clock3, Shield, Target } from 'lucide-react'
import { aboutItems } from '@/modules/portfolio/mock/data'

const icons = [Clock3, Target, Shield, Bell] as const

export function AboutPanel() {
  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-4 py-3">
        <h2 className="text-sm font-semibold tracking-tight text-slate-800">About this Dashboard</h2>
      </div>
      <ul className="space-y-4 p-5">
        {aboutItems.map((item, i) => {
          const Icon = icons[i] ?? Clock3
          return (
            <li key={item.title} className="flex gap-3">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-slate-100 text-slate-600">
                <Icon className="size-4" aria-hidden />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-800">{item.title}</p>
                <p className="mt-0.5 text-sm text-slate-500">{item.body}</p>
              </div>
            </li>
          )
        })}
      </ul>
    </div>
  )
}
