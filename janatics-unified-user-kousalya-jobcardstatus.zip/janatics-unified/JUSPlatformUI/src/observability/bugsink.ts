import * as Sentry from '@sentry/react'
import { getLastApiResponseId, getLastApiTraceId } from '@/observability/apiTrace'

/**
 * Browser application bugs → Bugsink (Sentry-compatible DSN).
 *
 * Traces stay on the API OpenTelemetry path (Grafana Tempo / Loki).
 * Do not enable Sentry performance / replay — Bugsink is errors only.
 * Last API `X-Trace-Id` / `X-Response-Id` are attached so you can jump to Tempo.
 */

const SENSITIVE_HEADER = /^(authorization|cookie|set-cookie|x-api-key)$/i

function bugsinkDsn(): string {
  return import.meta.env.VITE_BUGSINK_DSN?.trim() ?? ''
}

export function isBugsinkEnabled() {
  return bugsinkDsn().length > 0
}

export function initBugsink(): void {
  const dsn = bugsinkDsn()
  if (!dsn) return

  Sentry.init({
    dsn,
    environment: import.meta.env.VITE_BUGSINK_ENVIRONMENT?.trim() || import.meta.env.MODE,
    enabled: true,
    sendDefaultPii: false,
    // 0 = no Sentry traces. Use Grafana Tempo / Loki from the API instead.
    tracesSampleRate: 0,
    attachStacktrace: true,
    maxBreadcrumbs: 50,
    beforeSend(event) {
      applyTraceTags(event)
      stripSensitiveRequestHeaders(event)
      return event
    },
  })
}

function applyTraceTags(event: { tags?: Record<string, unknown> }) {
  const tags = { ...event.tags }
  const traceId = getLastApiTraceId()
  const responseId = getLastApiResponseId()
  if (traceId && tags.trace_id == null) tags.trace_id = traceId
  if (responseId && tags.response_id == null) tags.response_id = responseId
  event.tags = tags
}

function stripSensitiveRequestHeaders(event: { request?: { headers?: Record<string, string> } }) {
  const headers = event.request?.headers
  if (!headers) return
  for (const key of Object.keys(headers)) {
    if (SENSITIVE_HEADER.test(key)) {
      delete headers[key]
    }
  }
}

export function setBugsinkUser(user: { id: string; roleName?: string | null } | null) {
  if (!isBugsinkEnabled()) return
  if (!user) {
    Sentry.setUser(null)
    return
  }
  Sentry.setUser({ id: user.id })
  if (user.roleName) Sentry.setTag('role_name', user.roleName)
}

export function reportAppError(error: unknown, extras?: Record<string, unknown>) {
  if (!isBugsinkEnabled()) return
  const traceId = getLastApiTraceId()
  const responseId = getLastApiResponseId()
  Sentry.captureException(error, (scope) => {
    if (traceId) scope.setTag('trace_id', traceId)
    if (responseId) scope.setTag('response_id', responseId)
    if (extras) {
      for (const [key, value] of Object.entries(extras)) {
        if (value != null) scope.setExtra(key, value)
      }
    }
    return scope
  })
}
