/**
 * Last API correlation ids from JUSPlatform responses.
 * Paste `trace_id` into Grafana → Tempo when observability is on.
 * Loki logs use the same service name (`JUSPlatform`).
 */

let lastTraceId: string | null = null
let lastResponseId: string | null = null

function header(headers: { get?(name: string): string | null | undefined } | Record<string, unknown> | undefined, name: string) {
  if (!headers) return null
  if (typeof headers.get === 'function') {
    return headers.get(name) ?? headers.get(name.toLowerCase()) ?? null
  }
  const record = headers as Record<string, unknown>
  const value = record[name] ?? record[name.toLowerCase()]
  return typeof value === 'string' && value.length > 0 ? value : null
}

export function rememberApiTraceHeaders(headers: { get?(name: string): string | null | undefined } | Record<string, unknown> | undefined) {
  const traceId = header(headers, 'x-trace-id')
  const responseId = header(headers, 'x-response-id')
  if (traceId) lastTraceId = traceId
  if (responseId) lastResponseId = responseId
}

export function getLastApiTraceId() {
  return lastTraceId
}

export function getLastApiResponseId() {
  return lastResponseId
}
