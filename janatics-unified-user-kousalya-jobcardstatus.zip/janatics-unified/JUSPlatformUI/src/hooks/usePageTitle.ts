import { useEffect } from 'react'
import { brand } from '@/constants/brand'
import { usePageTitleContext } from '@/contexts/PageTitleContext'

export function usePageTitle(title: string) {
  const { setTitle } = usePageTitleContext()
  useEffect(() => {
    setTitle(title)
    document.title = `${title} · ${brand.shortName}`
  }, [setTitle, title])
}
