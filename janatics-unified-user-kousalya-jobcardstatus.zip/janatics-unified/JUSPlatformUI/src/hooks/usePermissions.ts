import { isOrgAdminRole, isSuperAdminRole } from '@/constants/permissions'
import { useAuth } from '@/hooks/useAuth'

export function usePermissions() {
  const { session, hasPermission, canAccessPath } = useAuth()
  const isSuperAdmin = isSuperAdminRole(session?.roleName)
  const isAdmin = isOrgAdminRole(session?.roleName)
  return {
    hasPermission,
    canAccessPath,
    isSuperAdmin,
    isAdmin,
    isPrivileged: isSuperAdmin || isAdmin,
    roleName: session?.roleName,
    permissions: session?.permissions ?? [],
    modules: session?.modules ?? [],
  }
}
