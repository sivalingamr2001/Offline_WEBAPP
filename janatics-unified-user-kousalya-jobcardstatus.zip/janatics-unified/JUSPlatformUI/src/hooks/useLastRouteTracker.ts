import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { saveLastRoute } from '@/utils/lastRouteStorage'

/** Persists the last dashboard path for splash / post-login redirect. */
export function useLastRouteTracker() {
  const { pathname } = useLocation()

  useEffect(() => {
    saveLastRoute(pathname)
  }, [pathname])
}
