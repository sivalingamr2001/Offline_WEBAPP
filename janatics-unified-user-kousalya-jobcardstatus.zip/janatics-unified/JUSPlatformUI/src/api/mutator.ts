import { type AxiosRequestConfig } from 'axios'
import { AXIOS_INSTANCE } from './axiosInstance'

export { AXIOS_INSTANCE }

export const customInstance = <T>(config: AxiosRequestConfig): Promise<T> =>
  AXIOS_INSTANCE.request<T>(config).then(({ data }) => data)
