import axios from 'axios'
import { rememberApiTraceHeaders } from '@/observability/apiTrace'
import { setBugsinkUser } from '@/observability/bugsink'
import { clearSession, getAccessToken } from '@/utils/tokenStorage'

export const AXIOS_INSTANCE = axios.create({
  baseURL: '',
  headers: { 'Content-Type': 'application/json' },
})

AXIOS_INSTANCE.interceptors.request.use((config) => {
  const token = getAccessToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

AXIOS_INSTANCE.interceptors.response.use(
  (response) => {
    rememberApiTraceHeaders(response.headers)
    return response
  },
  (error) => {
    if (error.response?.headers) {
      rememberApiTraceHeaders(error.response.headers)
    }
    if (error.response?.status === 401) {
      clearSession()
      setBugsinkUser(null)
      if (window.location.pathname.startsWith('/dashboard')) {
        window.location.assign('/login')
      }
    }
    return Promise.reject(error)
  },
)
