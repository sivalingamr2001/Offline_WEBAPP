import { customInstance } from '@/api/mutator'

export type ChangePasswordRequest = {
  currentPassword: string
  newPassword: string
}

export type UserProfileDto = {
  id: string
  organizationId?: string
  email: string
  displayName: string
  designation?: string | null
  isActive: boolean
  roleName?: string | null
  avatarUrl?: string | null
}

export type UpdateCurrentUserRequest = {
  designation?: string | null
}

export function getCurrentUser() {
  return customInstance<UserProfileDto>({
    url: '/api/v1/users/me',
    method: 'GET',
  })
}

export function updateCurrentUser(body: UpdateCurrentUserRequest) {
  return customInstance<UserProfileDto>({
    url: '/api/v1/users/me',
    method: 'PUT',
    data: body,
  })
}

export function changePassword(body: ChangePasswordRequest) {
  return customInstance<{ message: string }>({
    url: '/api/v1/auth/change-password',
    method: 'POST',
    data: body,
  })
}

export function uploadAvatar(file: File) {
  const formData = new FormData()
  formData.append('file', file)
  return customInstance<UserProfileDto>({
    url: '/api/v1/users/me/avatar',
    method: 'POST',
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}
