import { customInstance } from '@/api/mutator'

export type JobCardQuery = {
  dateRange?: string
  jobType?: string
  product?: string
  plant?: string
  organizationId?: string
}

export type JobCardPhaseDto = {
  kind: string
  planDays: number | string
  actualDays: number | string
  status: string
}

export type JobCardOperationDto = {
  index: number | string
  name: string
  vendor?: string | null
  qtyQueue: number | string
  qtyMove: number | string
  qtyScrap: number | string
  qtyComp: number | string
  leadTimeDays: number | string
  status: string
  processStartDate?: string | null
  phases: JobCardPhaseDto[]
}

export type JobCardRowDto = {
  id: string
  jobNo: string
  description: string
  jobType: string
  plant: string
  ospCount: number | string
  planTatDays: number | string
  actualTatDays: number | string
  varianceDays: number | string
  overallStatus: string
  operations: JobCardOperationDto[]
}

export type JobCardKpisDto = {
  totalJobs: number | string
  onTrack: number | string
  onTrackPct: number | string
  atRisk: number | string
  atRiskPct: number | string
  delayed: number | string
  delayedPct: number | string
  avgPlanTatDays: number | string
  avgActualTatDays: number | string
  avgVarianceDays: number | string
  onTimeCompletionPct: number | string
  onTimeCompletionDeltaPct: number | string
}

export type JobCardScreenDto = {
  kpis: JobCardKpisDto
  jobs: JobCardRowDto[]
  varianceByStage: { stage: string; avgVarianceDays: number | string }[]
  topDelayedOsps: { label: string; avgVarianceDays: number | string }[]
  jobsByStatus: { status: string; count: number | string; pct: number | string }[]
  plants: string[]
  jobTypes: string[]
  products: string[]
  lastUpdated: string
}

export function getJobCardStatus(params?: JobCardQuery) {
  return customInstance<JobCardScreenDto>({
    url: '/api/v1/job-card-status',
    method: 'GET',
    params,
  })
}

export function getJobCardStatusJob(wipEntityId: string) {
  return customInstance<JobCardRowDto>({
    url: `/api/v1/job-card-status/${wipEntityId}`,
    method: 'GET',
  })
}

export const jobCardStatusApi = {
  getJobCardStatus,
  getJobCardStatusJob,
}

export function toNum(value: number | string | null | undefined) {
  if (value == null) return 0
  return typeof value === 'number' ? value : Number(value)
}
