import { customInstance } from '@/api/mutator'
import type { ApiPagedResponse } from '@/api/auth'

export type AppModuleDto = {
  id: string
  code: string
  name: string
  description?: string | null
  icon?: string | null
  sortOrder: number
  isActive: boolean
}

export type AppMenuDto = {
  id: string
  moduleId: string
  moduleName: string
  parentId?: string | null
  code: string
  name: string
  path?: string | null
  icon?: string | null
  sortOrder: number
  permissionCode?: string | null
  isActive: boolean
}

export type CreateAppModuleRequest = {
  code: string
  name: string
  description?: string | null
  icon?: string | null
  sortOrder: number
}

export type CreateAppMenuRequest = {
  moduleId: string
  parentId?: string | null
  code?: string | null
  name: string
  path?: string | null
  icon?: string | null
  sortOrder?: number
  permissionCode?: string | null
}

export function listAppModules(params?: { page?: number; pageSize?: number; search?: string }) {
  return customInstance<ApiPagedResponse<AppModuleDto>>({
    url: '/api/v1/app-modules',
    method: 'GET',
    params,
  })
}

export function createAppModule(body: CreateAppModuleRequest) {
  return customInstance<AppModuleDto>({
    url: '/api/v1/app-modules',
    method: 'POST',
    data: body,
  })
}

export function listAppMenus(params?: {
  page?: number
  pageSize?: number
  search?: string
  moduleId?: string
  sort?: string
}) {
  return customInstance<ApiPagedResponse<AppMenuDto>>({
    url: '/api/v1/app-menus',
    method: 'GET',
    params,
  })
}

export function createAppMenu(body: CreateAppMenuRequest) {
  return customInstance<AppMenuDto>({
    url: '/api/v1/app-menus',
    method: 'POST',
    data: body,
  })
}

export type UpdateAppMenuRequest = {
  moduleId: string
  name: string
  path?: string | null
  icon?: string | null
  permissionCode?: string | null
  isActive: boolean
}

export function updateAppMenu(id: string, body: UpdateAppMenuRequest) {
  return customInstance<AppMenuDto>({
    url: `/api/v1/app-menus/${id}`,
    method: 'PUT',
    data: body,
  })
}
