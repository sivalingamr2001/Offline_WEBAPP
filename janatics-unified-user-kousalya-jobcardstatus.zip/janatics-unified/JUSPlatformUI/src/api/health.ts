export type PingResponse = {
  status: string
  message: string
  utc: string
}

import { getApiBaseUrl } from '@/config/env'

export async function pingApi(signal?: AbortSignal): Promise<PingResponse> {
  const base = getApiBaseUrl()
  const response = await fetch(`${base}/api`, { method: 'GET', signal })

  if (!response.ok) {
    throw new Error(`API unreachable (${response.status})`)
  }

  return response.json() as Promise<PingResponse>
}
