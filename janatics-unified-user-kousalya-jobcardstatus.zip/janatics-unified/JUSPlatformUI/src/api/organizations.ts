import { customInstance } from '@/api/mutator'
import type { ApiPagedResponse } from '@/api/auth'

export type OrganizationDto = {
  id: string
  name: string
  code: string
  isActive: boolean
  createdAt: string
  operatingUnitId?: string | null
  operatingUnitName?: string | null
  oracleOrgId?: number | null
  unitName?: string | null
}

export type CreateOrganizationRequest = {
  name: string
  code: string
  operatingUnitId?: string | null
  oracleOrgId?: number | null
  unitName?: string | null
}

export type OperatingUnitDto = {
  id: string
  orgId: number
  name: string
  isActive: boolean
  createdAt: string
}

export function listOrganizations(params?: { page?: number; pageSize?: number; search?: string }) {
  return customInstance<ApiPagedResponse<OrganizationDto>>({
    url: '/api/v1/organizations',
    method: 'GET',
    params,
  })
}

export function createOrganization(body: CreateOrganizationRequest) {
  return customInstance<OrganizationDto>({
    url: '/api/v1/organizations',
    method: 'POST',
    data: body,
  })
}

export function createOperatingUnit(body: { orgId: number; name: string; isActive?: boolean }) {
  return customInstance<OperatingUnitDto>({
    url: '/api/v1/operating-units',
    method: 'POST',
    data: body,
  })
}

export function listOperatingUnits(params?: { page?: number; pageSize?: number; search?: string }) {
  return customInstance<ApiPagedResponse<OperatingUnitDto>>({
    url: '/api/v1/operating-units',
    method: 'GET',
    params,
  })
}

export function getCurrentOrganization() {
  return customInstance<OrganizationDto>({
    url: '/api/v1/organizations/me',
    method: 'GET',
  })
}
