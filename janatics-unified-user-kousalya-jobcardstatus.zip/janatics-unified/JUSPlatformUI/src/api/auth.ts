import { customInstance } from '@/api/mutator'
import type { SessionNavModule } from '@/constants/navigation'
import type { AuthSession } from '@/utils/tokenStorage'

export type LoginRequest = { email: string; password: string }

export type NavMenuDto = {
  id: string
  parentId?: string | null
  code: string
  name: string
  path?: string | null
  icon?: string | null
  sortOrder: number
  permissionCode?: string | null
  canCreate: boolean
  canRead: boolean
  canUpdate: boolean
  canDelete: boolean
}

export type NavModuleDto = {
  id: string
  code: string
  name: string
  icon?: string | null
  sortOrder: number
  menus: NavMenuDto[]
}

export type LoginResponse = {
  accessToken: string
  expiresAt: string
  userId: string
  email: string
  displayName: string
  designation?: string | null
  roleName?: string | null
  permissions: string[]
  modules?: NavModuleDto[]
}

export type RegisterRequest = {
  organizationName: string
  organizationCode: string
  email: string
  displayName: string
  password: string
}

export type ForgotPasswordRequest = { email: string }
export type ResetPasswordRequest = { token: string; password: string }

export function login(body: LoginRequest) {
  return customInstance<LoginResponse>({
    url: '/api/v1/auth/login',
    method: 'POST',
    data: body,
  })
}

export function register(body: RegisterRequest) {
  return customInstance<LoginResponse>({
    url: '/api/v1/auth/register',
    method: 'POST',
    data: body,
  })
}

export function forgotPassword(body: ForgotPasswordRequest) {
  return customInstance<{ message: string }>({
    url: '/api/v1/auth/forgot-password',
    method: 'POST',
    data: body,
  })
}

export function resetPassword(body: ResetPasswordRequest) {
  return customInstance<{ message: string }>({
    url: '/api/v1/auth/reset-password',
    method: 'POST',
    data: body,
  })
}

export function logout() {
  return customInstance<void>({
    url: '/api/v1/auth/logout',
    method: 'POST',
  })
}

export function toSession(response: LoginResponse): AuthSession {
  return {
    accessToken: response.accessToken,
    expiresAt: response.expiresAt,
    userId: response.userId,
    email: response.email,
    displayName: response.displayName,
    designation: response.designation,
    roleName: response.roleName,
    permissions: response.permissions ?? [],
    modules: (response.modules ?? []).map((module): SessionNavModule => ({
      id: module.id,
      code: module.code,
      name: module.name,
      icon: module.icon,
      sortOrder: module.sortOrder,
      menus: (module.menus ?? []).map((menu) => ({
        id: menu.id,
        parentId: menu.parentId,
        code: menu.code,
        name: menu.name,
        path: menu.path,
        icon: menu.icon,
        sortOrder: menu.sortOrder,
        permissionCode: menu.permissionCode,
      })),
    })),
  }
}

/** Hand-written until `pnpm api:generate` runs Orval against OpenAPI. */
export type UserDto = {
  id: string
  organizationId?: string | null
  organizationName?: string | null
  email: string
  displayName: string
  designation?: string | null
  isActive: boolean
  roleName?: string | null
  userCode?: string | null
  empId?: string | null
}

export type ApiPagedResponse<T> = {
  items: T[]
  page: number
  pageSize: number
  totalItems: number
  totalPages: number
}

export function listUsers(params?: { page?: number; pageSize?: number; search?: string }) {
  return customInstance<ApiPagedResponse<UserDto>>({
    url: '/api/v1/users',
    method: 'GET',
    params,
  })
}

export type CreateUserRequest = {
  email: string
  displayName: string
  password: string
  roleId?: string | null
  organizationId?: string | null
  userCode?: string | null
  empId?: string | null
}

export function createUser(body: CreateUserRequest) {
  return customInstance<UserDto>({
    url: '/api/v1/users',
    method: 'POST',
    data: body,
  })
}

export type RoleDto = {
  id: string
  name: string
  description?: string | null
}

export function listRoles(params?: { page?: number; pageSize?: number }) {
  return customInstance<ApiPagedResponse<RoleDto>>({
    url: '/api/v1/roles',
    method: 'GET',
    params,
  })
}

export type OrganizationDto = {
  id: string
  name: string
  code: string
  isActive: boolean
  createdAt: string
}

export type MenuAccessDto = {
  menuId: string
  canCreate: boolean
  canRead: boolean
  canUpdate: boolean
  canDelete: boolean
}

export function listUserAccessRights(userId: string) {
  return customInstance<MenuAccessDto[]>({
    url: `/api/v1/users/${userId}/access-rights`,
    method: 'GET',
  })
}

export function replaceUserAccessRights(userId: string, rights: MenuAccessDto[]) {
  return customInstance<MenuAccessDto[]>({
    url: `/api/v1/users/${userId}/access-rights`,
    method: 'PUT',
    data: rights,
  })
}

export type UserOrganizationDto = {
  organizationId: string
  organizationName: string
  organizationCode: string
  operatingUnit?: number | null
  isActive: boolean
}

export type UserOrganizationAssignment = {
  organizationId: string
  operatingUnit?: number | null
  isActive?: boolean
}

export function listUserOrganizations(userId: string) {
  return customInstance<UserOrganizationDto[]>({
    url: `/api/v1/users/${userId}/organizations`,
    method: 'GET',
  })
}

export function replaceUserOrganizations(userId: string, assignments: UserOrganizationAssignment[]) {
  return customInstance<UserOrganizationDto[]>({
    url: `/api/v1/users/${userId}/organizations`,
    method: 'PUT',
    data: assignments,
  })
}
