import { customInstance } from '@/api/mutator'

export type GetCustomerComplaintsOverviewParams = {
  weekStart?: string
  page?: number | string
  pageSize?: number | string
  organizationId?: string
}

export type ComplaintsKpiDeltaDto = {
  current: number | string
  previous: number | string
  changePct: number | string | null
  pctOfTotal: number | string
}

export type ComplaintsRateKpiDto = {
  ratePct: number | string
  previousRatePct: number | string
  deltaPp: number | string
}

export type ComplaintsOverviewKpisDto = {
  totalComplaints: ComplaintsKpiDeltaDto
  solvedWithinSla: ComplaintsKpiDeltaDto
  openWithinSla: ComplaintsKpiDeltaDto
  openBreachedSla: ComplaintsKpiDeltaDto
  complaintRate: ComplaintsRateKpiDto
}

export type ComplaintsTrendPointDto = {
  date: string
  label: string
  solvedWithinSla: number | string
  openWithinSla: number | string
  openBreachedSla: number | string
  complaintRatePct: number | string
}

export type ComplaintsSlaGaugeDto = {
  withinSlaPct: number | string
  previousWithinSlaPct: number | string
  deltaPct: number | string
  targetPct: number | string
}

export type ComplaintsProductSlaCountsDto = {
  count: number | string
  pct: number | string
}

export type ComplaintsProductRowDto = {
  rank: number | string
  productCode: string
  productDescription: string
  ordersDelivered: number | string
  totalComplaints: number | string
  solvedWithinSla: ComplaintsProductSlaCountsDto
  openWithinSla: ComplaintsProductSlaCountsDto
  openBreachedSla: ComplaintsProductSlaCountsDto
  complaintRatePct: number | string
}

export type ComplaintsProductTotalDto = {
  ordersDelivered: number | string
  totalComplaints: number | string
  solvedWithinSla: ComplaintsProductSlaCountsDto
  openWithinSla: ComplaintsProductSlaCountsDto
  openBreachedSla: ComplaintsProductSlaCountsDto
  complaintRatePct: number | string
}

export type ComplaintsOverviewDto = {
  title: string
  subtitle: string
  periodLabel: string
  weekStart: string
  weekEnd: string
  asOf: string
  kpis: ComplaintsOverviewKpisDto
  trend: ComplaintsTrendPointDto[]
  sla: ComplaintsSlaGaugeDto
  products: ComplaintsProductRowDto[]
  totals: ComplaintsProductTotalDto
  page: number | string
  pageSize: number | string
  totalProducts: number | string
  footnote: string
}

export type ComplaintsWeekOptionDto = {
  weekStart: string
  weekEnd: string
  label: string
}

export function getCustomerComplaintsOverview(params?: GetCustomerComplaintsOverviewParams) {
  return customInstance<ComplaintsOverviewDto>({
    url: '/api/v1/customer-complaints',
    method: 'GET',
    params,
  })
}

export function listCustomerComplaintWeeks(params?: { organizationId?: string }) {
  return customInstance<ComplaintsWeekOptionDto[]>({
    url: '/api/v1/customer-complaints/weeks',
    method: 'GET',
    params,
  })
}

export const customerComplaintApi = {
  getCustomerComplaintsOverview,
  listCustomerComplaintWeeks,
}

export function toNum(value: number | string | null | undefined) {
  if (value == null) return 0
  return typeof value === 'number' ? value : Number(value)
}

export function formatUnits(value: number | string | null | undefined) {
  return toNum(value).toLocaleString('en-US')
}

export function formatLastUpdated(iso: string) {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const dd = String(d.getDate()).padStart(2, '0')
  const mon = d.toLocaleString('en-GB', { month: 'short' })
  const yyyy = d.getFullYear()
  const time = d.toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })
  return `${dd}-${mon}-${yyyy} ${time}`
}
