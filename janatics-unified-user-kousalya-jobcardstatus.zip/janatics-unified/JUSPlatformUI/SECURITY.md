# JUSPlatform UI — Secure SDLC

Frontend security is enforced in **Docker** (no local Node scanner installs required). Reports merge into the same SARIF → HTML pipeline as the backend.

## SDLC gates

| Phase | Gate | Command |
|-------|------|---------|
| **Develop** | Oxlint + TypeScript strict | `pnpm lint` · `pnpm typecheck` |
| **Build** | Production build | `pnpm build` |
| **CI (Docker)** | Lint + typecheck + build | `.\docker\ci\run-ui-ci.sh` |
| **Security PR (Docker)** | Semgrep UI + Trivy UI | `.\docker\ci\run-ui-security-pr.sh` then `.\docker\ci\run-html.sh` |
| **Full stack PR** | Backend + UI scanners | `.\docker\ci\run-security-pr.sh` |

## Docker reporting

All UI security findings are written to `docker/security/reports/`:

| Artifact | Scanner |
|----------|---------|
| `semgrep-ui.sarif` | SAST (React/TS + custom rules) |
| `trivy-ui.sarif` | SCA + secrets + misconfig on `JUSPlatformUI/` |
| `security-evidence.html` | Combined HTML (backend + UI SARIF) |

```powershell
# Windows Git Bash / WSL — these CI wrappers are shell scripts
.\docker\ci\run-ui-ci.sh
.\docker\ci\run-ui-security-pr.sh
.\docker\ci\run-html.sh
.\docker\ci\run-security-pr.sh
```

```bash
# Linux
./docker/ci/run-ui-ci.sh
./docker/ci/run-ui-security-pr.sh
./docker/ci/run-html.sh
./docker/ci/run-security-pr.sh
```

Open `docker/security/reports/security-evidence.html`

Jenkins publishes the same HTML under **Security Evidence** (`:8091` reports share when enabled).

## Secure coding rules (product)

1. **No secrets in the browser** — JWT lives in `sessionStorage`; never use `VITE_*` for keys/passwords. `VITE_BUGSINK_DSN` is a public ingest URL (Bugsink/Sentry), not a signing secret.
2. **API base URL** — set in `configureEnv()` at startup; Orval mutator stays free of `import.meta` for codegen.
3. **Open redirects** — post-login routes limited to `/dashboard/*` (`lastRouteStorage.ts`).
4. **Auth headers** — axios interceptor only; 401 clears session and redirects from dashboard.
5. **Dependencies** — lockfile committed; Trivy UI scans `pnpm-lock.yaml` in CI.

## Custom Semgrep rules

`docker/security/semgrep-ui.rules.yml` — eval, `dangerouslySetInnerHTML`, hardcoded JWT patterns, `VITE_*` secret keys.

## Local (optional)

With Node/pnpm installed:

```bash
cd JUSPlatformUI
pnpm install
pnpm lint && pnpm typecheck && pnpm build
```

CI truth source remains Docker (`./docker/ci/run-ui-ci.sh`).

See also: [docs/devsecops-frontend.md](../docs/devsecops-frontend.md) · [docs/security.md](../docs/security.md)
