$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
docker compose -f (Join-Path $Root 'docker\mailpit\docker-compose.yml') down
