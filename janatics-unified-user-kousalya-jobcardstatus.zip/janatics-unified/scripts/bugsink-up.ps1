# Bugsink UI — http://localhost:8000  (admin@example.org / admin)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
docker compose -f (Join-Path $Root 'docker\bugsink\docker-compose.yml') up -d
Write-Host "Bugsink: http://localhost:8000  (admin@example.org / admin)"
Write-Host "Create a project, copy DSN, set Bugsink:Dsn in appsettings.Development.json (gitignored)."
