# Vite UI on http://localhost:5173. Run the API in another terminal first.
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location (Join-Path $Root 'JUSPlatformUI')
if (-not (Test-Path '.\node_modules')) { pnpm install }
pnpm dev
