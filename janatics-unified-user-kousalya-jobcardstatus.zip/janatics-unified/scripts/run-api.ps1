# API on http://localhost:5201 (Development). Connection: user-secrets or appsettings.Development.json.
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
dotnet run --project (Join-Path $Root 'JUSPlatform\JUSPlatform.csproj')
