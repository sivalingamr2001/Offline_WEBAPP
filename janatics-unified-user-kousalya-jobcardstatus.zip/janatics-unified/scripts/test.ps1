# Local SDK tests (no Docker). Default: unit + integration.
param(
    [switch]$Unit,
    [switch]$Integration,
    [switch]$Coverage
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$runUnit = $Unit -or (-not $Integration -and -not $Coverage)
$runIntegration = $Integration -or (-not $Unit -and -not $Coverage)

if ($Coverage) {
    & (Join-Path $PSScriptRoot 'test-coverage.ps1')
    return
}

if ($Unit -or $runUnit) {
    dotnet test (Join-Path $Root 'tests\JUSPlatform.UnitTests\JUSPlatform.UnitTests.csproj')
}
if ($Integration -or $runIntegration) {
    dotnet test (Join-Path $Root 'tests\JUSPlatform.IntegrationTests\JUSPlatform.IntegrationTests.csproj')
}
