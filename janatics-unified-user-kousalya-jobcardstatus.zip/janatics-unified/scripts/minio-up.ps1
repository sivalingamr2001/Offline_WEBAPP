# MinIO API :9000  console :9001  (minioadmin / minioadmin)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
docker compose -f (Join-Path $Root 'docker\minio\docker-compose.yml') up -d
Write-Host "MinIO API:     http://localhost:9000"
Write-Host "MinIO console: http://localhost:9001  (minioadmin / minioadmin)"
Write-Host "Set Storage:Provider=minio and Storage:S3:* in appsettings.Development.json (gitignored)."
