# Migrate if needed, seed SuperAdmin/permissions, then exit (does not listen).
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$project = Join-Path $Root 'JUSPlatform\JUSPlatform.csproj'
dotnet run --project $project -- --seed
