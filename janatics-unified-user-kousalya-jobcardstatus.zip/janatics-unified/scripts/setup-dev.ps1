# Copy gitignored Development settings from the example (no-op if the file exists).
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Example = Join-Path $Root 'JUSPlatform\appsettings.Development.json.example'
$Local = Join-Path $Root 'JUSPlatform\appsettings.Development.json'

if (-not (Test-Path $Local)) {
    Copy-Item $Example $Local
    Write-Host "Created JUSPlatform\appsettings.Development.json (gitignored)."
} else {
    Write-Host "JUSPlatform\appsettings.Development.json already exists."
}

Write-Host "DEV/UAT PostgreSQL: prefer user-secrets (overrides the json file):"
Write-Host '  dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project .\JUSPlatform\JUSPlatform.csproj'
