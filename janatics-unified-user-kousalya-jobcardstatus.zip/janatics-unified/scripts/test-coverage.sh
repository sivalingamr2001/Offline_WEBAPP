#!/usr/bin/env bash
# Coverlet + HTML report. Open artifacts/coverage-report/index.html
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
dotnet tool restore
dotnet test tests/JUSPlatform.UnitTests/JUSPlatform.UnitTests.csproj \
  --settings tests/coverlet.runsettings \
  --collect:"XPlat Code Coverage" \
  --results-directory artifacts/test-results \
  --logger "trx;LogFileName=unit-tests.trx"
dotnet test tests/JUSPlatform.IntegrationTests/JUSPlatform.IntegrationTests.csproj \
  --settings tests/coverlet.runsettings \
  --collect:"XPlat Code Coverage" \
  --results-directory artifacts/test-results \
  --logger "trx;LogFileName=integration-tests.trx"
dotnet reportgenerator \
  "-reports:artifacts/test-results/**/coverage.cobertura.xml" \
  "-targetdir:artifacts/coverage-report" \
  "-reporttypes:Html;HtmlSummary;TextSummary" \
  "-title:JUSPlatform Product Coverage" \
  "-classfilters:+JUSPlatform.Application.*;+JUSPlatform.Controllers.*;+JUSPlatform.Middleware.*;+JUSPlatform.Domain.*;+JUSPlatform.Authorization.*"
echo "Coverage HTML: $ROOT/artifacts/coverage-report/index.html"
