# Coverlet + HTML report (product folders only). Open artifacts\coverage-report\index.html
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $Root
dotnet tool restore
dotnet test .\tests\JUSPlatform.UnitTests\JUSPlatform.UnitTests.csproj `
    --settings .\tests\coverlet.runsettings `
    --collect:"XPlat Code Coverage" `
    --results-directory .\artifacts\test-results `
    --logger "trx;LogFileName=unit-tests.trx"
dotnet test .\tests\JUSPlatform.IntegrationTests\JUSPlatform.IntegrationTests.csproj `
    --settings .\tests\coverlet.runsettings `
    --collect:"XPlat Code Coverage" `
    --results-directory .\artifacts\test-results `
    --logger "trx;LogFileName=integration-tests.trx"
dotnet reportgenerator `
    "-reports:.\artifacts\test-results\**\coverage.cobertura.xml" `
    "-targetdir:.\artifacts\coverage-report" `
    "-reporttypes:Html;HtmlSummary;TextSummary" `
    "-title:JUSPlatform Product Coverage" `
    "-classfilters:+JUSPlatform.Application.*;+JUSPlatform.Controllers.*;+JUSPlatform.Middleware.*;+JUSPlatform.Domain.*;+JUSPlatform.Authorization.*"
Write-Host "Coverage HTML: $Root\artifacts\coverage-report\index.html"
