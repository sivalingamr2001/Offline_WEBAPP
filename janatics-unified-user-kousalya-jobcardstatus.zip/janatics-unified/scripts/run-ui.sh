#!/usr/bin/env bash
# Vite UI on http://localhost:5173. Run the API in another terminal first.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/JUSPlatformUI"
[[ -d node_modules ]] || pnpm install
pnpm dev
