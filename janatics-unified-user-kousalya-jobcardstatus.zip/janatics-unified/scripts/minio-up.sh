#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
docker compose -f "$ROOT/docker/minio/docker-compose.yml" up -d
echo "MinIO API:     http://localhost:9000"
echo "MinIO console: http://localhost:9001  (minioadmin / minioadmin)"
echo "Set Storage:Provider=minio and Storage:S3:* in appsettings.Development.json (gitignored)."
