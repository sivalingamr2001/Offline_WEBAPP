#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
docker compose -f "$ROOT/docker/mailpit/docker-compose.yml" up -d
echo "Mailpit UI: http://localhost:8025"
