#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
docker compose -f "$ROOT/docker/observability/docker-compose.yml" up -d --build
echo "Grafana:    http://localhost:3000  (admin / admin)"
echo "Prometheus: http://localhost:9090"
echo "Mock API:   http://localhost:8090/health"
echo "OTLP gRPC:  localhost:4317"
echo "Enable Observability + MockIntegrations in appsettings.Development.json, then restart the API."
