#!/usr/bin/env bash
# Migrate if needed, seed SuperAdmin/permissions, then exit (does not listen).
# Usage: ./scripts/seed.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
dotnet run --project "$ROOT/JUSPlatform/JUSPlatform.csproj" -- --seed
