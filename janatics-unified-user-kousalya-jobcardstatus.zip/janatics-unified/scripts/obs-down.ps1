$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
docker compose -f (Join-Path $Root 'docker\observability\docker-compose.yml') down
docker rm -f observability-zipkin-1 2>$null | Out-Null
