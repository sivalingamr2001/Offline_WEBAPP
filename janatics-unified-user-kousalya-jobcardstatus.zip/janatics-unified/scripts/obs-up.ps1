# Grafana / Tempo / Loki / Prometheus / OTel / mocks — http://localhost:3000 (admin / admin)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
docker compose -f (Join-Path $Root 'docker\observability\docker-compose.yml') up -d --build
Write-Host "Grafana:    http://localhost:3000  (admin / admin)"
Write-Host "Prometheus: http://localhost:9090"
Write-Host "Mock API:   http://localhost:8090/health"
Write-Host "OTLP gRPC:  localhost:4317"
Write-Host "Enable Observability + MockIntegrations in appsettings.Development.json, then restart the API."
