#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
docker compose -f "$ROOT/docker/observability/docker-compose.yml" down
docker rm -f observability-zipkin-1 2>/dev/null || true
