#!/usr/bin/env bash
# Copy gitignored Development settings from the example (no-op if the file exists).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EXAMPLE="$ROOT/JUSPlatform/appsettings.Development.json.example"
LOCAL="$ROOT/JUSPlatform/appsettings.Development.json"

if [[ ! -f "$LOCAL" ]]; then
  cp "$EXAMPLE" "$LOCAL"
  echo "Created JUSPlatform/appsettings.Development.json (gitignored)."
else
  echo "JUSPlatform/appsettings.Development.json already exists."
fi

echo "DEV/UAT PostgreSQL: prefer user-secrets (overrides the json file):"
echo '  dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform/JUSPlatform.csproj'
