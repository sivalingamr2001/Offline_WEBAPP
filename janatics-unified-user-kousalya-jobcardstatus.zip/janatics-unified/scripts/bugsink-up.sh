#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
docker compose -f "$ROOT/docker/bugsink/docker-compose.yml" up -d
echo "Bugsink: http://localhost:8000  (admin@example.org / admin)"
echo "Create a project, copy DSN, set Bugsink:Dsn in appsettings.Development.json (gitignored)."
