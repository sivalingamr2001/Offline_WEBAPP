#!/usr/bin/env bash
# API on http://localhost:5201 (Development).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
dotnet run --project "$ROOT/JUSPlatform/JUSPlatform.csproj"
