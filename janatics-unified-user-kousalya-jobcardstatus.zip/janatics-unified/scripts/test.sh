#!/usr/bin/env bash
# Local SDK tests (no Docker). Default: unit + integration.
# Usage: ./scripts/test.sh [--unit|--integration|--coverage]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mode="${1:-all}"
case "$mode" in
  --unit)
    dotnet test "$ROOT/tests/JUSPlatform.UnitTests/JUSPlatform.UnitTests.csproj"
    ;;
  --integration)
    dotnet test "$ROOT/tests/JUSPlatform.IntegrationTests/JUSPlatform.IntegrationTests.csproj"
    ;;
  --coverage)
    "$ROOT/scripts/test-coverage.sh"
    ;;
  all|"")
    dotnet test "$ROOT/tests/JUSPlatform.UnitTests/JUSPlatform.UnitTests.csproj"
    dotnet test "$ROOT/tests/JUSPlatform.IntegrationTests/JUSPlatform.IntegrationTests.csproj"
    ;;
  *)
    echo "Usage: $0 [--unit|--integration|--coverage]" >&2
    exit 1
    ;;
esac
