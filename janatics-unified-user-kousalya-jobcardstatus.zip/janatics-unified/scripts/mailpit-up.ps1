# Mailpit SMTP :1025  UI :8025
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
docker compose -f (Join-Path $Root 'docker\mailpit\docker-compose.yml') up -d
Write-Host "Mailpit UI: http://localhost:8025"
