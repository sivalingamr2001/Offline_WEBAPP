# Janatics Unified Suite (JUSPlatform)

Publisher: **Janatics India**

This repository is the **Janatics Unified Suite** monolith (also called **JUSPlatform**):

| Part | Folder | Stack |
|------|--------|--------|
| API | `JUSPlatform/` | ASP.NET Core Web API |
| UI | `JUSPlatformUI/` | React + TypeScript + Vite |

**Default development OS is Windows** (PowerShell). Linux is supported; those commands are listed second.

## Get started (Windows, default)

Docker is **not required**. Paste these into **CMD** or PowerShell from the **repo root**. More detail: [JUSPlatform/README.md](JUSPlatform/README.md).

If `dotnet --version` is still 8.x, put the 10 SDK first on `PATH`:

```
set PATH=%USERPROFILE%\.dotnet;%PATH%
```

PowerShell: `$env:PATH = "$env:USERPROFILE\.dotnet;$env:PATH"` · Git Bash: `export PATH="$HOME/.dotnet:$PATH"`

### 1. PostgreSQL connection

Never commit a real host, user, or password. Npgsql shape only (not MariaDB/MySQL):

```
Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>
```

**Recommended — this machine only (user-secrets, not in git):**

```
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform\JUSPlatform.csproj
```

**Or a gitignored file** (user-secrets still win if both are set):

```
copy JUSPlatform\appsettings.Development.json.example JUSPlatform\appsettings.Development.json
```

Edit `ConnectionStrings:Default` in that file. Local default:

```
Host=localhost;Port=5432;Database=jusplatform;Username=postgres;Password=
```

Create the empty database once if it does not exist:

```
psql -U postgres -c "CREATE DATABASE jusplatform;"
```

### 2. Restore, migrate, seed

`--seed` applies pending EF migrations, creates SuperAdmin + permission catalog, then **exits** (no API listener).

```
dotnet restore JUSPlatform\JUSPlatform.csproj
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
```

Optional Control Tower demo org/data:

```
dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed
```

Login after seed: `admin@demo.local` / `ChangeMe123!` (override in the `Seed` config section). Register an organization to get an Admin JWT with `org_id`.

### 3. Run the API

`dotnet run` applies any **pending** migrations again (no-op if current). It does **not** seed.

```
dotnet run --project JUSPlatform\JUSPlatform.csproj
```

- API: `http://localhost:5201` · ping: `/api`
- Scalar: `/docs` · OpenAPI: `/openapi/v1.json`

Hot reload when nuget.org resets the connection:

```
cd JUSPlatform
dotnet watch run --no-restore
```

### 4. Run the UI

```
cd JUSPlatformUI
pnpm install
pnpm run dev
```

UI: `http://localhost:5173`

### 5. Further development

| You changed | Then run |
|-------------|----------|
| Domain entity / Fluent config | `dotnet ef migrations add <Name> --project JUSPlatform\JUSPlatform.csproj --output-dir Infrastructure/Persistence/Migrations` then start the API (migrate-on-boot) |
| Permission codes in `Authorization/Permissions.cs` | `dotnet run --project JUSPlatform\JUSPlatform.csproj -- --seed` |
| API behavior | unit tests below; smoke login against PostgreSQL |

PostgreSQL columns are snake_case (`created_at`). C# stays PascalCase (`CreatedAt`).

If `dotnet ef` is missing: `dotnet tool restore` (repo local tool) or `dotnet tool install --global dotnet-ef`.

**Tests:**

```
dotnet test tests\JUSPlatform.UnitTests\JUSPlatform.UnitTests.csproj
dotnet test tests\JUSPlatform.IntegrationTests\JUSPlatform.IntegrationTests.csproj
```

### Linux

```
export PATH="$HOME/.dotnet:$PATH"
cp JUSPlatform/appsettings.Development.json.example JUSPlatform/appsettings.Development.json
dotnet user-secrets set "ConnectionStrings:Default" "Host=<DB_HOST>;Port=5432;Database=<DB_NAME>;Username=<DB_USER>;Password=<DB_PASSWORD>" --project JUSPlatform/JUSPlatform.csproj
dotnet restore JUSPlatform/JUSPlatform.csproj
dotnet run --project JUSPlatform/JUSPlatform.csproj -- --seed
dotnet run --project JUSPlatform/JUSPlatform.csproj
dotnet test tests/JUSPlatform.UnitTests/JUSPlatform.UnitTests.csproj
cd JUSPlatformUI && pnpm install && pnpm run dev
```

**Database:** PostgreSQL is the product engine. Docker Compose is optional; skip it when Docker is not installed.

**Windows production host:** IIS — see [deploy/iis/README.md](deploy/iis/README.md). Linux: systemd + Nginx in [deploy/README.md](deploy/README.md).

## Runtime: .NET 10

| | **.NET 10 (this repo)** |
|--|--|
| Org license | Approved |
| TFM | `net10.0` |
| Support | LTS through **November 2028** |
| OpenAPI | Built-in `Microsoft.AspNetCore.OpenApi` → `/openapi/v1.json` |

Do not mix TFMs. All API, test, mock, IIS hosting bundle, and Docker SDK images must share **.NET 10**. History of the 8 → 10 bump: [docs/migrate-net10.md](docs/migrate-net10.md).

---

# Engineering Instructions

## 1. Purpose

This project is a **production-grade enterprise application** (API + UI) built with modern .NET and React.

Primary goals:

- secure-by-default development
- predictable architecture
- strong OpenAPI contracts
- maintainable C# code
- robust authorization and validation
- high-quality relational persistence (PostgreSQL)
- strong observability
- automated testing
- consistent API conventions
- safe AI-assisted development
- developer productivity on **Windows (default)** and Linux
- long-term maintainability
- measurable engineering quality

The backend is API-first. The React UI in `JUSPlatformUI/` is the product frontend.

Primary stack:

```text
Language:
C#

Platform:
.NET 10 LTS (licensed)

Web:
ASP.NET Core Web API

UI:
React + TypeScript (JUSPlatformUI)

API style:
Controller-based REST APIs

Contract:
OpenAPI

Database:
PostgreSQL

ORM:
Entity Framework Core

Background processing:
Hangfire where durable jobs are required

Caching:
Redis where justified

Logging:
ILogger + structured logging

Observability:
OpenTelemetry

Testing:
xUnit

API testing:
Bruno

Documentation:
OpenAPI + Markdown + optional DocFX

Containers:
Docker (optional; not required for local development)

Build:
dotnet CLI / pnpm (Windows PowerShell default)

Supported IDEs:
Visual Studio
JetBrains Rider
Cursor / VS Code

Supported development OS:
Windows (default)
Linux
```

---

# 2. Architectural Philosophy

Use a **modular monolith** unless there is a proven reason to introduce distributed services.

Do not introduce:

```text
microservices
Kafka
service mesh
Kubernetes
distributed sagas
multiple databases
complex message brokers
```

without a concrete requirement.

The preferred architecture is:

```text
HTTP Request
      |
      v
ASP.NET Core Middleware
      |
      v
API Controller
      |
      v
Application / Use Case
      |
      v
Domain Rules
      |
      v
Infrastructure / Persistence
      |
      v
PostgreSQL
```

Cross-cutting capabilities sit around this flow:

```text
Authentication
Authorization
Validation
Exception handling
Logging
Tracing
Rate limiting
Caching
Audit
```

---

# 3. Project Structure

Recommended baseline:

```text
src/
├── Api/
│   ├── Controllers/
│   ├── Middleware/
│   ├── Filters/
│   ├── OpenApi/
│   ├── Authentication/
│   ├── Authorization/
│   └── Program.cs
│
├── Application/
│   ├── Common/
│   ├── Users/
│   ├── Roles/
│   ├── Reports/
│   ├── Jobs/
│   └── Interfaces/
│
├── Domain/
│   ├── Entities/
│   ├── ValueObjects/
│   ├── Enums/
│   ├── Exceptions/
│   └── Rules/
│
└── Infrastructure/
    ├── Persistence/
    ├── Repositories/
    ├── Authentication/
    ├── BackgroundJobs/
    ├── Caching/
    ├── Logging/
    └── Integrations/
```

Tests:

```text
tests/
├── UnitTests/
├── IntegrationTests/
├── ArchitectureTests/
└── ApiTests/
```

Prefer feature-oriented organization inside `Application`.

Example:

```text
Application/
└── Users/
    ├── GetUser/
    ├── SearchUsers/
    ├── CreateUser/
    ├── UpdateUser/
    └── DeleteUser/
```

Do not create giant folders containing hundreds of unrelated:

```text
Services/
Dtos/
Validators/
Helpers/
```

Feature boundaries should remain visible.

---

# 4. Dependency Direction

The intended dependency direction is:

```text
Api
 |
 v
Application
 |
 v
Domain

Infrastructure
 |
 +--> Application abstractions
 +--> Domain
```

Rules:

```text
Domain must not depend on Infrastructure.

Domain must not depend on ASP.NET Core.

Domain must not depend on EF Core.

Application must not depend on concrete database implementations.

Controllers must not directly execute database queries.

Infrastructure may implement Application interfaces.
```

Architecture tests should enforce important dependency rules.

---

# 5. C# Standards

C# is the only production backend language unless explicitly approved.

Enable:

```xml
<Nullable>enable</Nullable>
<ImplicitUsings>enable</ImplicitUsings>
```

Use modern language features where they improve clarity.

Prefer:

```csharp
public sealed record UserDto(
    Guid Id,
    string Name,
    string Email);
```

for immutable DTO-style data.

Use `sealed` for classes that are not intended to be inherited.

Do not use inheritance merely for code reuse.

Prefer composition.

---

# 6. Nullability

Nullable reference types are mandatory.

Correct:

```csharp
string Name
string? MiddleName
```

Do not silence nullable warnings without understanding why.

Avoid:

```csharp
value!
```

unless null safety has already been proven.

Nullability is part of the API and domain contract.

---

# 7. Async Programming

All database, file, network, cache and external I/O should use async APIs.

Prefer:

```csharp
await db.Users
    .ToListAsync(cancellationToken);
```

Never use:

```csharp
.Result
.Wait()
.GetAwaiter().GetResult()
```

inside normal request paths.

Do not use:

```csharp
Task.Run(...)
```

as a fake background-job mechanism.

---

# 8. Cancellation Tokens

Propagate `CancellationToken` through I/O operations.

Example:

```csharp
public async Task<UserDto?> GetAsync(
    Guid id,
    CancellationToken cancellationToken)
```

Pass the token into:

```text
EF Core
HTTP clients
file operations
background operations where appropriate
```

Cancellation is part of production reliability.

---

# 9. Dependency Injection

Use ASP.NET Core's built-in DI container.

Understand lifetime semantics:

```text
Singleton
Scoped
Transient
```

Database contexts should normally be:

```text
Scoped
```

Do not inject a scoped service into a singleton.

Avoid service locator patterns.

Bad:

```csharp
serviceProvider.GetService(...)
```

inside arbitrary business code.

Prefer constructor injection.

---

# 10. Controllers

Controllers are HTTP adapters.

Controllers should:

```text
receive request
bind input
trigger authorization
call application service/use case
return typed HTTP response
```

Controllers should NOT contain:

```text
business logic
SQL
EF queries
large validation logic
email logic
background job implementation
complex mapping
security rule duplication
```

Preferred style:

```csharp
[ApiController]
[Route("api/v1/users")]
[Tags("Users")]
public sealed class UsersController : ControllerBase
{
    private readonly IUserService _service;

    public UsersController(IUserService service)
    {
        _service = service;
    }
}
```

Use:

```csharp
ControllerBase
```

not:

```csharp
Controller
```

unless server-rendered Views are genuinely required.

---

# 11. REST API Conventions

Use resource-oriented REST conventions.

Examples:

```text
GET    /api/v1/users
GET    /api/v1/users/{id}
POST   /api/v1/users
PUT    /api/v1/users/{id}
PATCH  /api/v1/users/{id}
DELETE /api/v1/users/{id}
```

Avoid RPC-style routes such as:

```text
/getUser
/createUser
/updateUserData
/deleteUserNow
```

unless the operation genuinely represents a command rather than resource CRUD.

---

# 12. API Versioning

Version APIs from day one.

Preferred baseline:

```text
/api/v1/...
```

API version should be explicit.

Breaking API changes must not silently modify existing published contracts.

---

# 13. OpenAPI Is a First-Class Deliverable

OpenAPI is a major project output.

The C# backend is the contract source.

Preferred flow:

```text
C# DTOs
    |
    v
ASP.NET Core Web API
    |
    v
OpenAPI
    |
    +--> documentation
    +--> Bruno testing
    +--> client generation if required
    +--> contract linting
    +--> breaking-change analysis
```

Every endpoint must expose a meaningful OpenAPI definition.

---

# 14. Required OpenAPI Metadata

Every public/internal API endpoint must define where applicable:

```text
Tag
Stable operationId
Summary
Description if necessary
Request schema
Success response schema
Error response schemas
HTTP status codes
Authentication requirement
Authorization requirement
Pagination contract
```

Example:

```csharp
[HttpGet("{id:guid}")]
[EndpointName("getUser")]
[EndpointSummary("Get user by ID")]
[ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
[ProducesResponseType<ProblemDetails>(
    StatusCodes.Status404NotFound)]
public async Task<ActionResult<UserDto>> GetAsync(...)
```

Stable operation IDs should not depend on internal method names.

Good:

```text
getUser
searchUsers
createUser
updateUser
deleteUser
```

---

# 15. OpenAPI Documentation Style

Prefer attributes and endpoint metadata.

Use XML comments only where they add genuine value.

Do not add useless comments such as:

```csharp
/// <summary>
/// Gets the name.
/// </summary>
public string Name { get; init; }
```

Useful documentation explains:

```text
business meaning
constraints
external identifiers
units
immutability
special semantics
```

Example:

```csharp
/// <summary>
/// External personnel identifier assigned by the upstream HR system.
/// </summary>
public string PersonnelNumber { get; init; }
```

---

# 16. DTO Rules

Never expose EF entities directly through APIs.

Use explicit:

```text
Request DTOs
Response DTOs
Command DTOs
Query DTOs
```

Bad:

```text
Database Entity
   |
   v
JSON
```

Preferred:

```text
Database Entity
   |
   v
Application Mapping
   |
   v
Response DTO
   |
   v
OpenAPI
```

Avoid anonymous response objects.

Bad:

```csharp
return Ok(new
{
    success = true,
    data = user
});
```

Prefer explicit contracts.

---

# 17. Request Validation

All external input must be validated.

Use:

```text
DataAnnotations
or
FluentValidation
```

depending on complexity.

Simple constraints may include:

```text
required
length
range
email format
enum validation
numeric constraints
```

Business rules belong in the Application or Domain layer.

Example distinction:

```text
Email required
    -> request validation

User cannot approve own request
    -> application/domain rule
```

---

# 18. Response Contracts

Typed responses are strongly preferred.

Use:

```csharp
Task<ActionResult<UserDto>>
```

instead of:

```csharp
Task<IActionResult>
```

where practical.

Pagination should use a shared response type.

Example:

```csharp
public sealed record PagedResponse<T>(
    IReadOnlyList<T> Items,
    int Page,
    int PageSize,
    long TotalItems,
    int TotalPages);
```

---

# 19. Standard Error Model

Use ASP.NET Core `ProblemDetails`.

Do not create arbitrary error shapes across controllers.

Expected pattern:

```text
400 -> ValidationProblemDetails
401 -> ProblemDetails
403 -> ProblemDetails
404 -> ProblemDetails
409 -> ProblemDetails
429 -> ProblemDetails
500 -> ProblemDetails
```

Never expose:

```text
stack traces
database errors
SQL
connection strings
filesystem paths
internal exception details
```

to clients.

---

# 20. Exception Handling

Use centralized exception handling.

Preferred:

```text
IExceptionHandler
or
global exception middleware
```

Do not repeat:

```csharp
try
{
}
catch (Exception ex)
{
}
```

inside every controller.

Application-specific exceptions should map predictably to HTTP responses.

Examples:

```text
ValidationException -> 400
UnauthorizedAccess -> 403
ResourceNotFound -> 404
Conflict -> 409
```

---

# 21. Authentication

Use standard ASP.NET Core authentication.

Preferred enterprise options:

```text
OIDC
OAuth2
Microsoft Entra ID
corporate identity provider
JWT Bearer
```

Do not create custom authentication protocols.

If local authentication is required, use established standards and secure password hashing.

---

# 22. Authorization

Authorization must be permission/policy driven.

Prefer:

```csharp
[Authorize(Policy = Policies.UserWrite)]
```

over:

```csharp
if (user.Role == "Admin")
```

Roles may be used as collections of permissions.

Policies should represent meaningful capabilities.

Examples:

```text
UserRead
UserWrite
UserDelete
ReportView
ReportExport
AdminConfiguration
```

---

# 23. Authentication vs Authorization

Never confuse:

```text
Authentication:
Who are you?

Authorization:
What may you do?
```

Every sensitive endpoint should explicitly consider both.

---

# 24. EF Core Is the Default Persistence Mechanism

Use EF Core as the primary ORM.

Default rule:

```text
EF Core first.
```

Dapper/raw SQL are not day-one requirements.

Use escalation levels:

```text
Level 1:
Normal EF Core

Level 2:
Optimized EF Core

Level 3:
Raw SQL through EF Core when justified

Level 4:
Dapper/direct SQL only as an approved exception
```

Do not introduce multiple database access styles casually.

---

# 25. Persistence

PostgreSQL is the **current** relational database.

Hangfire, the optional Database log sink, systemd unit, Docker Compose, and EF migrations in `JUSPlatform/Infrastructure/Persistence/Migrations/` target PostgreSQL.

Microsoft SQL Server and SQLite remain out of scope. See **JUSPlatform/README.md → Other SQL engines**.

Database responsibilities may include:

```text
users
roles
permissions
configuration
business data
audit metadata
application state
job metadata
workflow data
```

Use a compatible EF Core provider approved by the project.

Database provider versions must be centrally pinned.

---

# 26. DbContext Rules

`DbContext` is short-lived.

Normally:

```text
one scoped context per request/work unit
```

Never:

```text
singleton DbContext
static DbContext
global context
long-lived context
```

Do not pass `DbContext` through unrelated application layers.

Controllers should not query it directly.

---

# 27. EF Core Tracking

Understand tracking behavior.

Use normal tracking when updating entities.

For read-only queries, consider:

```csharp
.AsNoTracking()
```

especially for large query results.

Do not blindly apply `AsNoTracking()` everywhere.

---

# 28. EF Query Discipline

Developers must understand:

```text
IQueryable<T>
IEnumerable<T>
deferred execution
ToListAsync()
FirstOrDefaultAsync()
CountAsync()
projection
Include()
```

Do not materialize data too early.

Bad:

```csharp
var allUsers = await db.Users.ToListAsync();

var active = allUsers
    .Where(x => x.IsActive);
```

when the database could filter directly.

Prefer:

```csharp
var active = await db.Users
    .Where(x => x.IsActive)
    .ToListAsync(cancellationToken);
```

---

# 29. Query Projection

Do not load entire entities when only a few fields are required.

Prefer:

```csharp
var users = await db.Users
    .Select(x => new UserListDto(
        x.Id,
        x.Name,
        x.Email))
    .ToListAsync(cancellationToken);
```

Projection improves:

```text
performance
memory usage
contract clarity
security
```

---

# 30. Avoid N+1 Queries

Review ORM-generated SQL.

Do not assume EF Core automatically produces optimal queries.

Watch for:

```text
N+1 queries
unbounded Include()
unnecessary joins
large materialization
client-side evaluation
missing indexes
```

Performance-sensitive endpoints must be inspected.

---

# 31. Repository Pattern

Do not create generic repositories automatically.

Avoid:

```text
IGenericRepository<T>
GetAll()
GetById()
Create()
Update()
Delete()
```

solely to wrap EF Core.

EF Core already behaves similarly to repository/unit-of-work patterns.

Use repositories when they represent meaningful domain/data boundaries.

Example:

```text
IUserRepository
IAuditRepository
IReportRepository
```

---

# 32. Database Transactions

Use transactions when multiple changes must be atomic.

Keep transaction boundaries short.

Do not keep a DB transaction open while performing:

```text
HTTP calls
email
external services
slow file processing
third-party integrations
```

Prefer:

```text
DB transaction
commit
then external operation
```

with reliable recovery where needed.

---

# 33. Database Constraints

Application validation does not replace database constraints.

Use:

```text
foreign keys
unique indexes
not-null constraints
check constraints where suitable
indexes
```

Database integrity is part of correctness.

---

# 34. Migrations

Schema changes should be reproducible.

Use EF Core migrations where appropriate.

Migrations must:

```text
be committed
be reviewed
be tested
avoid destructive changes without approval
```

Production schema changes must never depend on manual developer memory.

---

# 35. Connection Strings

Never commit real credentials.

Connection strings should come from:

```text
environment variables
secret stores
Vault
Azure Key Vault
Kubernetes secrets
CI/CD secret storage
```

Do not log them.

---

# 36. Configuration

Use strongly typed configuration.

Prefer:

```csharp
IOptions<T>
IOptionsSnapshot<T>
IOptionsMonitor<T>
```

instead of repeated:

```csharp
configuration["Some:Deep:Key"]
```

Business logic should not read configuration directly from random locations.

---

# 37. Secret Management

Never commit:

```text
passwords
JWT secrets
API keys
connection strings
private keys
certificates
tokens
```

Secret scanning must run in CI.

If a secret is committed:

```text
remove it
rotate it
inspect history
assume compromise until proven otherwise
```

Deleting the line alone is insufficient.

---

# 38. Logging

Use:

```csharp
ILogger<T>
```

throughout application code.

Prefer structured logging:

```csharp
logger.LogInformation(
    "User {UserId} created report {ReportId}",
    userId,
    reportId);
```

Do not use:

```csharp
Console.WriteLine(...)
```

for production logging.

---

# 39. Structured Logging

Do not concatenate important values into free text.

Good:

```csharp
logger.LogWarning(
    "Login failed for user {UserId} from {IpAddress}",
    userId,
    ipAddress);
```

Structured properties should allow filtering by:

```text
userId
requestId
traceId
operationId
resourceId
jobId
```

---

# 40. Sensitive Logging

Never log:

```text
password
JWT
refresh token
Authorization header
database password
secret key
full credit/private data
security answers
```

Sensitive business fields must be reviewed before logging.

---

# 41. Operational Logging vs Audit Logging

Operational logs answer:

```text
What happened technically?
```

Audit logs answer:

```text
Who changed what?
```

Keep them conceptually separate.

Audit events may include:

```text
user created
role changed
permission granted
record deleted
configuration changed
security override
report exported
```

Audit logs should be append-oriented.

---

# 42. OpenTelemetry

Implement OpenTelemetry from early development.

Capture where appropriate:

```text
HTTP traces
database traces
outbound HTTP calls
background jobs
metrics
exceptions
```

A request should be traceable across layers.

Example:

```text
HTTP request       220ms
 |- auth             3ms
 |- controller       1ms
 |- service          5ms
 |- MariaDB query  180ms
 |- serialization    8ms
```

---

# 43. Correlation and Trace IDs

Every request should have a trace/correlation identity.

Expose a safe correlation identifier where useful.

Logs and errors should include trace context.

This improves production debugging significantly.

---

# 44. Health Checks

Provide:

```text
/health/live
/health/ready
```

Liveness:

```text
process is alive
```

Readiness:

```text
application is capable of serving requests
```

Readiness may check MariaDB and critical dependencies.

Do not make health checks unnecessarily expensive.

---

# 45. Redis

Redis is optional.

Use it only when justified for:

```text
cache
distributed ephemeral state
rate limiting support
temporary data
distributed coordination
```

Do not use Redis as the primary source of durable business truth.

Every cache requires:

```text
TTL
invalidation strategy
failure behavior
```

---

# 46. Caching Rules

Do not cache because "Redis exists."

Before caching, answer:

```text
What problem are we solving?
How stale may this data be?
When is it invalidated?
What happens if Redis fails?
Could this cache cause authorization leakage?
```

Authorization-sensitive cache keys must include appropriate context.

---

# 47. Background Jobs

Use durable background jobs for operations such as:

```text
report generation
bulk export
email sending
large imports
data synchronization
long-running processing
```

Prefer Hangfire where appropriate.

API pattern:

```text
POST /api/v1/reports
        |
        v
202 Accepted
        |
        v
jobId
        |
        v
background worker
        |
        v
GET /api/v1/jobs/{jobId}
```

Do not keep an HTTP request open for minutes.

---

# 48. BackgroundService

Use built-in `BackgroundService` for simple long-running internal processes.

Do not use it as a substitute for durable job storage when business-critical jobs must survive restart.

---

# 49. Job Requirements

Background jobs must consider:

```text
idempotency
retry strategy
timeout
cancellation
failure state
dead jobs
logging
traceability
duplicate execution
```

Never assume a job runs exactly once.

---

# 50. Rate Limiting

Use rate limiting where useful.

Especially consider:

```text
authentication
search
exports
report generation
large uploads
expensive queries
```

Do not blindly rate-limit every endpoint identically.

---

# 51. Pagination

All potentially large collection APIs require pagination.

Preferred contract:

```text
GET /api/v1/users?page=1&pageSize=25
```

Response:

```json
{
  "items": [],
  "page": 1,
  "pageSize": 25,
  "totalItems": 100,
  "totalPages": 4
}
```

Enforce maximum page size.

Never allow unbounded endpoints on large tables.

---

# 52. Filtering and Sorting

Filtering parameters must be explicit and validated.

Example:

```text
GET /api/v1/users
    ?page=1
    &pageSize=25
    &status=active
    &sort=name
```

Never allow user-provided arbitrary SQL column names to flow directly into queries.

Whitelist allowed sort fields.

---

# 53. Date and Time

Use UTC internally unless business requirements explicitly require another representation.

Prefer:

```text
DateTimeOffset
```

for timestamps involving real-world moments.

Use:

```text
DateOnly
```

for pure dates.

Do not ambiguously mix:

```text
local DateTime
UTC DateTime
unspecified DateTime
```

---

# 54. JSON Conventions

Standardize JSON globally.

Decide:

```text
camelCase
enum serialization
null behavior
DateOnly representation
DateTimeOffset representation
number behavior
```

Do not allow endpoint-specific inconsistent JSON formats.

---

# 55. Enums

Use strongly typed enums for constrained values.

Avoid:

```csharp
string Status
```

when the set of values is fixed.

Enum behavior exposed through APIs must be stable and documented.

---

# 56. Value Objects

Use value objects for domain concepts that carry rules.

Examples:

```text
EmailAddress
Money
Percentage
DateRange
Identifier
```

Do not turn every primitive into a class.

Use value objects where they reduce ambiguity or enforce invariants.

---

# 57. SOLID

Apply SOLID pragmatically.

## Single Responsibility

Separate responsibilities that change independently.

## Open/Closed

Prefer extension through abstractions where justified.

## Liskov Substitution

Implementations must preserve interface expectations.

## Interface Segregation

Prefer focused interfaces.

## Dependency Inversion

Business/application logic should depend on abstractions rather than concrete infrastructure.

Do not use SOLID as an excuse for unnecessary abstraction.

---

# 58. DRY

DRY means:

```text
Do not duplicate business knowledge.
```

It does NOT mean:

```text
never repeat two similar lines.
```

Duplicate syntax may be acceptable.

Duplicated business rules are dangerous.

Example:

```text
User cannot approve their own request.
```

This rule should have one authoritative backend implementation.

---

# 59. Avoid Overengineering

Do not create:

```text
GenericManagerFactory
UniversalServiceBase
RepositoryFactoryProvider
AbstractBaseControllerFactory
```

without a real requirement.

Prefer:

```text
clear
boring
explicit
testable
maintainable
```

code.

---

# 60. Middleware

Use middleware for cross-cutting HTTP behavior.

Possible middleware concerns:

```text
correlation ID
exception handling
request logging
security headers
authentication
authorization
rate limiting
```

Middleware ordering is significant.

Do not change ordering casually.

---

# 61. Authorization Rules

Authorization should never depend on client-side behavior.

All sensitive resource access must be verified server-side.

Consider:

```text
authenticated identity
permission
resource ownership
tenant/org boundary if applicable
record state
```

---

# 62. Security Headers

Use appropriate headers where relevant:

```text
Strict-Transport-Security
X-Content-Type-Options
Content-Security-Policy where applicable
Referrer-Policy
Permissions-Policy
```

Do not blindly copy header configurations without understanding deployment.

---

# 63. CORS

CORS must be explicit.

Never configure:

```text
AllowAnyOrigin
AllowAnyHeader
AllowAnyMethod
```

for production without a documented reason.

Use known origins where applicable.

---

# 64. HTTPS

Production APIs must use HTTPS.

Never transmit:

```text
credentials
tokens
sensitive data
```

over plaintext HTTP.

---

# 65. JWT

If JWT bearer authentication is used:

```text
validate issuer
validate audience
validate signature
validate expiration
use short-lived access tokens
protect signing keys
```

Do not store sensitive information unnecessarily inside tokens.

Do not write custom JWT implementations.

---

# 66. Input Validation

Treat all external data as untrusted:

```text
HTTP body
route parameter
query parameter
header
file upload
database import
webhook
external API response
```

Validate at boundaries.

---

# 67. SQL Injection

EF Core parameterization should be preferred.

If raw SQL is introduced:

```text
parameterize everything
```

Never concatenate user input into SQL.

Raw SQL requires review.

---

# 68. File Uploads

If file uploads exist:

```text
validate size
validate content type
generate server-side filename
prevent path traversal
store outside executable path
scan if required
authorize downloads
```

Never trust the original filename.

---

# 69. External HTTP Calls

Use `HttpClientFactory`.

Do not repeatedly create raw `HttpClient` instances.

External calls should consider:

```text
timeout
cancellation
retry
circuit behavior
authentication
logging
PII leakage
```

Retries must be bounded.

Never blindly retry non-idempotent operations.

---

# 70. Resilience

External failures are normal.

Design for:

```text
timeout
network failure
database transient failure
service unavailable
duplicate processing
partial failure
```

Do not catch exceptions and silently continue.

---

# 71. Testing Layers

The project must maintain multiple levels of tests.

```text
Unit Tests
Integration Tests
API Tests
Architecture Tests
Security Tests
```

Use E2E tests only where they provide value.

---

# 72. Unit Tests

Unit tests should focus on:

```text
business rules
domain behavior
application services
validators
pure transformations
```

Do not heavily mock trivial code.

---

# 73. Integration Tests

Integration tests should cover:

```text
API endpoints
authentication
authorization
MariaDB persistence
EF mappings
transactions
serialization
validation
ProblemDetails
```

Prefer realistic infrastructure where practical.

---

# 74. Testcontainers

Use Testcontainers where useful for integration testing.

A real MariaDB container is preferable to pretending another database behaves exactly like MariaDB.

Do not run product integration tests against PostgreSQL or SQLite and call that equivalent coverage.

Avoid relying solely on EF's in-memory provider for persistence tests.

---

# 75. API Testing with Bruno

Bruno collections should be version-controlled.

Recommended structure:

```text
bruno/
├── environments/
├── auth/
├── users/
├── reports/
└── health/
```

Use assertions for:

```text
status code
response shape
headers
pagination
authentication
authorization
validation
error contracts
```

Bruno supplements automated tests.

It does not replace backend unit/integration tests.

---

# 76. OpenAPI Contract Testing

CI should verify the OpenAPI document.

At minimum detect:

```text
invalid spec
missing operationId
missing tags
missing summary
missing response schema
missing security declarations
```

Consider OpenAPI linting.

---

# 77. Breaking API Changes

Breaking API changes must be identified during CI or review.

Examples:

```text
endpoint removed
property removed
type changed
required property introduced
enum value behavior changed
status response changed
```

Do not silently break consumers.

---

# 78. API Documentation

Provide an interactive OpenAPI UI.

Scalar or another approved OpenAPI viewer may be used.

The OpenAPI document is the authoritative REST contract.

---

# 79. Code Documentation

Use Markdown for architecture and engineering documentation.

Recommended:

```text
docs/
├── architecture.md
├── api-conventions.md
├── authentication.md
├── authorization.md
├── database.md
├── background-jobs.md
├── logging.md
├── testing.md
├── local-development.md
└── deployment.md
```

Use DocFX only if generated code/API documentation is valuable.

---

# 80. Developer Toolchain

The project must be IDE-independent.

Supported IDEs:

```text
Visual Studio
JetBrains Rider
Cursor / VS Code
```

**Windows is the default development OS.** Document PowerShell first. Keep equivalent bash for Linux developers. `make` is optional and must not be required on Windows.

Critical workflows must work through:

```text
dotnet restore
dotnet build
dotnet test
dotnet run
dotnet watch
pnpm install / pnpm run dev / pnpm run build
```

No required workflow may depend solely on clicking an IDE menu.

---

# 81. Windows (default) and Linux

Windows is the **default** development OS. Linux must also work.

Document commands in this order:

```text
1. Windows PowerShell (default)
2. Linux / Git Bash
```

Do not require `make` on Windows. Do not use Windows-only APIs (Registry, COM, IIS-only behavior) in application code. Paths in code must stay platform-neutral (`Path.Combine`). Helper scripts may be PowerShell-first with a bash twin when Linux developers need them.

Use platform-neutral approaches.

---

# 82. .NET SDK Version

Janatics India licenses **.NET 10**. `global.json` pins the 10.0 SDK (`rollForward: latestFeature`).

Do not mix `net8.0` and `net10.0` across API, tests, mocks, IIS hosting bundle, and Docker images. See [docs/migrate-net10.md](docs/migrate-net10.md).

---

# 83. Central Package Management

Use:

```text
Directory.Packages.props
```

where practical.

Package versions should be centrally controlled.

Avoid projects silently using different versions of:

```text
EF Core
MariaDB provider
OpenTelemetry
test framework
logging packages
```

---

# 84. Build Configuration

Use:

```text
Directory.Build.props
```

for common build settings where appropriate.

Potential shared rules:

```text
nullable
warnings
analyzers
language version
documentation behavior
```

---

# 85. EditorConfig

Commit:

```text
.editorconfig
```

Formatting/style rules belong to the repository.

Do not depend on individual Rider/Visual Studio preferences.

---

# 86. Formatting

Use:

```bash
dotnet format
```

or equivalent approved tooling.

CI should detect formatting violations where practical.

Formatting should never become a subjective PR argument.

---

# 87. Warnings

Warnings should be treated seriously.

Consider:

```xml
<TreatWarningsAsErrors>true</TreatWarningsAsErrors>
```

for project code where feasible.

Generated code may require targeted exceptions.

Do not suppress warnings without documented reasoning.

---

# 88. Static Analysis

Use compiler analyzers and additional static analysis as justified.

Possible tooling:

```text
Roslyn analyzers
SonarQube/SonarCloud
Semgrep
security analyzers
```

Avoid installing dozens of overlapping analyzers without governance.

---

# 89. Dependency Security

CI must check vulnerable dependencies.

Package upgrades should be deliberate.

Do not blindly auto-upgrade major versions.

Use automated tooling such as:

```text
Dependabot
Renovate
approved enterprise equivalent
```

where appropriate.

---

# 90. Container Security

If Docker is used:

```text
use minimal base images
run as non-root where possible
pin important image versions
scan images
do not bake secrets into images
```

Use multi-stage builds.

---

# 91. Docker Development

Docker/Compose is **optional**. Local development uses `dotnet run` and `pnpm run dev`. Skip Docker when it is not installed.

Compose files remain for CI and other environments (API, MariaDB, Redis). Do not force every dependency into Docker if native development provides better DX.

---

# 92. Nginx or IIS

Application code must not depend on either.

Deployment options:

```text
Linux:
Nginx -> Kestrel

Windows:
IIS -> ASP.NET Core
```

Infrastructure choice should follow customer operational standards.

---

# 93. Kestrel

ASP.NET Core runs on Kestrel.

Reverse proxies such as Nginx or IIS sit in front where appropriate.

Do not write application logic that assumes a particular reverse proxy.

---

# 94. CI Pipeline

Minimum pipeline:

```text
restore
    |
    v
build
    |
    v
format check
    |
    v
static analysis
    |
    v
unit tests
    |
    v
integration tests
    |
    v
OpenAPI generation
    |
    v
OpenAPI lint
    |
    v
dependency vulnerability scan
    |
    v
secret scan
    |
    v
container scan if applicable
    |
    v
publish
```

---

# 95. Pull Request Requirements

Every PR should be:

```text
small enough to review
linked to requirement/bug
tested
formatted
free from secrets
free from critical analyzer issues
documented where behavior changes
```

PR descriptions should explain:

```text
what changed
why
risk
how tested
migration impact
API impact
security impact
```

---

# 96. Review Checklist

Reviewers should evaluate:

```text
correctness
security
authorization
validation
null handling
async behavior
query performance
API contract
logging
testing
architecture
maintainability
```

Do not review only style.

---

# 97. Security Review Checklist

For sensitive changes ask:

```text
Can another user access this?
Can input bypass validation?
Can this expose data?
Can this escalate privilege?
Can this create SQL injection?
Can this leak secrets?
Can this bypass authorization?
Can this be abused repeatedly?
Can this cause resource exhaustion?
```

---

# 98. Performance Checklist

Before optimizing, measure.

Consider:

```text
query count
query duration
payload size
allocations
serialization
cache hit rate
DB indexes
external latency
thread-pool starvation
```

Do not optimize based on assumptions.

---

# 99. EF Performance Escalation

If an endpoint is slow:

```text
1. measure
2. inspect generated SQL
3. inspect indexes
4. project only required columns
5. remove unnecessary tracking
6. avoid N+1
7. review pagination
8. review query shape
9. consider caching if appropriate
10. consider raw SQL/Dapper only after evidence
```

Dapper is an escape hatch, not the default.

---

# 100. AI-Assisted Development

AI-generated code must follow the same standards as human code.

AI may assist with:

```text
implementation
tests
refactoring
OpenAPI metadata
documentation
migration review
code review
```

AI must not bypass engineering controls.

---

# 101. AI Rules

Before generating code, AI should:

```text
inspect existing architecture
inspect similar implementations
reuse established patterns
check DTOs
check policies
check database entities
check validation strategy
check tests
```

AI must not:

```text
invent database columns
invent permissions
disable auth
remove validation
ignore cancellation
add random packages
switch architecture
introduce raw SQL casually
hard-code secrets
```

---

# 102. AGENTS Mental Checklist

Before completing any backend change, verify:

## Architecture

```text
Is this the correct layer?
Am I bypassing Application?
Am I leaking Infrastructure upward?
Does an equivalent abstraction already exist?
```

## API

```text
Does the endpoint have a tag?
Does it have a stable operationId?
Does it have a summary?
Is the request typed?
Is the response typed?
Are errors documented?
```

## Validation

```text
Is all external input validated?
Are bounds defined?
Are enums constrained?
```

## Authorization

```text
Is authentication required?
Is the correct policy applied?
Is resource ownership checked?
```

## Database

```text
Is EF Core used correctly?
Could this create N+1?
Is pagination required?
Is projection possible?
Are indexes appropriate?
```

## Async

```text
Is I/O asynchronous?
Is CancellationToken propagated?
Am I blocking anywhere?
```

## Security

```text
Could this leak secrets?
Could this create injection?
Could this expose another user's data?
Could this permit privilege escalation?
Are public auth endpoints rate limited?
```

## Reliability

```text
What happens on timeout?
What happens on duplicate request?
What happens on retry?
Could this partially complete?
```

## Logging

```text
Is failure observable?
Is structured context present?
Am I logging sensitive data?
```

## Testing

```text
Is success tested?
Is validation failure tested?
Is authorization failure tested?
Is database behavior tested?
Is regression covered?
```

---

# 103. Definition of Done

A backend feature is not complete only because the endpoint works.

Applicable checklist:

```text
[ ] architecture respected
[ ] endpoint route follows convention
[ ] OpenAPI tag added
[ ] stable operationId added
[ ] summary added
[ ] typed request DTO added
[ ] typed response DTO added
[ ] error responses documented
[ ] request validation added
[ ] business validation added
[ ] authentication reviewed
[ ] authorization policy reviewed
[ ] EF Core query reviewed
[ ] pagination considered
[ ] indexes considered
[ ] async used correctly
[ ] CancellationToken propagated
[ ] logging added where meaningful
[ ] sensitive logging checked
[ ] exception behavior standardized
[ ] unit tests added
[ ] integration tests added
[ ] Bruno scenario updated where relevant
[ ] OpenAPI generated successfully
[ ] OpenAPI lint passes
[ ] static analysis passes
[ ] dependency/security scans pass
[ ] documentation updated
```

---

# 104. Engineering Philosophy

Prefer:

```text
explicit over magical
typed over dynamic
measured over assumed
secure over convenient
simple over clever
consistent over personal preference
automated enforcement over memory
```

Use the C# compiler, type system, nullable analysis, analyzers, tests and CI as active engineering controls.

The goal is not merely:

```text
"code that works"
```

The goal is:

```text
code that is difficult to misuse,
easy to review,
predictable to operate,
safe to change,
and robust under failure.
```

---

# 105. Final Project Rules

The following rules are considered baseline unless explicitly overridden by architecture review:

```text
C# only for backend production code.

.NET 10 LTS is the licensed runtime (`net10.0`).

ASP.NET Core Web API.

Controller-based REST APIs.

OpenAPI is a first-class deliverable.

Every API has typed request and response contracts.

Every API has stable operationId, tag and summary.

ProblemDetails is the standard error model.

EF Core is the default persistence mechanism.

PostgreSQL is the current database.

Raw SQL/Dapper require justification.

Nullable reference types are enabled.

Async I/O is mandatory.

CancellationToken is propagated.

Controllers contain no business logic.

Authorization is policy-based.

Secrets never enter source control.

Structured logging is mandatory.

OpenTelemetry is enabled for observability.

Bruno is used for API acceptance/smoke tests.

xUnit is used for backend testing.

Integration tests use realistic infrastructure.

Docker is optional and is not required for local development.

Windows is the default development OS. Linux is also supported. Docs are PowerShell-first.

The project must build from dotnet CLI.

IDE choice must not affect build correctness.

CI enforces formatting, tests, OpenAPI quality and security checks.

AI-generated code follows exactly the same rules as human-generated code.
```
