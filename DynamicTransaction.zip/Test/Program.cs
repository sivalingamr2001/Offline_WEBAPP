﻿using DynamicTransaction.Interfaces;
using Microsoft.Extensions.DependencyInjection;

// 1. Define your exact Oracle connection string
string connectionString = "Data source=(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.30.50.81)(PORT = 1522))(CONNECT_DATA =(SID = prod)));User ID=jan_it;Password=Ka7rv#;";

// 2. Set up Dependency Injection
var services = new ServiceCollection();

// Register the connection factory with your connection string
services.AddSingleton<IDbConnectionFactory>(new OracleDbConnectionFactory(connectionString));

// Use your library extension method to register the query executor infrastructure
services.AddDynamicQueryInfrastructure<OracleDbConnectionFactory>();

var provider = services.BuildServiceProvider();

// 3. Resolve the DynamicQueryExecutor from the container
var executor = provider.GetRequiredService<IDynamicQueryExecutor>();

Console.WriteLine("Executing SELECT query through DynamicTransaction DLL...");

try
{
    // 4. Run your SELECT query using Dapper's async model
    // For a simple demo, we query dual. You can replace this with your actual tables (e.g., SELECT * FROM USERS)
    string sqlQuery = "SELECT 'Connection Active!' AS status, TO_CHAR(SYSDATE, 'YYYY-MM-DD') AS current_date FROM DUAL";

    IEnumerable<DatabaseResult> results = await executor.QueryAsync<DatabaseResult>(sqlQuery);

    // 5. Print out the retrieved dataset
    Console.ForegroundColor = ConsoleColor.Green;
    foreach (var row in results)
    {
        Console.WriteLine($"[SUCCESS] Status: {row.Status} | System Date: {row.Current_Date}");
    }
    Console.ResetColor();
}
catch (Exception ex)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine($"Execution Failed: {ex.Message}");
    if (ex.InnerException != null)
    {
        Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
    }
    Console.ResetColor();
}

Console.WriteLine("\nPress any key to exit...");
Console.ReadKey();

// Simple strongly-typed C# record class to cleanly map your SQL query results
public record DatabaseResult(string Status, string Current_Date);
