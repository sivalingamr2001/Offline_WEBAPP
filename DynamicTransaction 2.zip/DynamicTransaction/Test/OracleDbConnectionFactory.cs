using System;
using DynamicTransaction.Interfaces;
using DynamicTransaction.Services;
using Oracle.ManagedDataAccess.Client;

namespace DynamicTransaction;

/// <summary>
/// Factory implementation for Oracle Database connections.
/// </summary>
public sealed class OracleDbConnectionFactory : IDbConnectionFactory
{
    private readonly string _defaultConnectionString;

    /// <summary>
    /// Initializes a new instance of <see cref="OracleDbConnectionFactory"/> with the default connection string.
    /// </summary>
    /// <param name="connectionString">Default Oracle connection string.</param>
    public OracleDbConnectionFactory(string connectionString)
    {
        _defaultConnectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
    }

    /// <inheritdoc/>
    public IAsyncDbConnectionWrapper CreateConnection(string? connectionStringOverride = null)
    {
        var connStr = connectionStringOverride ?? _defaultConnectionString;
        var connection = new OracleConnection(connStr);
        return new DbConnectionWrapper(connection);
    }
}
