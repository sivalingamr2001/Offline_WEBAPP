using Dapper;
using DynamicTransaction.Interfaces;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace DynamicTransaction.Services;

/// <summary>
/// Production-ready, thread-safe implementation of <see cref="IDynamicQueryExecutor"/>.
/// Each public method opens a short-lived connection (or reuses a transactional one),
/// delegates to Dapper, and logs every call with its elapsed time.
/// </summary>
/// <remarks>
/// Initializes a new instance of <see cref="DynamicQueryExecutor"/>.
/// </remarks>
/// <param name="factory">Factory used to resolve database connections.</param>
/// <param name="logger">Logger for query diagnostics.</param>
public sealed class DynamicQueryExecutor(IDbConnectionFactory factory, ILogger<DynamicQueryExecutor> logger) : IDynamicQueryExecutor
{
    private readonly IDbConnectionFactory _factory = factory ?? throw new ArgumentNullException(nameof(factory));
    private readonly ILogger<DynamicQueryExecutor> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    /// <inheritdoc/>
    public async Task<IEnumerable<T>> QueryAsync<T>(
        string sql,
        object? parameters = null,
        IDbTransaction? transaction = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sql);

        _logger.LogDebug("QueryAsync<{Type}> START  SQL: {Sql}", typeof(T).Name, sql);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            // Reuse the transactional connection if one is supplied.
            if (transaction is not null)
            {
                var cmd = BuildCommand(sql, parameters, transaction, cancellationToken);
                var result = await transaction.Connection!
                    .QueryAsync<T>(cmd).ConfigureAwait(false);

                LogSuccess(sw, typeof(T).Name, nameof(QueryAsync));
                return result;
            }

            await using var connWrapper = await OpenAsync(connectionString, cancellationToken)
                .ConfigureAwait(false);

            var command = BuildCommand(sql, parameters, null, cancellationToken);
            var rows = await connWrapper.Connection.QueryAsync<T>(command).ConfigureAwait(false);

            LogSuccess(sw, typeof(T).Name, nameof(QueryAsync));
            return rows;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "QueryAsync<{Type}> FAILED  SQL: {Sql}", typeof(T).Name, sql);
            throw;
        }
    }

    /// <inheritdoc/>
    public async Task<T?> QueryFirstOrDefaultAsync<T>(
        string sql,
        object? parameters = null,
        IDbTransaction? transaction = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sql);

        _logger.LogDebug("QueryFirstOrDefaultAsync<{Type}> START  SQL: {Sql}", typeof(T).Name, sql);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            if (transaction is not null)
            {
                var cmd = BuildCommand(sql, parameters, transaction, cancellationToken);
                var result = await transaction.Connection!
                    .QueryFirstOrDefaultAsync<T>(cmd).ConfigureAwait(false);

                LogSuccess(sw, typeof(T).Name, nameof(QueryFirstOrDefaultAsync));
                return result;
            }

            await using var connWrapper = await OpenAsync(connectionString, cancellationToken)
                .ConfigureAwait(false);

            var command = BuildCommand(sql, parameters, null, cancellationToken);
            var row = await connWrapper.Connection.QueryFirstOrDefaultAsync<T>(command).ConfigureAwait(false);

            LogSuccess(sw, typeof(T).Name, nameof(QueryFirstOrDefaultAsync));
            return row;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "QueryFirstOrDefaultAsync<{Type}> FAILED  SQL: {Sql}",
                typeof(T).Name, sql);
            throw;
        }
    }


    /// <inheritdoc/>
    public async Task<T?> QuerySingleOrDefaultAsync<T>(
        string sql,
        object? parameters = null,
        IDbTransaction? transaction = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sql);

        _logger.LogDebug("QuerySingleOrDefaultAsync<{Type}> START  SQL: {Sql}", typeof(T).Name, sql);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            if (transaction is not null)
            {
                var cmd = BuildCommand(sql, parameters, transaction, cancellationToken);
                var result = await transaction.Connection!
                    .QuerySingleOrDefaultAsync<T>(cmd).ConfigureAwait(false);

                LogSuccess(sw, typeof(T).Name, nameof(QuerySingleOrDefaultAsync));
                return result;
            }

            await using var connWrapper = await OpenAsync(connectionString, cancellationToken)
                .ConfigureAwait(false);

            var command = BuildCommand(sql, parameters, null, cancellationToken);
            var row = await connWrapper.Connection.QuerySingleOrDefaultAsync<T>(command).ConfigureAwait(false);

            LogSuccess(sw, typeof(T).Name, nameof(QuerySingleOrDefaultAsync));
            return row;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "QuerySingleOrDefaultAsync<{Type}> FAILED  SQL: {Sql}",
                typeof(T).Name, sql);
            throw;
        }
    }

    /// <inheritdoc/>
    public async Task<int> ExecuteAsync(
        string sql,
        object? parameters = null,
        IDbTransaction? transaction = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sql);

        _logger.LogDebug("ExecuteAsync START  SQL: {Sql}", sql);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            if (transaction is not null)
            {
                var cmd = BuildCommand(sql, parameters, transaction, cancellationToken);
                var result = await transaction.Connection!
                    .ExecuteAsync(cmd).ConfigureAwait(false);

                LogSuccess(sw, null, nameof(ExecuteAsync), result);
                return result;
            }

            await using var connWrapper = await OpenAsync(connectionString, cancellationToken)
                .ConfigureAwait(false);

            var command = BuildCommand(sql, parameters, null, cancellationToken);
            var affected = await connWrapper.Connection.ExecuteAsync(command).ConfigureAwait(false);

            LogSuccess(sw, null, nameof(ExecuteAsync), affected);
            return affected;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ExecuteAsync FAILED  SQL: {Sql}", sql);
            throw;
        }
    }

    /// <inheritdoc/>
    public async Task<T?> ExecuteScalarAsync<T>(
        string sql,
        object? parameters = null,
        IDbTransaction? transaction = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sql);

        _logger.LogDebug("ExecuteScalarAsync<{Type}> START  SQL: {Sql}", typeof(T).Name, sql);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            if (transaction is not null)
            {
                var cmd = BuildCommand(sql, parameters, transaction, cancellationToken);
                var result = await transaction.Connection!
                    .ExecuteScalarAsync<T>(cmd).ConfigureAwait(false);

                LogSuccess(sw, typeof(T).Name, nameof(ExecuteScalarAsync));
                return result;
            }

            await using var connWrapper = await OpenAsync(connectionString, cancellationToken)
                .ConfigureAwait(false);

            var command = BuildCommand(sql, parameters, null, cancellationToken);
            var scalar = await connWrapper.Connection.ExecuteScalarAsync<T>(command).ConfigureAwait(false);

            LogSuccess(sw, typeof(T).Name, nameof(ExecuteScalarAsync));
            return scalar;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ExecuteScalarAsync<{Type}> FAILED  SQL: {Sql}", typeof(T).Name, sql);
            throw;
        }
    }

    /// <inheritdoc/>
    public async Task<(IEnumerable<T> Data, int TotalCount)> QueryPagedAsync<T>(
        string dataSql,
        string countSql,
        object? parameters = null,
        IDbTransaction? transaction = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(dataSql);
        ArgumentException.ThrowIfNullOrWhiteSpace(countSql);

        _logger.LogDebug("QueryPagedAsync<{Type}> START  DataSQL: {DataSql}  CountSQL: {CountSql}",
            typeof(T).Name, dataSql, countSql);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        IAsyncDbConnectionWrapper? connWrapper = null;
        try
        {
            IDbConnection conn;
            bool owned = transaction is null;

            if (owned)
            {
                connWrapper = await OpenAsync(connectionString, cancellationToken).ConfigureAwait(false);
                conn = connWrapper.Connection;
            }
            else
            {
                conn = transaction!.Connection!;
            }

            try
            {
                var dataCmd = BuildCommand(dataSql, parameters, transaction, cancellationToken);
                var countCmd = BuildCommand(countSql, parameters, transaction, cancellationToken);

                var data = await conn.QueryAsync<T>(dataCmd).ConfigureAwait(false);
                var dataList = data as IReadOnlyCollection<T> ?? data.ToList();
                var total = await conn.QuerySingleOrDefaultAsync<int>(countCmd).ConfigureAwait(false);

                _logger.LogInformation(
                    "QueryPagedAsync<{Type}> OK  rows={Rows}  total={Total}  {Elapsed}ms",
                    typeof(T).Name, dataList.Count, total, sw.ElapsedMilliseconds);

                return (dataList, total);
            }
            finally
            {
                if (owned && connWrapper is not null)
                    await connWrapper.DisposeAsync().ConfigureAwait(false);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "QueryPagedAsync<{Type}> FAILED  DataSQL: {Sql}",
                typeof(T).Name, dataSql);
            throw;
        }
    }

    /// <inheritdoc/>
    public async Task<int> ExecuteInTransactionAsync(
        Func<IDbTransaction, Task<int>> work,
        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(work);

        _logger.LogDebug("ExecuteInTransactionAsync START  IsolationLevel: {Level}", isolationLevel);
        var sw = System.Diagnostics.Stopwatch.StartNew();

        await using var connWrapper = await OpenAsync(connectionString, cancellationToken)
            .ConfigureAwait(false);

        IDbTransaction tx;
        System.Data.Common.DbTransaction? dbTx = null;

        if (connWrapper.Connection is System.Data.Common.DbConnection dbConn)
        {
            dbTx = await dbConn.BeginTransactionAsync(isolationLevel, cancellationToken).ConfigureAwait(false);
            tx = dbTx;
        }
        else
        {
            tx = connWrapper.Connection.BeginTransaction(isolationLevel);
        }

        try
        {
            var affectedRows = await work(tx).ConfigureAwait(false);
            
            if (dbTx is not null)
            {
                await dbTx.CommitAsync(cancellationToken).ConfigureAwait(false);
            }
            else
            {
                tx.Commit();
            }

            _logger.LogInformation("ExecuteInTransactionAsync COMMITTED  {Elapsed}ms",
                sw.ElapsedMilliseconds);
            return affectedRows;
        }
        catch (Exception ex)
        {
            try
            {
                if (dbTx is not null)
                {
                    await dbTx.RollbackAsync(cancellationToken).ConfigureAwait(false);
                }
                else
                {
                    tx.Rollback();
                }
            }
            catch (Exception rollbackEx)
            {
                _logger.LogError(rollbackEx, "Failed to rollback transaction");
            }

            _logger.LogError(ex, "ExecuteInTransactionAsync ROLLED BACK  {Elapsed}ms",
                sw.ElapsedMilliseconds);
            throw;
        }
        finally
        {
            if (dbTx is not null)
            {
                await dbTx.DisposeAsync().ConfigureAwait(false);
            }
            else
            {
                tx.Dispose();
            }
        }
    }

    /// <inheritdoc/>
    public async Task<int> ExecutePayloadTransactionAsync(
        string jsonPayload,
        string primaryKeyColumn = "Id",
        string? childTableName = null,
        string? childForeignKeyColumn = null,
        string? connectionString = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(jsonPayload);

        return await ExecuteInTransactionAsync(async tx =>
        {
            var conn = tx.Connection!;
            var prefix = GetParamPrefix(conn);
            var isOracle = conn.GetType().FullName?.Contains("Oracle", StringComparison.OrdinalIgnoreCase) ?? false;
            var isSqlServer = conn.GetType().FullName?.Contains("SqlConnection", StringComparison.OrdinalIgnoreCase) ?? false;
            var isPostgres = conn.GetType().FullName?.Contains("Npgsql", StringComparison.OrdinalIgnoreCase) ?? false;

            // Parse JSON payload
            var root = JsonNode.Parse(jsonPayload);
            if (root is null)
                throw new ArgumentException("Invalid JSON payload.");

            var transactionId = root["transactionId"]?.ToString();
            var transactionEntity = root["transactionEntity"]?.ToString();

            if (string.IsNullOrWhiteSpace(transactionEntity))
                throw new ArgumentException("The 'transactionEntity' parameter is required in the payload.");

            int totalRowsAffected = 0;

            // 1. Process deletes (delProps)
            var delPropsNode = root["delProps"]?.AsObject();
            if (delPropsNode is not null && delPropsNode.Count > 0)
            {
                var deleteTargetTable = childTableName ?? $"{transactionEntity}_CHILD";
                var deleteConditions = new List<string>();
                var deleteParams = new DynamicParameters();
                foreach (var prop in delPropsNode)
                {
                    var col = prop.Key;
                    var val = GetJsonNodeValue(prop.Value);
                    var paramName = $"del_{col}";
                    deleteConditions.Add($"{col} = {prefix}{paramName}");
                    deleteParams.Add(paramName, val);
                }

                var deleteSql = $"DELETE FROM {deleteTargetTable} WHERE {string.Join(" AND ", deleteConditions)}";
                _logger.LogDebug("Executing dynamic DELETE: {Sql}", deleteSql);
                totalRowsAffected += await conn.ExecuteAsync(new CommandDefinition(deleteSql, deleteParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
            }

            // 2. Process mainProps (INSERT or UPDATE)
            var mainPropsNode = root["mainProps"]?.AsObject();
            object? parentIdValue = null;

            if (mainPropsNode is not null && mainPropsNode.Count > 0)
            {
                if (!string.IsNullOrWhiteSpace(transactionId))
                {
                    // Perform UPDATE
                    var updateSets = new List<string>();
                    var updateParams = new DynamicParameters();
                    foreach (var prop in mainPropsNode)
                    {
                        var col = prop.Key;
                        if (string.Equals(col, primaryKeyColumn, StringComparison.OrdinalIgnoreCase))
                            continue; // Skip the PK in SET

                        var val = GetJsonNodeValue(prop.Value);
                        updateSets.Add($"{col} = {prefix}{col}");
                        updateParams.Add(col, val);
                    }
                    updateParams.Add("pkVal", transactionId);

                    var updateSql = $"UPDATE {transactionEntity} SET {string.Join(", ", updateSets)} WHERE {primaryKeyColumn} = {prefix}pkVal";
                    _logger.LogDebug("Executing dynamic UPDATE: {Sql}", updateSql);
                    totalRowsAffected += await conn.ExecuteAsync(new CommandDefinition(updateSql, updateParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                    parentIdValue = transactionId;
                }
                else
                {
                    // Perform INSERT
                    var mainCols = new List<string>();
                    var mainParamNames = new List<string>();
                    var mainParams = new DynamicParameters();
                    foreach (var prop in mainPropsNode)
                    {
                        var col = prop.Key;
                        var val = GetJsonNodeValue(prop.Value);
                        mainCols.Add(col);
                        mainParamNames.Add($"{prefix}{col}");
                        mainParams.Add(col, val);
                    }

                    // Check if primary key is already in mainProps
                    object? explicitPkVal = null;
                    foreach (var prop in mainPropsNode)
                    {
                        if (string.Equals(prop.Key, primaryKeyColumn, StringComparison.OrdinalIgnoreCase))
                        {
                            explicitPkVal = GetJsonNodeValue(prop.Value);
                            break;
                        }
                    }

                    if (explicitPkVal is not null)
                    {
                        var insertSql = $"INSERT INTO {transactionEntity} ({string.Join(", ", mainCols)}) VALUES ({string.Join(", ", mainParamNames)})";
                        _logger.LogDebug("Executing dynamic INSERT (explicit PK): {Sql}", insertSql);
                        totalRowsAffected += await conn.ExecuteAsync(new CommandDefinition(insertSql, mainParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                        parentIdValue = explicitPkVal;
                    }
                    else
                    {
                        // Identity generation
                        if (isOracle)
                        {
                            var insertSql = $"INSERT INTO {transactionEntity} ({string.Join(", ", mainCols)}) VALUES ({string.Join(", ", mainParamNames)}) RETURNING {primaryKeyColumn} INTO {prefix}out_id";
                            mainParams.Add("out_id", dbType: DbType.Int64, direction: ParameterDirection.Output);
                            _logger.LogDebug("Executing dynamic Oracle INSERT with RETURNING: {Sql}", insertSql);
                            totalRowsAffected += await conn.ExecuteAsync(new CommandDefinition(insertSql, mainParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                            parentIdValue = mainParams.Get<long>("out_id");
                        }
                        else if (isSqlServer)
                        {
                            var insertSql = $"INSERT INTO {transactionEntity} ({string.Join(", ", mainCols)}) VALUES ({string.Join(", ", mainParamNames)}); SELECT SCOPE_IDENTITY();";
                            _logger.LogDebug("Executing dynamic SQL Server INSERT with SCOPE_IDENTITY: {Sql}", insertSql);
                            parentIdValue = await conn.ExecuteScalarAsync<object>(new CommandDefinition(insertSql, mainParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                            totalRowsAffected += 1;
                        }
                        else if (isPostgres)
                        {
                            var insertSql = $"INSERT INTO {transactionEntity} ({string.Join(", ", mainCols)}) VALUES ({string.Join(", ", mainParamNames)}) RETURNING {primaryKeyColumn}";
                            _logger.LogDebug("Executing dynamic Postgres INSERT with RETURNING: {Sql}", insertSql);
                            parentIdValue = await conn.ExecuteScalarAsync<object>(new CommandDefinition(insertSql, mainParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                            totalRowsAffected += 1;
                        }
                        else
                        {
                            // Generic fallback (e.g. MySQL)
                            var insertSql = $"INSERT INTO {transactionEntity} ({string.Join(", ", mainCols)}) VALUES ({string.Join(", ", mainParamNames)})";
                            _logger.LogDebug("Executing dynamic INSERT: {Sql}", insertSql);
                            await conn.ExecuteAsync(new CommandDefinition(insertSql, mainParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                            
                            var selectIdSql = "SELECT LAST_INSERT_ID();";
                            parentIdValue = await conn.ExecuteScalarAsync<object>(new CommandDefinition(selectIdSql, transaction: tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
                            totalRowsAffected += 1;
                        }
                    }
                }
            }

            // 3. Process childProps (INSERT)
            var childPropsNode = root["childProps"]?.AsObject();
            if (childPropsNode is not null && childPropsNode.Count > 0)
            {
                var childTargetTable = childTableName ?? $"{transactionEntity}_CHILD";
                var childFkCol = childForeignKeyColumn ?? $"{transactionEntity}_ID";

                var childCols = new List<string> { childFkCol };
                var childParamNames = new List<string> { $"{prefix}{childFkCol}" };
                var childParams = new DynamicParameters();
                childParams.Add(childFkCol, parentIdValue);

                foreach (var prop in childPropsNode)
                {
                    var col = prop.Key;
                    if (string.Equals(col, childFkCol, StringComparison.OrdinalIgnoreCase))
                        continue; // Skip the foreign key if it's already defined

                    var val = GetJsonNodeValue(prop.Value);
                    childCols.Add(col);
                    childParamNames.Add($"{prefix}{col}");
                    childParams.Add(col, val);
                }

                var childSql = $"INSERT INTO {childTargetTable} ({string.Join(", ", childCols)}) VALUES ({string.Join(", ", childParamNames)})";
                _logger.LogDebug("Executing dynamic child INSERT: {Sql}", childSql);
                totalRowsAffected += await conn.ExecuteAsync(new CommandDefinition(childSql, childParams, tx, cancellationToken: cancellationToken)).ConfigureAwait(false);
            }

            return totalRowsAffected;
        }, connectionString: connectionString, cancellationToken: cancellationToken);
    }

    private static object? GetJsonNodeValue(JsonNode? node)
    {
        if (node is null) return null;
        if (node is JsonValue value)
        {
            if (value.TryGetValue<string>(out var s)) return s;
            if (value.TryGetValue<long>(out var l)) return l;
            if (value.TryGetValue<double>(out var d)) return d;
            if (value.TryGetValue<bool>(out var b)) return b;
            return value.ToString();
        }
        return node.ToString();
    }

    private static string GetParamPrefix(IDbConnection connection)
    {
        var typeName = connection.GetType().FullName ?? "";
        if (typeName.Contains("Oracle", StringComparison.OrdinalIgnoreCase))
            return ":";
        return "@";
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /// <summary>
    /// Opens a connection via the factory, using the override string when provided.
    /// Returns an <see cref="IAsyncDisposable"/> wrapper so callers can <c>await using</c> it.
    /// </summary>
    private async Task<IAsyncDbConnectionWrapper> OpenAsync(string? connectionString, CancellationToken cancellationToken)
    {
        var connectionWrapper = _factory.CreateConnection(connectionString);
        try
        {
            if (connectionWrapper.Connection.State != ConnectionState.Open)
            {
                if (connectionWrapper.Connection is System.Data.Common.DbConnection commonConn)
                {
                    await commonConn.OpenAsync(cancellationToken).ConfigureAwait(false);
                }
                else
                {
                    connectionWrapper.Connection.Open();
                }
            }
            return connectionWrapper;
        }
        catch
        {
            connectionWrapper.Dispose();
            throw;
        }
    }

    /// <summary>
    /// Builds a Dapper <see cref="CommandDefinition"/> that carries the SQL, parameters,
    /// transaction, and cancellation token.
    /// </summary>
    private static CommandDefinition BuildCommand(
        string sql,
        object? parameters,
        IDbTransaction? transaction,
        CancellationToken cancellationToken)
        => new(sql,
               parameters: parameters,
               transaction: transaction,
               cancellationToken: cancellationToken);

    private void LogSuccess(System.Diagnostics.Stopwatch sw, string? typeName,
                            string method, int? rows = null)
    {
        if (rows.HasValue)
            _logger.LogInformation("{Method} OK  rowsAffected={Rows}  {Elapsed}ms",
                method, rows.Value, sw.ElapsedMilliseconds);
        else
            _logger.LogInformation("{Method}<{Type}> OK  {Elapsed}ms",
                method, typeName, sw.ElapsedMilliseconds);
    }
}
