using System;
using System.Data;
using System.Threading.Tasks;
using DynamicTransaction.Interfaces;

namespace DynamicTransaction.Services;

/// <summary>
/// A reusable wrapper that allows any IDbConnection to support unified synchronous 
/// and asynchronous disposal.
/// </summary>
public sealed class DbConnectionWrapper : IAsyncDbConnectionWrapper
{
    /// <inheritdoc/>
    public IDbConnection Connection { get; }

    /// <summary>
    /// Initializes a new instance of the <see cref="DbConnectionWrapper"/> class.
    /// </summary>
    /// <param name="connection">The underlying ADO.NET connection to wrap.</param>
    public DbConnectionWrapper(IDbConnection connection)
    {
        Connection = connection ?? throw new ArgumentNullException(nameof(connection));
    }

    /// <inheritdoc/>
    public void Dispose()
    {
        Connection.Dispose();
    }

    /// <inheritdoc/>
    public async ValueTask DisposeAsync()
    {
        if (Connection is IAsyncDisposable asyncDisposable)
        {
            await asyncDisposable.DisposeAsync().ConfigureAwait(false);
        }
        else
        {
            Connection.Dispose();
        }
    }
}
